/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.vertigo;

import junit.framework.TestCase;

import static com.inversoft.vertigo.VertigoObject.NO_MATCH_MSG;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class VertigoObjectTest extends TestCase {

    public VertigoObjectTest(String s) {
        super(s);
    }

    public void testNoDefaultConstructor() throws VertigoException {
        VertigoObject vertigoObject = new VertigoObject<Bean3>(Bean3.class);
        assertEquals("public com.inversoft.vertigo.VertigoObjectTest$Bean3()",
                vertigoObject.getTheConstructor().toString());
    }

    public void testDefaultConstructor() throws VertigoException {
        VertigoObject vertigoObject = new VertigoObject<Bean4>(Bean4.class);
        assertEquals("public com.inversoft.vertigo.VertigoObjectTest$Bean4()",
                vertigoObject.getTheConstructor().toString());
    }

    public void testMultipleConstructorsNoParams() throws VertigoException {
        VertigoObject<Bean2> vertigoObject = new VertigoObject<Bean2>(Bean2.class);
        assertEquals("public com.inversoft.vertigo.VertigoObjectTest$Bean2()",
                vertigoObject.getTheConstructor().toString());
    }

    public void testMultipleConstructorsRightParamsDefined() throws VertigoException {
        Object[] constructorParams_1 = {new String("test1")};
        VertigoObject<Bean2> vertigoObject_1 = new VertigoObject<Bean2>(Bean2.class, constructorParams_1);
        assertEquals("public com.inversoft.vertigo.VertigoObjectTest$Bean2(java.lang.String)",
                vertigoObject_1.getTheConstructor().toString());
    }

    public void testMultipleConstructorsWrongParamsDefined() {
        try {
            Object[] constructorParams_1 = {new Integer(1)};
            new VertigoObject<Bean2>(Bean2.class, constructorParams_1);
            fail("Should have thrown exception. Wrong class type supplied as an argument");
        } catch (VertigoException ve) {
            assertEquals(NO_MATCH_MSG, ve.getMessage());
        }
    }

    public void testNoParamsNoDefaultDefined() {
        try {
            new VertigoObject<Bean6>(Bean6.class);
            fail("Should have thrown exception. No params supplied, however, no default constructor defined");
        } catch (VertigoException ve) {
            assertEquals(NO_MATCH_MSG, ve.getMessage());
        }
    }

    public void testPrimativeTypes() throws VertigoException {
        Object[] constructorParams = {new Integer(1), new Double(2.3), new Character('c')};
        VertigoObject<Bean5> vertigoObject = new VertigoObject<Bean5>(Bean5.class, constructorParams);
        assertEquals("public com.inversoft.vertigo.VertigoObjectTest$Bean5(int,double,char)",
                vertigoObject.getTheConstructor().toString());
    }

    public void testGenericBean() throws VertigoException {
        Object[] constructorParams = {new String("test1"), new Integer(1), new Double(1.1)};
        VertigoObject<Bean1> vertigoObject = new VertigoObject<Bean1>(Bean1.class, constructorParams);
        assertEquals("public com.inversoft.vertigo.VertigoObjectTest$Bean1(java.lang.String,java.lang.Integer,java.lang.Double)",
                vertigoObject.getTheConstructor().toString());
    }

    public void testArrayParameters() throws VertigoException {
        String[] stringArrayParam = {"intVar", "doubleVar", "charVar"};
        Object[] params = {stringArrayParam};
        VertigoObject<Bean7> vertigoObject = new VertigoObject<Bean7>(Bean7.class, params);
        assertEquals("public com.inversoft.vertigo.VertigoObjectTest$Bean7(java.lang.String[])",
                vertigoObject.getTheConstructor().toString());
    }

    public void testMixedParameters() throws VertigoException {
        String[] stringArrayParam = {"intVar", "doubleVar", "charVar"};
        Object[] params = {stringArrayParam, new Integer(10), new String("test string")};
        VertigoObject<Bean8> vertigoObject = new VertigoObject<Bean8>(Bean8.class, params);
        assertEquals("public com.inversoft.vertigo.VertigoObjectTest$Bean8(java.lang.String[],int,java.lang.String)",
                vertigoObject.getTheConstructor().toString());
    }

    /**
     * Bean1
     */
    public static class Bean1 <S extends String, I extends Integer, D extends Double> {
        private S testVar_1;

        private I testVar_2;

        private D testVar_3;

        public Bean1() {
            // stub
        }

        public Bean1(S testVar) {
            this.testVar_1 = testVar;
        }

        public Bean1(S testVar_1, I testVar_2) {
            this.testVar_1 = testVar_1;
            this.testVar_2 = testVar_2;
        }

        public Bean1(S testVar_1, I testVar_2, D testVar_3) {
            this.testVar_1 = testVar_1;
            this.testVar_2 = testVar_2;
            this.testVar_3 = testVar_3;
        }

        public S getTestVar_1() {
            return testVar_1;
        }

        public I getTestVar_2() {
            return testVar_2;
        }

        public D getTestVar_3() {
            return testVar_3;
        }
    }

    /**
     * Bean2
     */
    public static class Bean2 {

        private String testString_1 = "default value";

        public Bean2() {
            // stub
        }

        public Bean2(String testString_1) {
            this.testString_1 = testString_1;
        }

        public String getTestString_1() {
            return testString_1;
        }

    }

    /**
     * Bean3
     */
    public static class Bean3 {
        // stub
    }

    /**
     * Bean4
     */
    public static class Bean4 {
        public Bean4() {
            // stub
        }
    }

    /**
     * Bean5
     */
    public static class Bean5 {
        private int intVar = 0;

        private double doubleVar = 0;

        private char charVar = 'c';

        public Bean5(int var1, double var2, char var3) {
            this.intVar = var1;
            this.doubleVar = var2;
            this.charVar = var3;
        }

        public int getIntVar() {
            return intVar;
        }

        public double getDoubleVar() {
            return doubleVar;
        }

        public char getCharVar() {
            return charVar;
        }
    }

    /**
     * Bean6
     */
    public static class Bean6 {
        private String var1 = "intVar";

        public Bean6(String var1) {
            this.var1 = var1;
        }

        public String getVar1() {
            return var1;
        }
    }

    /**
     * Bean7
     */
    public static class Bean7 {
        private String[] vars = {"test1", "test2", "test3"};

        public Bean7(String[] vars) {
            this.vars = vars;
        }
    }

    public static class Bean8 {
        private String[] strings = {"test1", "test2", "test3"};

        private int number = 0;

        private String string = "string";

        public Bean8(String[] strings, int number, String string) {
            this.strings = strings;
            this.number = number;
            this.string = string;
        }

        public String[] getStrings() {
            return strings;
        }

        public int getNumber() {
            return number;
        }

        public String getString() {
            return string;
        }
    }
}
