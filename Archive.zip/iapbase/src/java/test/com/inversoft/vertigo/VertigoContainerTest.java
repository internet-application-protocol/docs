/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.vertigo;

import junit.framework.TestCase;

/**
 * //TODO test arrays
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class VertigoContainerTest extends TestCase {

    VertigoObject<VertigoObjectTest.Bean1> objectBean1;

    VertigoObject<VertigoObjectTest.Bean2> objectBean2;

    VertigoObject<VertigoObjectTest.Bean3> objectBean3;

    VertigoObject<VertigoObjectTest.Bean4> objectBean4;

    VertigoObject<VertigoObjectTest.Bean5> objectBean5_wrapperParams;

    VertigoObject<VertigoObjectTest.Bean5> objectBean5_primativeParams;

    public VertigoContainerTest(String s) {
        super(s);
        configVertigoObjects();
    }

    public void testInstantiationNoArgs() {
        new VertigoContainer();
    }

    public void testContainsFalse() {
        VertigoContainer container = new VertigoContainer();
        assertFalse(container.contains(VertigoObjectTest.Bean1.class));
    }

    public void testContainsTrue() throws VertigoException {
        VertigoContainer container = new VertigoContainer();
        container.register(objectBean1, false);
        assertTrue(container.contains(VertigoObjectTest.Bean1.class));
    }

    public void testGenericGetInstance() throws VertigoException {
        VertigoContainer container = new VertigoContainer();
        container.register(objectBean1, false);
        VertigoObjectTest.Bean1 bean1 = container.get(VertigoObjectTest.Bean1.class);
        assertNotNull(bean1);
        assertEquals("bean1 test", bean1.getTestVar_1());

    }

    public void testPrimativeBeanWithWrapperParamsGetIntstance() throws VertigoException {
        VertigoContainer container = new VertigoContainer();
        container.register(objectBean5_wrapperParams, false);
        VertigoObjectTest.Bean5 bean5 = container.get(VertigoObjectTest.Bean5.class);
        assertNotNull(bean5);
        assertEquals(1, bean5.getIntVar());
        assertEquals(1.2, bean5.getDoubleVar());
        assertEquals('c', bean5.getCharVar());
    }

    public void testPrimativeBeanWithPrimativeParamsGetIntstance() throws VertigoException {
        VertigoContainer container = new VertigoContainer();
        container.register(objectBean5_primativeParams, false);
        VertigoObjectTest.Bean5 bean5 = container.get(VertigoObjectTest.Bean5.class);
        assertNotNull(bean5);
        assertEquals(1, bean5.getIntVar());
        assertEquals(1.2, bean5.getDoubleVar());
        assertEquals('c', bean5.getCharVar());
    }

    private void configVertigoObjects() {
        try {
            objectBean1 = new VertigoObject<VertigoObjectTest.Bean1>(VertigoObjectTest.Bean1.class,
                    new String("bean1 test"));
            objectBean2 = new VertigoObject<VertigoObjectTest.Bean2>(VertigoObjectTest.Bean2.class);
            objectBean3 = new VertigoObject<VertigoObjectTest.Bean3>(VertigoObjectTest.Bean3.class);
            objectBean4 = new VertigoObject<VertigoObjectTest.Bean4>(VertigoObjectTest.Bean4.class);
            objectBean5_wrapperParams = new VertigoObject<VertigoObjectTest.Bean5>(VertigoObjectTest.Bean5.class,
                    new Integer(1), new Double(1.2), new Character('c'));
            objectBean5_primativeParams = new VertigoObject<VertigoObjectTest.Bean5>(VertigoObjectTest.Bean5.class,
                    1, 1.2, 'c');
        } catch (VertigoException ve) {
            System.out.println("VertigoObjects did not instantiate successfully.  Check the parameter list " +
                    "and/or re-run the VertigoObjectTest");
            System.out.println("Exception msg: " + ve.getMessage());
        }
    }
}
