/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;


import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * <p>
 * This is a simple HTTP compliant client test.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class TestNIOClient {

    private static final Logger logger = Logger.getLogger(TestNIOClient.class.getName());


    public static void main(String[] args) {
        try {
            logger.log(Level.FINEST, "Starting up client");

            NIOClient client = new NIOClient(200, 200);
            URL url = new URL("http://localhost:5039");
            client.execute(url, "GET / \r\n\r\n", 60000);
        } catch (IOException ioe) {
            logger.log(Level.SEVERE, "Exception", ioe);
        } catch (QueueFullException qfe) {
            logger.log(Level.SEVERE, "Exception", qfe);
        }
    }
}