/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import junit.framework.Assert;

import com.inversoft.iap.IAPConstants;

/**
 * <p>
 * This class is a test lifecycle implementation.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class TestNIOLifecycle implements NIOLifecycle {
    public boolean startedTransaction;
    public boolean startedProcessing;
    public boolean endedTransaction;

    public String startTransaction() {
        startedTransaction = true;
        return "foo";
    }

    public void startProcessing(NIOCallback callback, String transactionID, InputStream inputStream,
            OutputStream outputStream) {
        startedProcessing = true;
        System.out.println("Started processing");
        Runner runner = new Runner();
        runner.callback = callback;
        runner.inputStream = inputStream;
        runner.outputStream = outputStream;
        runner.start();
    }

    public void endTransaction(String transactionId) {
        endedTransaction = true;
    }

    public class Runner extends Thread {
        public InputStream inputStream;
        public OutputStream outputStream;
        public NIOCallback callback;

        public void run() {
            StringBuilder build = new StringBuilder();
            int i = -1;
            do {
                try {
                    i = inputStream.read();
                    System.out.println("Read [" + i + "]");
                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
                build.append((char) i);
            } while (i != IAPConstants.EOT && i != -1);

            callback.doneReading();
            System.out.println("Was [" + build.toString() + "]");
            Assert.assertTrue(i != -1);
            Assert.assertEquals("bar" + IAPConstants.EOT, build.toString());

            try {
                outputStream.write("foo".getBytes());
                callback.doneWriting();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}