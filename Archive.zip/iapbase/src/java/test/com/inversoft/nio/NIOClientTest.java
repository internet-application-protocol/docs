/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.atomic.AtomicReference;

import junit.framework.TestCase;

/**
 * <p>
 * This class is a test case for the NIOClient.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class NIOClientTest extends TestCase {
    /**
     * Constructs a new <code>NIOClientTest</code>.
     */
    public NIOClientTest(String name) {
        super(name);
    }

    /**
     * Tests a simple fetch from Yahoo.
     */
    public void testGet() throws IOException, QueueFullException {
        NIOClient client = new NIOClient(200, 10);
        String result = client.execute(new URL("http://www.yahoo.com"),
            "GET / HTTP/1.0\r\n\r\n", 1000);
        assertNotNull(result);
    }

    /**
     * Tests that the queue fills up and fails.
     */
    public void testQueueFull() throws IOException, InterruptedException {
        final NIOClient client = new NIOClient(200, 2);
        final AtomicReference<QueueFullException> pointer =
            new AtomicReference<QueueFullException>();

        for (int i = 0; i < 10; i++) {
            Runnable runner = new Runnable() {
                public void run() {
                    try {
                        client.execute(new URL("http://www.gutenberg.org"),
                            "GET /dirs/etext98/2ws1610.txt HTTP/1.0\r\n\r\n", 1000);
                    } catch (IOException ioe) {
                        fail(ioe.toString());
                    } catch (QueueFullException qfe) {
                        pointer.set(qfe);
                    }
                }
            };
            new Thread(runner).start();
        }

        // Wait for the threads to run so that one or more of them can fail.
        Thread.sleep(500);
        // todo failing
        assertNotNull(pointer.get());
    }

    /**
     * Tests a simple fetch from Yahoo that times out.
     */
    public void testTimeout() throws IOException, QueueFullException {
        NIOClient client = new NIOClient(200, 10);
        String result = client.execute(new URL("http://www.yahoo.com"),
            "GET / HTTP/1.0\r\n\r\n", 50);
        assertNull(result); // Should have timedout
    }
}