/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import java.util.logging.Level;

import junit.framework.TestCase;

import com.inversoft.iap.IAPConstants;

/**
 * <p>
 * This class tests both the NIOClient and the NIOServer.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class FullNIOTest extends TestCase {
    public static final char EOT = IAPConstants.EOT;
    private StringBuilder longInput = new StringBuilder();

    /**
     * Constructs a new <code>FullNIOTest</code>.
     */
    public FullNIOTest(String name) {
        super(name);

        for (int i = 0; i < 1200; i++) {
            longInput.append("1");
        }
    }

    /**
     * Tests a simple client server interaction.
     */
    public void testSimple() throws IOException, InterruptedException {
        Logger.getLogger("com.inversoft.nio.NIOClient").setLevel(Level.FINEST);
        System.out.println("single");

        TestNIOLifecycle lifecycle = new TestNIOLifecycle();
        NIOServer server = new NIOServer(lifecycle, 5039, 1500, 200);

        final AtomicReference<String> pointer = new AtomicReference<String>();
        Runnable runner = new Runnable() {
            public void run() {
                try {
                    NIOClient client = new NIOClient(200, 1);
                    String message = "bar" + EOT;
                    String result = client.execute(new URL("http://localhost:5039"), message, 2000);
                    pointer.set(result);
                    client.shutdown();
                } catch (IOException ioe) {
                    fail(ioe.toString());
                } catch (QueueFullException qfe) {
                    fail(qfe.toString());
                }
            }
        };

        new Thread(runner).start();
        Thread.sleep(2000);
        server.shutdown();
        server.join();

        assertTrue(lifecycle.startedTransaction);
        assertTrue(lifecycle.startedProcessing);
        assertTrue(lifecycle.endedTransaction);
        assertEquals("foo", pointer.get());
    }

    public void testSocket() throws IOException, InterruptedException {
        System.out.println("socket");

        TestNIOLifecycle lifecycle = new TestNIOLifecycle();
        NIOServer server = new NIOServer(lifecycle, 5039, 1500, 200);

        final AtomicReference<String> pointer = new AtomicReference<String>();
        Runnable runner = new Runnable() {
            InetAddress addr = InetAddress.getByName("localhost");
            Socket sc = new Socket(addr, 5039);

            public void run() {
                long start = System.currentTimeMillis();
                try {
                    Writer writer = new OutputStreamWriter(sc.getOutputStream());
                    writer.write("bar" + EOT);
                    writer.flush();
                    System.out.println("Wrote in " + (System.currentTimeMillis() - start));

                    start = System.currentTimeMillis();
                    char[] buf = new char[3];
                    Reader reader = new InputStreamReader(sc.getInputStream());
                    reader.read(buf);
                    System.out.println("Read in " + (System.currentTimeMillis() - start));
                    String result = new String(buf);
                    pointer.set(result);
                    writer.close();
                    reader.close();
                } catch (IOException ioe) {
                    fail(ioe.toString());
                }
            }
        };

        new Thread(runner).start();
        Thread.sleep(2000);
        server.shutdown();
        server.join();

        assertTrue(lifecycle.startedTransaction);
        assertTrue(lifecycle.startedProcessing);
        assertTrue(lifecycle.endedTransaction);
        assertEquals("foo", pointer.get());
    }

    public void testSocketMultiple() throws IOException, InterruptedException {
//        Logger.getLogger("com.inversoft.nio").setLevel(Level.FINEST);
        System.out.println("multiple");

        TestNIOLifecycle lifecycle = new TestNIOLifecycle();
        NIOServer server = new NIOServer(lifecycle, 5039, 1500, 200);

        final AtomicReference<String[]> pointer = new AtomicReference<String[]>();
        Runnable runner = new Runnable() {
            InetAddress addr = InetAddress.getByName("localhost");
            Socket sc = new Socket(addr, 5039);

            public void run() {
                long start = System.currentTimeMillis();
                String[] result = new String[2];
                try {
                    Writer writer = new OutputStreamWriter(sc.getOutputStream());
                    writer.write("bar" + EOT);
                    writer.flush();
                    System.out.println("Wrote in 1: " + (System.currentTimeMillis() - start));

                    start = System.currentTimeMillis();
                    char[] buf = new char[3];
                    Reader reader = new InputStreamReader(sc.getInputStream());
                    reader.read(buf);
                    System.out.println("Read in 1: " + (System.currentTimeMillis() - start));
                    result[0] = new String(buf);

                    start = System.currentTimeMillis();
                    writer.write("bar" + EOT);
                    writer.flush();
                    System.out.println("Wrote in 2: " + (System.currentTimeMillis() - start));

                    start = System.currentTimeMillis();
                    buf = new char[3];
                    reader.read(buf);
                    System.out.println("Read in 2: " + (System.currentTimeMillis() - start));
                    result[1] = new String(buf);

                    pointer.set(result);
                    writer.close();
                    reader.close();
                } catch (IOException ioe) {
                    fail(ioe.toString());
                }
            }
        };

        new Thread(runner).start();
        Thread.sleep(4000);
        server.shutdown();
        server.join();

        assertTrue(lifecycle.startedTransaction);
        assertTrue(lifecycle.startedProcessing);
        assertTrue(lifecycle.endedTransaction);
        assertEquals("foo", pointer.get()[0]);
        assertEquals("foo", pointer.get()[1]);
    }

    public void testLongInputAndSlowReader() throws IOException, InterruptedException {
        System.out.println("socket");

        TestSlowNIOLifecycle lifecycle = new TestSlowNIOLifecycle();
        NIOServer server = new NIOServer(lifecycle, 5039, 1500, 200);

        final AtomicReference<String> pointer = new AtomicReference<String>();
        Runnable runner = new Runnable() {
            InetAddress addr = InetAddress.getByName("localhost");
            Socket sc = new Socket(addr, 5039);

            public void run() {
                long start = System.currentTimeMillis();
                try {
                    Writer writer = new OutputStreamWriter(sc.getOutputStream());
                    writer.write(longInput.toString() + EOT);
                    writer.flush();
                    System.out.println("Wrote in " + (System.currentTimeMillis() - start));

                    start = System.currentTimeMillis();
                    char[] buf = new char[3];
                    Reader reader = new InputStreamReader(sc.getInputStream());
                    reader.read(buf);
                    System.out.println("Read in " + (System.currentTimeMillis() - start));
                    String result = new String(buf);
                    pointer.set(result);
                    writer.close();
                    reader.close();
                } catch (IOException ioe) {
                    fail(ioe.toString());
                }
            }
        };

        new Thread(runner).start();
        Thread.sleep(2000);
        server.shutdown();
        server.join();

        assertEquals("foo", pointer.get());
    }
}