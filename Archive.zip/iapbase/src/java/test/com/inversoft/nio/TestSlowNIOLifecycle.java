/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import junit.framework.Assert;

import com.inversoft.iap.IAPConstants;

/**
 * <p>
 * This class is a Lifecycle that is slow.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class TestSlowNIOLifecycle implements NIOLifecycle {
    public String startTransaction() {
        return "foo";
    }

    public void startProcessing(NIOCallback callback, String transactionID, InputStream inputStream,
            OutputStream outputStream) {
        System.out.println("Started processing");
        Runner runner = new Runner();
        runner.inputStream = inputStream;
        runner.outputStream = outputStream;
        runner.callback = callback;
        runner.start();
    }

    public void endTransaction(String transactionId) {
    }

    public class Runner extends Thread {
        public InputStream inputStream;
        public OutputStream outputStream;
        public NIOCallback callback;

        public void run() {
            StringBuilder build = new StringBuilder();
            int i = -1;
            do {
                try {
                    i = inputStream.read();
                    System.out.println("Read [" + i + "]");
                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
                build.append((char) i);
            } while (i != IAPConstants.EOT && i != -1);

            callback.doneReading();
            System.out.println("Was [" + build.toString() + "]");
            Assert.assertTrue(i != -1);

            try {
                outputStream.write("foo".getBytes());
                callback.doneWriting();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}