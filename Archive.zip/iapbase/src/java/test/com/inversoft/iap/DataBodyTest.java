/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap;

import java.util.List;

import junit.framework.TestCase;

import iap.response.DataScope;

/**
 * <p>
 * This class tests the DataBody.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class DataBodyTest extends TestCase {
    public DataBodyTest(String s) {
        super(s);
    }

    /**
     * Tests that the general usage works.
     */
    public void testGeneralUsage() {
        DataBody db = new DataBody();
        db.setValue("user.name", "Brian", DataType.STRING, 0, DataScope.VIEW);
        db.setValue("user.age", 1, DataType.INT, 0, DataScope.APPLICATION);
        db.setValue("user.aliases", new String[]{"Ponch","Guido"}, DataType.STRING, 1, DataScope.APPLICATION);

        assertEquals("Brian", db.getValue("user.name"));
        assertEquals(0, db.getArrayDepth("user.name"));
        assertEquals(DataScope.VIEW, db.getScope("user.name"));
        assertEquals(new Integer(1), db.getValue("user.age"));
        assertEquals(0, db.getArrayDepth("user.age"));
        assertEquals(DataScope.APPLICATION, db.getScope("user.age"));
        assertEquals("Ponch", ((Object[]) db.getValue("user.aliases"))[0]);
        assertEquals("Guido", ((Object[]) db.getValue("user.aliases"))[1]);
        assertEquals(1, db.getArrayDepth("user.aliases"));
        assertEquals(DataScope.APPLICATION, db.getScope("user.aliases"));

        // Test removal
        db.removeValue("user.age");
        assertNull(db.getValue("user.age"));
        assertNull(db.getScope("user.age"));
        assertEquals(-1, db.getArrayDepth("user.age"));
        assertEquals("Brian", db.getValue("user.name"));
        assertNull(db.getValue("user.height"));
    }

    /**
     * Tests that the getAllValues works with local and nested values and complex
     * types.
     */
    public void testGetAllValues() {
        DataBody db = new DataBody();
        db.setValue("user.name", "Brian", DataType.STRING, 0, DataScope.APPLICATION);
        db.setValue("user.age", 1, DataType.INT, 0, DataScope.APPLICATION);
        db.setValue("user.address.city", "Denver", DataType.STRING, 0, DataScope.APPLICATION);
        db.setValue("user.address.state", "Colorado", DataType.STRING, 0, DataScope.APPLICATION);
        db.setValue("age", 28, DataType.INT, 0, DataScope.APPLICATION);

        List<Data> values = db.getAllValues("age");
        assertEquals(1, values.size());
        assertEquals("age", values.get(0).getKey());
        assertEquals(28, values.get(0).getValue());
        assertSame(DataType.INT, values.get(0).getType());
        assertEquals(DataScope.APPLICATION, values.get(0).getScope());

        values = db.getAllValues("user.address.city");
        assertEquals(1, values.size());
        assertEquals("user.address.city", values.get(0).getKey());
        assertEquals("Denver", values.get(0).getValue());
        assertSame(DataType.STRING, values.get(0).getType());
        assertEquals(DataScope.APPLICATION, values.get(0).getScope());

        values = db.getAllValues("user.address");
        assertEquals(2, values.size());
        assertEquals("user.address.city", values.get(0).getKey());
        assertEquals("Denver", values.get(0).getValue());
        assertSame(DataType.STRING, values.get(0).getType());
        assertEquals(DataScope.APPLICATION, values.get(0).getScope());
        assertEquals("user.address.state", values.get(1).getKey());
        assertEquals("Colorado", values.get(1).getValue());
        assertSame(DataType.STRING, values.get(1).getType());
        assertEquals(DataScope.APPLICATION, values.get(1).getScope());

        values = db.getAllValues("user");
        assertEquals(4, values.size());
        assertEquals("user.name", values.get(0).getKey());
        assertEquals("Brian", values.get(0).getValue());
        assertSame(DataType.STRING, values.get(0).getType());
        assertEquals(DataScope.APPLICATION, values.get(0).getScope());
        assertEquals("user.age", values.get(1).getKey());
        assertEquals(1, values.get(1).getValue());
        assertSame(DataType.INT, values.get(1).getType());
        assertEquals(DataScope.APPLICATION, values.get(1).getScope());
        assertEquals("user.address.city", values.get(2).getKey());
        assertEquals("Denver", values.get(2).getValue());
        assertSame(DataType.STRING, values.get(2).getType());
        assertEquals(DataScope.APPLICATION, values.get(2).getScope());
        assertEquals("user.address.state", values.get(3).getKey());
        assertEquals("Colorado", values.get(3).getValue());
        assertSame(DataType.STRING, values.get(3).getType());
        assertEquals(DataScope.APPLICATION, values.get(3).getScope());

        values = db.getAllValues("address");
        assertEquals(0, values.size());

        values = db.getAllValues("city");
        assertEquals(0, values.size());
    }
}