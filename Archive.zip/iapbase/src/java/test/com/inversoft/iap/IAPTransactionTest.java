/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap;

import junit.framework.TestCase;

import iap.TransportType;

/**
 * <p>
 * This tests the IAPTransaction class.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPTransactionTest extends TestCase {
    /**
     * Constructs a new <code>IAPTransaction</code>.
     */
    public IAPTransactionTest(String name) {
        super(name);
    }

    public void testAuth() {
        IAPTransaction t = new IAPTransaction(TransportType.AUTHENTICATE_USER, "1");
        for (TransportType type : TransportType.values()) {
            try {
                t.setStage(type);
                if (type != TransportType.RECONNECT_SESSION) {
                    fail("Should have failed but let " + type + " through");
                }
            } catch (IAPTransactionException e) {
                assertNotSame(TransportType.RECONNECT_SESSION, type);
            }
        }
    }

    public void testClose() {
        IAPTransaction t = new IAPTransaction(TransportType.CLOSE_APPLICATION, "1");
        for (TransportType type : TransportType.values()) {
            try {
                t.setStage(type);
                fail("Should have failed");
            } catch (IAPTransactionException e) {
            }
        }
    }

    public void testData() {
        IAPTransaction t = new IAPTransaction(TransportType.FETCH_DATA, "1");
        for (TransportType type : TransportType.values()) {
            try {
                t.setStage(type);
                if (type != TransportType.RECONNECT_SESSION) {
                    fail("Should have failed but let " + type + " through");
                }
            } catch (IAPTransactionException e) {
                assertNotSame(TransportType.RECONNECT_SESSION, type);
            }
        }
    }

    public void testModule() {
        IAPTransaction t = new IAPTransaction(TransportType.FETCH_MODULE, "1");
        for (TransportType type : TransportType.values()) {
            try {
                t.setStage(type);
                if (type != TransportType.RECONNECT_SESSION) {
                    fail("Should have failed but let " + type + " through");
                }
            } catch (IAPTransactionException e) {
                assertNotSame(TransportType.RECONNECT_SESSION, type);
            }
        }
    }

    public void testApp() {
        IAPTransaction t = new IAPTransaction(TransportType.OPEN_APPLICATION, "1");
        try {
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.OPEN_VIEW);
        } catch (IAPTransactionException e) {
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.OPEN_APPLICATION, "1");
        try {
            t.setStage(TransportType.RECONNECT_SESSION);
            t.setStage(TransportType.OPEN_APPLICATION);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.OPEN_VIEW);
        } catch (IAPTransactionException e) {
            e.printStackTrace();
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.OPEN_APPLICATION, "1");
        try {
            t.setStage(TransportType.OPEN_APPLICATION);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.FETCH_DATA);
        } catch (IAPTransactionException e) {
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.OPEN_APPLICATION, "1");
        for (TransportType type : new TransportType[]{TransportType.PERFORM_ACTION, TransportType.AUTHENTICATE_USER,
                                          TransportType.CLOSE_APPLICATION}) {
            try {
                t.setStage(type);
                fail("Should have failed");
            } catch (IAPTransactionException e) {
            }
        }

        t = new IAPTransaction(TransportType.OPEN_APPLICATION, "1");
        try {
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.RECONNECT_SESSION);
            fail("Should have failed");
        } catch (IAPTransactionException e) {
        }
    }

    public void testView() {
        IAPTransaction t = new IAPTransaction(TransportType.OPEN_VIEW, "1");
        try {
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.OPEN_VIEW);
        } catch (IAPTransactionException e) {
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.OPEN_VIEW, "1");
        try {
            t.setStage(TransportType.RECONNECT_SESSION);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.OPEN_VIEW);
        } catch (IAPTransactionException e) {
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.OPEN_VIEW, "1");
        try {
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.FETCH_DATA);
        } catch (IAPTransactionException e) {
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.OPEN_VIEW, "1");
        for (TransportType type : new TransportType[]{TransportType.OPEN_APPLICATION,
                                          TransportType.PERFORM_ACTION,
                                          TransportType.AUTHENTICATE_USER,
                                          TransportType.CLOSE_APPLICATION}) {
            try {
                t.setStage(type);
                fail("Should have failed");
            } catch (IAPTransactionException e) {
            }
        }

        t = new IAPTransaction(TransportType.OPEN_VIEW, "1");
        try {
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.RECONNECT_SESSION);
            fail("Should have failed");
        } catch (IAPTransactionException e) {
        }
    }

    public void testAction() {
        IAPTransaction t = new IAPTransaction(TransportType.PERFORM_ACTION, "1");
        try {
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.OPEN_VIEW);
        } catch (IAPTransactionException e) {
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.PERFORM_ACTION, "1");
        try {
            t.setStage(TransportType.RECONNECT_SESSION);
            t.setStage(TransportType.PERFORM_ACTION);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.OPEN_VIEW);
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.OPEN_VIEW);
        } catch (IAPTransactionException e) {
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.PERFORM_ACTION, "1");
        try {
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.FETCH_MODULE);
            t.setStage(TransportType.FETCH_DATA);
        } catch (IAPTransactionException e) {
            fail("Should not have failed");
        }

        t = new IAPTransaction(TransportType.PERFORM_ACTION, "1");
        for (TransportType type : new TransportType[]{TransportType.OPEN_APPLICATION,
                                          TransportType.PERFORM_ACTION,
                                          TransportType.AUTHENTICATE_USER,
                                          TransportType.CLOSE_APPLICATION}) {
            try {
                t.setStage(type);
                fail("Should have failed");
            } catch (IAPTransactionException e) {
            }
        }

        t = new IAPTransaction(TransportType.PERFORM_ACTION, "1");
        try {
            t.setStage(TransportType.FETCH_DATA);
            t.setStage(TransportType.RECONNECT_SESSION);
            fail("Should have failed");
        } catch (IAPTransactionException e) {
        }
    }

    public void testReturnTypes() {
        IAPTransaction t = new IAPTransaction(TransportType.OPEN_APPLICATION, "1");
        assertEquals(TransportType.OPEN_APPLICATION, t.getType());
        assertEquals(TransportType.OPEN_APPLICATION, t.getStage());
        assertEquals("1", t.getId());
        try {
            t.setStage(TransportType.OPEN_VIEW);
        } catch (IAPTransactionException iap) {
            fail("Should not fail");
        }
        assertEquals(TransportType.OPEN_VIEW, t.getStage());
    }
}