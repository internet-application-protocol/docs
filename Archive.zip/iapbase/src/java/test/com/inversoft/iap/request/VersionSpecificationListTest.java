/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.request;


import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import iap.VersionNumber;


/**
 *
 * Tests the VersionSpecificationList class
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */
public class VersionSpecificationListTest extends TestCase{

    public VersionSpecificationListTest(String name) {
        super(name);
    }

    public void testVersionSpecificationList() {

        // test the constructors
        VersionSpecification v2 = new VersionSpecification(5, null);
        List<VersionSpecification> specList1 = new ArrayList<VersionSpecification>();
        specList1.add(v2);

        assertTrue(new VersionSpecificationList("1.2").supports(VersionNumber.decode("1.2")));
        assertTrue(new VersionSpecificationList(specList1).supports(VersionNumber.decode("5")));
        assertTrue(new VersionSpecificationList(specList1).supports(VersionNumber.decode("5.1")));
        assertTrue(new VersionSpecificationList(specList1).supports(VersionNumber.decode("5.6.4")));
        assertTrue(new VersionSpecificationList(v2).supports(VersionNumber.decode("5")));

        // test the toString() method
        assertEquals("3.4.0,1.*.*", new VersionSpecificationList("1.2", "3.4", "1.*", "1.5").toString());

        // do some simple list testing...
        VersionSpecificationList specList2 =
                new VersionSpecificationList(new VersionSpecification(1, null));

        // 1.*.* is now in the list, verify this
        assertEquals("1.*.*", specList2.toString());

        // test the string addSpecification varargs method
        // 1.*.*, 2.0.0, 3.1.2, are now in the list
        specList2.addSpecification("2", "3.1.2");
        assertEquals("1.*.*,2.0.0,3.1.2", specList2.toString());

        // test the VersionSpecification addSpecification varargs method
        // 5.0.0, 2.1.* is now in the list
        specList2.addSpecification(new VersionSpecification(5), new VersionSpecification(2,1));
        assertEquals("1.*.*,2.0.0,3.1.2,5.0.0,2.1.0", specList2.toString());

        // now test the matching capabilities
        // adding 5.*....this should remove 5.0.0 and then add 5.*.* to the
        // end of the list
        specList2.addSpecification("5.*");
        assertEquals("1.*.*,2.0.0,3.1.2,2.1.0,5.*.*", specList2.toString());

        // adding 2.*...this should remove 2.0.0 and 2.1.0 and then add 2.*.*
        // to the end of the list
        specList2.addSpecification("2.*");
        assertEquals("1.*.*,3.1.2,5.*.*,2.*.*", specList2.toString());

        // adding 1.1.*.  this shouldnt add since 1.*.* is EQUAL_TO it
        specList2.addSpecification("1.1.*");
        assertEquals("1.*.*,3.1.2,5.*.*,2.*.*", specList2.toString());

        // adding 3.1.*.  this should remove 3.1.2 and add 3.1.*
        specList2.addSpecification("3.1.*");
        assertEquals("1.*.*,5.*.*,2.*.*,3.1.*", specList2.toString());

        // adding 3.1.1.  this shouldn't add since 3.1.* already exists
        specList2.addSpecification("3.1.1");
        assertEquals("1.*.*,5.*.*,2.*.*,3.1.*", specList2.toString());

        // test remove
        specList2.removeSpecification("1.*.*","2.*.*");
        assertEquals("5.*.*,3.1.*", specList2.toString());

        // adding 1.1.
        specList2.addSpecification(new VersionSpecification(1,1));
        assertEquals("5.*.*,3.1.*,1.1.0", specList2.toString());

        // adding 1.1  This shouldn't add since 1.1.0 already exists
        specList2.addSpecification(new VersionSpecification(1, 1));
        assertEquals("5.*.*,3.1.*,1.1.0", specList2.toString());

        // adding 3.1.1.  This shouldn't add since 3.1.* already exists
        specList2.addSpecification(new VersionSpecification(3, 1, 1));
        assertEquals("5.*.*,3.1.*,1.1.0", specList2.toString());

        // adding 5.1.*.  This shouldn't add since 5.*.* already exists
        specList2.addSpecification("5.1.*");
        assertEquals("5.*.*,3.1.*,1.1.0", specList2.toString());

        // adding 3.*  This should replace 3.1.*
        specList2.addSpecification("3.*");
        assertEquals("5.*.*,1.1.0,3.*.*", specList2.toString());

        // test decode() and encode
        assertEquals("5.*.*,1.1.0,3.*.*",
                VersionSpecificationList.encode(VersionSpecificationList.decode("5.*.*,1.1.0,3.*.*")));
        // test decode() and encode() with some spaces between the comma delimit
        assertEquals("5.*.*,1.1.0,3.*.*",
                VersionSpecificationList.encode(VersionSpecificationList.decode("5.*.*, 1.1.0, 3.*.*")));
        assertEquals("5.*.*,1.1.0,3.*.*",
                VersionSpecificationList.encode(VersionSpecificationList.decode("5.*.*,    1.1.0,  3.*.*")));
    }


}
