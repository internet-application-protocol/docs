/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.xml;

import junit.framework.TestCase;

import iap.TransportType;

import com.inversoft.nio.ParseException;

/**
 * <p>
 * This class is a test case for the IAP XML message listener.
 * </p>
 *
 * @author  Brian Pontarelli
 * @see
 * @since   IAP 1.0
 * @version 1.0
 */
public class XMLStreamListenerTest extends TestCase {
    /**
     * Constructs a new <code>IAPMessagelistenerTest</code>.
     */
    public XMLStreamListenerTest(String name) {
        super(name);
    }

    public void testTrueWithoutDoctype() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<authenticateUserRequest foo='dd'>\n   </authenticateUserRequest>";
        char[] ca = msg.toCharArray();
        boolean done = false;
        StringBuilder build = new StringBuilder();
        for (int i = 0; i < ca.length; i++) {
            char c = ca[i];
            listener.characterFeed(c, build.length(), build);
            done |= listener.isRequestComplete();
            build.append(c);
        }

        assertTrue(done);
        assertEquals(TransportType.AUTHENTICATE_USER, listener.getRequestType());
    }

    public void testFalseWithoutDoctype() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<closeApplicationRequest>\n   </closeApplicationRequest";
        char[] ca = msg.toCharArray();
        boolean done = false;
        StringBuilder build = new StringBuilder();
        for (int i = 0; i < ca.length; i++) {
            char c = ca[i];
            listener.characterFeed(c, build.length(), build);
            done |= listener.isRequestComplete();
            build.append(c);
        }

        assertFalse(done);
        assertEquals(TransportType.CLOSE_APPLICATION, listener.getRequestType());
    }

    public void testTrueDeep() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<fetchDataRequest attr=\"1\">\n\t<elem foo=\"ddd\" attr='a'>\n\n   </elem>   </fetchDataRequest>";
        char[] ca = msg.toCharArray();
        boolean done = false;
        StringBuilder build = new StringBuilder();
        for (int i = 0; i < ca.length; i++) {
            char c = ca[i];
            listener.characterFeed(c, build.length(), build);
            done |= listener.isRequestComplete();
            build.append(c);
        }

        assertTrue(done);
        assertEquals(TransportType.FETCH_DATA, listener.getRequestType());
    }

    public void testTrueSingle() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<fetchModuleRequest>\n\t<elem lkjks='oeps' ljslkjd='ssssss' slkjdlkj='sssslkja' dkjhdlkjh=\"adslkh\"/>  </fetchModuleRequest>";
        boolean done = doWork(listener, msg);

        assertTrue(done);
        assertEquals(TransportType.FETCH_MODULE, listener.getRequestType());
    }

    public void testTrueWithDoctype() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n\n<openApplicationRequest>\n   </openApplicationRequest>";
        boolean done = doWork(listener, msg);

        assertTrue(done);
        assertEquals(TransportType.OPEN_APPLICATION, listener.getRequestType());
    }

    public void testFalseWithDoctype() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n\n<openViewRequest attr='dssss'>\n   /openViewRequest>";
        boolean done = doWork(listener, msg);

        assertFalse(done);
        assertEquals(TransportType.OPEN_VIEW, listener.getRequestType());
    }

    public void testTrueWithCommentBeforeRoot() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n\n<!-- comment --><performActionRequest attr42='d'>\n   </performActionRequest>";
        boolean done = doWork(listener, msg);

        assertTrue(done);
        assertEquals(TransportType.PERFORM_ACTION, listener.getRequestType());
    }

    public void testTrueWithCommentInsideRoot() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n\n<!-- comment -->\n\n<root attr=\"dr\"><!-- root comment -->\n   </root>";
        boolean done = doWork(listener, msg);

        assertTrue(done);
    }

    public void testFalseWithCommentInsideRoot() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n\n<root attr=\"12.45\"><!-- comment --\n   </root>";
        boolean done = doWork(listener, msg);

        assertFalse(done);
    }

    public void testTrueWithCDATA() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n\n<!-- comment -->\n\n<root><!-- root comment --><subElem>   <subElement/><![CDATA[fuslkjdlkjsdlknasdkj&<><<><><lijslkjw]]></subElem>\n   </root>";
        boolean done = doWork(listener, msg);

        assertTrue(done);
    }

    public void testFalseWithCDATA() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n\n<!-- comment -->\n\n<root num='1.2.3.1'><!-- root comment --><subElem attr=\"foo|\">   <subElement/><![CDATA[fuslkjdlkjsdlknasdkj&<><<><><lijslkjw]]></subElem\n   </root>";
        boolean done = doWork(listener, msg);

        assertFalse(done);
    }

    public void testTrueWithSlash() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n\n<!-- comment --><performActionRequest attr42='test/html'>\n   </performActionRequest>";
        boolean done = doWork(listener, msg);

        assertTrue(done);
        assertEquals(TransportType.PERFORM_ACTION, listener.getRequestType());
    }

    public void testRandomSplit() throws ParseException {
        XMLStreamListener listener = new XMLStreamListener();
        String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
            "<openViewRequest><sessionId applicationId=\"test-app2\" id=\"8oiscssjk1\" " +
            "versionNumber=\"1.0.1\"/><viewInfo viewId=\"index.";
        String msg2 = "ral\"/></openViewRequest>\n";
        char[] ca = msg.toCharArray();
        boolean done = false;
        StringBuilder build = new StringBuilder();
        for (int i = 0; i < ca.length; i++) {
            char c = ca[i];
            listener.characterFeed(c, build.length(), build);
            done |= listener.isRequestComplete();
            build.append(c);
        }
        assertFalse(done);

        ca = msg2.toCharArray();
        for (int i = 0; i < ca.length; i++) {
            char c = ca[i];
            listener.characterFeed(c, build.length(), build);
            done |= listener.isRequestComplete();
            build.append(c);
        }
        assertTrue(done);
    }

    private boolean doWork(XMLStreamListener listener, String msg) throws ParseException {
        char[] ca = msg.toCharArray();
        StringBuilder build = new StringBuilder();
        boolean done = false;
        for (int i = 0; i < ca.length; i++) {
            char c = ca[i];
            listener.characterFeed(c, build.length(), build);
            done |= listener.isRequestComplete();
            build.append(c);
        }
        return done;
    }
}