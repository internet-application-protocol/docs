/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.request;


import junit.framework.TestCase;

import iap.InvalidVersionException;
import iap.VersionNumber;

import static com.inversoft.iap.request.VersionSpecification.decode;


/**
 * @author James Humphrey
 * @version 1.0
 * @since IAP 1.0
 */
public class VersionSpecificationTest extends TestCase {

    protected final String majorExMsg = "Major version number cannot be less than 1";

    protected final String minorExMsg = "Minor version number cannot be less than 0";

    protected final String subMinorExMsg = "Sub-Minor version number cannot be less than 0";

    private final String versionLogicMsg = "The Minor version number cannot be null if a Sub-Minor version number is specified";

    final String invalidVersionMsg = "Version specified is not a valid format";

    VersionSpecification versionSpec;

    public VersionSpecificationTest(String name) {
        super(name);
    }

    public void testVersionSpecification() throws InvalidVersionException {
        // test exceptions
        // test 1
        try {
            this.versionSpec = new VersionSpecification(0, null);
            fail("error in test 1");
        } catch (InvalidVersionException e) {
            assertEquals(majorExMsg, e.getMessage());
        }

        // test 2
        try {
            this.versionSpec = new VersionSpecification(0, 1, 1);
            fail("error in test 2");
        } catch (InvalidVersionException e) {
            assertEquals(majorExMsg, e.getMessage());
        }

        // test 3
        try {
            this.versionSpec = new VersionSpecification(1, -1, 1);
            fail("error in test 3");
        } catch (InvalidVersionException e) {
            assertEquals(minorExMsg, e.getMessage());
        }

        // test 4
        try {
            this.versionSpec = new VersionSpecification(1, 1, -1);
            fail("error in test 4");
        } catch (InvalidVersionException e) {
            assertEquals(subMinorExMsg, e.getMessage());
        }

        // test 5
        try {
            this.versionSpec = new VersionSpecification(null, 1, -1);
            fail("error in test 5");
        } catch (InvalidVersionException e) {
            assertEquals(majorExMsg, e.getMessage());
        }

        // test 6
        try {
            this.versionSpec = new VersionSpecification(1, null, -1);
            fail("error in test 6");
        } catch (InvalidVersionException e) {
            assertEquals(versionLogicMsg, e.getMessage());
        }

        // test 7
        try {
            this.versionSpec = new VersionSpecification(1, null, 1);
            fail("error in test 7");
        } catch (InvalidVersionException e) {
            assertEquals(versionLogicMsg, e.getMessage());
        }


        // test constructor instantiations and getVersion()
        assertEquals("1.0.0", new VersionSpecification(1).getVersion());
        assertEquals("1.0.0", new VersionSpecification(1, 0).getVersion());
        assertEquals("1.0.0", new VersionSpecification(1, 0, 0).getVersion());
        assertEquals("3.*.*", new VersionSpecification(3, null).getVersion());
        assertEquals("3.*.*", new VersionSpecification(3, null, null).getVersion());
        assertEquals("2.*.*", new VersionSpecification(2, null).getVersion());
        assertEquals("1.0.*", new VersionSpecification(1, 0, null).getVersion());
        assertEquals("1.1.1", new VersionSpecification(1, 1, 1).getVersion());
        assertEquals("1.1.*", new VersionSpecification(1, 1, null).getVersion());

        // test the equals() operation
        VersionSpecification testVersion = new VersionSpecification(5);

        assertFalse(new VersionSpecification(5).equals(new VersionSpecification(5, null, null)));
        assertFalse(new VersionSpecification(1, null).equals(new VersionSpecification(1, 1)));
        assertFalse(new VersionSpecification(1).equals(new VersionSpecification(2)));
        assertTrue(new VersionSpecification(1, 1).equals(new VersionSpecification(1, 1)));
        assertTrue(new VersionSpecification(1, null, null).equals(new VersionSpecification(1, null, null)));
        assertTrue(new VersionSpecification(5).equals(new VersionSpecification(5)));
        assertTrue(testVersion.equals(testVersion)); // make sure it equals itself
        assertTrue(new VersionSpecification(5).equals(new VersionSpecification(5, 0, 0)));
        assertTrue(new VersionSpecification(5).equals(new VersionSpecification(5, 0, 0)));

        // test decoder
        // test 5 exception
        try {
            decode(null);
            fail("error in test 5 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 6 exception
        try {
            decode("james");
            fail("error in test 6 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 7 exception
        try {
            decode("1.asdf");
            fail("error in test 7 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 8 exception
        try {
            decode("1.1.ponchie");
            fail("error in test 8 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 9 exception
        try {
            decode("james.1.1.ponchie");
            fail("error in test 9 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 10 exception
        try {
            decode("1.humpdy.2");
            fail("error in test 10 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 11 exception
        try {
            decode("1.*.bogus");
            fail("error in test 11 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 12 exception
        try {
            decode("*.*1.bogus");
            fail("error in test 12 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 13 exception
        try {
            decode("1.bogus.*");
            fail("error in test 13 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 14 exception
        try {
            decode("1..");
            fail("error in test 14 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 15 exception
        try {
            decode("...");
            fail("error in test 15 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 16 exception
        try {
            decode("1..2");
            fail("error in test 16 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        assertEquals("1.1.0", decode("1.1").getVersion());
        assertEquals("1.0.0", decode("1").getVersion());
        assertEquals("1.1.1", decode("1.1.1").getVersion());
        assertEquals("1.1.11", decode("1.1.11").getVersion());
        assertEquals("1.10.1", decode("1.10.1").getVersion());
        assertEquals("1001.1.43", decode("1001.1.43").getVersion());
        assertEquals("1001.*.*", decode("1001.*").getVersion());
        assertEquals("1001.*.*", decode("1001.*.*").getVersion());
        assertEquals("1001.1.*", decode("1001.1.*").getVersion());
        assertEquals("1.0.0", decode("1.0").getVersion());
        assertEquals("1.0.0", decode("1.0.0").getVersion());
        assertEquals("1.0.1", decode("1.0.1").getVersion());

        // test the compareTo operation
        // example: '1.1' compared to '2' should yield LESS_THAN
        //          since version '1.1' is less than version '2'
        assertEquals(0, decode("1.1").compareTo(decode("1.1")));

        assertEquals(0, decode("1").compareTo(decode("1.0.0")));
        assertEquals(0, decode("1.0.0").compareTo(decode("1")));

        assertTrue(decode("1.0.0").compareTo(decode("2")) < 0);
        assertTrue(decode("2").compareTo(decode("1.0.0")) > 0);

        assertTrue(decode("1.*").compareTo(decode("2")) < 0);
        assertTrue(decode("2").compareTo(decode("1.*")) > 0);

        assertTrue(decode("1.*").compareTo(decode("1.1")) < 0);
        assertTrue(decode("1.1").compareTo(decode("1.*")) > 0);

        assertTrue(decode("1.*.*").compareTo(decode("1.1")) < 0);
        assertTrue(decode("1.1").compareTo(decode("1.*.*")) > 0);

        assertTrue(decode("1.1.*").compareTo(decode("1.1")) < 0);
        assertTrue(decode("1.1").compareTo(decode("1.1.*")) > 0);

        assertTrue(decode("1.*.*").compareTo(decode("1.1.1")) < 0);
        assertTrue(decode("1.1.1").compareTo(decode("1.*.*")) > 0);

        assertTrue(decode("1.*.*").compareTo(decode("1")) < 0);
        assertTrue(decode("1").compareTo(decode("1.*.*")) > 0);

        assertTrue(decode("2").compareTo(decode("1.1")) > 0);
        assertTrue(decode("1.1").compareTo(decode("2")) < 0);

        assertTrue(decode("2.1.1").compareTo(decode("2.1")) > 0);
        assertTrue(decode("2.1").compareTo(decode("2.1.1")) < 0);

        assertTrue(decode("2.1.1").compareTo(decode("2.1.0")) > 0);
        assertTrue(decode("2.1.0").compareTo(decode("2.1.1")) < 0);

        assertTrue(decode("2.2.2").compareTo(decode("2.2.1")) > 0);
        assertTrue(decode("2.2.1").compareTo(decode("2.2.2")) < 0);

        assertTrue(decode("1").compareTo(decode("1.*")) > 0);
        assertTrue(decode("1.*").compareTo(decode("1")) < 0);

        assertTrue(decode("1").compareTo(decode("1.*.*")) > 0);
        assertTrue(decode("1.*.*").compareTo(decode("1")) < 0);

        assertTrue(decode("2.*.*").compareTo(decode("2.1.0")) < 0);
        assertTrue(decode("2.1.0").compareTo(decode("2.*.*")) > 0);

        // test supports
        assertTrue(decode("1.1").supports(VersionNumber.decode("1.1")));
        assertTrue(decode("1.*").supports(VersionNumber.decode("1.1")));
        assertTrue(decode("1.*").supports(VersionNumber.decode("1.9")));
        assertFalse(decode("1").supports(VersionNumber.decode("1.9")));
        assertTrue(decode("1.*.*").supports(VersionNumber.decode("1.9")));
        assertTrue(decode("1.0.1").supports(VersionNumber.decode("1.0.1")));
        assertTrue(decode("1.0.*").supports(VersionNumber.decode("1.0.1")));
        assertTrue(decode("1.0.*").supports(VersionNumber.decode("1.0")));
        assertTrue(decode("1.*.*").supports(VersionNumber.decode("1")));
        assertTrue(decode("1.1.*").supports(VersionNumber.decode("1.1")));
        assertTrue(decode("1.1.*").supports(VersionNumber.decode("1.1.9")));
        assertTrue(decode("1.*.*").supports(VersionNumber.decode("1.1.9")));
        assertTrue(decode("1").supports(VersionNumber.decode("1.0.0")));
        assertTrue(decode("1").supports(VersionNumber.decode("1.0")));
        assertTrue(decode("1.0.0").supports(VersionNumber.decode("1")));
        assertTrue(decode("1.0").supports(VersionNumber.decode("1")));
        assertTrue(decode("1.*").supports(decode("1.1.*")));
        assertTrue(decode("1.1.*").supports(decode("1.1.*")));
        assertFalse(decode("1.1.*").supports(decode("1.*.*")));

        // test toString()
        assertEquals("1.*.*", decode("1.*.*").toString());
        assertEquals("1.*.*", new VersionSpecification(1, null, null).toString());

        // test isWildcard()
        assertTrue(decode("1.*.*").isWildcard());
        assertTrue(decode("1.*").isWildcard());

        // test encode/decode
        assertEquals("2.3.4",
                VersionSpecification.encode(decode("2.3.4")));
    }
}
