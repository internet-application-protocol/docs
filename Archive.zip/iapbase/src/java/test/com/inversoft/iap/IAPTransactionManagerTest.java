/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap;

import junit.framework.TestCase;

import iap.TransportType;

/**
 * <p>
 * This is a testcase for the IAPTransactionManager.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPTransactionManagerTest extends TestCase {
    /**
     * Constructs a new <code>IAPTransactionManagerTest</code>.
     */
    public IAPTransactionManagerTest(String name) {
        super(name);
    }

    public void testAll() {
        testCreateID();
        testCreateTransaction();
    }

    public void testCreateID() {
        IAPTransactionManager tm = new IAPTransactionManager();
        String tid1 = tm.createTransactionID();
        String tid2 = tm.createTransactionID();
        assertFalse(tid1.equals(tid2));
        assertNull(tm.fetchTransaction(tid1));
        assertNull(tm.fetchTransaction(tid1));
    }

    public void testCreateTransaction() {
        IAPTransactionManager tm = new IAPTransactionManager();
        String tid1 = tm.createTransactionID();
        IAPTransaction t = tm.createTransaction(tid1,
                TransportType.AUTHENTICATE_USER);
        assertNotNull(t);
        assertEquals(TransportType.AUTHENTICATE_USER, t.getType());
        assertNotNull(tm.fetchTransaction(tid1));
        assertEquals(t.getId(), tid1);
    }
}