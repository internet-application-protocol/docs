/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap;

import junit.framework.TestCase;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MimeTypeTest extends TestCase {
    public MimeTypeTest(String s) {
        super(s);
    }

    public void testMimeTypeEnum() {
        assertEquals("text/html", MimeType.getContentType("html"));
        assertEquals("text/iapl", MimeType.getContentType("iapl"));
        assertEquals("text/xml", MimeType.getContentType("xml"));
        assertEquals(MimeType.TEXT_HTML, MimeType.getMimeType("text/html"));
        assertEquals(MimeType.TEXT_IAPL, MimeType.getMimeType("text/iapl"));
        assertEquals(MimeType.TEXT_XML, MimeType.getMimeType("text/xml"));
    }
}
