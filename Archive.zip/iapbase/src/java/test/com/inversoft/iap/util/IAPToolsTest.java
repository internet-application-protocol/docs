/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.util;

import java.util.Map;

import junit.framework.TestCase;

import iap.TransportType;
import iap.handler.AuthenticateUserHandler;
import iap.handler.CloseApplicationHandler;
import iap.handler.FetchDataHandler;
import iap.handler.FetchModuleHandler;
import iap.handler.IAPHandlerException;
import iap.handler.OpenApplicationHandler;
import iap.handler.OpenViewHandler;
import iap.handler.PerformActionHandler;
import iap.handler.ReconnectSessionHandler;
import iap.request.AuthenticateUserRequest;
import iap.request.CloseApplicationRequest;
import iap.request.FetchDataRequest;
import iap.request.FetchModuleRequest;
import iap.request.OpenApplicationRequest;
import iap.request.OpenViewRequest;
import iap.request.PerformActionRequest;
import iap.request.ReconnectSessionRequest;
import iap.response.AuthenticateUserResponse;
import iap.response.CloseApplicationResponse;
import iap.response.FetchDataResponse;
import iap.response.FetchModuleResponse;
import iap.response.OpenApplicationResponse;
import iap.response.OpenViewResponse;
import iap.response.PerformActionResponse;
import iap.response.ReconnectSessionResponse;

/**
 * <p>
 * This class is a test case for the IAPTools.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPToolsTest extends TestCase {
    /**
     * Constructs a new <code>IAPToolsTest</code>.
     */
    public IAPToolsTest(String name) {
        super(name);
    }

    public void testDetermineType() {
        assertSame(TransportType.AUTHENTICATE_USER, IAPTools.determineType(new AuthenticateUserHandler(){
            public void doAuthenticateUser(AuthenticateUserRequest request, AuthenticateUserResponse response) throws IAPHandlerException {
            }

            public void create(Map<String, String> parameters) throws IAPHandlerException {
            }

            public void destory() throws IAPHandlerException {
            }
        }));

        assertSame(TransportType.CLOSE_APPLICATION, IAPTools.determineType(new CloseApplicationHandler() {
            public void doCloseApplication(CloseApplicationRequest request, CloseApplicationResponse response) throws IAPHandlerException {
            }

            public void create(Map<String, String> parameters) throws IAPHandlerException {
            }

            public void destory() throws IAPHandlerException {
            }
        }));

        assertSame(TransportType.FETCH_DATA, IAPTools.determineType(new FetchDataHandler() {
            public void doFetchData(FetchDataRequest request, FetchDataResponse response) throws IAPHandlerException {
            }

            public void create(Map<String, String> parameters) throws IAPHandlerException {
            }

            public void destory() throws IAPHandlerException {
            }
        }));

        assertSame(TransportType.FETCH_MODULE, IAPTools.determineType(new FetchModuleHandler() {
            public void doFetchModule(FetchModuleRequest request, FetchModuleResponse response) throws IAPHandlerException {
            }

            public void create(Map<String, String> parameters) throws IAPHandlerException {
            }

            public void destory() throws IAPHandlerException {
            }
        }));

        assertSame(TransportType.OPEN_APPLICATION, IAPTools.determineType(new OpenApplicationHandler() {
            public void doOpenApplication(OpenApplicationRequest request, OpenApplicationResponse response) throws IAPHandlerException {
            }

            public void create(Map<String, String> parameters) throws IAPHandlerException {
            }

            public void destory() throws IAPHandlerException {
            }
        }));

        assertSame(TransportType.OPEN_VIEW, IAPTools.determineType(new OpenViewHandler() {
            public void doOpenView(OpenViewRequest request, OpenViewResponse response) throws IAPHandlerException {
            }

            public void create(Map<String, String> parameters) throws IAPHandlerException {
            }

            public void destory() throws IAPHandlerException {
            }
        }));

        assertSame(TransportType.PERFORM_ACTION, IAPTools.determineType(new PerformActionHandler() {
            public void doPerformAction(PerformActionRequest request, PerformActionResponse response) throws IAPHandlerException {
            }

            public void create(Map<String, String> parameters) throws IAPHandlerException {
            }

            public void destory() throws IAPHandlerException {
            }
        }));

        assertSame(TransportType.RECONNECT_SESSION, IAPTools.determineType(new ReconnectSessionHandler() {
            public void doReconnectSession(ReconnectSessionRequest request,
                                        ReconnectSessionResponse response)
                    throws IAPHandlerException {
            }

            public void create(Map<String, String> parameters)
                    throws IAPHandlerException {
            }

            public void destory() throws IAPHandlerException {
            }
        }));
    }
}