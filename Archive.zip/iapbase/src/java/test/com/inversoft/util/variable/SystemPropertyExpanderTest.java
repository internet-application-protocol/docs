/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util.variable;

import junit.framework.TestCase;

/**
 * This class test the SystemPropertyExpanderStrategy class
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 1.0
 */
public class SystemPropertyExpanderTest extends TestCase {

    /**
     * Constructs a new <code>SystemPropertyExpanderTest</code>.
     */
    public SystemPropertyExpanderTest(String name) {
        super(name);
    }


    /**
     * Test the expand method with common properties
     */
    public void testCommon() {

        ExpanderStrategy strat = new SystemPropertyExpanderStrategy();

        try {
            assertTrue("Should not have been null", strat.expand("java.home") != null);
            assertTrue("Should not have been null", strat.expand("user.home") != null);
        } catch (ExpanderException ee) {
            fail(ee.toString());
        }
    }

    /**
     * Test the expand method with non-existant properties
     */
    public void testFailure() {
        ExpanderStrategy strat = new SystemPropertyExpanderStrategy();

        try {
            assertNull(strat.expand("foo.bar"));
        } catch (ExpanderException ee) {
            fail("Should not have failed");
        }
    }

    /**
     * Test the expand method asserts
     */
    public void testAssert() {
        ExpanderStrategy strat = new SystemPropertyExpanderStrategy();

        try {
            strat.expand(null);
            fail("Should have failed");
        } catch (ExpanderException ee) {
            fail("Shouldn't have thrown this");
        } catch (AssertionError ae) {
            // Expected
        }

        try {
            strat.expand("");
            fail("Should have failed");
        } catch (ExpanderException ee) {
            fail("Shouldn't have thrown this");
        } catch (AssertionError ae) {
            // Expected
        }
    }
}