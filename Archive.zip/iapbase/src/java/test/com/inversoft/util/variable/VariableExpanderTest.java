/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util.variable;

import java.util.List;

import junit.framework.TestCase;

/**
 * This class is the JUnit test case for the variable
 * package.
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 1.0
 */
public class VariableExpanderTest extends TestCase {

    /**
     * Constructs a new <code>VariableExpanderTest</code>.
     */
    public VariableExpanderTest(String name) {
        super(name);
    }


    /**
     * Tests with a single variable
     */
    public void testSingle() {
        helperGood("${variable1}", "foo", new SimpleStrategy());
        helperGood("Inside ${variable1}", "Inside foo", new SimpleStrategy());
        helperGood("${variable1} outside", "foo outside", new SimpleStrategy());
        helperGood("Inside ${variable1} outside", "Inside foo outside", new SimpleStrategy());
    }

    /**
     * Tests with a empty string
     */
    public void testEmpty() {
        try {
            assertNull(VariableExpander.expand((String) null, new SimpleStrategy()));
            assertEquals("", VariableExpander.expand("", new SimpleStrategy()));
        } catch (ExpanderException ee) {
            fail("Shouldn't have failed");
        }
    }

    /**
     * Tests with two variables
     */
    public void testDouble() {
        helperGood("${variable1} ${variable2}", "foo foo", new SimpleStrategy());
        helperGood("Inside ${variable1} middle ${variable2} outside",
            "Inside foo middle foo outside",
            new SimpleStrategy());
        helperGood("Inside ${variable1} ${variable2} outside",
            "Inside foo foo outside",
            new SimpleStrategy());
    }

    /**
     * Tests Finding of names works.
     */
    public void testFind() {
        List<String> names = VariableExpander.findVariables("foo bar ${variable1} inside ${variable2} baz");
        assertEquals(2, names.size());
        assertEquals("variable1", names.get(0));
        assertEquals("variable2", names.get(1));
    }

    /**
     * Tests the expand (String, Strategy) for long variable names
     */
    public void testStringLongVariableNames() {
        helperGood("Inside ${long variable with spaces} ${long_variable{{{${} outside",
            "Inside foo foo outside",
            new LongNamesStrategy());
    }

    /**
     * Tests the expand (String, Strategy) for invalid variables
     */
    public void testInvalidSingle() {
        helperGood("variable1}",
            "variable1}",
            new SimpleStrategy());
        helperGood("Inside variable1}",
            "Inside variable1}",
            new SimpleStrategy());
        helperGood("Inside variable1} outside",
            "Inside variable1} outside",
            new SimpleStrategy());

        helperGood("${variable1",
            "${variable1",
            new SimpleStrategy());
        helperGood("Inside ${variable1",
            "Inside ${variable1",
            new SimpleStrategy());
        helperGood("Inside ${variable1 outside",
            "Inside ${variable1 outside",
            new SimpleStrategy());

        helperGood("$a{variable1}",
            "$a{variable1}",
            new SimpleStrategy());
        helperGood("Inside $a{variable1}",
            "Inside $a{variable1}",
            new SimpleStrategy());
        helperGood("Inside $a{variable1} outside",
            "Inside $a{variable1} outside",
            new SimpleStrategy());

        helperGood("{variable1}",
            "{variable1}",
            new SimpleStrategy());
        helperGood("Inside {variable1}",
            "Inside {variable1}",
            new SimpleStrategy());
        helperGood("Inside {variable1} outside",
            "Inside {variable1} outside",
            new SimpleStrategy());

        helperGood("}${variable1",
            "}${variable1",
            new SimpleStrategy());
        helperGood("${variable1 ${foo ${bar",
            "${variable1 ${foo ${bar",
            new SimpleStrategy());
    }

    /**
     * Tests for invalid variables
     */
    public void testInvalidDouble() {
        helperGood("variable1} variable2}",
            "variable1} variable2}",
            new SimpleStrategy());
        helperGood("Inside variable1} variable2}",
            "Inside variable1} variable2}",
            new SimpleStrategy());
        helperGood("Inside variable1} variable2} outside",
            "Inside variable1} variable2} outside",
            new SimpleStrategy());
        helperGood("Inside variable1} middle variable2} outside",
            "Inside variable1} middle variable2} outside",
            new SimpleStrategy());

        helperGood("${variable1 ${variable2",
            "${variable1 ${variable2",
            new SimpleStrategy());
        helperGood("Inside ${variable1 ${variable2",
            "Inside ${variable1 ${variable2",
            new SimpleStrategy());
        helperGood("Inside ${variable1 ${variable2 outside",
            "Inside ${variable1 ${variable2 outside",
            new SimpleStrategy());
        helperGood("Inside ${variable1 middle ${variable2 outside",
            "Inside ${variable1 middle ${variable2 outside",
            new SimpleStrategy());

        helperGood("$a{variable1} $a{variable2}",
            "$a{variable1} $a{variable2}",
            new SimpleStrategy());
        helperGood("Inside $a{variable1} $a{variable2}",
            "Inside $a{variable1} $a{variable2}",
            new SimpleStrategy());
        helperGood("Inside $a{variable1} $a{variable2} outside",
            "Inside $a{variable1} $a{variable2} outside",
            new SimpleStrategy());
        helperGood("Inside $a{variable1} middle $a{variable2} outside",
            "Inside $a{variable1} middle $a{variable2} outside",
            new SimpleStrategy());

        helperGood("{variable1} {variable2}",
            "{variable1} {variable2}",
            new SimpleStrategy());
        helperGood("Inside {variable1} {variable2}",
            "Inside {variable1} {variable2}",
            new SimpleStrategy());
        helperGood("Inside {variable1} {variable2} outside",
            "Inside {variable1} {variable2} outside",
            new SimpleStrategy());
        helperGood("Inside {variable1} middle {variable2} outside",
            "Inside {variable1} middle {variable2} outside",
            new SimpleStrategy());

        helperGood("}${variable1 ${variable2",
            "}${variable1 ${variable2",
            new SimpleStrategy());
        helperGood("${variable1 ${foo ${bar",
            "${variable1 ${foo ${bar",
            new SimpleStrategy());
        helperGood("$}{variable1 $a{variable2} ${variable3{",
            "$}{variable1 $a{variable2} ${variable3{",
            new SimpleStrategy());
    }

    /**
     * Tests the expand (String, Strategy) for invalid strategy
     */
    public void testStringFailureStrategy() {

        try {
            ExpanderStrategy strat = new FailureStrategy();
            String str = "Inside ${variable} ${variable} outside";
            /*String value = */VariableExpander.expand(str, strat);

            fail("Should have failed");
        } catch (ExpanderException ee) {
            assertTrue("Should have message of 'Message' but is '" + ee.getMessage() +
                "'", ee.getMessage().equals("Message"));
        }
    }

    /**
     * Tests the expand (StringBuffer, Strategy) for invalid strategy
     */
    public void testStringBufferFailureStrategy() {

        try {
            ExpanderStrategy strat = new FailureStrategy();
            StringBuilder str = new StringBuilder("Inside ${long variable with spaces} ${long_variable{{{${} outside");
            /*String value = */VariableExpander.expand(str, strat);

            fail("Should have failed");
        } catch (ExpanderException ee) {
            assertTrue("Should have message of 'Message' but is '" + ee.getMessage() +
                "'", ee.getMessage().equals("Message"));
        }
    }

    /**
     * Tests the assert statements
     */
    public void testAsserts() {
        try {
            StringBuilder str = new StringBuilder("");
            VariableExpander.expand(str, null);
            fail("Should have failed");
        } catch (ExpanderException ee) {
            fail("Should have asserted");
        } catch (AssertionError ae) {
            // Expected
        }
    }

    /**
     * Helper
     */
    private void helperGood(String in, String expected, ExpanderStrategy strat) {
        try {
            String value = VariableExpander.expand(in, strat);
            assertTrue("Should be '" + expected + "' but is '" + value + "'",
                value.equals(expected));

            strat = (ExpanderStrategy) strat.getClass().newInstance();
            StringBuilder strBuf = new StringBuilder(in);
            value = VariableExpander.expand(strBuf, strat);
            assertTrue("Should be '" + expected + "' but is '" + value + "'",
                value.equals(expected));
        } catch (ExpanderException ee) {
            fail(ee.toString());
        } catch (Exception e) {
            fail(e.toString());
        }
    }

    /**
     * This is the strategy for simple tests
     */
    public static class SimpleStrategy implements ExpanderStrategy {
        private int count = 1;

        public String expand(String name) {
            assertTrue("Should be 'variable" + count + "' but is '" + name + "'",
                name.equals("variable" + count));
            count++;
            return "foo";
        }
    }

    /**
     * This is the strategy for simple tests
     */
    public static class LongNamesStrategy implements ExpanderStrategy {
        private int count = 1;

        public String expand(String name) {
            if (count == 1) {
                assertTrue("Should be 'long variable with spaces' but is '" +
                    name + "'", name.equals("long variable with spaces"));
            } else {
                assertTrue("Should be 'long_variable{{{${' but is '" +
                    name + "'", name.equals("long_variable{{{${"));
            }
            count++;
            return "foo";
        }
    }

    /**
     * This is the strategy for simple tests
     */
    public static class FailureStrategy implements ExpanderStrategy {
        public String expand(String name) throws ExpanderException {
            throw new ExpanderException("Message");
        }
    }
}