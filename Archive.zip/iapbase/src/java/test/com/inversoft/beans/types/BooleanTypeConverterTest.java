/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


import junit.framework.TestCase;


/**
 * This class handles all of the test cases for the Type
 * conversion support in the JBeans package.
 *
 * @author  Brian Pontarelli
 */
public class BooleanTypeConverterTest extends TestCase {

    /** Construct and new test instance */
    public BooleanTypeConverterTest(String name) {
        super(name);
    }

    /**
     * Test the conversion of null values
     */
    public void testNullConversions() {
        try {
            String stringValue = null;
            BooleanTypeConverter converter = new BooleanTypeConverter();
            Object obj = converter.convertFromString(stringValue, Boolean.class);

            assertTrue("obj should be null", obj == null);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Test the conversion of empty (whitespace) values
     */
    public void testEmptyConversions() {
        try {
            String stringValue = "   ";
            BooleanTypeConverter converter = new BooleanTypeConverter();
            Object obj = converter.convertFromString(stringValue, Boolean.class);

            assertTrue("obj should be null", obj == null);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the conversion from a string to a boolean
     */
    public void testBooleanConversion() {
        try {
            String value = "true";
            BooleanTypeConverter converter = new BooleanTypeConverter();
            Object booleanObject = converter.convertFromString(value, Boolean.class);

            if (booleanObject instanceof Boolean) {
                assertTrue("Should be true", ((Boolean) booleanObject).booleanValue());
            } else {
                fail("Type is not correct: " + booleanObject.getClass().getName());
            }
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        try {
            String value = "fals3";
            BooleanTypeConverter converter = new BooleanTypeConverter();
            converter.convertFromString(value, Boolean.class);
            fail("Should have thrown an exception");
        } catch (TypeConversionException tce) {
            //System.err.println(tce.toString());
            assertTrue("Should have no root cause or target", tce.getCause() == null);
        }
    }

    /**
     * Tests that sending in empty primitives returns a Boolean.FALSE value.
     */
    public void testPrimitiveFalse() {
        try {
            String value = " ";
            BooleanTypeConverter converter = new BooleanTypeConverter();
            Object booleanObject = converter.convertFromString(value, Boolean.TYPE);

            if (booleanObject instanceof Boolean) {
                assertFalse("Should be false", ((Boolean) booleanObject).booleanValue());
            } else {
                fail("Type is not correct: " + booleanObject.getClass().getName());
            }
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }
}