/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import junit.framework.TestCase;


/**
 * <p>
 * This class tests the adapter classes for jBeans.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class AdaptersTest extends TestCase {

    /**
     * Constructs a new <code>AdaptersTest</code>.
     */
    public AdaptersTest(String name) {
        super(name);
    }


    /**
     * This is really just a compile time test. This won't compile unless the
     * adapters are not correct.
     */
    public void testAll() {
        ConversionListenerAdapter ca = new ConversionListenerAdapter() {};

        // Lame, but this ensures that no code is in there in a really, really
        // naive kinda way
        try {
            ca.handleFailedConversion(null);
            ca.handlePostConversion(null);
            ca.handlePreConversion(null);
        } catch (Throwable t) {
            fail(t.toString());
        }

        PropertyListenerAdapter pa = new PropertyListenerAdapter() {
        };

        // Lame, but this ensures that no code is in there in a really, really
        // naive kinda way
        try {
            pa.handleGet(null);
            pa.handleSet(null);
        } catch (Throwable t) {
            fail(t.toString());
        }
    }
}
