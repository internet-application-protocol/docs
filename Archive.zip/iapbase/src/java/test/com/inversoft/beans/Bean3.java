/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;


/**
 * This class is a simple JavaBean that is used in testing.
 *
 * @author  Brian Pontarelli
 */
public class Bean3 {

    private String property3;
    private Integer integer3;
    private List<Object> list = new ArrayList<Object>();
    private Map<Object, Object> map = new HashMap<Object, Object>();
    private Collection<Object> collection = new HashSet<Object>();
    private Object[] array = new Object[4];
    private Integer[] integerArray = new Integer[4];

    /** Gets the property3 property */
    public String getProperty3() {
        return property3;
    }

    /** Sets the property3 property */
    public void setProperty3(String value) {
        this.property3 = value;
    }

    /** Gets the Integer3 property */
    public Integer getInteger3() {
        return integer3;
    }

    /** Sets the Integer3 property */
    public void setInteger3(Integer value) {
        integer3 = value;
    }

    /** Gets the list property */
    public List<Object> getList() {
        return list;
    }

    /** Sets the list property */
    public void setList(List<Object> list) {
        this.list = list;
    }

    /** Gets the map property */
    public Map<Object, Object> getMap() {
        return map;
    }

    /** Sets the map property */
    public void setMap(Map<Object, Object> map) {
        this.map = map;
    }

    /** Gets the collection property */
    public Collection<Object> getCollection() {
        return collection;
    }

    /** Sets the collection property */
    public void setCollection(Collection<Object> collection) {
        this.collection = collection;
    }

    /** Gets the array property */
    public Object[] getArray() {
        return array;
    }

    /** Sets the array property */
    public void setArray(Object[] array) {
        this.array = array;
    }

    /** Gets the integerArray property */
    public Integer[] getIntegerArray() {
        return integerArray;
    }

    /** Sets the integerArray property */
    public void setIntegerArray(Integer[] integerArray) {
        this.integerArray = integerArray;
    }
}