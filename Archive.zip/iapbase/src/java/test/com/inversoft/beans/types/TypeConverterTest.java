/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


import junit.framework.TestCase;


/**
 * This class handles all of the test cases for the Type
 * conversion support in the JBeans package.
 *
 * @author  Brian Pontarelli
 */
public class TypeConverterTest extends TestCase {

    /** Construct and new test instance */
    public TypeConverterTest(String name) {
        super(name);
    }

    /**
     * Test the lookup of converters
     */
    public void testLookups() {
        TypeConverter tc = TypeConverterRegistry.lookup(Character.class);
        assertEquals(CharacterTypeConverter.class, tc.getClass());
        tc = TypeConverterRegistry.lookup(Character.TYPE);
        assertEquals(CharacterTypeConverter.class, tc.getClass());

        tc = TypeConverterRegistry.lookup(Byte.class);
        assertEquals(NumberTypeConverter.class, tc.getClass());
        tc = TypeConverterRegistry.lookup(Byte.TYPE);
        assertEquals(NumberTypeConverter.class, tc.getClass());

        tc = TypeConverterRegistry.lookup(Short.class);
        assertEquals(NumberTypeConverter.class, tc.getClass());
        tc = TypeConverterRegistry.lookup(Short.TYPE);
        assertEquals(NumberTypeConverter.class, tc.getClass());

        tc = TypeConverterRegistry.lookup(Integer.class);
        assertEquals(NumberTypeConverter.class, tc.getClass());
        tc = TypeConverterRegistry.lookup(Integer.TYPE);
        assertEquals(NumberTypeConverter.class, tc.getClass());

        tc = TypeConverterRegistry.lookup(Long.class);
        assertEquals(NumberTypeConverter.class, tc.getClass());
        tc = TypeConverterRegistry.lookup(Long.TYPE);
        assertEquals(NumberTypeConverter.class, tc.getClass());

        tc = TypeConverterRegistry.lookup(Float.class);
        assertEquals(NumberTypeConverter.class, tc.getClass());
        tc = TypeConverterRegistry.lookup(Float.TYPE);
        assertEquals(NumberTypeConverter.class, tc.getClass());

        tc = TypeConverterRegistry.lookup(Double.class);
        assertEquals(NumberTypeConverter.class, tc.getClass());
        tc = TypeConverterRegistry.lookup(Double.TYPE);
        assertEquals(NumberTypeConverter.class, tc.getClass());

        tc = TypeConverterRegistry.lookup(Boolean.class);
        assertEquals(BooleanTypeConverter.class, tc.getClass());
        tc = TypeConverterRegistry.lookup(Boolean.TYPE);
        assertEquals(BooleanTypeConverter.class, tc.getClass());

        tc = TypeConverterRegistry.lookup(String.class);
        assertEquals(StringTypeConverter.class, tc.getClass());
    }

    /**
     * Tests lookup failures
     */
    public void testLookupFailures() {
        TypeConverter tc = TypeConverterRegistry.lookup(this.getClass());
        assertNull(tc);
    }

    /**
     * Tests registration and unregistration
     */
    public void testRegistration() {
        TypeConverter tc = new NumberTypeConverter();
        TypeConverterRegistry.register(this.getClass(), tc);
        assertSame(tc, TypeConverterRegistry.lookup(this.getClass()));

        TypeConverterRegistry.unregister(this.getClass());
        assertNull(TypeConverterRegistry.lookup(this.getClass()));
    }
}