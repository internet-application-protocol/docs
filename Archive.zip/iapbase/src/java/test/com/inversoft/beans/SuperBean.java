/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * This class is a simple JavaBean parent class
 *
 * @author  Brian Pontarelli
 */
public class SuperBean {

    private String fromSuper;

    /** Gets the FromSuper property */
    public String getFromSuper() {
        return fromSuper;
    }

    /** Sets the FromSuper property */
    public void setFromSuper(String value) {
        fromSuper = value;
    }
}

