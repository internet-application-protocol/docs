/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * This class is a simple JavaBean that is used in testing. This
 * Java bean does not have a default constructor.
 * 
 * @author  Brian Pontarelli
 */
public class Bean4 {

    private String string1;

    /** No default constructor */
    public Bean4(String name) {
        super();
    }

    /** Gets the String1 property */
    public String getString1() {
        return string1;
    }

    /** Sets the String1 property */
    public void setString1(String value) {
        string1 = value;
    }
}
