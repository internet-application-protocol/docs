/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * A simple test exception used in testing
 *
 * @author  Brian Pontarelli
 */
public class TestException extends Exception {

    public TestException() {
        super();
    }

    public TestException(String msg) {
        super(msg);
    }
}
