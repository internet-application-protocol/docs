/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import junit.framework.TestCase;

import com.inversoft.beans.types.TypeConversionException;


/**
 * This class contains all the tests for the IndexedBeanProperty
 * class in the jBeans package. Any new tests for that class
 * should be added here.
 *
 * @author  Brian Pontarelli
 */
public class IndexedBeanPropertyTest extends TestCase {

    /** Constructs a new test case for the IndexedBeanProperty class */
    public IndexedBeanPropertyTest(String name) {
        super(name);
    }

    /**
     * This tests the read only properties of a JavaBean using the BeanProperty
     * class.
     */
    public void testReadOnlyBeanProperty() {

        // Tests that the read only property returns the correct value
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("readOnlyIndexed", Bean1.class);

            assertEquals(prop.getPropertyValue(bean1, 0), "readOnly");
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Tests that the read only property fails correctly when being set
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("readOnlyIndexed", Bean1.class);

            // Should fail
            prop.setPropertyValue(bean1, 0, "foo", true);
            fail("Should have failed because read-only");
        } catch (BeanException be) {
            //System.err.println(be.toString());
            assertTrue("Should NOT have a root cause or target exception because this is read-only",
                be.getCause() == null && be.getTarget() == null);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the simple bean property getting and setting operations
     */
    public void testSimpleBeanProperty() {

        // Tests the bean property gets set correctly and no object mangling happens
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("stringIndexed", Bean1.class);
            String value = "foo";

            // Test the simple value setting
            prop.setPropertyValue(bean1, 0, value);

            // Test that the value getting is the same object reference
            assertSame("Should point to same object", bean1.getStringIndexed(0), value);
            assertSame("Should point to same object", prop.getPropertyValue(bean1, 0), value);
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the methods without indices fail.
     */
    public void testNonIndicesFail() {
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("stringIndexed", Bean1.class);

            prop.getPropertyValue(bean1);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }

        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("stringIndexed", Bean1.class);
            String value = "foo";

            prop.setPropertyValue(bean1, value, true);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
    }

    /**
     * Tests the methods with bad indices fail.
     */
    public void testBadIndicesFail() {
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("stringIndexed", Bean1.class);

            prop.getPropertyValue(bean1, "badIndex");
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }

        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("stringIndexed", Bean1.class);
            String value = "foo";

            prop.setPropertyValue(bean1, "foo", value, true);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
    }

    /**
     * Test setting null values into a JavaBean property and also tests the handling
     * of null values when auto-converting values when setting
     */
    public void testNullValue() {

        // Test the simple null value setting
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("stringIndexed", Bean1.class);
            String value = null;

            prop.setPropertyValue(bean1, 0, value, true);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test the non-simple null value setting with conversion
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("integerIndexed", Bean1.class);
            Integer value = null;

            prop.setPropertyValue(bean1, 0, value, true);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test the non-simple null value setting with conversion to boolean
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("booleanIndexed", Bean1.class);
            Object value = null;

            bean1.setBooleanIndexed(0, true);
            prop.setPropertyValue(bean1, 0, value, true);
            assertTrue("Should have been set to false", !bean1.isBoolean1());
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test the non-simple null value setting with conversion to primitive
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("intIndexed", Bean1.class);
            Object value = null;

            bean1.setIntIndexed(0, 42);
            prop.setPropertyValue(bean1, 0, value, true);
            assertTrue("Should have been set to 0", bean1.getInt1() == 0);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the auto-conversion of something simple like string to Integer
     */
    public void testAutoConversion() {

        // Tests a simple automatic conversion from a string to an integer
        try {
            Bean1 bean1 = new Bean1();
            IndexedBeanProperty prop = create("integerIndexed", Bean1.class);
            String value = "1024";

            prop.setPropertyValue(bean1, 0, value, true);

            assertTrue("Should have converted value to new Integer(1024)",
                       bean1.getIntegerIndexed(0).intValue() == 1024);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the invalid property failure
     */
    public void testInvalidProperty() {

        try {
            /*BeanProperty prop =*/ create("notAProperty", Bean1.class);
            fail("Should have failed because notAProperty does not exist");
        } catch (BeanException be) {
            assertTrue("Should have a root cause of NoSuchMethodException",
                be.getCause() != null && be.getCause() instanceof NoSuchMethodException);
            assertTrue("Should NOT have a target", be.getTarget() == null);
        }

        try {
            /*BeanProperty prop =*/ create("     ", Bean1.class);
            fail("Should have failed because the property is white space");
        } catch (BeanException be) {
            //System.err.println(be.toString());
            assertTrue("Should NOT have a root cause", be.getCause() == null);
            assertTrue("Should NOT have a target", be.getTarget() == null);
        }

        try {
            /*BeanProperty prop =*/ create("     a", Bean1.class);
            fail("Should have failed because the property starts with white space");
        } catch (BeanException be) {
            //System.err.println(be.toString());
            assertTrue("Should have a root cause of NoSuchMethodException",
                be.getCause() != null && be.getCause() instanceof NoSuchMethodException);
            assertTrue("Should NOT have a target", be.getTarget() == null);
        }

        try {
            /*BeanProperty prop =*/ create("", Bean1.class);
            fail("Should have failed because the property is empty");
        } catch (BeanException be) {
            //System.err.println(be.toString());
            assertTrue("Should NOT have a root cause", be.getCause() == null);
            assertTrue("Should NOT have a target", be.getTarget() == null);
        }
    }

    /**
     * Test that the cache lookup works correctly
     */
    public void testCache() {
        try {
            IndexedBeanProperty bp = IndexedBeanProperty.getIndexedInstance("indexed", Bean1.class);
            IndexedBeanProperty bp2 = IndexedBeanProperty.getIndexedInstance("indexed", Class.forName("com.inversoft.beans.Bean1"));
            IndexedBeanProperty bp3 = IndexedBeanProperty.getIndexedInstance("indexed", new Bean1().getClass());

            assertSame(bp, bp2);
            assertSame(bp, bp3);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (Exception e) {
            fail(e.toString());
        }

        try {
            IndexedBeanProperty.getIndexedInstance("foo.bar", Bean1.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
    }

    /**
     * Creates the IndexedBeanProperty to test. This can be overridden in sub-classes
     * to test other types of NestedBeanProperties.
     */
    protected IndexedBeanProperty create(String property, Class<?> bean)
    throws BeanException {
        return new IndexedBeanProperty(property, bean);
    }
}