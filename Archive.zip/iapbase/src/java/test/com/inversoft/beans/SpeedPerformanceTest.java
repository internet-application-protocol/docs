/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;

import junit.framework.TestCase;


/**
 * This class contains all speed performance tests for the
 * entire package.
 *
 * @author  Brian Pontarelli
 */
public class SpeedPerformanceTest extends TestCase {

    /** The number of iterations to do for each test */
    public static final int ITERATIONS = 10000;

    public SpeedPerformanceTest(String name) {
        super(name);
    }

    public void testBeanPropertyConstructorSpeed() {

        try {
            long timeBefore = System.currentTimeMillis();

            for (int i = 0; i < ITERATIONS; i++) {
                /*BeanProperty prop =*/ new BeanProperty("integer1", Bean1.class);
            }

            long timeAfter = System.currentTimeMillis();
            System.err.println("The number of millis for jBeans BeanProperty construction: "
                + (timeAfter - timeBefore));
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            long timeBefore = System.currentTimeMillis();

            for (int i = 0; i < ITERATIONS; i++) {
                /*PropertyDescriptor prop =*/ new PropertyDescriptor("integer1", Bean1.class);
            }

            long timeAfter = System.currentTimeMillis();
            System.err.println("The number of millis for java.beans PropertyDescriptor construcion: "
                + (timeAfter - timeBefore));
        } catch (IntrospectionException ie) {
            fail(ie.toString());
        }
    }

    public void testBeanPropertyReadSpeed() {

        try {
            Bean1 bean = new Bean1();
            BeanProperty prop = new BeanProperty("integer1", Bean1.class);
            long timeBefore = System.currentTimeMillis();

            for (int i = 0; i < ITERATIONS; i++) {
                prop.getPropertyValue(bean);
            }

            long timeAfter = System.currentTimeMillis();
            System.err.println("The number of millis for jBeans BeanProperty read: "
                + (timeAfter - timeBefore));
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean = new Bean1();
            PropertyDescriptor prop = new PropertyDescriptor("integer1", Bean1.class);
            Method method;
            long timeBefore = System.currentTimeMillis();

            for (int i = 0; i < ITERATIONS; i++) {
                try {
                    method = prop.getReadMethod();
                    method.invoke(bean, (Object[]) null);
                } catch (Exception e) {
                    fail(e.toString());
                }
            }

            long timeAfter = System.currentTimeMillis();
            System.err.println("The number of millis for java.beans PropertyDescriptor read: "
                + (timeAfter - timeBefore));
        } catch (IntrospectionException ie) {
            fail(ie.toString());
        }
    }

    public void testBeanPropertyWriteSpeed() {

        try {
            Bean1 bean = new Bean1();
            BeanProperty prop = new BeanProperty("integer1", Bean1.class);
            long timeBefore = System.currentTimeMillis();

            for (int i = 0; i < ITERATIONS; i++) {
                prop.setPropertyValue(bean, new Integer(42));
            }

            long timeAfter = System.currentTimeMillis();
            System.err.println("The number of millis for jBeans BeanProperty write: "
                + (timeAfter - timeBefore));
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean = new Bean1();
            PropertyDescriptor prop = new PropertyDescriptor("integer1", Bean1.class);
            Method method;
            long timeBefore = System.currentTimeMillis();

            for (int i = 0; i < ITERATIONS; i++) {
                try {
                    method = prop.getWriteMethod();
                    method.invoke(bean, new Object[]{new Integer(42)});
                } catch (Exception e) {
                    fail(e.toString());
                }
            }

            long timeAfter = System.currentTimeMillis();
            System.err.println("The number of millis for java.beans PropertyDescriptor write: "
                + (timeAfter - timeBefore));
        } catch (IntrospectionException ie) {
            fail(ie.toString());
        }
    }
}
