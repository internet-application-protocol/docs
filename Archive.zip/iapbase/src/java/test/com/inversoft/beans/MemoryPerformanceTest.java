/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


//import java.beans.*;
//import java.lang.reflect.*;

import junit.framework.TestCase;

//import com.inversoft.beans.*;


/**
 * This class contains all memory performance tests for the entire
 * package
 * @author  Brian Pontarelli
 */
public class MemoryPerformanceTest extends TestCase {

    public MemoryPerformanceTest(String name) {
        super(name);
    }

    public void testBeanPropertyMemory() {

        /*
        try {
            Bean1 bean = new Bean1();
            BeanProperty [] properties = new BeanProperty[ITERATIONS];
            Runtime runtime = Runtime.getRuntime();
            long memoryBefore = runtime.totalMemory() - runtime.freeMemory();

            for (int i = 0; i < ITERATIONS; i++) {
                properties[i] = new BeanProperty("integer1", Bean1.class);
            }

            long memoryAfter = runtime.totalMemory() - runtime.freeMemory();
            System.err.println("The number of bytes for 10,000 jBeans BeanProperty's: "
                + (memoryAfter - memoryBefore));
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean = new Bean1();
            PropertyDescriptor [] properties = new PropertyDescriptor[ITERATIONS];
            Runtime runtime = Runtime.getRuntime();
            long memoryBefore = runtime.totalMemory() - runtime.freeMemory();

            for (int i = 0; i < ITERATIONS; i++) {
                properties[i] = new PropertyDescriptor("integer1", Bean1.class);
            }

            long memoryAfter = runtime.totalMemory() - runtime.freeMemory();
            System.err.println("The number of bytes for 10,000 java.beans PropertyDescriptor's: "
                + (memoryAfter - memoryBefore));
        } catch (IntrospectionException ie) {
            fail(ie.toString());
        }
        */
    }
}
