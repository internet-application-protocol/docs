/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.lang.reflect.Method;
import java.util.List;

import junit.framework.TestCase;

import com.inversoft.util.ReflectionException;
import com.inversoft.util.ReflectionTools;


/**
 * This class contains all the tests for the JavaBeanTools
 * class. This should not directly test any other class.
 *
 * @author  Brian Pontarelli
 */
public class JavaBeanToolsTest extends TestCase {

    public JavaBeanToolsTest(String name) {
        super(name);
    }


    public void testInheritance() {

        try {
            Method method = JavaBeanTools.findReadMethod("fromSuper", Bean1.class);
            assertTrue("method should never be null", method != null);
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the retrieve of a property name from a method
     */
    public void testGetPropertyName() {
        try {
            Method method = ReflectionTools.getMethod(Bean1.class, "getProperty1", new Class[0]);
            assertEquals("property1", JavaBeanTools.getPropertyName(method));
            method = ReflectionTools.getMethod(Bean1.class, "setString1", new Class[]{String.class});
            assertEquals("string1", JavaBeanTools.getPropertyName(method));
            method = ReflectionTools.getMethod(Bean1.class, "isBoolean1", new Class[0]);
            assertEquals("boolean1", JavaBeanTools.getPropertyName(method));

            method = ReflectionTools.getMethod(Bean1.class, "get", new Class[0]);
            assertNull(JavaBeanTools.getPropertyName(method));
            method = ReflectionTools.getMethod(Bean1.class, "set", new Class[]{String.class});
            assertNull(JavaBeanTools.getPropertyName(method));
            method = ReflectionTools.getMethod(Bean1.class, "is", new Class[0]);
            assertNull(JavaBeanTools.getPropertyName(method));
        } catch (ReflectionException e) {
            fail(e.toString());
        }

        try {
            Method method = ReflectionTools.getMethod(Bean1.class, "notAProp", new Class[0]);
            assertNull(JavaBeanTools.getPropertyName(method));
        } catch (ReflectionException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests capitalization
     */
    public void testCapitalize() {
        assertEquals("UpperCase", JavaBeanTools.capitalize("upperCase"));
        assertEquals("URL", JavaBeanTools.capitalize("URL"));
        assertEquals("    a", JavaBeanTools.capitalize("    a"));
        assertEquals("Done", JavaBeanTools.capitalize("Done"));
    }

    /**
     * Tests making of JavaBean method names.
     */
    public void testMaking() {
        assertEquals("getFoo", JavaBeanTools.makeGetter("foo"));
        assertEquals("setFoo", JavaBeanTools.makeSetter("foo"));
        assertEquals("isFoo", JavaBeanTools.makeIs("foo"));
        assertEquals("handleFoo", JavaBeanTools.makeHandle("foo"));
    }

    /**
     * Tests the checking of methods
     */
    public void testChecking() {
        try {
            Method method = ReflectionTools.getMethod(Bean1.class, "getProperty1", new Class[0]);
            assertTrue(JavaBeanTools.isValidGetter(method));
            method = ReflectionTools.getMethod(Bean1.class, "setString1", new Class[]{String.class});
            assertTrue(JavaBeanTools.isValidSetter(method));
            method = ReflectionTools.getMethod(Bean1.class, "isBoolean1", new Class[0]);
            assertTrue(JavaBeanTools.isValidGetter(method));

            method = ReflectionTools.getMethod(Bean1.class, "get", new Class[0]);
            assertFalse(JavaBeanTools.isValidGetter(method));
            assertTrue(JavaBeanTools.isValidGetter(method, false));
            method = ReflectionTools.getMethod(Bean1.class, "set", new Class[]{String.class});
            assertFalse(JavaBeanTools.isValidSetter(method));
            assertTrue(JavaBeanTools.isValidSetter(method, false));
            method = ReflectionTools.getMethod(Bean1.class, "is", new Class[0]);
            assertFalse(JavaBeanTools.isValidGetter(method));
            assertTrue(JavaBeanTools.isValidGetter(method, false));

            method = ReflectionTools.getMethod(Bean1.class, "get", new Class[0]);
            assertFalse(JavaBeanTools.isValidGetter(method));
            assertFalse(JavaBeanTools.isValidGetter(method, true));
            method = ReflectionTools.getMethod(Bean1.class, "set", new Class[]{String.class});
            assertFalse(JavaBeanTools.isValidSetter(method));
            assertFalse(JavaBeanTools.isValidSetter(method, true));
            method = ReflectionTools.getMethod(Bean1.class, "is", new Class[0]);
            assertFalse(JavaBeanTools.isValidGetter(method));
            assertFalse(JavaBeanTools.isValidGetter(method, true));
        } catch (ReflectionException e) {
            fail(e.toString());
        }

        // Indexed methods
        try {
            Method method = ReflectionTools.getMethod(Bean1.class, "getStringIndexed", new Class[]{Integer.TYPE});
            assertTrue(JavaBeanTools.isValidIndexedGetter(method));
            method = ReflectionTools.getMethod(Bean1.class, "setStringIndexed", new Class[]{Integer.TYPE, String.class});
            assertTrue(JavaBeanTools.isValidIndexedSetter(method));
            method = ReflectionTools.getMethod(Bean1.class, "isBooleanIndexed", new Class[]{Integer.TYPE});
            assertTrue(JavaBeanTools.isValidIndexedGetter(method));

            method = ReflectionTools.getMethod(Bean1.class, "get", new Class[]{Integer.TYPE});
            assertFalse(JavaBeanTools.isValidIndexedGetter(method));
            assertTrue(JavaBeanTools.isValidIndexedGetter(method, false));
            method = ReflectionTools.getMethod(Bean1.class, "set", new Class[]{Integer.TYPE, String.class});
            assertFalse(JavaBeanTools.isValidIndexedSetter(method));
            assertTrue(JavaBeanTools.isValidIndexedSetter(method, false));
            method = ReflectionTools.getMethod(Bean1.class, "is", new Class[]{Integer.TYPE});
            assertFalse(JavaBeanTools.isValidIndexedGetter(method));
            assertTrue(JavaBeanTools.isValidIndexedGetter(method, false));

            method = ReflectionTools.getMethod(Bean1.class, "get", new Class[]{Integer.TYPE});
            assertFalse(JavaBeanTools.isValidIndexedGetter(method));
            assertFalse(JavaBeanTools.isValidIndexedGetter(method, true));
            method = ReflectionTools.getMethod(Bean1.class, "set", new Class[]{Integer.TYPE, String.class});
            assertFalse(JavaBeanTools.isValidIndexedSetter(method));
            assertFalse(JavaBeanTools.isValidIndexedSetter(method, true));
            method = ReflectionTools.getMethod(Bean1.class, "is", new Class[]{Integer.TYPE});
            assertFalse(JavaBeanTools.isValidIndexedGetter(method));
            assertFalse(JavaBeanTools.isValidIndexedGetter(method, true));
        } catch (ReflectionException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests the finding of methods.
     */
    public void testFind() {
        try {
            Method m1 = ReflectionTools.getMethod(Bean1.class, "getProperty1", new Class[0]);
            Method m2 = JavaBeanTools.findReadMethod("property1", Bean1.class);
            assertNotNull(m2);
            assertEquals(m1, m2);
            m1 = ReflectionTools.getMethod(Bean1.class, "setString1", new Class[]{String.class});
            m2 = JavaBeanTools.findWriteMethod("string1", Bean1.class, String.class);
            assertNotNull(m2);
            assertEquals(m1, m2);
            m1 = ReflectionTools.getMethod(Bean1.class, "isBoolean1", new Class[0]);
            m2 = JavaBeanTools.findReadMethod("boolean1", Bean1.class);
            assertNotNull(m2);
            assertEquals(m1, m2);
        } catch (ReflectionException e) {
            fail(e.toString());
        }

        // Indexed methods
        try {
            Method m1 = ReflectionTools.getMethod(Bean1.class, "getStringIndexed", new Class[]{Integer.TYPE});
            Method m2 = JavaBeanTools.findIndexedReadMethod("stringIndexed", Bean1.class);
            assertNotNull(m2);
            assertEquals(m1, m2);
            m1 = ReflectionTools.getMethod(Bean1.class, "setStringIndexed", new Class[]{Integer.TYPE, String.class});
            m2 = JavaBeanTools.findIndexedWriteMethod("stringIndexed", Bean1.class, String.class);
            assertNotNull(m2);
            assertEquals(m1, m2);
            m1 = ReflectionTools.getMethod(Bean1.class, "isBooleanIndexed", new Class[]{Integer.TYPE});
            m2 = JavaBeanTools.findIndexedReadMethod("booleanIndexed", Bean1.class);
            assertNotNull(m2);
            assertEquals(m1, m2);
        } catch (ReflectionException e) {
            fail(e.toString());
        }

        // Bad methods
        try {
            JavaBeanTools.findReadMethod("badProp", Bean1.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findWriteMethod("badProp", Bean1.class, String.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findReadMethod("badPropBool", Bean1.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findIndexedReadMethod("badProp", Bean1.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findIndexedWriteMethod("badProp", Bean1.class, String.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findIndexedReadMethod("badPropBool", Bean1.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }

        // Bad calls
        try {
            JavaBeanTools.findWriteMethod("badProp", Bean1.class, Void.TYPE);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findWriteMethod("badProp", Bean1.class, null);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findWriteMethod("   ", Bean1.class, String.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findIndexedWriteMethod("badProp", Bean1.class, Void.TYPE);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findIndexedWriteMethod("badProp", Bean1.class, null);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
        try {
            JavaBeanTools.findIndexedWriteMethod("   ", Bean1.class, String.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // expected
        }
    }

    /**
     * Tests spliting of names
     */
    public void testSplit() {
        JavaBeanTools.NameInfo ni = JavaBeanTools.splitNameBack("foo.bar.john");
        assertTrue(ni.indexOfDot != -1);
        assertTrue(ni.nested);
        assertEquals("foo.bar", ni.nestedPropertyName);
        assertEquals("john", ni.localPropertyName);
        ni = JavaBeanTools.splitNameBack("foo");
        assertTrue(ni.indexOfDot == -1);
        assertFalse(ni.nested);
        assertEquals(null, ni.nestedPropertyName);
        assertEquals("foo", ni.localPropertyName);

        ni = JavaBeanTools.splitNameFront("foo.bar.john");
        assertTrue(ni.indexOfDot != -1);
        assertTrue(ni.nested);
        assertEquals("bar.john", ni.nestedPropertyName);
        assertEquals("foo", ni.localPropertyName);
        ni = JavaBeanTools.splitNameFront("foo");
        assertTrue(ni.indexOfDot == -1);
        assertFalse(ni.nested);
        assertEquals(null, ni.nestedPropertyName);
        assertEquals("foo", ni.localPropertyName);

        String[] names = JavaBeanTools.splitNameComplete("foo.bar.john");
        assertEquals(3, names.length);
        assertEquals("foo", names[0]);
        assertEquals("bar", names[1]);
        assertEquals("john", names[2]);

        names = JavaBeanTools.splitNameComplete("bar");
        assertEquals(1, names.length);
        assertEquals("bar", names[0]);

        names = JavaBeanTools.splitNameComplete("");
        assertEquals(0, names.length);
    }

    /**
     * Tests the retrieval of property information.
     */
    public void testPropertyInfo() {
        new JavaBeanTools.PropertyInfo();
        try {
            JavaBeanTools.PropertyInfo pi =
                JavaBeanTools.retrievePropertyInfo("prop[0][\"foo\"]");
            assertEquals("prop", pi.propertyName);
            assertEquals(new Integer(0), pi.indices.get(0));
            assertEquals("foo", pi.indices.get(1));
        } catch (BeanException e) {
            fail(e.toString());
        }

        try {
            JavaBeanTools.retrievePropertyInfo("prop[0");
            fail("Should have failed");
        } catch (BeanException e) {
            // Expected
        }

        try {
            JavaBeanTools.retrievePropertyInfo("prop[\"0]");
            fail("Should have failed");
        } catch (BeanException e) {
            // Expected
        }

        try {
            JavaBeanTools.retrievePropertyInfo("prop['0]");
            fail("Should have failed");
        } catch (BeanException e) {
            // Expected
        }
    }

    /**
     * Tests the retrieval of property information in a list
     */
    public void testPropertyInfoList() {
        try {
            List list = JavaBeanTools.retrieveAllPropertyInfo("prop[0][\"foo\"].prop2[9]");
            assertEquals(2, list.size());

            JavaBeanTools.PropertyInfo pi1 = (JavaBeanTools.PropertyInfo) list.get(0);
            JavaBeanTools.PropertyInfo pi2 = (JavaBeanTools.PropertyInfo) list.get(1);
            assertEquals("prop", pi1.propertyName);
            assertEquals(new Integer(0), pi1.indices.get(0));
            assertEquals("foo", pi1.indices.get(1));

            assertEquals("prop2", pi2.propertyName);
            assertEquals(new Integer(9), pi2.indices.get(0));
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests the retrieval of property information in a list with single quotes.
     */
    public void testPropertyInfoListSinlgeQuote() {
        try {
            List list = JavaBeanTools.retrieveAllPropertyInfo("prop[0]['foo'].prop2[9]");
            assertEquals(2, list.size());

            JavaBeanTools.PropertyInfo pi1 = (JavaBeanTools.PropertyInfo) list.get(0);
            JavaBeanTools.PropertyInfo pi2 = (JavaBeanTools.PropertyInfo) list.get(1);
            assertEquals("prop", pi1.propertyName);
            assertEquals(new Integer(0), pi1.indices.get(0));
            assertEquals("foo", pi1.indices.get(1));

            assertEquals("prop2", pi2.propertyName);
            assertEquals(new Integer(9), pi2.indices.get(0));
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests the retrieval of property information in a list with no quotes.
     */
    public void testPropertyInfoListNoQuote() {
        try {
            List list = JavaBeanTools.retrieveAllPropertyInfo("prop[0][foo].prop2[9]");
            assertEquals(2, list.size());

            JavaBeanTools.PropertyInfo pi1 = (JavaBeanTools.PropertyInfo) list.get(0);
            JavaBeanTools.PropertyInfo pi2 = (JavaBeanTools.PropertyInfo) list.get(1);
            assertEquals("prop", pi1.propertyName);
            assertEquals(new Integer(0), pi1.indices.get(0));
            assertEquals("foo", pi1.indices.get(1));

            assertEquals("prop2", pi2.propertyName);
            assertEquals(new Integer(9), pi2.indices.get(0));
        } catch (BeanException e) {
            fail(e.toString());
        }
    }
}