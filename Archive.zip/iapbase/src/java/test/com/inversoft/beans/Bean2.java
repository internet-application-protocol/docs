/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * This class is a simple JavaBean that is used in testing.
 *
 * @author  Brian Pontarelli
 */
public class Bean2 {

    private Bean3 property2;
    private Bean3 [] indexed2 = new Bean3[1];
    private String name;

    /** Gets the property2 property */
    public Bean3 getProperty2() {
        return property2;
    }

    /** Sets the property2 property */
    public void setProperty2(Bean3 value) {
        this.property2 = value;
    }

    /** Gets the Name property */
    public String getName() {
        return name;
    }

    /** Sets the Name property */
    public void setName(String value) {
        name = value;
    }

    /** Gets the Indexed2 property */
    public Bean3 getIndexed2(int index) {
        return indexed2[index];
    }

    /** Sets the Indexed2 property */
    public void setIndexed2(int index, Bean3 value) {
        indexed2[index] = value;
    }
}
