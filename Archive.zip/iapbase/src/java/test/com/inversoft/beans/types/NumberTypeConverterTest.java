/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


import junit.framework.TestCase;


/**
 * This class handles all of the test cases for the Type
 * conversion support in the JBeans package.
 *
 * @author  Brian Pontarelli
 */
public class NumberTypeConverterTest extends TestCase {

    /** Construct and new test instance */
    public NumberTypeConverterTest(String name) {
        super(name);
    }

    /**
     * Tests the convertFromString method works with null values
     */
    public void testStringNull() {

        try {
            NumberTypeConverter c = new NumberTypeConverter();
            Object obj;

            obj = c.convertFromString(null, Byte.class);
            assertNull(obj);
            obj = c.convertFromString(null, Byte.TYPE);
            assertEquals(new Byte((byte) 0), obj);

            obj = c.convertFromString(null, Short.class);
            assertNull(obj);
            obj = c.convertFromString(null, Short.TYPE);
            assertEquals(new Short((short)0), obj);

            obj = c.convertFromString(null, Integer.class);
            assertNull(obj);
            obj = c.convertFromString(null, Integer.TYPE);
            assertEquals(new Integer(0), obj);

            obj = c.convertFromString(null, Long.class);
            assertNull(obj);
            obj = c.convertFromString(null, Long.TYPE);
            assertEquals(new Long(0), obj);

            obj = c.convertFromString(null, Float.class);
            assertNull(obj);
            obj = c.convertFromString(null, Float.TYPE);
            assertEquals(new Float(0), obj);

            obj = c.convertFromString(null, Double.class);
            assertNull(obj);
            obj = c.convertFromString(null, Double.TYPE);
            assertEquals(new Double(0), obj);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the convertFromString method works with String values
     */
    public void testString() {

        try {
            NumberTypeConverter c = new NumberTypeConverter();
            Object obj;

            obj = c.convertFromString("42", Byte.class);
            assertEquals(new Byte((byte) 42), obj);
            assertTrue(obj instanceof Byte);
            obj = c.convertFromString("42", Byte.TYPE);
            assertEquals(new Byte((byte) 42), obj);
            assertTrue(obj instanceof Byte);

            obj = c.convertFromString("1", Short.class);
            assertEquals(new Short((short) 1), obj);
            assertTrue(obj instanceof Short);
            obj = c.convertFromString("1", Short.TYPE);
            assertEquals(new Short((short) 1), obj);
            assertTrue(obj instanceof Short);

            obj = c.convertFromString("2", Integer.class);
            assertEquals(new Integer(2), obj);
            assertTrue(obj instanceof Integer);
            obj = c.convertFromString("2", Integer.TYPE);
            assertEquals(new Integer(2), obj);
            assertTrue(obj instanceof Integer);

            obj = c.convertFromString("3", Long.class);
            assertEquals(new Long(3), obj);
            assertTrue(obj instanceof Long);
            obj = c.convertFromString("3", Long.TYPE);
            assertEquals(new Long(3), obj);
            assertTrue(obj instanceof Long);

            obj = c.convertFromString("2.5", Float.class);
            assertEquals(new Float(2.5f), obj);
            assertTrue(obj instanceof Float);
            obj = c.convertFromString("2.5", Float.TYPE);
            assertEquals(new Float(2.5f), obj);
            assertTrue(obj instanceof Float);

            obj = c.convertFromString("3.14", Double.class);
            assertEquals(new Double(3.14), obj);
            assertTrue(obj instanceof Double);
            obj = c.convertFromString("3.14", Double.TYPE);
            assertEquals(new Double(3.14), obj);
            assertTrue(obj instanceof Double);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests that the convertFromString method fails when the type is bogus
     */
    public void testStringFail() {
        try {
            NumberTypeConverter c = new NumberTypeConverter();
            c.convertFromString("3.14", Object.class);
            fail("Should have failed");
        } catch (TypeConversionException tce) {
            // Expected
        }
    }

    /**
     * Tests the convertFromString method works with empty values
     */
    public void testStringEmpty() {

        try {
            NumberTypeConverter c = new NumberTypeConverter();
            Object obj;

            obj = c.convertFromString("  ", Byte.class);
            assertNull(obj);
            obj = c.convertFromString("  ", Byte.TYPE);
            assertEquals(new Byte((byte) 0), obj);

            obj = c.convertFromString(" ", Short.class);
            assertNull(obj);
            obj = c.convertFromString(" ", Short.TYPE);
            assertEquals(new Short((short)0), obj);

            obj = c.convertFromString("    ", Integer.class);
            assertNull(obj);
            obj = c.convertFromString("    ", Integer.TYPE);
            assertEquals(new Integer(0), obj);

            obj = c.convertFromString(" ", Long.class);
            assertNull(obj);
            obj = c.convertFromString(" ", Long.TYPE);
            assertEquals(new Long(0), obj);

            obj = c.convertFromString("", Float.class);
            assertNull(obj);
            obj = c.convertFromString("", Float.TYPE);
            assertEquals(new Float(0), obj);

            obj = c.convertFromString("", Double.class);
            assertNull(obj);
            obj = c.convertFromString("", Double.TYPE);
            assertEquals(new Double(0), obj);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }
}