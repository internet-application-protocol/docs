/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.util.List;

import junit.framework.TestCase;

import com.inversoft.beans.types.TypeConversionException;


/**
 * This class is the testing class for the listeners of the events
 * fired from the bean properties.
 *
 * @author  Brian Pontarelli
 */
public class ListenerTest extends TestCase {

    /** Constructs a new test instance */
    public ListenerTest(String name) {
        super(name);
    }

    /**
     * Tests the bean property listener methods from BaseBeanProperty
     */
    public void testListenerMethods() {
        try {
            BeanProperty prop = new BeanProperty("string1", Bean1.class);
            ListenerHelper l = new ListenerHelper();
            ListenerHelper l2 = new ListenerHelper();
            prop.addPropertyListener(l);
            prop.addPropertyListener(l2);

            List<PropertyListener> list = prop.getPropertyListeners();
            assertSame(l, list.get(0));
            assertSame(l2, list.get(1));

            prop.removePropertyListener(l);
            list = prop.getPropertyListeners();
            assertSame(l2, list.get(0));
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            BeanProperty prop = new BeanProperty("string1", Bean1.class);
            ListenerHelper l = new ListenerHelper();
            ListenerHelper l2 = new ListenerHelper();
            prop.addConversionListener(l);
            prop.addConversionListener(l2);

            List<ConversionListener> list = prop.getConversionListeners();
            assertSame(l, list.get(0));
            assertSame(l2, list.get(1));

            prop.removeConversionListener(l);
            list = prop.getConversionListeners();
            assertSame(l2, list.get(0));
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests that sub-classes can not fire incorrect types of events.
     */
    public void testBadSubClassEventType() {
        BeanProperty bp = new BeanProperty("foo", Bean1.class) {
            protected void initialize() throws BeanException {
            }

            public Object getPropertyValue(Object bean) throws BeanException {
                try {
                    fireConversionEvent(null, bean, null, null);
                    fail("Should have failed");
                } catch (IllegalArgumentException iae) {
                    // Expected
                }
                return null;
            }

            public void setPropertyValue(Object bean, Object value,
                    boolean convert)
            throws BeanException, TypeConversionException {
                try {
                    firePropertyEvent(null, bean, value, null, null);
                    fail("Should have failed");
                } catch (IllegalArgumentException iae) {
                    // Expected
                }
            }
        };
        ListenerHelper l = new ListenerHelper();
        bp.addPropertyListener(l);
        bp.addConversionListener(l);

        try {
            bp.setPropertyValue(null, null, true);
            bp.getPropertyValue(null);
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the bean property get
     */
    public void testBeanPropertyGet() {

        try {
            final Bean1 bean = new Bean1();
            BeanProperty prop = new BeanProperty("string1", Bean1.class);

            prop.addPropertyListener( new ListenerHelper() {
                    public void handleGet(PropertyEvent event) {
                        //System.err.println("Got get event 1");
                        assertTrue("Old value should be foo", event.getOldValue().equals("foo"));
                        assertTrue("New value should be foo", event.getNewValue().equals("foo"));
                        assertTrue("Bean should be bean", event.getBean() == bean);
                        assertEquals("string1", event.getFullName());
                        assertTrue("Property name should be string1", event.getPropertyName().equals("string1"));
                        assertTrue("Property type should be String", event.getPropertyType() == String.class);
                        assertTrue("Index should be -1", event.getIndex() == null);
                    }
                } );

            bean.setString1("foo");
            prop.getPropertyValue(bean);
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the bean property set
     */
    public void testBeanPropertySet() {

        try {
            final Bean1 bean = new Bean1();
            BeanProperty prop = new BeanProperty("string1", Bean1.class);

            prop.addPropertyListener( new ListenerHelper() {
                    public void handleSet(PropertyEvent event) {
                        //System.err.println("Got set event 1");
                        assertTrue("Old value should be foo", event.getOldValue().equals("foo"));
                        assertTrue("New value should be bar", event.getNewValue().equals("bar"));
                        assertTrue("Bean should be bean", event.getBean() == bean);
                        assertTrue("Property name should be string1", event.getPropertyName().equals("string1"));
                        assertTrue("Property type should be String", event.getPropertyType() == String.class);
                        assertTrue("Index should be -1", event.getIndex() == null);
                    }
                } );

            bean.setString1("foo");
            prop.setPropertyValue(bean, "bar");
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the bean property conversion listener
     */
    public void testBeanPropertyConversion() {

        try {
            final Bean1 bean = new Bean1();
            BeanProperty prop = new BeanProperty("integer1", Bean1.class);

            prop.addConversionListener( new ListenerHelper() {
                    public void handleSet(PropertyEvent event) {
                        //System.err.println("Got conversion set event 1");
                        assertNull("Old value should be null", event.getOldValue());
                        assertEquals("New value should be new Integer(\"1\")", new Integer(1), event.getNewValue());
                        assertSame("Bean should be bean", bean, event.getBean());
                        assertEquals("Property name should be integer1", "integer1", event.getPropertyName());
                        assertSame("Property type should be Integer", Integer.class, event.getPropertyType());
                        assertNull("Index should be -1", event.getIndex());
                    }

                    public void handlePreConversion(ConversionEvent event) {
                        //System.err.println("Got pre-conversion event 1");
                        assertEquals("Old value should be new String(\"1\")", "1", event.getOldValue());
                        assertNull("New value should be null", event.getNewValue());
                        assertSame("Bean should be bean", bean, event.getBean());
                        assertEquals("Property name should be integer1", "integer1", event.getPropertyName());
                        assertSame("Property type should be Integer", Integer.class, event.getPropertyType());
                    }

                    public void handlePostConversion(ConversionEvent event) {
                        //System.err.println("Got post-conversion event 1");
                        assertEquals("Old value should be new String(\"1\")", "1", event.getOldValue());
                        assertEquals("New value should be new Integer(\"1\")", new Integer(1), event.getNewValue());
                        assertSame("Bean should be bean", bean, event.getBean());
                        assertEquals("Property name should be integer1", "integer1", event.getPropertyName());
                        assertSame("Property type should be Integer", Integer.class, event.getPropertyType());
                    }
                } );

            prop.setPropertyValue(bean, "1", true);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the bean property failed conversion listener
     */
    public void testBeanPropertyFailedConversion() {

        try {
            final Bean1 bean = new Bean1();
            BeanProperty prop = new BeanProperty("integer1", Bean1.class);

            prop.addConversionListener( new ConversionListenerAdapter() {
                    public void handlePreConversion(ConversionEvent event) {
                        //System.err.println("Got pre-conversion event 2");
                        assertEquals("Old value should be new String(\"foo\")", "foo", event.getOldValue());
                        assertNull("New value should be new String(\"foo\")", event.getNewValue());
                        assertSame("Bean should be bean", bean, event.getBean());
                        assertEquals("Property name should be integer1", "integer1", event.getPropertyName());
                        assertSame("Property type should be Integer", Integer.class, event.getPropertyType());
                    }

                    public void handleFailedConversion(ConversionEvent event) {
                        //System.err.println("Got bad-conversion event 1");
                        assertEquals("Old value should be foo", "foo", event.getOldValue());
                        assertNull("New value should be foo", event.getNewValue());
                        assertSame("Bean should be bean", bean, event.getBean());
                        assertEquals("Property name should be integer1", "integer1", event.getPropertyName());
                        assertSame("Property type should be Integer", Integer.class, event.getPropertyType());
                    }
                } );

            prop.setPropertyValue(bean, "foo", true);
        } catch (TypeConversionException tce) {
            assertTrue("Should have a root cause of NumberFormatException",
                tce.getCause() instanceof NumberFormatException);
            //System.err.println(tce.toString());
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the indexed bean property get
     */
    public void testIndexedBeanPropertyGet() {

        try {
            final Bean1 bean = new Bean1();
            IndexedBeanProperty prop = new IndexedBeanProperty("stringIndexed", Bean1.class);

            prop.addPropertyListener( new ListenerHelper() {
                    public void handleGet(PropertyEvent event) {
                        //System.err.println("Got indexed get event 1");
                        assertTrue("Old value should be foo", event.getOldValue().equals("foo"));
                        assertTrue("New value should be foo", event.getNewValue().equals("foo"));
                        assertTrue("Bean should be bean", event.getBean() == bean);
                        assertTrue("Property name should be stringIndexed", event.getPropertyName().equals("stringIndexed"));
                        assertTrue("Property type should be String", event.getPropertyType() == String.class);
                        assertEquals("Index should be 0", new Integer(0), event.getIndex());
                    }
                } );

            bean.setStringIndexed(0, "foo");
            prop.getPropertyValue(bean, 0);
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the indexed bean property set
     */
    public void testIndexedBeanPropertySet() {

        try {
            final Bean1 bean = new Bean1();
            IndexedBeanProperty prop = new IndexedBeanProperty("stringIndexed", Bean1.class);

            prop.addPropertyListener( new ListenerHelper() {
                    public void handleSet(PropertyEvent event) {
                        //System.err.println("Got indexed set event 1");
                        assertTrue("Old value should be foo", event.getOldValue().equals("foo"));
                        assertTrue("New value should be bar", event.getNewValue().equals("bar"));
                        assertTrue("Bean should be bean", event.getBean() == bean);
                        assertTrue("Property name should be stringIndexed", event.getPropertyName().equals("stringIndexed"));
                        assertTrue("Property type should be String", event.getPropertyType() == String.class);
                        assertEquals("Index should be 0", new Integer(0), event.getIndex());
                    }
                } );

            bean.setStringIndexed(0, "foo");
            prop.setPropertyValue(bean, 0, "bar");
        } catch (BeanException be) {
            fail(be.toString());
        }
    }
}