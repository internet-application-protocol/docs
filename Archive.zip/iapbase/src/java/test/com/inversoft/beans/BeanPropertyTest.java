/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.lang.reflect.InvocationTargetException;

import junit.framework.TestCase;

import com.inversoft.beans.types.TypeConversionException;


/**
 * This class contains all the tests for the BeanProperty
 * class.
 *
 * @author  Brian Pontarelli
 */
public class BeanPropertyTest extends TestCase {

    /**
     * Constructs a new test case for the BeanProperty class
     */
    public BeanPropertyTest(String name) {
        super(name);
    }


    /**
     * This tests the read only properties of a JavaBean using the BeanProperty
     * class.
     */
    public void testReadOnlyBeanProperty() {

        // Tests that the read only property returns the correct value
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("readOnly", Bean1.class);

            assertTrue("Should return readOnly", prop.getPropertyValue(bean1).equals("readOnly"));

        } catch (BeanException be) {
            fail(be.toString());
        }

        // Tests that the read only property fails correctly when being set
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("readOnly", Bean1.class);

            // Should fail
            prop.setPropertyValue(bean1, "foo", true);
            fail("Should have failed because read-only");

        } catch (BeanException be) {
            //System.err.println(be.toString());
            assertTrue("Should NOT have a root cause or target exception because this is read-only",
                be.getCause() == null && be.getTarget() == null);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * This tests the instantiation in the BaseBeanProperty class.
     */
    public void testInstantiation() {
        try {
            BeanProperty prop = create("readOnly", Bean1.class);
            Bean1 bean1 = (Bean1) prop.instantiate();
            assertNotNull(bean1);
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the simple bean property getting and setting operations
     */
    public void testSimpleBeanProperty() {

        // Tests the bean property gets set correctly and no object mangling happens
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("string1", Bean1.class);
            String value = "foo";

            // Test the simple value setting
            prop.setPropertyValue(bean1, value);

            // Test that the value getting is the same object reference
            assertTrue("Should point to same object", prop.getPropertyValue(bean1) == value);
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Test setting null values into a JavaBean property and also tests the handling
     * of null values when auto-converting values when setting
     */
    public void testNullValue() {

        // Test the simple null value setting
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("string1", Bean1.class);
            String [] values = null;

            bean1.setString1("foo");
            prop.setPropertyValue(bean1, values, true);
            assertNull(bean1.getString1());
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test the non-simple null value setting with conversion
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("integer1", Bean1.class);
            String [] values = null;

            bean1.setInteger1(1);
            prop.setPropertyValue(bean1, values, true);
            assertNull(bean1.getInteger1());
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test the non-simple null value setting with conversion to boolean
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("boolean1", Bean1.class);
            Object value = null;

            bean1.setBoolean1(true);
            prop.setPropertyValue(bean1, value, true);
            assertTrue("Should have been set to false", !bean1.isBoolean1());
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test the non-simple null value setting with conversion to primitive
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("int1", Bean1.class);
            Object value = null;

            bean1.setInt1(42);
            prop.setPropertyValue(bean1, value, true);
            assertTrue("Should have been set to 0", bean1.getInt1() == 0);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test the non-simple null value setting with conversion to primitive
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("char1", Bean1.class);
            Object value = null;

            bean1.setChar1('a');
            prop.setPropertyValue(bean1, value, true);
            assertTrue("Should have been set to \u0000", bean1.getChar1() == '\u0000');
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the auto-conversion of something simple like string to Integer
     */
    public void testAutoConversion() {

        // Tests a simple automatic conversion from a string to an integer
        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("integer1", Bean1.class);
            String value = "1024";

            prop.setPropertyValue(bean1, value, true);

            assertTrue("Should have converted value to new Integer(1024)",
                       bean1.getInteger1().intValue() == 1024);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the overridden constructor
     */
    public void testSecondConstructor() {

        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("integer1", Bean1.class);
            String value = "1024";

            prop.setPropertyValue(bean1, value, true);

            assertTrue("Should have converted value to new Integer(1024)",
                       bean1.getInteger1().intValue() == 1024);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the invalid property failure
     */
    public void testInvalidProperty() {

        try {
            /*BeanProperty prop =*/ create("notAProperty", Bean1.class);
            fail("Should have failed because notAProperty does not exist");
        } catch (BeanException be) {
            assertTrue("Should have a root cause of NoSuchMethodException",
                be.getCause() != null && be.getCause() instanceof NoSuchMethodException);
            assertTrue("Should NOT have a target", be.getTarget() == null);
        }

        /*
        */
        try {
            /*BeanProperty prop =*/ create("     ", Bean1.class);
            fail("Should have failed because the property is white space");
        } catch (BeanException be) {
            //System.err.println(be.toString());
            assertTrue("Should NOT have a root cause", be.getCause() == null);
            assertTrue("Should NOT have a target", be.getTarget() == null);
        }

        try {
            /*BeanProperty prop =*/ create("     a", Bean1.class);
            fail("Should have failed because the property starts with white space");
        } catch (BeanException be) {
            //System.err.println(be.toString());
            assertTrue("Should have a root cause of NoSuchMethodException",
                be.getCause() != null && be.getCause() instanceof NoSuchMethodException);
            assertTrue("Should NOT have a target", be.getTarget() == null);
        }

        try {
            /*BeanProperty prop =*/ create("", Bean1.class);
            fail("Should have failed because the property is empty");
        } catch (BeanException be) {
            //System.err.println(be.toString());
            assertTrue("Should NOT have a root cause", be.getCause() == null);
            assertTrue("Should NOT have a target", be.getTarget() == null);
        }
    }

    /**
     * Tests the property that throws exception failure
     */
    public void testExceptionalProperty() {

        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("throwsAnException", Bean1.class);

            prop.getPropertyValue(bean1);
            fail("Should have failed because throwsAnException throws a TestException");
        } catch (BeanException be) {
            assertTrue("Should have a root cause of InvocationTargetException",
                be.getCause() instanceof InvocationTargetException);
            assertTrue("Should have a target of TestException",
                be.getTarget() instanceof TestException);
        }

        try {
            Bean1 bean1 = new Bean1();
            BeanProperty prop = create("throwsAnException", Bean1.class);

            prop.setPropertyValue(bean1, "foo");
            fail("Should have failed because throwsAnException throws a TestException");
        } catch (BeanException be) {
            assertTrue("Should have a root cause of InvocationTargetException",
                be.getCause() instanceof InvocationTargetException);
            assertTrue("Should have a target of TestException",
                be.getTarget() instanceof TestException);
        }
    }

    /**
     * Tests the property that is not accessible
     */
    public void testNonAccessibleProperty() {

        try {
            /*BeanProperty prop =*/ create("notAccessible", Bean1.class);
            fail("Should have failed because notAccessible is private");
        } catch (BeanException be) {
            assertTrue("Should have a root cause of NoSuchMethodException",
                be.getCause() instanceof NoSuchMethodException);
        }
    }

    /**
     * Tests the index methods fail
     */
    public void testIndexOnly() {

        try {
            BeanProperty prop = create("string1", Bean1.class);
            prop.getPropertyValue(new Bean1(), "key");
            fail("Should have failed because key operation not supported");
        } catch (BeanException be) {
            // Expected
        }
    }

    /**
     * Test that the cache lookup works correctly
     */
    public void testCache() {
        try {
            BeanProperty bp = BeanProperty.getInstance("string1", Bean1.class);
            BeanProperty bp2 = BeanProperty.getInstance("string1", Class.forName("com.inversoft.beans.Bean1"));
            BeanProperty bp3 = BeanProperty.getInstance("string1", new Bean1().getClass());

            assertSame("Shoudl be same object instance", bp, bp2);
            assertSame("Shoudl be same object instance", bp, bp3);
        } catch (BeanException be) {
            fail(be.toString());
        } catch (Exception e) {
            fail(e.toString());
        }

        try {
            BeanProperty.getInstance("", Bean1.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // Expected
        }

        try {
            BeanProperty.getInstance("foo.bar", Bean1.class);
            fail("Should have failed");
        } catch (BeanException be) {
            // Expected
        }
    }

    /**
     * Creates the BeanProperty to test. This can be overridden in sub-classes
     * to test other types of NestedBeanProperties.
     */
    protected BeanProperty create(String property, Class<?> bean)
    throws BeanException {
        return new BeanProperty(property, bean);
    }
}