/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import junit.framework.TestCase;

import com.inversoft.beans.types.TypeConversionException;


/**
 * This class contains all the tests for the JavaBean class.
 * This should not directly test any other class.
 *
 * @author  Brian Pontarelli
 */
public class JavaBeanTest extends TestCase {

    /** Constructs a new test instance */
    public JavaBeanTest(String name) {
        super(name);
    }


    /**
     * Tests the adding of a local property to the JavaBean
     */
    public void testGetLocalProperty() {
        try {
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1");
            BaseBeanProperty bp = jb.getBeanProperty("property1");
            assertTrue("Should never be null", bp != null);
        } catch (BeanException e) {
            fail(e.toString());
        }

        try {
            JavaBean jb = JavaBean.getInstance(Bean1.class);
            jb.getBeanProperty("property1");
            BaseBeanProperty bp = jb.getBeanProperty("property1");
            assertTrue("Should never be null", bp != null);
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests the adding of a deep property to the JavaBean
     */
    public void testGetDeepProperty() {

        // Tests the adding of a deep property
        try {
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
        } catch (BeanException e) {
            fail(e.toString());
        }

        try {
            JavaBean jb = new JavaBean(Bean1.class);
            //System.err.println("START");
            jb.getBeanProperty("property1");
            jb.getBeanProperty("property1.property2");
            jb.getBeanProperty("property1.property2.property3");
            //System.err.println("END");
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests that the JavaBean instances for children are correct
     */
    public void testChildJavaBeans() {

        // Tests the adding of a deep property and then getting the child java bean
        // instances out and tests them
        try {
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
            JavaBean c1 = jb.getChildJavaBean("property1");
            assertTrue("children should never be null", c1 != null);
            assertTrue("children should be of type Bean2", c1.getBeanClass() == Bean2.class);
            JavaBean c2 = jb.getChildJavaBean("property1.property2");
            assertTrue("children should never be null 2", c2 != null);
            assertTrue("children should be of type Bean3", c2.getBeanClass() == Bean3.class);
            JavaBean c3 = jb.getChildJavaBean("property1.property2.property3");
            assertTrue("children should never be null 3", c3 != null);
            assertTrue("children should be of type String", c3.getBeanClass() == String.class);
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests that the bean property instances for nested properties are correct
     */
    public void testChildBeanProperties() {

        // Tests the adding of a deep property and then getting the child bean property
        // instances out and tests them
        try {
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
            BaseBeanProperty bp = jb.getBeanProperty("property1");
            assertTrue("Should never be null", bp != null);
            assertTrue("Should be of type Bean2", bp.getPropertyType() == Bean2.class);
            BaseBeanProperty bp2 = jb.getBeanProperty("property1.property2");
            assertTrue("Should never be null 2", bp2 != null);
            assertTrue("Should be of type Bean3", bp2.getPropertyType() == Bean3.class);
            BaseBeanProperty bp3 = jb.getBeanProperty("property1.property2.property3");
            assertTrue("Should never be null 3", bp3 != null);
            assertTrue("Should be of type String", bp3.getPropertyType() == String.class);
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests the child beans that don't exist cause the correct errors
     */
    public void testChildJavaBeanErrors() {

        try {
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property2");
            fail("Should have failed because Bean1 has no property2");
        } catch (BeanException e) {
            //System.err.println("Good! " + e.toString());
            assertTrue("Should have a root cause of NoSuchMethodException",
                e.getCause() != null && e.getCause() instanceof NoSuchMethodException);
        }

        try {
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property3");
            fail("Should have failed because Bean2 has no property3");
        } catch (BeanException e) {
            //System.err.println("Good! " + e.toString());
            assertTrue("Should have a root cause of NoSuchMethodException",
                e.getCause() != null && e.getCause() instanceof NoSuchMethodException);
            assertTrue("Should NOT have a target", e.getTarget() == null);
        }
    }

    /**
     * Tests that get all properties method.
     */
    public void testAllBeanProperties() {
        try {
            JavaBean jb = new JavaBean(Bean4.class);
            List<BeanProperty> props = jb.getAllBeanProperties();
            assertEquals(1, props.size());
            assertEquals("string1", props.get(0).getPropertyName());
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests getting of local bean properties
     */
    public void testLocalGetting() {

        // Test local property null
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1");
            assertTrue("Should be null", jb.getPropertyValue("property1", bean, true) == null);
        } catch (BeanException e) {
            fail(e.toString());
        }

        // Test local property get
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            bean.setProperty1(bean2);
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1");
            assertTrue("Should be bean2 using prepopulated JavaBean",
                       jb.getPropertyValue("property1", bean) == bean2);
        } catch (BeanException e) {
            fail(e.toString());
        }

        // Test local property without add
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            bean.setProperty1(bean2);
            JavaBean jb = new JavaBean(Bean1.class);
            assertTrue("Should be bean2 using prepopulated JavaBean again",
                       jb.getPropertyValue("property1", bean) == bean2);
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests getting of nested bean properties
     */
    public void testNestedGetting() {

        // Test a nested property failure
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
            jb.getPropertyValue("property1.property2.property3", bean, true);
            fail("Should have error out because property1 is null");
        } catch (BeanException e) {
           // System.err.println("Good! " + e.toString());
            assertTrue("Should not have a root cause or target",
                e.getCause() == null && e.getTarget() == null);
        }

        // Test a nested property get using instance of operator
        try {
            Bean1 bean = new Bean1();
            bean.setProperty1(new Bean2());
            bean.getProperty1().setProperty2(new Bean3());
            bean.getProperty1().getProperty2().setProperty3("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
            Object obj = jb.getPropertyValue("property1.property2", bean);
            assertTrue("Should be a Bean3 instance prepopulated JavaBean", obj instanceof Bean3);
        } catch (BeanException e) {
            //e.printStackTrace();
            fail(e.toString());
        }

        // Test a nested property get
        try {
            Bean1 bean = new Bean1();
            bean.setProperty1(new Bean2());
            bean.getProperty1().setProperty2(new Bean3());
            bean.getProperty1().getProperty2().setProperty3("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
            String value = (String) jb.getPropertyValue("property1.property2.property3", bean);
            assertTrue("Should be foo using prepopulated JavaBean", value.equals("foo"));
        } catch (BeanException e) {
            //e.printStackTrace();
            fail(e.toString());
        }

        // Test a nested property get without add
        try {
            Bean1 bean = new Bean1();
            bean.setProperty1(new Bean2());
            bean.getProperty1().setProperty2(new Bean3());
            bean.getProperty1().getProperty2().setProperty3("foo");

            JavaBean jb = new JavaBean(Bean1.class);
            String value = (String) jb.getPropertyValue("property1.property2.property3", bean);
            assertTrue("Should be foo using prepopulated JavaBean", value.equals("foo"));
        } catch (BeanException e) {
            //e.printStackTrace();
            fail(e.toString());
        }
    }

    /**
     * Tests the setting of nested bean properties
     */
    public void testLocalSetting() {

        // Test local set null
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            bean.setProperty1(new Bean2());
            jb.getBeanProperty("property1");
            jb.setPropertyValue("property1", bean, null, /*convert=*/false, true);
            assertTrue("Should have been set to null", bean.getProperty1() == null);
        } catch (BeanException e) {
            fail(e.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test local set success
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1");
            jb.setPropertyValue("property1", bean, bean2);
            assertTrue("Should be set to same object", bean.getProperty1() == bean2);
        } catch (BeanException e) {
            fail(e.toString());
        }

        // Test local set without add
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.setPropertyValue("property1", bean, bean2);
            assertTrue("Should be set to same object", bean.getProperty1() == bean2);
        } catch (BeanException e) {
            fail(e.toString());
        }
    }

    /**
     * Tests the setting of nested bean properties
     */
    public void testNestedSetting() {

        // Test nested set failure
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
            jb.setPropertyValue("property1.property2.property3", bean, "foo", /*convert=*/false, true);
            fail("Should have error out because property1 is null");
        } catch (BeanException e) {
            //System.err.println("Good! " + e.toString());
            assertTrue("Should not have a root cause or target",
                e.getCause() == null && e.getTarget() == null);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test nested set success
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
            jb.setPropertyValue("property1.property2.property3", bean, "foo", /*convert=*/false);
            assertTrue("Should be set to foo", bean.getProperty1().getProperty2().getProperty3().equals("foo"));
        } catch (BeanException e) {
            fail(e.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test nested set partials
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("property1.property2.property3");
            jb.setPropertyValue("property1", bean, new Bean2(), /*convert=*/false);
            assertTrue("Should have a bean2", bean.getProperty1() != null);
            assertTrue("Should not have a bean3", bean.getProperty1().getProperty2() == null);
        } catch (BeanException e) {
            fail(e.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test nested set without add
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.setPropertyValue("property1.property2.property3", bean, "foo", /*convert=*/false);
            assertTrue("Should be set to foo", bean.getProperty1().getProperty2().getProperty3().equals("foo"));
        } catch (BeanException e) {
            fail(e.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the getting of indexed properties
     */
    public void testGettingIndexed() {

        // Test a simple local property
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            bean.setIndexed(0, bean2);
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed");
            assertTrue("Should be same object", jb.getPropertyValue("indexed[0]", bean) == bean2);
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test a indexed property
        try {
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setName("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.name");
            assertTrue("Should be foo", jb.getPropertyValue("indexed[0].name", bean).equals("foo"));
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test a indexed property failure
        try {
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setName("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.name");
            jb.getPropertyValue("indexed[1].name", bean, true);
            fail("Should have errored out because indexed[1] is null");
        } catch (BeanException be) {
            //System.err.println("Good! " + be.toString());
            assertTrue("Should not have a root cause or target",
                be.getCause() == null && be.getTarget() == null);
        }

        // Test a deep indexed property
        try {
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setProperty2(new Bean3());
            bean.getIndexed(0).getProperty2().setProperty3("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.property2.property3");
            assertTrue("Should have been foo",
                       jb.getPropertyValue("indexed[0].property2.property3", bean, true).equals("foo"));
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the getting of indexed properties with indices
     */
    public void testGettingIndexedIndices() {

        // Test a simple local property
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            bean.setIndexed(0, bean2);
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed");
            assertTrue("Should be same object", jb.getPropertyValue("indexed", bean, new int[][]{{0}}) == bean2);
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test a indexed property
        try {
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setName("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.name");
            assertTrue("Should be foo", jb.getPropertyValue("indexed.name", bean, new int[][]{{0}}).equals("foo"));
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test a indexed property failure
        try {
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setName("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.name");
            jb.getPropertyValue("indexed.name", bean, true, new int[][]{{1}});
            fail("Should have errored out because indexed[1] is null");
        } catch (BeanException be) {
            //System.err.println("Good! " + be.toString());
            assertTrue("Should not have a root cause or target",
                be.getCause() == null && be.getTarget() == null);
        }

        // Test a deep indexed property
        try {
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setProperty2(new Bean3());
            bean.getIndexed(0).getProperty2().setProperty3("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.property2.property3");
            assertEquals("foo", jb.getPropertyValue("indexed.property2.property3",
                bean, true, new int[][]{{0}}));
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test a double deep indexed property
        try {
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setIndexed2(0, new Bean3());
            bean.getIndexed(0).getIndexed2(0).setProperty3("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.indexed2.property3");
            assertEquals("foo", jb.getPropertyValue("indexed.indexed2.property3",
                bean, true, new int[][]{{0}, {0}}));
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test a double deep indexed property with list
        try {
            List<List<Object>> list = new ArrayList<List<Object>>();
            List<Object> list1 = new ArrayList<Object>();
            List<Object> list2 = new ArrayList<Object>();
            list.add(list1);
            list.add(list2);
            list1.add(new Integer(0));
            list2.add(new Integer(0));
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setIndexed2(0, new Bean3());
            bean.getIndexed(0).getIndexed2(0).setProperty3("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.indexed2.property3");
            assertEquals("foo", jb.getPropertyValue("indexed.indexed2.property3",
                bean, true, list));
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test a double deep indexed property with list failure
        try {
            List<List<Object>> list = new ArrayList<List<Object>>();
            List<Object> list1 = new ArrayList<Object>();
            List<Object> list2 = new ArrayList<Object>();
            list.add(list1);
            list.add(list2);
            list1.add(new Integer(0));
            list2.add(new String("foo"));
            Bean1 bean = new Bean1();
            bean.setIndexed(0, new Bean2());
            bean.getIndexed(0).setIndexed2(0, new Bean3());
            bean.getIndexed(0).getIndexed2(0).setProperty3("foo");
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.indexed2.property3");
            jb.getPropertyValue("indexed.indexed2.property3", bean, true, list);
            fail("Should have thrown an exception because the indices list contains a String");
        } catch (BeanException be) {
            System.err.println(be.toString());
            assertTrue("Should not have a root cause or target", be.getCause() == null && be.getTarget() == null);
        }
    }

    /**
     * Tests the setting of indexed properties
     */
    public void testSettingIndexed() {

        // Test a local set
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed");
            jb.setPropertyValue("indexed[0]", bean, bean2, false, true);
            assertTrue("Should be same object", bean.getIndexed(0) == bean2);
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test a indexed set failure
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.name");
            jb.setPropertyValue("indexed[0].name", bean, "foo", true, true);
            fail("Should have thrown and exception because indexed[0] is null");
        } catch (BeanException be) {
            //System.out.println("Good! " + be.toString());
            assertTrue("Should not have a root cause or target",
                be.getCause() == null && be.getTarget() == null);
        }

        // Test a indexed set success
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.name");
            jb.setPropertyValue("indexed[0].name", bean, "foo", false);
            assertTrue("Should be foo", bean.getIndexed(0).getName().equals("foo"));
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test conversions
        try {
            Bean1 bean = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);
            jb.getBeanProperty("indexed.property2.integer3");
            jb.setPropertyValue("indexed[0].property2.integer3", bean, "16", true, false);
            assertTrue("Should be 16", bean.getIndexed(0).getProperty2().getInteger3().equals(new Integer(16)));
        } catch (BeanException be) {
            fail(be.toString());
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }
    }

    /**
     * Tests the instantiate method
     */
    public void testInstantiate() {

        try {
            JavaBean jb = new JavaBean(Bean1.class);
            Object bean1 = jb.instantiate();
            assertTrue("Should be an instance of Bean1", bean1 instanceof Bean1);
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests the setting of indexed properties
     */
    public void testIndexedProperty() {

        // Test using the getIndexedBeanProperty method
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);
            IndexedBeanProperty ibp = jb.getIndexedBeanProperty("indexed");
            jb.setPropertyValue("indexed[0]", bean, bean2, true, true);
            assertSame(bean2, ibp.getPropertyValue(bean, 0));
        } catch (BeanException be) {
            be.printStackTrace();
            fail(be.toString());
        }

        // Test a using the isBeanPropertyIndexed method
        try {
            JavaBean jb = new JavaBean(Bean1.class);
            assertTrue("Should be indexed", jb.isBeanPropertyIndexed("indexed"));
        } catch (BeanException be) {
            be.printStackTrace();
            fail(be.toString());
        }

        // Test using the getIndexedBeanProperty method deep
        try {
            Bean1 bean = new Bean1();
            Bean2 bean2 = new Bean2();
            Bean3 bean3 = new Bean3();
            JavaBean jb = new JavaBean(Bean1.class);
            IndexedBeanProperty ibp = jb.getIndexedBeanProperty("property1.indexed2");

            bean.setProperty1(bean2);
            jb.setPropertyValue("property1.indexed2[0]", bean, bean3, true, true);
            assertTrue("Should be same object", ibp.getPropertyValue(bean2, 0) == bean3);
        } catch (BeanException be) {
            be.printStackTrace();
            fail(be.toString());
        }

        // Test using the isBeanPropertyIndexed method deep
        try {
            JavaBean jb = new JavaBean(Bean1.class);
            assertTrue("Should be indexed", jb.isBeanPropertyIndexed("property1.indexed2"));
        } catch (BeanException be) {
            be.printStackTrace();
            fail(be.toString());
        }
    }

    /**
     * Tests single array retrieval locally and nested
     */
    public void testSingleArrayGet() {
        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.getSingleArray()[0] = bean2;

            assertSame(bean2, jb.getPropertyValue("singleArray[0]", bean1));
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.getSingleArray()[0] = bean2;
            bean2.setName("fred");

            assertEquals("Should have value fred", jb.getPropertyValue("singleArray[0].name", bean1), "fred");
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test failure
        try {
            Bean1 bean1 = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);

            jb.getPropertyValue("singleArray[0].name", bean1, true);
            fail("Should have failed because of strictness");
        } catch (BeanException be) {
            // Smother
        }

        try {
            Bean1 bean1 = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);

            assertNull("Should have value null", jb.getPropertyValue("singleArray[0].name", bean1));
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.getSingleArray()[0] = bean2;

            assertNull("Should be null in nesting", jb.getPropertyValue("singleArray[0].name", bean1));
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests single array setting locally and nested
     */
    public void testSingleArraySet() {
        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            jb.setPropertyValue("singleArray[0]", bean1, bean2, true, true);
            assertEquals("Should have value bean2", bean1.getSingleArray()[0], bean2);
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.getSingleArray()[0] = bean2;

            jb.setPropertyValue("singleArray[0].name", bean1, "fred", true, true);
            assertEquals("Should have value fred", bean1.getSingleArray()[0].getName(), "fred");
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test failure
        try {
            Bean1 bean1 = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);

            jb.setPropertyValue("singleArray[0].name", bean1, "fred", true, true);
            fail("Should have failed because of strictness");
        } catch (BeanException be) {
            // Smother
        }

        // Test creation of the array
        try {
            Bean1 bean1 = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setSingleArray(null);

            jb.setPropertyValue("singleArray[2].name", bean1, "fred", true, false);
            assertEquals("Should have an array of length 3", bean1.getSingleArray().length, 3);
            assertNotNull("Should have a Bean2 at index 2", bean1.getSingleArray()[2]);
            assertEquals("Should be fred", bean1.getSingleArray()[2].getName(), "fred");
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test creation of the array using Object
        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setSingleArrayObject(null);

            jb.setPropertyValue("singleArrayObject[2]", bean1, bean2, true, false);
            assertEquals("Should have an array of length 3", bean1.getSingleArrayObject().length, 3);
            assertNotNull("Should have a Bean2 at index 2", bean1.getSingleArrayObject()[2]);
            assertTrue("Should have a Bean2 at index 2", bean1.getSingleArrayObject()[2] instanceof Bean2);
            assertEquals("Should be fred", bean1.getSingleArrayObject()[2], bean2);
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test Object failure
        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setSingleArrayObject(null);

            jb.setPropertyValue("singleArrayObject[2].name", bean1, bean2, true, false);
            fail("Should have failed because name is not on Object");
        } catch (BeanException be) {
            System.out.println(be.toString());
        }
    }

    /**
     * Tests multi array retrieval locally and nested
     */
    public void testMultiArrayGet() {
        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArray(new Bean2[1][2][3]);
            bean1.getMultiArray()[0][1][2] = bean2;

            assertEquals("Should have value bean2", jb.getPropertyValue("multiArray[0][1][2]", bean1), bean2);
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArray(new Bean2[1][2][5]);
            bean1.getMultiArray()[0][1][4] = bean2;
            bean2.setName("fred");

            assertEquals("Should have value fred", jb.getPropertyValue("multiArray[0][1][4].name", bean1), "fred");
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test failure
        try {
            Bean1 bean1 = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);

            jb.getPropertyValue("multiArray[0].name", bean1, true);
            fail("Should have failed because of strictness");
        } catch (BeanException be) {
            // Smother
        }

        try {
            Bean1 bean1 = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);

            assertNull("Should have value null", jb.getPropertyValue("multiArray[0][1][1].name", bean1));
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArray(new Bean2[3][1][6]);
            bean1.getMultiArray()[2][0][5] = bean2;

            assertNull("Should be null in nesting", jb.getPropertyValue("multiArray[2][0][5].name", bean1));
        } catch (BeanException be) {
            fail(be.toString());
        }
    }

    /**
     * Tests single array setting locally and nested
     */
    public void testMultiArraySet() {
        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArray(new Bean2[1][4][2]);
            jb.setPropertyValue("multiArray[0][3][1]", bean1, bean2, true, true);
            assertEquals("Should have value bean2", bean1.getMultiArray()[0][3][1], bean2);
        } catch (BeanException be) {
            fail(be.toString());
        }

        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArray(new Bean2[1][3][5]);
            bean1.getMultiArray()[0][2][4] = bean2;

            jb.setPropertyValue("multiArray[0][2][4].name", bean1, "fred", true, true);
            assertEquals("Should have value fred", bean1.getMultiArray()[0][2][4].getName(), "fred");
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test failure
        try {
            Bean1 bean1 = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArray(new Bean2[1][4][2]);
            jb.setPropertyValue("multiArray[0][3][1].name", bean1, "fred", true, true);
            fail("Should have failed because of strictness");
        } catch (BeanException be) {
            // Smother
        }

        // Test creation of the array
        try {
            Bean1 bean1 = new Bean1();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArray(null);

            jb.setPropertyValue("multiArray[2][0][3].name", bean1, "fred", true, false);
            assertEquals("Should have an array of length 3", bean1.getMultiArray().length, 3);
            assertNotNull("Should have a Bean2 at index 2,0,3", bean1.getMultiArray()[2][0][3]);
            assertEquals("Should be fred", bean1.getMultiArray()[2][0][3].getName(), "fred");
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test Object multi array
        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArrayObject(null);

            jb.setPropertyValue("multiArrayObject[2][3][1]", bean1, bean2, true, false);
            assertEquals("Should have an array of length 3", bean1.getMultiArrayObject().length, 3);
            assertNotNull("Should have a Bean2 at index 2", bean1.getMultiArrayObject()[2][3][1]);
            assertTrue("Should have a Bean2 at index 2", bean1.getMultiArrayObject()[2][3][1] instanceof Bean2);
            assertEquals("Should be bean2", bean1.getMultiArrayObject()[2][3][1], bean2);
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test Object multi array
        try {
            Bean1 bean1 = new Bean1();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean1.class);

            bean1.setMultiArrayObject(null);

            jb.setPropertyValue("multiArrayObject[2][3]", bean1, bean2, true, false);
            fail("should have failed because not correct type");
        } catch (BeanException be) {
            fail("Should be a type conversion exception");
        } catch (TypeConversionException tce) {
            // Expected
        }
    }

    /**
     * Tests Collection usage
     */
    public void testCollection() {
        try {
            Bean3 bean3 = new Bean3();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean3.class);

            bean3.getCollection().add(bean2);
            bean2.setName("fred");
            assertEquals("fred", jb.getPropertyValue("collection[0].name", bean3));

            List newList = new ArrayList();
            jb.setPropertyValue("collection", bean3, newList, true, true);
            assertSame("Should have list", bean3.getCollection(), newList);
            assertSame("Should have list", jb.getPropertyValue("collection", bean3), newList);

            bean3.setCollection(null);
            assertNull("Should be null", jb.getPropertyValue("collection[0].foo.bar", bean3));
        } catch (BeanException be) {
            fail(be.toString());
        }

        // Test set failure because you can't set a Collection
        try {
            Bean3 bean3 = new Bean3();
            JavaBean jb = new JavaBean(Bean3.class);

            bean3.setCollection(new HashSet<Object>());
            jb.setPropertyValue("collection[0]", bean3, "fred", true, true);
            fail("Should fail because you can't set a collection");
        } catch (BeanException be) {
            System.out.println(be.toString());
        }

        // Test strict failure
        try {
            Bean3 bean3 = new Bean3();
            JavaBean jb = new JavaBean(Bean3.class);

            // Test failure even unstrict
            jb.setPropertyValue("collection[0].property1.name", bean3, "fred", true, true);
            fail("Should fail for strictness");
        } catch (BeanException be) {
            System.out.println(be.toString());
        }

        // Test failure even unstrict
        try {
            Bean3 bean3 = new Bean3();
            JavaBean jb = new JavaBean(Bean3.class);

            jb.setPropertyValue("collection[0].property1.name", bean3, "fred", true, false);
            fail("Should fail to Collection");
        } catch (BeanException be) {
            System.out.println(be.toString());
        }

        // Wierd cases
        try {
            Bean3 bean3 = new Bean3();
            JavaBean jb = new JavaBean(Bean3.class);

            bean3.setCollection(new ArrayList<Object>());
            bean3.getCollection().add(new Bean2[1][1]);
            jb.setPropertyValue("collection[0][0][0].name", bean3, "fred", true, false);
            assertEquals("fred", ((Bean2[][]) ((ArrayList) bean3.getCollection()).get(0))[0][0].getName());

            bean3.setCollection(new ArrayList<Object>());
            ArrayList[] array = new ArrayList[] {new ArrayList<Object>(),
                                           new ArrayList<Object>(),
                                           new ArrayList<Object>()};
            bean3.getCollection().add(array);
            array[1].add(new Bean2());
            jb.setPropertyValue("collection[0][1][0].name", bean3, "fred", true, false);
            assertEquals("fred",
                ((Bean2) ((ArrayList<Object>) ((Object[]) ((ArrayList<Object>) bean3.getCollection()).get(0))[1]).get(0)).getName());
        } catch (BeanException be) {
            // Smother
        }
    }

    /**
     * Tests Map usage
     */
    public void testMap() {
        try {
            Bean3 bean3 = new Bean3();
            Bean2 bean2 = new Bean2();
            JavaBean jb = new JavaBean(Bean3.class);

            bean3.getMap().put("b2", bean2);
            bean2.setName("fred");
            assertNotNull("Should have Bean2", jb.getPropertyValue("map[b2]", bean3));
            assertSame("Should have Bean2", bean2, jb.getPropertyValue("map[b2]", bean3));
            assertEquals("Should have value fred", "fred", jb.getPropertyValue("map[b2].name", bean3));

            List<Object> newList = new ArrayList<Object>();
            newList.add(bean2);
            newList.add(bean2);
            jb.setPropertyValue("map[l1]", bean3, newList, true, true);
            assertSame("Should have list", newList, bean3.getMap().get("l1"));
            assertSame("Should have list", newList, jb.getPropertyValue("map[l1]", bean3));
            assertSame("Should have bean2", "fred", jb.getPropertyValue("map[l1][1].name", bean3));
            assertSame("Should have fred", "fred", jb.getPropertyValue("map[l1][1].name", bean3));

            bean3.setMap(null);
            assertNull("Should be null", jb.getPropertyValue("map[0].foo.bar", bean3));
        } catch (BeanException be) {
            fail(be.toString());
        }
    }
}