/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import junit.framework.TestCase;


/**
 * This class is a helper for the listener tests so that the
 * tests check to be certain that only the handle methods
 * that are expected are called.
 *
 * @author  Brian Pontarelli
 */
public class ListenerHelper extends TestCase
implements PropertyListener, ConversionListener {

    public ListenerHelper() {
        super("com.inversoft.beans.test.ListenerHelper");
    }

    public ListenerHelper(String name) {
        super(name);
    }

    /**
     * This handle method is called when the property value is being retrieved
     * by calling the getter for the property. This method always calls fail
     */
    public void handleGet(PropertyEvent event) {
        fail("Should not have called the handleGet method");
    }

    /**
     * This handle method is called when the property value is being changed
     * by calling the setter for the property. This method always calls fail
     */
    public void handleSet(PropertyEvent event) {
        fail("Should not have called the handleSet method");
    }

    /**
     * This handle method is called when the property value being set is going
     * to be auto-converted but has not been converted yet. This method always calls fail
     */
    public void handlePreConversion(ConversionEvent event) {
        fail("Should not have called the handlePreConversion method");
    }

    /**
     * This handle method is called when the property value being set has just been
     * successfully auto-converted. This method always calls fail
     */
    public void handlePostConversion(ConversionEvent event) {
        fail("Should not have called the handlePostConversion method");
    }

    /**
     * This handle method is called when the property value being set has been
     * converted and the conversion failed. This method always calls fail
     */
    public void handleFailedConversion(ConversionEvent event) {
        fail("Should not have called the handleFailedConversion method");
    }
}
