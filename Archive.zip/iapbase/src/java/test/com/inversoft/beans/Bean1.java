/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;

import java.util.HashMap;


/**
 * This class is a simple JavaBean that is used in testing
 * @author  Brian Pontarelli
 */
public class Bean1 extends SuperBean {

    private Bean2 property1;
    private Bean4 property4;

    private Bean2[] array = new Bean2[1];
    private Object[] objectArray = new Object[1];
    private Bean2[][][] multiArray = new Bean2[1][2][3];
    private Object[][][] multiObjectArray = new Object[1][2][3];

    private String[] strArray = new String[3];
    private String readOnly = "readOnly";
    private String[] readOnlyIndexed = new String[] {"readOnly"};
    private String string1;
    private Integer integer1;
    private Integer[] integerIndexed = new Integer[] { new Integer(1) };
    private boolean boolean1;
    private boolean[] booleanIndexed = new boolean[] {true};
    private byte byte1;
    private char char1;
    private double double1;
    private float float1;
    private int int1;
    private int[] intIndexed = new int[] {1};
    private long long1;
    private short short1;
    private HashMap map;


    /** Gets the property1 property */
    public Bean2 getProperty1(){
        return property1;
    }

    /** Sets the property1 property */
    public void setProperty1(Bean2 value) {
        this.property1 = value;
    }

    /** Gets the Property4 property */
    public Bean4 getProperty4() {
        return property4;
    }

    /** Sets the Property4 property */
    public void setProperty4(Bean4 value) {
        property4 = value;
    }

    /** Gets the indexed property. If indices is out of bounds, null is returned */
    public Bean2 getIndexed(int index) {
        if (index >= array.length) {
            return null;
        }

        return array[index];
    }

    /** Sets the indexed property. If indices is out of bounds, an exception is thrown*/
    public void setIndexed(int index, Bean2 value) {
        array[index] = value;
    }

    public Bean2[] getSingleArray() {
        return array;
    }

    public void setSingleArray(Bean2[] array) {
        this.array = array;
    }

    public Object[] getSingleArrayObject() {
        return objectArray;
    }

    public void setSingleArrayObject(Object[] objectArray) {
        this.objectArray = objectArray;
    }

    public Bean2[][][] getMultiArray() {
        return multiArray;
    }

    public void setMultiArray(Bean2[][][] multiArray) {
        this.multiArray = multiArray;
    }

    public Object[][][] getMultiArrayObject() {
        return multiObjectArray;
    }

    public void setMultiArrayObject(Object[][][] multiObjectArray) {
        this.multiObjectArray = multiObjectArray;
    }

    /** Gets the indexed string property. If indices is out of bounds, null is returned */
    public String getStringIndexed(int index) {
        if (index >= strArray.length) {
            return null;
        }

        return strArray[index];
    }

    /** Sets the indexed string property. If indices is out of bounds, an exception is thrown*/
    public void setStringIndexed(int index, String value) {
        strArray[index] = value;
    }

    /** Gets the ReadOnly property */
    public String getReadOnly() {
        return readOnly;
    }

    public String getReadOnlyIndexed(int index) {
        return readOnlyIndexed[index];
    }

    /** Gets the String1 property */
    public String getString1() {
        return string1;
    }

    /** Sets the String1 property */
    public void setString1(String value) {
        string1 = value;
    }

    /** Gets the Integer1 property */
    public Integer getInteger1() {
        return integer1;
    }

    /** Sets the Integer1 property */
    public void setInteger1(Integer value) {
        integer1 = value;
    }

    public Integer getIntegerIndexed(int index) {
        return integerIndexed[index];
    }

    public void setIntegerIndexed(int index, Integer integerIndexed) {
        this.integerIndexed[index] = integerIndexed;
    }

    /** Gets the Boolean1 property */
    public boolean isBoolean1() {
        return boolean1;
    }

    /** Sets the Boolean1 property */
    public void setBoolean1(boolean value) {
        boolean1 = value;
    }

    /** Gets the booleanIndexed property */
    public boolean isBooleanIndexed(int index) {
        return booleanIndexed[index];
    }

    /** Sets the booleanIndexed property */
    public void setBooleanIndexed(int index, boolean value) {
        booleanIndexed[index] = value;
    }

    /** Gets the Byte1 property */
    public byte getByte1() {
        return byte1;
    }

    /** Sets the Byte1 property */
    public void setByte1(byte value) {
        byte1 = value;
    }

    /** Gets the Char1 property */
    public char getChar1() {
        return char1;
    }

    /** Sets the Char1 property */
    public void setChar1(char value) {
        char1 = value;
    }

    /** Gets the Double1 property */
    public double getDouble1() {
        return double1;
    }

    /** Sets the Double1 property */
    public void setDouble1(double value) {
        double1 = value;
    }

    /** Gets the Float1 property */
    public float getFloat1() {
        return float1;
    }

    /** Sets the Float1 property */
    public void setFloat1(float value) {
        float1 = value;
    }

    /** Gets the Int1 property */
    public int getInt1() {
        return int1;
    }

    /** Sets the Int1 property */
    public void setInt1(int value) {
        int1 = value;
    }

    /** Gets the intIndexed property */
    public int getIntIndexed(int index) {
        return intIndexed[index];
    }

    /** Sets the intIndexed property */
    public void setIntIndexed(int index, int value) {
        intIndexed[index] = value;
    }

    /** Gets the Long1 property */
    public long getLong1() {
        return long1;
    }

    /** Sets the Long1 property */
    public void setLong1(long value) {
        long1 = value;
    }

    /** Gets the Short1 property */
    public short getShort1() {
        return short1;
    }

    /** Sets the Short1 property */
    public void setShort1(short value) {
        short1 = value;
    }

    /** Gets the ThrowsAnException property */
    public String getThrowsAnException() throws TestException {
        throw new TestException();
    }

    /** Sets the ThrowsAnException property */
    public void setThrowsAnException(String value) throws TestException{
        throw new TestException();
    }

    /** Gets the NotAccessible property */
    private String getNotAccessible() {
        throw new NullPointerException();
    }

    /** Sets the NotAccessible property */
    private void setNotAccessible(String value) {
        throw new NullPointerException();
    }

    /** Gets the HashMap property */
    public HashMap getHashMap() {
        return map;
    }

    /** Sets the HashMap property */
    public void setHashMap(HashMap map) {
        this.map = map;
    }

    /** bad property */
    public String get() {
        return null;
    }

    /** bad property */
    public void set(String s) {
    }

    /** bad property */
    public boolean is() {
        return false;
    }

    /** bad property */
    public String get(int index) {
        return null;
    }

    /** bad property */
    public void set(int index, String s) {
    }

    /** bad property */
    public boolean is(int index) {
        return false;
    }

    /** bad property */
    public void getBadProp() {
    }

    /** bad property */
    public String setBadProp(String s) {
        return null;
    }

    /** bad property */
    public void isBadPropBool() {
    }

    /** bad property */
    public void getBadProp(int index) {
    }

    /** bad property */
    public String setBadProp(int index, String s) {
        return null;
    }

    /** bad property */
    public void isBadPropBool(int index) {
    }

    public String notAProp() {
        return null;
    }
}