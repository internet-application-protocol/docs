/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.security.Permission;


/**
 * This class is a test security manager for testing security
 * exception stuff
 *
 * @author  Brian Pontarelli
 */
public class TestSecurityManager extends SecurityManager {

    /**
     * Throws SecurityException under certain circumstances for testing.
     */
    public void checkMemberAccess(Class klass, int which) {
        throw new SecurityException("Testing security exceptions");
    }

    /**
     * Overridden so that we can set back the old security manager later.
     */
    public void checkPermission(Permission perm) {
        // No-op
    }
}
