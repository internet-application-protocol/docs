/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


import junit.framework.TestCase;


/**
 * This class handles all of the test cases for the character
 * type conversion support in the JBeans package.
 *
 * @author  Brian Pontarelli
 */
public class CharacterTypeConverterTest extends TestCase {

    public static final char DEFAULT = 0;


    /**
     * Tests the convertFromString method works for primitive types and wrapper
     */
    public void testString() {
        try {
            CharacterTypeConverter ctc = new CharacterTypeConverter();

            // Test primitive
            Character c = ctc.convertFromString("a", Character.TYPE);
            assertEquals(new Character('a'), c);

            // Test wrapper
            c = ctc.convertFromString("b", Character.class);
            assertEquals(new Character('b'),  c);

            // Test null primitive
            c = ctc.convertFromString(null, Character.TYPE);
            assertEquals(new Character(DEFAULT),  c);

            // Test null wrapper
            c = ctc.convertFromString(null, Character.class);
            assertEquals(null,  c);

            // Test spaces primitive
            c = ctc.convertFromString(" ", Character.TYPE);
            assertEquals(new Character(DEFAULT),  c);

            // Test null wrapper
            c = ctc.convertFromString(" ", Character.class);
            assertEquals(null,  c);
        } catch (TypeConversionException tce) {
            fail(tce.toString());
        }

        // Test primitive
        try {
            CharacterTypeConverter ctc = new CharacterTypeConverter();
            ctc.convertFromString("ab", Character.TYPE);
            fail("Should have failed because string is two characters");
        } catch (TypeConversionException e) {
            // Expected
            System.out.println(e.toString());
        }

        // Test wrapper
        try {
            CharacterTypeConverter ctc = new CharacterTypeConverter();
            ctc.convertFromString("ab", Character.class);
            fail("Should have failed because string is two characters");
        } catch (TypeConversionException e) {
            // Expected
            System.out.println(e.toString());
        }
    }
}