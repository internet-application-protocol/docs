/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.response;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */
public enum ReconnectSessionStatus implements Status {
    SUCCESS("1.0"), FAILURE("2.0"), FAILURE_SESSION_ID("2.2");

    private transient String code;

    private ReconnectSessionStatus(String code) {
        this.code = code;
    }

    /**
     * Resolves the ReconnectSessionStatus based on the IAP specification code.
     *
     * @param   code The code from the IAP specification.
     * @return  The ReconnectSessionStatus or null if the code is invalid.
     */
    public static ReconnectSessionStatus resolve(String code) {
        ReconnectSessionStatus[] all = ReconnectSessionStatus.values();
        ReconnectSessionStatus result = null;
        for (int i = 0; i < all.length; i++) {
            ReconnectSessionStatus status = all[i];
            if (status.getCode().equals(code)) {
                result = status;
            }
        }

        return result;
    }

    /**
     * Returns the status code associated with this status.
     *
     * @return The status code and never null.
     */
    public String getCode() {
        return this.code;
    }
}
