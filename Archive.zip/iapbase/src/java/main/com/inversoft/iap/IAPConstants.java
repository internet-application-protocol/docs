/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap;


/**
 * <p>
 * This class stores constants used for IAP processing or
 * functionality. This class should be used very sparingly
 * so that it does not become a dumping ground of Strings
 * and ints.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since IAP 1.0
 * @version 1.0
 */
public final class IAPConstants {

    /**
     * The terminator character to denotes the end
     * of an IAP message (request and response).
     */
    public static final char EOT = 0x20;
}