/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.response;

/**
 * <p>
 * This enum are the status codes for the fetch module response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum FetchModuleStatus implements Status {
    SUCCESS("1.0"), FAILURE("2.0"), SESSION_EXPIRATION("2.1"), FAILURE_SESSION_ID("2.2"),
    FAILURE_LOAD("2.3"), FAILURE_NON_EXISTENT("2.4");

    private transient String code;

    private FetchModuleStatus(String code) {
        this.code = code;
    }

    /**
     * Resolves the FetchModuleStatus using the code given.
     *
     * @param   code The code of the status to look for.
     * @return  The status enum value or null if the code given isn't valid.
     */
    public static FetchModuleStatus resolve(String code) {
        FetchModuleStatus[] all = FetchModuleStatus.values();
        FetchModuleStatus result = null;
        for (int i = 0; i < all.length; i++) {
            FetchModuleStatus status = all[i];
            if (status.getCode().equals(code)) {
                result = status;
                break;
            }
        }
        return result;
    }

    /**
     * Returns the status code for this status instance.
     *
     * @return  The status code and never null.
     */
    public String getCode() {
        return code;
    }
}