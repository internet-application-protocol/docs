/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap;


import iap.response.DataScope;
import iap.annotation.XmlElement;


/**
 * <p>
 * This class is a simple struct that stores data values and
 * the scope of that value.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
@XmlElement(name = "data")
public class Data {
    private final String key;
    private final Object value;
    private final DataType type;
    private final int arrayDepth;
    private final DataScope scope;


    /**
     * Constructs a new <code>Data</code> instance with the given value and scope.
     *
     * @param   key The key that the value is stored under in the request or
     *          response.
     * @param   value The value of the data.
     * @param   type The type of the value.
     * @param   scope The scope of the data.
     */
    public Data(String key, Object value, DataType type, DataScope scope) {
        this.key = key;
        this.value = value;
        this.type = type;
        this.arrayDepth = 0;
        this.scope = scope;
    }

    /**
     * Constructs a new <code>Data</code> instance with the given value and scope.
     *
     * @param   key The key that the value is stored under in the request or
     *          response.
     * @param   value The value of the data.
     * @param   type The type of the value.
     * @param   scope The scope of the data.
     */
    public Data(String key, Object value, DataType type, int arrayDepth,
                DataScope scope) {
        this.key = key;
        this.value = value;
        this.arrayDepth = arrayDepth;
        this.type = type;
        this.scope = scope;
    }


    /**
     * Returns the key.
     *
     * @return  The key.
     */
    public String getKey() {
        return key;
    }

    /**
     * Gets the value.
     *
     * @return  The value.
     */
    public Object getValue() {
        return value;
    }

    /**
     * Returns the type of the value.
     *
     * @return  The type of the value.
     */
    public DataType getType() {
        return this.type;
    }

    /**
     *
     * @return
     */
    public int getArrayDepth() {
        return this.arrayDepth;
    }

    /**
     * Returns true if this data value is an array. If it is, the DataType is the
     * component type of the array.
     *
     * @return  True if this data value is an array, false otherwise.
     */
    public boolean isArray() {
        return this.arrayDepth > 0;
    }

    /**
     * Gets the scope.
     *
     * @return  The scope.
     */
    public DataScope getScope() {
        return scope;
    }

    /**
     * True if the variables represented by the Data types are equal.  Variables are equals if their keys are equal
     *
     * @param data the Data to compare to
     * @return true if equal, false otherwise
     *
     *
     */


    /**
     * True if the variables represented by the Data types are equal.  Variables are equal if their keys are equal
     *
     * @param data1 first data to compare
     * @param data2 second data to compare
     * @return true if equal, false otherwise
     */
    public static boolean areVariablesEqual(Data data1, Data data2) {
        return (data1.key.equals(data2.key)) ? true : false;
    }

    /**
     * Returns a string representation of the object. In general, the
     * <code>toString</code> method returns a string that
     * "textually represents" this object. The result should
     * be a concise but informative representation that is easy for a
     * person to read.
     * It is recommended that all subclasses override this method.
     * <p>
     * The <code>toString</code> method for class <code>Object</code>
     * returns a string consisting of the name of the class of which the
     * object is an instance, the at-sign character `<code>@</code>', and
     * the unsigned hexadecimal representation of the hash code of the
     * object. In other words, this method returns a string equal to the
     * value of:
     * <blockquote>
     * <pre>
     * getClass().getName() + '@' + Integer.toHexString(hashCode())
     * </pre></blockquote>
     *
     * @return  a string representation of the object.
     */
    public String toString() {
        return key;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Data)) {
            return false;
        }

        final Data data = (Data) o;

        if (!key.equals(data.key)) {
            return false;
        }
        if (!scope.equals(data.scope)) {
            return false;
        }
        if (!value.equals(data.value)) {
            return false;
        }

        return true;
    }

    public int hashCode() {
        int result;
        result = key.hashCode();
        result = 29 * result + value.hashCode();
        result = 29 * result + scope.hashCode();
        return result;
    }
}