/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import iap.TransportType;

/**
 * <p>
 * This class manages the creation and fetching of an IAPTransaction.  An
 * IAPTransaction is modeled after the IAP Specification
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPTransactionManager {
    private final Map<String, IAPTransaction> map = new HashMap<String, IAPTransaction>();
    private final AtomicLong nextId = new AtomicLong();

    /**
     * Creates a new transaction ID that is a long and is incremental. This number
     * should NEVER go back to the client, under ANY circumstances.
     *
     * @return  The new transaction ID. This does not create a transaction.
     */
    public String createTransactionID() {
        String id = Long.toString(nextId.getAndIncrement());
        return id;
    }

    /**
     * Creates a new transaction.
     *
     * @param   id The ID of the transaction created.
     * @param   type The type of transaction to create.
     * @return  The transaction and never null.
     */
    public IAPTransaction createTransaction(String id, TransportType type) {
        IAPTransaction transaction = new IAPTransaction(type, id);
        synchronized (map) {
            map.put(id, transaction);
        }

        return transaction;
    }

    /**
     * Fetches the transaction previously created for the given transaction ID.
     *
     * @param   id The ID of the transaction to fetch.
     * @return  The transaction or null if the ID is invalid or the transaction
     *          was cleaned out.
     */
    public IAPTransaction fetchTransaction(String id) {
        IAPTransaction transaction;
        synchronized (map) {
            transaction = map.get(id);
        }
        return transaction;
    }

    /**
     * Ends a transaction.
     *
     * @param   id The ID of the transaction to end.
     */
    public void endTransaction(String id) {
        this.map.remove(id);
    }
}