/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.response;

/**
 * <p>
 * This enum stores the status values for the close application
 * response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum CloseApplicationStatus implements Status {
    SUCCESS("1.0"), FAILURE_SESSION_ID("2.0"), FAILURE("2.1");

    private transient String code;

    private CloseApplicationStatus(String code) {
        this.code = code;
    }

    /**
     * Resolves the CloseApplicationStatus based on the IAP specification code.
     *
     * @param   code The code from the IAP specification.
     * @return  The CloseApplicationStatus or null if the code is invalid.
     */
    public static CloseApplicationStatus resolve(String code) {
        CloseApplicationStatus[] all = CloseApplicationStatus.values();
        CloseApplicationStatus result = null;
        for (int i = 0; i < all.length; i++) {
            CloseApplicationStatus status = all[i];
            if (status.getCode().equals(code)) {
                result = status;
            }
        }

        return result;
    }

    /**
     * Returns the status code associated with this status.
     *
     * @return The status code and never null.
     */
    public String getCode() {
        return this.code;
    }
}