/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.response;

/**
 * <p>
 * This enum are the status codes for the open application
 * response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum OpenApplicationStatus implements Status {
    SUCCESS("1.0"), SUCCESS_NEWER_VERSION("1.1"), SUCCESS_AUTH_FAILURE("1.2"),
    FAILURE("2.0"), FAILURE_OLDER_VERSION("2.1"), FAILURE_NEWER_VERSION("2.2"),
    FAILURE_NON_EXISTENT("2.3"), FAILURE_OPENING("2.4");

    private transient String code;

    private OpenApplicationStatus(String code) {
        this.code = code;
    }

    /**
     * Resolves the OpenApplicationStatus based on the IAP specification code.
     *
     * @param   code The code from the IAP specification.
     * @return  The OpenApplicationStatus or null if the code is invalid.
     */
    public static OpenApplicationStatus resolve(String code) {
        OpenApplicationStatus[] all = OpenApplicationStatus.values();
        OpenApplicationStatus result = null;
        for (int i = 0; i < all.length; i++) {
            OpenApplicationStatus status = all[i];
            if (status.getCode().equals(code)) {
                result = status;
            }
        }

        return result;
    }

    /**
     * Returns the status code associated with this status.
     *
     * @return The status code and never null.
     */
    public String getCode() {
        return this.code;
    }
}