/**
 * Copyright 2004 Inversoft, Inc.  All rights reserved.
 */

package com.inversoft.iap.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.net.URLConnection;

/**
 * IapURLConecction opens a socket connection to a particular URL specified
 *
 * @author James Humphrey
 * @version 1.0
 * @since IAP 1.0
 */
public class IapURLConnection extends URLConnection {

    Socket socket;

    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    public IapURLConnection(URL url) {
        super(url);
    }

    /**
     * Overloaded to provide a timeout to control socket timeouts.
     *
     * @param timeout the socket timeout
     * @throws IOException
     */
    public void connect(int timeout) throws IOException {
        socket = new Socket();
        InetAddress address = InetAddress.getByName(url.getHost());
        int port = url.getPort();
        if (port == -1) {
            port = url.getDefaultPort();
        }
        SocketAddress socketAddress = new InetSocketAddress(address, port);
        socket.connect(socketAddress, timeout);
        // set connected to true
        connected = true;
    }

    /**
     * Establishes a socket connection with the specified host and port.
     *
     * @throws IOException
     */
    public void connect() throws IOException {
        // timeout defaults to 30 seconds if this method is used
        connect(30);
    }

    /**
     * <p>returns the socket input stream</p>
     *
     * @return InputStream the socket input stream
     * @throws IOException
     */
    public InputStream getInputStream() throws IOException {
        // make sure we are connected to the socket
        if (!connected) {
            connect();
        }

        return socket.getInputStream();
    }

    /**
     * <p>returns the socket output stream</p>
     *
     * @return OutStream the socket output stream
     * @throws IOException
     */
    public OutputStream getOutputStream() throws IOException {
        // make sure we are connected to the socket
        if (!connected) {
            connect();
        }

        return socket.getOutputStream();
    }

    /**
     * <p>Closes a socket</p>
     *
     * @throws IOException
     */
    public void close() throws IOException {
        if (socket != null) {
            socket.shutdownInput();
            socket.shutdownOutput();
            socket.close();
            connected = false;
        }
    }

    /**
     * Returns the {@link Socket} for this instance
     *
     * @return {@link Socket}
     */
    public Socket getSocket() {
        if (connected) {
            return socket;
        } else {
            return null;
        }
    }

    /**
     * True if connected, false otherwise
     *
     * @return true if connected, false otherwise
     */
    public boolean isConnected() {
        return (connected || socket == null) ? true : false;
    }
}
