/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.response;

import iap.response.AuthenticationFailure;

/**
 * <p>
 * This enum are the status codes for the authenticate user
 * response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum AuthenticateUserStatus implements Status {
    SUCCESS("1.0"), FAILURE("2.0"), SESSION_EXPIRATION("2.1"), FAILURE_SESSION_ID("2.2"), FAILURE_USER("2.3"),
    FAILURE_PASSWORD("2.4"), FAILURE_USER_PASSWORD("2.5");

    private transient String code;

    private AuthenticateUserStatus(String code) {
        this.code = code;
    }

    /**
     * Resolves the AuthenticateUserStatus based on the IAP specification code.
     *
     * @param   code The code from the IAP specification.
     * @return  The AuthenticateUserStatus or null if the code is invalid.
     */
    public static AuthenticateUserStatus resolve(String code) {
        AuthenticateUserStatus[] all = AuthenticateUserStatus.values();
        AuthenticateUserStatus result = null;
        for (int i = 0; i < all.length; i++) {
            AuthenticateUserStatus status = all[i];
            if (status.getCode().equals(code)) {
                result = status;
            }
        }

        return result;
    }

    /**
     * Resolves the AuthenticateUserStatus based on the AuthenticationFailure
     * given. If the failure is null, SUCCESS is returned. Otherwise the failure
     * is used to determine the status.
     *
     * @param   failure The failure to use to determine the status.
     * @return  The status and never null.
     */
    public static AuthenticateUserStatus resolve(AuthenticationFailure failure) {
        AuthenticateUserStatus status = AuthenticateUserStatus.SUCCESS;
        if (failure != null) {
            switch (failure) {
                case USERNAME_PASSWORD:
                    status = AuthenticateUserStatus.FAILURE_USER_PASSWORD;
                    break;
                case USERNAME:
                    status = AuthenticateUserStatus.FAILURE_USER;
                    break;
                case PASSWORD:
                    status = AuthenticateUserStatus.FAILURE_PASSWORD;
                    break;
            }
        }

        return status;
    }

    /**
     * Returns the status code associated with this status.
     *
     * @return The status code and never null.
     */
    public String getCode() {
        return this.code;
    }
}