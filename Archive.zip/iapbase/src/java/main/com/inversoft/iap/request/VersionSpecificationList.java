/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.request;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import iap.Version;


/**
 * <p>
 * This class is used to store Protocol Constraint information for a
 * particular client.
 * </p>
 *
 * @author  James Humphrey
 * @since   IAP 1.0
 * @version 1.0
 */
public final class VersionSpecificationList {
    /**
     * delimiter for string representations
     */
    private static final String LIST_DELIMETER = ",";

    /**
     * list holds the protocol constraints of a given client
     */
    private final List<VersionSpecification> specList =
        new ArrayList<VersionSpecification>();

    /**
     * Instantiates with a supplied list of
     * <code>VersionSpecification</code> objects
     *
     * @param specs list of VersionSpecification objects
     */
    public VersionSpecificationList(List<VersionSpecification> specs) {
        this.specList.addAll(specs);
    }

    /**
     * Instantiates with a VersionSpecification object.
     *
     * @param specs VersionSpecification spec string
     */
    public VersionSpecificationList(VersionSpecification... specs) {
        for (VersionSpecification spec : specs) {
            addToList(spec);
        }

    }

    /**
     * Instantiates with a string.
     *
     * @param specs VersionSpecification spec string
     */
    public VersionSpecificationList(String... specs) {
        for (String spec : specs) {
            addToList(VersionSpecification.decode(spec));
        }
    }

    /**
     *  Adds a <code>VersionSpecification</code> object to the list
     *
     * @param specs VersionSpecification object representing the spec
     */
    public void addSpecification(VersionSpecification... specs) {
        for (VersionSpecification spec : specs) {
            addToList(spec);
        }
    }

    /**
     * Takes a string, decodes it into a VersionSpecification object and
     * then adds it to the VersionSpecification list.  This should be the
     * preferred method for instantiating a VersionSpecification and adding
     * it to the VersionSpecificationList object
     *
     * @param specs String object representing the spec
     */
    public void addSpecification(String... specs) {
        for (String spec : specs) {
            addToList(VersionSpecification.decode(spec));
        }
    }

    /**
     *  Removes a <code>VersionSpecification</code> object from the list
     *
     * @param specs VersionSpecification object representing the spec
     */
    public void removeSpecification(VersionSpecification... specs) {
        for (VersionSpecification spec : specs) {
            this.specList.remove(spec);
        }
    }

    /**
     * Takes a string, decodes it into a VersionSpecification object and
     * then removes it from the VersionSpecificationList
     *
     * @param specs String object representing the spec
     */
    public void removeSpecification(String... specs) {
        for (String spec : specs) {
            this.specList.remove(VersionSpecification.decode(spec));
        }
    }

    /**
     * Returns the complete list of VersionSpecifications.  This list is
     * a Collections.unmodifiableList object.  the VersionSpecificationList
     * interface should be used explicitly to do any kind of adding or removal
     * of VersionSpecification objects
     *
     * @return list of <code>VersionSpecifications</code>
     */
    public List<VersionSpecification> getAllSpecifications() {
        return Collections.unmodifiableList(this.specList);
    }

    /**
     * This method acts as a delegator for VersionSpecification supports().
     * It loops through the list checking to see if each spec supports the
     * supplied VersionNumber.  If at least one spec supports it, then
     * the method returns true.  If none support it, then it returns false.
     *
     * @param number the VersionNumber to check
     * @return true if supported, false otherwise
     */
    public boolean supports(Version number) {
        boolean isSupported = false;

        // loop through the spec list
        for (VersionSpecification spec : this.specList) {
            if (spec.supports(number)) {
                isSupported = true;
            }
        }

        return isSupported;
    }

    /**
     * <p>
     * Validates the data prior to adding it to the list so that
     * wildcards don't conflict with non-wildcard specification numbers
     * </p>
     * <p>
     * Example:
     *      if '1.1' is trying to get added to the list but '1.*' already exists
     *      then don't add '1.1'.  Conversely, if '1.*' is being
     *      added and '1.1' already exists, then remove '1.1'.
     * </p>
     *
     * @param anotherSpec the specification to validate against
     */
    private void addToList(VersionSpecification anotherSpec) {
        boolean addToList = true;
        boolean addingWildcard = false;
        boolean replacingWildcard = false;
        List<VersionSpecification> specsToRemove =
                new ArrayList<VersionSpecification>();

        // check to see if we are adding a wildcard.
        if (anotherSpec.isWildcard()) {
            addingWildcard = true;
        }

        // loop through the spec list
        for (VersionSpecification spec : this.specList) {
            // first check to see if anotherSpec is equal to this spec
            if (anotherSpec.equals(spec)) {
                addToList = false;
                break;
            }

            // check if the spec in the list is a wildcard
            if (spec.isWildcard()) {
                replacingWildcard = true;
            }

            // if we are adding a wildcard
            if (addingWildcard) {
                // if anotherSpec supports this spec then add the spec
                // to the remove list.
                if (anotherSpec.supports(spec)) {
                    specsToRemove.add(spec);
                } else if (spec.supports(anotherSpec)) {
                    addToList = false;
                    break;
                }
            } else {
                if (replacingWildcard && spec.supports(anotherSpec)) {
                    addToList = false;
                    break;
                }
            }

            // reset replacingWildcard for next iteration
            replacingWildcard = false;
        }

        if (addToList) {
            // if the specsToRemove list is not empty, then
            // we know we are adding a wildcard to the list
            // and there are non-wildcards in the list that need removing
            if (!specsToRemove.isEmpty()) {
                for (VersionSpecification spec : specsToRemove) {
                    this.specList.remove(spec);
                }
            }

            this.specList.add(anotherSpec);
        }
    }

    /**
     * Returns a string representation of the object in the form of:
     *
     * SPEC [", " SPEC [", " SPEC [...]]]
     *
     * @return  a string representation of the object.
     */
    public String toString() {
        String concatString = "";
        int index = 0;

        for (VersionSpecification spec :  this.specList) {
            concatString += spec.getVersion();

            if (index != (this.specList.size() - 1)) {
                concatString += LIST_DELIMETER;
            }

            index++;
        }

        return concatString;
    }

    /**
     * Decodes a supplied String object into a VersionSpecificationList object
     * The string list must be a list delimited by the static member variable
     * LIST_DELIMETER.
     *
     * @return VersionSpecificationList object
     */
    public static VersionSpecificationList decode(String specListString) {
        List<VersionSpecification> specList =
                new ArrayList<VersionSpecification>();
        String[] specs = specListString.split(LIST_DELIMETER);

        for (String spec : specs) {
            specList.add(VersionSpecification.decode(spec.trim()));
        }

        return new VersionSpecificationList(specList);
    }

    /**
     * Returns a string representation of the object in the form of:
     *
     * SPEC [", " SPEC [", " SPEC [...]]]
     *
     * @return
     * @param versionSpecificationList
     */
    public static String encode(VersionSpecificationList versionSpecificationList) {
        return versionSpecificationList.toString();
    }
}