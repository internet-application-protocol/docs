/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import iap.response.DataScope;
import iap.annotation.XmlElement;

/**
 * <p>
 * Contains the data supplied to a PerformActionRequest object to be
 * processed by the remote server.
 * </p>
 *
 * <p>
 * The DataBody object is instantiated with a Map containing
 * name-value associations from a particular action request
 * </p>
 *
 * @author  James Humphrey
 * @since   IAP 1.0
 * @version 1.0
 */
@XmlElement(name = "dataBody")
public final class DataBody {
    /**
     * Map containing name-value pairs of the data to be processed.
     */
    private final Map<String, Data> dataBody = new LinkedHashMap<String, Data>();

    /**
     * Constructs a new empty <code>DataBody</code>.
     */
    public DataBody() {
    }

    /**
     * Returns the value previously added under the given key.
     *
     * @param   key The key of the value to lookup.
     * @return  The value if it was previously added, or null.
     */
    public Object getValue(String key) {
        Data data = this.dataBody.get(key);
        return (data == null) ? null : data.getValue();
    }

    /**
     * Returns all the Data values that match the given key, or were stored into this DataBody under
     * a key which starts with the given key, i.e. nested value. This list is NOT live, so changes
     * to it do not effect the DataBody.
     *
     * @param   key The key or the key prefix.
     * @return  A list of Data values or an empty List if no values exist. NOT LIVE.
     */
    public List<Data> getAllValues(String key) {
        List<Data> list = new ArrayList<Data>();

        // Check direct hit first and if that fails, check nested keys.
        Data data = this.dataBody.get(key);
        if (data != null) {
            list.add(data);
        } else {
            Set<String> keys = this.dataBody.keySet();
            for (String s : keys) {
                if (s.startsWith(key)) {
                    data = this.dataBody.get(s);
                    list.add(data);
                }
            }
        }

        return list;
    }

    /**
     * Returns a List that contains all the data values currently in this DataBody.
     *
     * @return  A List of data objects and never null.
     */
    public List<Data> getAllData() {
        List<Data> dataValues = new ArrayList<Data>(this.dataBody.size());
        Collection<Data> values = this.dataBody.values();
        for (Data data : values) {
            dataValues.add(data);
        }
        return dataValues;
    }

    /**
     * Returns the DataScope of the value previously added under the given key.
     *
     * @param   key The key of the value to lookup.
     * @return  The DataScope of the value if it was previously added, or null.
     */
    public DataScope getScope(String key) {
        Data data = this.dataBody.get(key);
        return (data == null) ? null : data.getScope();
    }

    /**
     * Returns the array depth of the given data value. If the value doesn't exist
     * than -1 is returned.
     *
     * @param   key The key of the value to lookup the array depth for.
     * @return  The array depth or -1 if the data value doesn't exist.
     */
    public int getArrayDepth(String key) {
        Data data = this.dataBody.get(key);
        return (data == null) ? -1 : data.getArrayDepth();
    }

    /**
     * Sets the value and scope into the DataBody under the given key. Any previous
     * value is overwritten and returned.
     *
     * @param   key The key to store the value and scope under.
     * @param   value The value to store (nulls allowed).
     * @param   dataType The type of the value.
     * @param   arrayDepth The depth of the array (used if the value is null).
     * @param   scope (Optional) The scope (defaults to APPLICATION if null).
     */
    public Data setValue(String key, Object value, DataType dataType, int arrayDepth,
                         DataScope scope) {
        assert (dataType != null) : "type == null";

        if (value != null) {
            if (arrayDepth > 0) {
                assert (value.getClass().isArray()) : "arrayDepth given but value " +
                    "is not an array";

                Class<?> componentType = value.getClass();
                int depth = 0;
                while (componentType.isArray()) {
                    componentType = componentType.getComponentType();
                    depth++;
                }

                assert (depth == arrayDepth) : "arrayDepth and depth of value " +
                    "don't match";
                assert (DataType.find(componentType) == dataType) : "DataType given " +
                    "and data type of array component types are not the same";
            } else {
                assert (!value.getClass().isArray()) : "arrayDepth zero but value " +
                    "an array";
                assert (dataType.supportsValue(value)) : "Invalid value [" + value +
                    "] for type [" + dataType + "]";
            }
        }

        DataScope ds = (scope == null) ? DataScope.APPLICATION : scope;
        Data data = new Data(key, value, dataType, arrayDepth, ds);
        return this.dataBody.put(key, data);
    }

    /**
     * Adds the given data value to this DataBody.
     *
     * @param   data The data to add.
     * @return  The previously stored data that had the same key.
     */
    public Data addData(Data data) {
        return this.dataBody.put(data.getKey(), data);
    }

    /**
     * Removes the Data stored under the given key.
     *
     * @param   key The key of the Data to remove.
     * @return  The Data that was removed or null if there was no Data stored
     *          under the given key.
     */
    public Data removeValue(String key) {
        return this.dataBody.remove(key);
    }
}
