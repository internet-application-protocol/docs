/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.util;

import iap.TransportType;
import iap.handler.AuthenticateUserHandler;
import iap.handler.CloseApplicationHandler;
import iap.handler.FetchDataHandler;
import iap.handler.FetchModuleHandler;
import iap.handler.IAPHandler;
import iap.handler.OpenApplicationHandler;
import iap.handler.OpenViewHandler;
import iap.handler.PerformActionHandler;
import iap.handler.ReconnectSessionHandler;

import static iap.TransportType.*;

/**
 * <p>
 * This class is a simple toolkit for IAP classes.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPTools {

    /**
     * Determines the type of handler that is passed in. This uses instanceof to determine
     * the type of the handler.
     *
     * @param   handler The handler to figure out the type.
     * @return  The type or null if the handler is null.
     */
    public static TransportType determineType(IAPHandler handler) {
        TransportType type = null;
        if (handler instanceof AuthenticateUserHandler) {
            type = AUTHENTICATE_USER;
        } else if (handler instanceof CloseApplicationHandler) {
            type = CLOSE_APPLICATION;
        } else if (handler instanceof FetchDataHandler) {
            type = FETCH_DATA;
        } else if (handler instanceof FetchModuleHandler) {
            type = FETCH_MODULE;
        } else if (handler instanceof OpenApplicationHandler) {
            type = OPEN_APPLICATION;
        } else if (handler instanceof OpenViewHandler) {
            type = OPEN_VIEW;
        } else if (handler instanceof PerformActionHandler) {
            type = PERFORM_ACTION;
        } else if (handler instanceof ReconnectSessionHandler) {
            type = RECONNECT_SESSION;
        }
        return type;
    }
}