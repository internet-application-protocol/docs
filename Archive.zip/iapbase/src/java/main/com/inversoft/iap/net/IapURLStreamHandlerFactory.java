/**
 * Date Created: Sep 22, 2004
 * Created By:   James Humphrey
 *
 * Copyright 2004 Inversoft, Inc.  All rights reserved.
 */

package com.inversoft.iap.net;

import java.net.URLStreamHandler;
import java.net.URLStreamHandlerFactory;


/**
 * <p>This class implements the URLStreamHandlerFactory so that IAP protocols can be used.</p>
 * <p>It is used by the URL class to create a <code>IapURLStreamHandler</code>.</p>
 *
 * @author James Humphrey
 * @version 1.0
 * @see com.inversoft.protocol.iap.Handler
 * @since IAP 1.0
 */
public class IapURLStreamHandlerFactory implements URLStreamHandlerFactory {

    /**
     * Factory Method to return appropriate URLStreamHandler object.
     *
     * @param protocol The protocol being handled
     * @return The URLStreamHandler object to handle the specified protocol
     */
    public URLStreamHandler createURLStreamHandler(String protocol) {
        if (protocol.equals("iap")) {
            return new com.inversoft.protocol.iap.Handler();
        } else if (protocol.equals("http")) {
            return new sun.net.www.protocol.http.Handler();
        } else if (protocol.equals("file")) {
            return new sun.net.www.protocol.file.Handler();
        } else if (protocol.equals("ftp")) {
            return new sun.net.www.protocol.ftp.Handler();
        } else if (protocol.equals("doc")) {
            return new sun.net.www.protocol.doc.Handler();
        } else if (protocol.equals("gopher")) {
            return new sun.net.www.protocol.gopher.Handler();
        } else if (protocol.equals("https")) {
            return new sun.net.www.protocol.https.Handler();
        } else if (protocol.equals("jar")) {
            return new sun.net.www.protocol.jar.Handler();
        } else if (protocol.equals("mailto")) {
            return new sun.net.www.protocol.mailto.Handler();
        } else if (protocol.equals("netdoc")) {
            return new sun.net.www.protocol.netdoc.Handler();
        } else if (protocol.equals("systemresource")) {
            return new sun.net.www.protocol.systemresource.Handler();
        } else if (protocol.equals("verbatim")) {
            return new sun.net.www.protocol.verbatim.Handler();
        } else {
            return null;
        }
    }
}
