/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.xml;

import java.util.logging.Level;
import java.util.logging.Logger;

import iap.TransportType;

import com.inversoft.nio.ParseException;

/**
 * <p>
 * This class listens to an XML stream and determines when the
 * XML is complete. This also determines the IAP type of the XML
 * document based on the root element.
 * </p>
 *
 * <strong>This class 100% NOT thread safe.</strong>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class XMLStreamListener {
    private static final Logger logger = Logger.getLogger(XMLStreamListener.class.getName());
    protected boolean open = false;
    protected boolean close = false;
    protected boolean cdata = false;

    protected boolean insideRoot = false;
    protected TransportType requestType = null;
    protected StringBuilder rootName = new StringBuilder();

    protected int openIndex = -1;
    protected int count = 0;

    /**
     * Watches as an XML document is streamed into a buffer (or something similar)
     * and extracts enough information to determine the root element name and when
     * the XML document is complete.
     *
     * @param   c A single character from the message.
     * @param   length The current length of the parser content before the new character is added.
     * @param   build The buffer that is storing the XML.
     */
    public void characterFeed(char c, int length, StringBuilder build) throws ParseException {
        if (!insideRoot) {
            // Check if the character is a name, which means we are inside the root
            if (Character.isJavaIdentifierStart(c) && length >= 1 && build.charAt(length - 1) == '<') {
                insideRoot = true;
                open = true;
                openIndex = build.length();
                rootName.append(c);
                logger.log(Level.FINEST, "Inside root and open element");
            }
        } else {
            // Collect the root name for determining the type
            if (requestType == null) {
                if (c != ' ' && c != '>') {
                    rootName.append(c);
                } else if (c == ' ' || c == '>') {
                    String name = rootName.toString();
                    requestType = TransportType.findFromXML(name);
                }
            }

            if (c == '<' && !cdata) {
                open = true;
                close = false;
                openIndex = build.length();
                logger.log(Level.FINEST, "Open element");
            } else if (c == '!' && open) {
                if (length == (openIndex + 1)) {
                    logger.log(Level.FINEST, "CDATA or comment element, skipping");
                    open = false;
                    cdata = true;
                }
            } else if (c == '/' && open && build.charAt(length - 1) == '<') {
                open = false;
                close = true;
                logger.log(Level.FINEST, "Close element");
            } else if (c == '>' && open) {
                if (build.charAt(length - 1) == '/') {
                    if (length != (openIndex + 1)) {
                        logger.log(Level.FINEST, "singluar element, skipping");
                        open = false;
                    }
                } else {
                    count++;
                    open = false;
                    close = false;
                    logger.log(Level.FINEST, "End open element");
                }
            } else if (c == '>' && close) {
                count--;
                open = false;
                close = false;
                logger.log(Level.FINEST, "End close element");
            } else if (c == '>' && cdata) {
                if (length < 6) {
                    throw new ParseException("Invalid XML");
                }
                if ((build.charAt(length - 2) == ']' && build.charAt(length - 1) == ']') ||
                        (build.charAt(length - 2) == '-' && build.charAt(length - 1) == '-')) {
                    cdata = false;
                }
            }
        }
    }

    /**
     * Determines if the Request is complete by checking the state of the XML document
     * that this listener has been watching.
     *
     * @return  True if the request is complete, false otherwise.
     */
    public boolean isRequestComplete() {
        boolean complete = insideRoot && !open && !close && !cdata && count == 0;
        if (complete) {
            logger.log(Level.FINEST, "Request is complete");
        } else if (logger.isLoggable(Level.FINEST)) {
            logger.log(Level.FINEST, "ir=" + insideRoot + " o=" + open + " c=" + close +
                " cd=" + cdata + " co=" + count);
        }
        return complete;
    }

    /**
     * Returns the request type that was parsed from the XML stream.
     *
     * @return  The request type or null if it hasn't been determined yet.
     */
    public TransportType getRequestType() {
        return this.requestType;
    }

    /**
     * Resets the internal state of this XMLStreamListener so that it can be reused.
     */
    public void reset() {
        this.open = false;
        this.close = false;
        this.cdata = false;

        this.insideRoot = false;
        this.requestType = null;
        this.rootName.delete(0, this.rootName.length());

        this.openIndex = -1;
        this.count = 0;
    }
}