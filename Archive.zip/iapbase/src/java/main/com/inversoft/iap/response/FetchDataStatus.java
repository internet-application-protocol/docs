/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.response;

/**
 * <p>
 * This enum are the status codes for the fetch data response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum FetchDataStatus implements Status {
    SUCCESS("1.0"), FAILURE("2.0"), SESSION_EXPIRATION("2.1"), FAILURE_SESSION_ID("2.2");

    private transient String code;

    private FetchDataStatus(String code) {
        this.code = code;
    }

    /**
     * Resolves the FetchDataStatus using the given code.
     *
     * @param   code The status code of the status enum to return.
     * @return  The status or null if the code was invalid.
     */
    public static FetchDataStatus resolve(String code) {
        FetchDataStatus[] all = FetchDataStatus.values();
        FetchDataStatus result = null;
        for (int i = 0; i < all.length; i++) {
            FetchDataStatus status = all[i];
            if (status.getCode().equals(code)) {
                result = status;
            }
        }
        return result;
    }

    /**
     * Returns the status code associated with this status.
     *
     * @return  The status code and never null.
     */
    public String getCode() {
        return code;
    }
}