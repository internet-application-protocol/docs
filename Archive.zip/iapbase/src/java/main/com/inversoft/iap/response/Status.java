/**
 * Date Created: Mar 14, 2005
 * Created By:   James Humphrey
 */

package com.inversoft.iap.response;

/**
 * Interface defining objects of the Status family
 *
 * @author James Humphrey
 * @version 1.0
 */
public interface Status {
    /**
     * Returns the status code associated with this status.
     *
     * @return The status code and never null.
     */
    public String getCode();
}
