/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap;

/**
 * Enumeration class to enumerate the MimeTypes supported by IAP.
 * The first string represents the transport response content type
 * and the second string represents the file extension associated to
 * that content type
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public enum MimeType {
    TEXT_IAPL("text/iapl", "iapl"), TEXT_HTML("text/html", "html"),
    TEXT_XML("text/xml", "xml"), TEXT_PLAIN("text/plain", "txt");

    /**
     * Represents the content type.  This is the first string
     * in the String enumeration list
     */
    private transient String contentType;

    /**
     * Represents the file extension associated to the content type.
     * This is the second string in the String enumeration list
     */
    private transient String fileExt;

    private MimeType(String contentType, String fileExt) {
        this.contentType = contentType;
        this.fileExt = fileExt;
    }

    /**
     * Returns the MimeType enumeration value based on the string content type.
     *
     * @param   contentType The code from the IAP specification.
     * @return  The mime type
     */
    public static MimeType getMimeType(String contentType) {
        MimeType[] types = MimeType.values();
        MimeType mimeType = null;
        for (MimeType type : types) {
            if (type.getContentType().equals(contentType)) {
                mimeType = type;
            }
        }

        return mimeType;
    }

    /**
     * Returns the content type associated to the file extension
     *
     * @param fileExt the file extension of the mime type
     * @return content type
     */
    public static String getContentType(String fileExt) {
        MimeType[] types = MimeType.values();
        String contentType = null;
        for (MimeType type : types) {
            if (type.getFileExt().equals(fileExt)) {
                contentType = type.getContentType();
            }
        }
        return contentType;
    }

    /**
     * Returns the content type string associated with this MimeType.
     *
     * @return the mime type
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * Returns the file extension associated to this MimeType
     *
     * @return file extension
     */
    public String getFileExt() {
        return fileExt;
    }
}
