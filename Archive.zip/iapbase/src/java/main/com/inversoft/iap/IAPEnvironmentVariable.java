/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap;

/**
 * These are reserved variables automatically set into Application Scope whenever an Internet Application is opened.
 * Each environment variable is guaranteed to return the {@link DataType} specified.
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public enum IAPEnvironmentVariable {
    HOST(DataType.STRING),
    VERSION_NUMBER(DataType.STRING),
    APPLICATION_ID(DataType.STRING),
    RATING(DataType.STRING),
    CACHEABLE(DataType.BOOLEAN),
    PORT(DataType.INT),
    URL(DataType.STRING);

    private DataType dataType;

    IAPEnvironmentVariable(DataType dataType) {
        this.dataType = dataType;
    }

    public DataType getDataType() {
        return dataType;
    }
}
