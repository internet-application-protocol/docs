/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap;

/**
 * <p>
 * This is an enumeration for all the possible types of a data
 * value that can be passed between a client and the server
 * and vice versa.
 * </p>
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="dataType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NCName">
 *     &lt;enumeration value="BYTE"/>
 *     &lt;enumeration value="SHORT"/>
 *     &lt;enumeration value="CHAR"/>
 *     &lt;enumeration value="INT"/>
 *     &lt;enumeration value="LONG"/>
 *     &lt;enumeration value="FLOAT"/>
 *     &lt;enumeration value="DOUBLE"/>
 *     &lt;enumeration value="STRING"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum DataType {
    BOOLEAN(boolean.class, Boolean.class),
    CHAR(char.class, Character.class),
    BYTE(byte.class, Byte.class),
    SHORT(short.class, Short.class),
    INT(int.class, Integer.class),
    LONG(long.class, Long.class),
    FLOAT(float.class, Float.class),
    DOUBLE(double.class, Double.class),
    STRING(String.class, String.class);

    private Class<?> primitive;
    private Class<?> wrapper;

    /**
     * Constructs a new <code>DataType</code> that is represented in Java by the
     * given primitive type and the given wrapper class.
     *
     * @param   primitive The primitive type.
     * @param   wrapper The wrapper class.
     */
    private DataType(Class<?> primitive, Class<?> wrapper) {
        this.primitive = primitive;
        this.wrapper = wrapper;
    }

    /**
     * Returns the DataType (if any) for the given type String. This type String
     * is the IAP specific type String as specified by the XML schema and IAP
     * specification. For example, <code>int</code> is the type String for the
     * INT DataType.
     *
     * @param   type The IAP type String.
     * @return  The corresponding DataType.
     */
    public static DataType find(String type) {
        return valueOf(type.toUpperCase());
    }

    /**
     * Returns the DataType (if any) for the given type String. This type String
     * is the IAP specific type String as specified by the XML schema and IAP
     * specification. For example, <code>int</code> is the type String for the
     * INT DataType.
     *
     * @param   type The IAP type String.
     * @return  The corresponding DataType.
     */
    public static DataType find(Class<?> type) {
        while (type.isArray()) {
            type = type.getComponentType();
        }

        DataType dataType = null;
        if (type == boolean.class || type == Boolean.class) {
            dataType = BOOLEAN;
        } else if (type == char.class || type == Character.class) {
            dataType = CHAR;
        } else if (type == byte.class || type == Byte.class) {
            dataType = BYTE;
        } else if (type == short.class || type == Short.class) {
            dataType = SHORT;
        } else if (type == int.class || type == Integer.class) {
            dataType = INT;
        } else if (type == long.class || type == Long.class) {
            dataType = LONG;
        } else if (type == float.class || type == Float.class) {
            dataType = FLOAT;
        } else if (type == double.class || type == Double.class) {
            dataType = DOUBLE;
        } else if (type == String.class) {
            dataType = STRING;
        }

        return dataType;
    }

    /**
     * Returns the primitive Class object for this DataType.
     *
     * @return  The primitive Class.
     */
    public Class<?> getPrimitive() {
        return this.primitive;
    }

    /**
     * Returns the wrapper Class object for this DataType.
     *
     * @return  The wrapper class object.
     */
    public Class<?> getWrapper() {
        return this.wrapper;
    }

    /**
     * Returns a Wrapper class instance that contains the default value for the
     * current type.
     *
     * @return  A wrapper with the default value.
     */
    public Object getDefaultValue() {
        Object value;
        if (this == BOOLEAN) {
            value = Boolean.FALSE;
        } else if (this == BYTE){
            value = new Byte((byte) 0);
        } else if (this == CHAR){
            value = new Character((char) 0);
        } else if (this == SHORT){
            value = new Short((short) 0);
        } else if (this == INT){
            value = new Integer(0);
        } else if (this == LONG){
            value = new Long(0l);
        } else if (this == FLOAT){
            value = new Float(0.0f);
        } else if (this == DOUBLE){
            value = new Double(0.0);
        } else {
            value = ""; // Default String value
        }

        return value;
    }

    /**
     * Determines if the given value is supported by this DataType.
     *
     * @param   value The given value.
     * @return  True if this DataType supports the value, false otherwise.
     */
    public boolean supportsValue(Object value) {
        if (value == null) {
            return true;
        }

        boolean result = false;
        Class<?> type = value.getClass();
        if (this == BOOLEAN) {
            result = (type == Boolean.class);
        } else if (this == BYTE) {
            result = (type == Byte.class);
        } else if (this == CHAR) {
            result = (type == Character.class);
        } else if (this == SHORT) {
            result = (type == Short.class);
        } else if (this == INT) {
            result = (type == Integer.class);
        } else if (this == LONG) {
            result = (type == Long.class);
        } else if (this == FLOAT) {
            result = (type == Float.class);
        } else if (this == DOUBLE) {
            result = (type == Double.class);
        } else if (this == STRING) {
            result = (type == String.class);
        }

        return result;
    }

    /**
     * Returns the number of bytes in the data type.
     *
     * @return  The number of bytes.
     */
    public int getNumberOfBytes() {
        int result = 0;
        if (this == BOOLEAN || this == BYTE) {
            result = 1;
        } else if (this == CHAR || this == SHORT) {
            result = 2;
        } else if (this == INT || this == FLOAT) {
            result = 4;
        } else if (this == LONG || this == DOUBLE) {
            result = 8;
        } else if (this == STRING) {
            result = -1;
        }

        return result;
    }

    /**
     * Returns the primitive symbol that can be used for class loading arrays of primitive types. This
     * is controlled by the {@link Class#getName()} method in the JDK. String's are considered arrays of chars
     * and therefore they return "C".
     *
     * @return  The primitive symbol that the {@link Class#forName(String)} method can use to create
     *          Class objects for arrays.
     */
    public String getPrimitiveSymbol() {
        String name;
        if (this == BOOLEAN) {
            name = "Z";
        } else if (this == BYTE) {
            name = "B";
        } else if (this == CHAR) {
            name = "C";
        } else if (this == SHORT) {
            name = "S";
        } else if (this == INT) {
            name = "I";
        } else if (this == LONG) {
            name = "L";
        } else if (this == FLOAT) {
            name = "F";
        } else if (this == DOUBLE) {
            name = "D";
        } else if (this == STRING) {
            name = "C";
        } else {
            throw new AssertionError("Invalid instance! Inconceivable");
        }
        return name;
    }
}