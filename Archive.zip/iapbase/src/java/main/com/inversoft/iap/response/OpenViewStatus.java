/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.response;

/**
 * <p>
 * This enum are the status codes for the open view response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum OpenViewStatus implements Status {
    SUCCESS("1.0"), FAILURE("2.0"), SESSION_EXPIRATION("2.1"), FAILURE_SESSION_ID("2.2"), FAILURE_NON_EXISTENT("2.3");

    private transient String code;

    private OpenViewStatus(String code) {
        this.code = code;
    }

    /**
     * Resolves the OpenViewStatus based on the IAP specification code.
     *
     * @param   code The code from the IAP specification.
     * @return  The OpenViewStatus or null if the code is invalid.
     */
    public static OpenViewStatus resolve(String code) {
        OpenViewStatus[] all = OpenViewStatus.values();
        OpenViewStatus result = null;
        for (int i = 0; i < all.length; i++) {
            OpenViewStatus status = all[i];
            if (status.getCode().equals(code)) {
                result = status;
            }
        }

        return result;
    }

    /**
     * Returns the status code associated with this status.
     *
     * @return The status code and never null.
     */
    public String getCode() {
        return this.code;
    }
}