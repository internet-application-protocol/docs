/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.request;


import iap.InvalidVersionException;
import iap.Version;


/**
 * <p>
 * The Version Specification is a protocol constraint that
 * informs the server what versions of the IAP protocol it
 * supports. With this version string, it allows the client
 * to specify wildcards, which mean any version. For example,
 * 1.* means support for major version 1 and any minor version.
 * The version numbering system supports only major, minor
 * and sub-minor versioning.
 * </p>
 *
 * <p>
 * Internal Wildcard representations and it's associated alias are
 * defined in <code>Version</code>
 * </p>
 *
 * <p>
 * This class supports comparisons with VersionNumbers to
 * allow programatic evaluations of whether or not a
 * specification supports a specific version.
 * </p>
 *
 * @author  James Humphrey
 * @see     iap.Version
 * @see     iap.VersionNumber
 * @since   IAP 1.0
 * @version 1.0
 */
public final class VersionSpecification extends Version {
    /**
     * Wildcard character
     */
    public static final String WILDCARD = "*";

    /**
     * Integer.MIN_VALUE represents the wildcard value '*'
     */
    public static final Integer WILDCARD_ALIAS = Integer.MIN_VALUE;

    /**
     * Exception message for cases where minor is specified to be null (an
     * asterisk) when an Integer is specified as the Sub-Minor
     */
    private final String versionLogicMsg = "The Minor version number cannot be " +
        "null if a Sub-Minor version number is specified";


    /**
     * Constructor for supplying just a major version specification numbers
     *
     * @param major major version number specification
     */
    public VersionSpecification(Integer major) throws InvalidVersionException {
        this(major, 0, 0);
    }

    /**
     * <p>
     * Constructor for supplying just a major and minor version specification.
     * </p>
     *
     * @param major major version number specification
     * @param minor minor version number specification
     */
    public VersionSpecification(Integer major, Integer minor)
    throws InvalidVersionException {
        this(major, minor, (minor == null) ? WILDCARD_ALIAS : new Integer(0));
    }

    /**
     * Constructor for supplying major, minor, and sub-minor version
     * specification numbers
     *
     * @param major    major version number specification
     * @param minor    minor version number specification
     * @param subMinor sub-minor version number specification
     */
    public VersionSpecification(Integer major, Integer minor, Integer subMinor)
    throws InvalidVersionException {
        super(
            major,
            (minor == null) ? WILDCARD_ALIAS : minor,
            (subMinor == null) ? WILDCARD_ALIAS : subMinor
            );
    }


    /**
     * Decodes a String version object into a Version object
     *
     * @param version the version string to be decoded
     */
   public static VersionSpecification decode(String version) {

        String[] versionNumbers;
        Integer major;
        Integer minor;
        Integer subMinor;
        String delimeter;
        final String invalidVersionMsg = "Version specified is not a valid format";

        // first check for null
        if (version == null) {
            throw new InvalidVersionException(invalidVersionMsg);
        }

        // check if delimeter is a period and escape if so
        if (DELIMETER.equals(".")) {
            delimeter = "\\.";
        } else {
            delimeter = DELIMETER;
        }

        // split up the version string tokens by the periods with max 3 splits
        versionNumbers = version.split(delimeter, 3);

        // return new Version type based on array token values
        //  - VersionSpecification.length = 1
        //      it can only be a major or exception
        //  - VersionSpecification.length = 2
        //      it can only be a major and minor, or an exception
        //  - VersionSpecification.length = 3
        //      it can only be a major and minor and subminor, or an exception
        // - VersionSpecification.length > 3
        //      it's an exception
        if (versionNumbers.length == 1) {
            try {
                major = new Integer(versionNumbers[0]);

                return new VersionSpecification(major);

            } catch (NumberFormatException nfe) {
                throw new InvalidVersionException(invalidVersionMsg);
            }
        } else if (versionNumbers.length == 2) {
            try {
                major = new Integer(versionNumbers[0]);

                // check for asterisk and set minor to null if found
                if (versionNumbers[1].equals(WILDCARD)) {
                    minor = null;
                } else {
                    minor = new Integer(versionNumbers[1]);
                }

                return new VersionSpecification(major, minor);

            } catch (NumberFormatException nfe) {
                throw new InvalidVersionException(invalidVersionMsg);
            }
        } else if (versionNumbers.length == 3) {
            try {

                major = new Integer(versionNumbers[0]);

                // check minor for asterisk and set to null if found
                if (versionNumbers[1].equals(WILDCARD)) {
                    minor = null;
                } else {
                    minor = new Integer(versionNumbers[1]);
                }

                // check for subMinor for asterisk and set null if found
                if (versionNumbers[2].equals(WILDCARD)) {
                    subMinor = null;
                } else {
                    subMinor = new Integer(versionNumbers[2]);
                }

                return new VersionSpecification(major, minor, subMinor);

            } catch (NumberFormatException nfe) {
                throw new InvalidVersionException(invalidVersionMsg);
            }
        } else {
            throw new InvalidVersionException(invalidVersionMsg);
        }
    }

    /**
     * <p>
     * Builds the version number using the major, minor, and sub-minor vars
     * </p>
     * <p>
     * Version Specs will always be in the form of:
     * </p>
     * <ul>
     *      <li>major "." (minor | "*") "." (subMinor | "*")</li>
     * </ul>
     * <p>
     */
    protected String buildVersionString() {

        // concatenate major and delimeter
        String version = getMajor() + DELIMETER;

        // check if minor is a WILDCARD_ALIAS.
        // If so, then subMinor should also be a wildcard.  This makes sense
        // if you think about '1.*', for instance.  '1.*' says that the client
        // is compatible with any major version '1'.  Therefore, '1.*' deduces
        // to '1.*.*'
        if (getMinor().equals(WILDCARD_ALIAS)) {
            version += WILDCARD + DELIMETER + WILDCARD;
        } else {
            version += getMinor() + DELIMETER;

            // check if subMinor is a WILDCARD_ALIAS
            if (getSubMinor().equals(WILDCARD_ALIAS)) {
                version += WILDCARD;
            } else {
                version += getSubMinor();
            }
        }

        return version;
    }

    /**
    * <p>
    * validates the major, minor and subMinor version specification
    * numbers accordingly
    * </p>
    * <ul>
    *      <li>Major must be greater than or equal to 1</li>
    *      <li>Minor must be '*' or a number greater than or equal to 0</li>
    *      <li>Sub-minor must be '*' or a number greater than or equal to 0</li>
    * </ul>
    * <p>
    * Note:  validate() will throw an InvalidVersionException if
    *        minor is a wildcard while subMinor is a valid integer.
    * </p>
    * <p>
    * Example:
    * </p>
    * <ul>
    *      <li>1.*.2 will throw an exception</li>
    *      <li>1.*.* will not throw an exception</li>
    *
    * @throws iap.InvalidVersionException throws exception if versions are not valid
    */
    protected void validate() throws InvalidVersionException {
        // validate major
        if (getMajor() == null || getMajor().intValue() < 1) {
            throw new InvalidVersionException(majorExMsg);
        }

        // minor validation
        if (!getMinor().equals(WILDCARD_ALIAS) && getMinor() < 0) {
            throw new InvalidVersionException(minorExMsg);
        }

        // subMinor validation
        if (!getSubMinor().equals(WILDCARD_ALIAS)) {
            if (getMinor().equals(WILDCARD_ALIAS)) {
                throw new InvalidVersionException(versionLogicMsg);
            } else if (getSubMinor() < 0) {
                throw new InvalidVersionException(subMinorExMsg);
            }
        }
    }

    /**
     * <p>
     * Indicates whether the Version Specification is a wildcard or not
     * </p>
     * <p>
     * It's important to reiterate here that specifications in the form of
     * 'x.*.x' cannot exist.  Additionally, VersionSpecification objects
     * convert internally to their major, minor, subMinor format.  Therefore,
     * a version specification is always a wildcard iff it's sub minor
     * number is a wildcard
     * </p>
     *
     * @return true if wildcard, false otherwise
     */
    public boolean isWildcard() {
        return (getSubMinor().equals(WILDCARD_ALIAS) ? true : false);
    }

    /**
     * <p>
     * Compares the given VersionNumber against this specification and determines
     * if this specification supports the given version number. Wildcards are
     * always taken into consideration.
     * </p>
     *
     * @param   version The version number to evaluate.
     * @return  True if the version number is supported, false otherwise.
     */
    final boolean supports(Version version) {
        boolean isSupported = false;

        if (getMajor().equals(version.getMajor())) {
            if (getMinor().equals(WILDCARD_ALIAS)) {
                isSupported = true;
            } else if (getMinor().equals(version.getMinor())) {
                if (getSubMinor().equals(WILDCARD_ALIAS)
                        || getSubMinor().equals(version.getSubMinor())) {
                    isSupported = true;
                }
            }
        }
        return isSupported;
    }
}