/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.nio.channels.SelectionKey;

/**
 * <p>
 * This implementation is used by the NIO server to control the flow
 * of the server processing for a specific transaction.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class DefaultNIOCallback implements NIOCallback {
    private SelectionKey key;
    private NIOServer server;

    public DefaultNIOCallback(SelectionKey key, NIOServer server) {
        this.key = key;
        this.server = server;
    }

    /**
     * Since the read operation is blocking on the NIOServer to feed in all the data to the
     * NIOInputStream, this method assumes that the NIOServer is finished reading and can change the
     * SelectionKey's interested operations set to write.
     */
    public void doneReading() {
        key.interestOps(SelectionKey.OP_WRITE);
        
        // Reset this to denote a write cycle so that the next read starts new processing
        NIOServer.NIOServerState state = (NIOServer.NIOServerState) key.attachment();
       state.reading = false;
    }

    /**
     * This is complex because it requires the synchronization of three players, the NIOServer, the
     * Request runnable thread that is doing the processing and the NIOOutputStream that is storing
     * the bytes. Here are the steps:
     *
     * 1. The Request runnable has successfully written out all of the bytes it has to the NIOOutputStream
     *    using the write methods. This is guaranteed because those methods block until all bytes are
     *    buffered for later writing.
     * 2. The NIOServer has started writing out the bytes and has quite possibly finished at this point
     *    writing out all of the bytes to the Channel. In either case, the NIOServer is still set to
     *    have the SelectionKey's interested operations set to write. This must not be changed until
     *    the NIOServer is totally confident that it has written everything the Request runnable had
     *    for it.
     * 3. This code is called by the Request runnable and signals to the NIOServer that where ever it
     *    is at, everything that needs to be buffered in the NIOOutputStream has been added.
     * 4. a. The NIOServer has not yet written everything buffered to the channel. It continues to
     *       write until everything is written. It then checks this flag and sees that it has nothing
     *       more to wait for and can now change the SelectionKey's interseted operations set to
     *       read.
     *    b. The NIOServer has already written everything. Since it is still set such that the
     *       SelectionKey's interested operations set is write, it will be guaranteed to call into
     *       the write method once more. At this point it will see that the flag is set and nothing
     *       more is buffered or can be buffered and will change the SelectionKey's interested
     *       operations set to read.
     */
    public void doneWriting() {
        NIOServer.NIOServerState state = (NIOServer.NIOServerState) key.attachment();
        state.doneWriting = true;
    }

    public void failed() {
        server.finished(key);
    }
}