/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * <p>
 * This class is an NIOClient that handles outgoing requests.
 * This class handles all of the IO processing and there should
 * only be a single instance of this class running per VM (or
 * per CPU if necessary).
 * </p>
 *
 * @author Brian Pontarelli
 */
public class NIOClient extends Thread {
    private static final Logger logger = Logger.getLogger(NIOClient.class.getName());

    private final ByteBuffer buffer = ByteBuffer.allocate(4096);
    private final int selectTimeout;
    private final int queueSize;
    private final Selector selector;
    private volatile boolean running = false;

    /**
     * <p>
     * Constructs a new NIOClient that has the given maximum queue size. This
     * starts the NIOClient Thread before returning so there is no need for the
     * caller to start this Thread.
     * </p>
     *
     * @param   queueSize The maximum size that the IO work queue can grow to
     *          before work is turned away.
     * @throws  IOException If the Selector used internally could not be created.
     */
    public NIOClient(int selectTimeout, int queueSize) throws IOException {
        this.selectTimeout = selectTimeout;
        this.queueSize = queueSize;
        this.selector = Selector.open();
        this.running = true;

        start();
    }

    /**
     * <p>Runs the NIO processing.</p>
     */
    public void run() {
        // Run until stopped
        while (running) {
            try {
                Set keys = selector.keys();
                synchronized (keys) {
                    if (keys.size() == 0) {
                        keys.wait();
                    } else {
                        // Clear out the invalid keys
                        long now = System.currentTimeMillis();
                        for (Iterator i = keys.iterator(); i.hasNext();) {
                            SelectionKey key = (SelectionKey) i.next();
                            if (!isValid(key, now)) {
                                finished(key);
                            }
                        }
                    }
                }

                int num = selector.select(selectTimeout);
                if (num > 0) {
                    processKeys();
                } else {
                    Thread.yield();
                }
            } catch (IOException ioe) {
                logger.log(Level.SEVERE, "Unable to select", ioe);
            } catch (InterruptedException ie) {
                // Continue processing
            }
        }

        try {
            selector.close();
        } catch (IOException ioe) {
            logger.log(Level.SEVERE, "Unable to close selector", ioe);
        }
    }

    /**
     * Signals this NIOClient to shutdown.
     */
    public void shutdown() {
        running = false;

        Set keys = selector.keys();
        synchronized (keys) {
            for (Iterator iter = keys.iterator(); iter.hasNext();) {
                SelectionKey key = (SelectionKey) iter.next();
                finished(key);
            }

            keys.notify();
        }

        try {
            selector.close();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Unable to close selector", e);
        }
    }

    /**
     * <p>
     * Sends a request to the given URL. The request itself is the byte[] given.
     * These bytes are transmitted wholesale to the server.
     * </p>
     *
     * @param   url The URL to contact and transmit the bytes to.
     * @param   bytes The bytes to transmit.
     * @param   timeout The length of time to attempt to transmit the bytes before
     *          giving up and returning null.
     * @return  The result from the URL or null if the timeout was reached.
     * @throws  IOException If the socket creation failed. This is not throw if
     *          the read or write failed, but only if the creation failed.
     * @throws  QueueFullException If the queue is full and this work can not be
     *          added.
     */
    public byte[] execute(URL url, byte[] bytes, long timeout) throws IOException, QueueFullException {
        Work work = new Work();
        work.in = url;
        work.request = bytes;

        synchronized (work) {
            add(work, timeout);
            try {
                work.wait(timeout);
            } catch (InterruptedException e) {
                logger.log(Level.INFO, "NIO operation interrupted");
            }

            return work.response;
        }
    }

    /**
     * <p>
     * Convienence method that calls {@link #execute(URL, byte[], long)} with the
     * bytes from the String message.
     * </p>
     *
     * @param   url The URL to contact and transmit the bytes to.
     * @param   message The message to transmit.
     * @param   timeout The length of time to attempt to transmit the bytes before
     *          giving up and returning null.
     * @return  The result from the URL or null if the timeout was reached. This is decoded using the
     *          UTF-8 character set.
     * @throws  IOException If the socket creation failed. This is not throw if
     *          the read or write failed, but only if the creation failed.
     * @throws  QueueFullException If the queue is full and this work can not be
     *          added.
     */
    public String execute(URL url, String message, long timeout) throws IOException, QueueFullException {
        byte[] ba = execute(url, message.getBytes(), timeout);
        String result = null;
        if (ba != null) {
            result = new String(ba, "UTF-8");
        }

        return result;
    }

    /**
     * <p>Internally adds the work to the selector.</p>
     */
    private void add(Work work, long timeout) throws QueueFullException, IOException {
        SocketChannel channel = null;
        try {
            Set keys = selector.keys();
            synchronized (keys) {
                if (keys.size() + 1 > queueSize) {
                    throw new QueueFullException("Queue has reached maximum size" +
                        " of " + queueSize);
                }

                // Open the local socket
                URL url = work.in;
                int port = url.getPort() == -1 ? url.getDefaultPort() : url.getPort();
                InetSocketAddress addr = new InetSocketAddress(url.getHost(), port);

                channel = SocketChannel.open();
                channel.configureBlocking(false);
                channel.connect(addr);

                // Register the selector with the channel to perform a connect operation
                WorkState state = new WorkState(timeout, work);
                channel.register(selector, SelectionKey.OP_CONNECT, state);
                logger.log(Level.FINEST, "Connecting to server");

                // Wake up the Worker thread if it is waiting in run
                keys.notify();
                selector.wakeup();
            }
        } catch (IOException ioe) {
            // Close the channel if it was created.
            if (channel != null) {
                try {
                    channel.close();
                } catch (IOException ioe2) {
                    logger.log(Level.SEVERE, "Unable to close channel", ioe2);
                }
            }

            // Being very anal, but I'm going to cancel the key just in case
            SelectionKey key = channel.keyFor(selector);
            if (key != null) {
                key.cancel();
            }

            logger.log(Level.SEVERE, "Channel creation or registration failed", ioe);
            throw ioe;
        }
    }

    /**
     * <p>
     * The main IO processing method. This iterates over the selected keys and
     * reads from, writes to and finishes connecting to the remote server.
     * </p>
     */
    private void processKeys() {
        Set keys = selector.selectedKeys();
        long now = System.currentTimeMillis();
        for (Iterator iter = keys.iterator(); iter.hasNext();) {
            SelectionKey key = (SelectionKey) iter.next();
            iter.remove();

            SocketChannel channel = (SocketChannel) key.channel();
            if (!isValid(key, now)) {
                finished(key);
                continue;
            }

            try {
                WorkState state = (WorkState) key.attachment();
                boolean connectable = key.isConnectable();
                if (connectable && channel.finishConnect()) {
                    logger.log(Level.FINEST, "Connected to server");
                    key.interestOps(SelectionKey.OP_WRITE);
                } else if (connectable) {
                    logger.log(Level.FINEST, "Still connecting to server");
                    key.interestOps(SelectionKey.OP_CONNECT);
                } else if (key.isWritable()) {
                    if (doWrite(channel, state)) {
                        logger.log(Level.FINEST, "Done writing, registering for read");
                        key.interestOps(SelectionKey.OP_READ);
                    }
                } else if (key.isReadable()) {
                    if (doRead(channel, state)) {
                        logger.log(Level.FINEST, "Done reading");
                        finished(key);
                    }
                }
            } catch (IOException ioe) {
                logger.log(Level.SEVERE, "Failure during IO operation", ioe);
                finished(key);
            }
        }
    }

    /**
     * <p>
     * Writes the bytes for a specific request to the remote server. This might
     * not write all the bytes, or it might write them all, or it might write none.
     * </p>
     *
     * @param   channel The channel to write to.
     * @param   state The state to get the bytes to write from.
     * @return  True if finished writing, false otherwise.
     * @throws  IOException If the write failed.
     */
    private boolean doWrite(SocketChannel channel, WorkState state)
    throws IOException {
        int rem = state.request.remaining();
        int num = channel.write(state.request);
        if (logger.isLoggable(Level.FINEST)) {
            logger.log(Level.FINEST, "Wrote " + num + " bytes to server");
        }

        return (num == rem);
    }

    /**
     * Reads the response from the remote server using the socket channel given.
     * The success, if the read finishes is stored in the WorkState object given.
     * Likewise, any data read in is appened to the buffer in the WorkState object
     * given.
     *
     * @param   channel The channel to read from.
     * @param   state The state to store success status and the data.
     * @return  True if the read is finished, false otherwise.
     * @throws  IOException If the read failed.
     */
    private boolean doRead(SocketChannel channel, WorkState state)
    throws IOException {
        boolean done = false;
        int num = channel.read(buffer);
        if (num == -1) {
            logger.finest("Read end of stream");
            state.success = true;
            done = true;
        } else if (num > 0) {
            if (logger.isLoggable(Level.FINEST)) {
                logger.finest("Read in " + num + " bytes");
            }

            buffer.flip();
            if (state.response == null) {
                logger.finest("New response");
                state.response = ByteBuffer.allocate(num);
                state.response.put(buffer);
            } else {
                logger.finest("Adding to existing response");
                ByteBuffer newBuf = ByteBuffer.allocate(state.response.capacity() + num);
                newBuf.put(state.response);
                newBuf.put(buffer);
                state.response = newBuf;
            }
            buffer.clear();
        }

        return done;
    }

    /**
     * <p>
     * Called when the work for the given key is complete. This will cancel the
     * key, close the channel and add any result (if the WorkState was marked as
     * successful) to the WorkState object.
     * </p>
     *
     * @param   key The key to finish.
     */
    private void finished(SelectionKey key) {
        key.cancel();

        try {
            Channel ch = key.channel();
            ch.close();
        } catch (IOException ioe) {
            logger.log(Level.SEVERE, "Failed to close socket", ioe);
        } finally {
            WorkState state = (WorkState) key.attachment();
            Work work = state.work;
            synchronized (work) {
                if (state.success && state.response != null) {
                    logger.finest("NIOClient success. Converting ByteBuffer to byte array");
                    work.response = state.response.array();
                } else if (state.success) {
                    logger.finest("NIOClient success. Response is null");
                }

                work.notify();
            }
        }
    }

    /**
     * Determines if the given key is valid or not. It does this based on the key
     * being valid {@link SelectionKey#isValid()}, the WorkState attachment being
     * not-timed out {@link WorkState#isTimedOut(long)} and the channel still
     * being open {@link SocketChannel#isOpen()}.
     *
     * @param   key The key to check for validity.
     * @param   now The current time in milliseconds.
     * @return  True if the key is valid false otherwise.
     */
    private boolean isValid(SelectionKey key, long now) {
        WorkState state = (WorkState) key.attachment();
        return (key.isValid() && !state.isTimedOut(now) && key.channel().isOpen());
    }


    private static class WorkState {
        private final ByteBuffer request;
        private final Work work;
        private final long expires;
        private ByteBuffer response;
        private boolean success = false;

        public WorkState(long timeout, Work work) {
            this.request = ByteBuffer.wrap(work.request);
            this.expires = System.currentTimeMillis() + timeout;
            this.work = work;
        }

        /**
         * Using the given current time in milliseconds, this determines if the
         * unit of work has timed out or not.
         *
         * @param   now The current time in milliseconds.
         * @return  True if timed out, false if not.
         */
        public boolean isTimedOut(long now) {
            return (now >= expires);
        }
    }

    public static class Work {
        public URL in;
        public byte[] request;
        public byte[] response;
    }
}