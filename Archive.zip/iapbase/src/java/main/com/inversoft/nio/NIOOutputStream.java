/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;

/**
 * <p>
 * This
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class NIOOutputStream extends OutputStream {
    private byte[] buffer = new byte[1024];
    private int length = 0;
    private volatile boolean closed;

    ByteBuffer grabQuick() {
        ByteBuffer buf = null;
        synchronized (this) {
            if (length > 0) {
                buf = ByteBuffer.allocate(length);
                buf.put(buffer, 0, length);
                buf.flip();
                length = 0;
                notify();
            }
        }

        return buf;
    }

    boolean isClosed() {
        return closed;
    }

    public void write(int b) throws IOException {
        if (closed) {
            throw new IOException("Stream closed");
        }

        synchronized (this) {
            if (length >= 1024) {
                if (!waitForSpace()) {
                    throw new IOException("Stream closed");
                }
            }

            buffer[length++] = (byte) (b & 0xFF);
        }
    }

    @Override
    public synchronized void write(byte ba[], int off, int len) throws IOException {
        for (int i = off; i < len; i++) {
            write(ba[i]);
        }
    }

    @Override
    public void close() throws IOException {
        closed = true;
        synchronized (this) {
            notify();
        }
    }

    private synchronized boolean waitForSpace() {
        int currentPosition = length;
        while (!closed && currentPosition >= 1024) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
            currentPosition = length;
        }

        return !closed;
    }
}