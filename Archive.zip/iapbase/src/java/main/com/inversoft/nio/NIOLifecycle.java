/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * <p>
 * This interface manages the lifecycle for an NIO transaction from
 * accept through close.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface NIOLifecycle {
    /**
     * Called by the NIO server at the beginning of a transaction. This occurs when the connection
     * from a remote client is accepted by the server.
     *
     * @return  The transaction ID for this transaction. This ID should be anything that the
     *          implementation might need to associate different transactions from one another. This
     *          can also be null if the implementation doesn't use transactions.
     */
    String startTransaction();

    /**
     * Called by the NIO server whenever it begins a single request/response cycle with the client
     * that will require server side processing.
     *
     * <p>
     * Okay everyone that implements this, here's the important stuff, down and dirty.
     * </p>
     *
     * <ol>
     *  <li>Do not do any work in this method!</li>
     *  <li>Always spawn threads or add work to a queue consumed by a thread pool!</li>
     *  <li>If this method ever blocks, bad things happen to the server!</li>
     *  <li>The piped streams given are for reading and writting in separate threads only!</li>
     *  <li>Luckily these streams can be used like normal without considering blocking issues.</li>
     *  <li>Feel free to close the streams when finished!</li>
     * </ol>
     *
     * @param   callback The NIOCallback that is used by the implementation and the runnable that is
     *          handling the transaction.
     * @param   transactionID The transaction ID created when the NIO server called the
     *          {@link #startTransaction()} method.
     * @param   inputStream The stream to read the request from.
     * @param   outputStream The stream to write the response to.
     */
    void startProcessing(NIOCallback callback, String transactionID, InputStream inputStream,
        OutputStream outputStream);

    /**
     * Called by the NIO server when all of the processing has finished and the server is tearing
     * down a connection to a client.
     *
     * @param   transactionId The transaction ID of the transaction being terminated.
     */
    void endTransaction(String transactionId);
}