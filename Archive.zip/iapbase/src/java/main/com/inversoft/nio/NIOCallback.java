/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

/**
 * <p>
 * This interface is used by {@link NIOLifecycle} implementations to control
 * the the NIOServer with respect to the selection key for the connection the
 * lifecycle is managing.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface NIOCallback {
    /**
     * Implementations should call this method when they have successfully completed a read cycle.
     */
    void doneReading();

    /**
     * Implementations should call this method when they have successfully completed a write cycle.
     */
    void doneWriting();

    /**
     * Implementations should call this method immediately upon encountering a failure and should
     * immediately cease processing.
     */
    void failed();
}