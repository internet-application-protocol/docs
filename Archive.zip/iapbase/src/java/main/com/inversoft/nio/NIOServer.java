/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectableChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * <p>
 * This class is an NIOServer that handles incoming requests.
 * </p>
 *
 * @author Brian Pontarelli
 */
public class NIOServer extends Thread {
    private static final Logger logger = Logger.getLogger(NIOServer.class.getName());

    private final Selector selector;
    private final NIOLifecycle lifecycle;
    private final SelectionKey acceptKey;
    private final int port;
    private final long timeout;
    private final long selectTimeout;
    private volatile boolean running;
    private volatile boolean shutdownSignal;

    /**
     * Starts a new NIOServer.
     *
     * @param   lifecycle An NIOLifecycle that handles the creation, processing and end of transactions
     *          that are received by the selector.
     * @param   port The port for the server to listen on.
     * @param   timeout The timeout for requests (in milliseconds). If the request
     *          takes longer than this time to process, the connection to the client
     *          will be closed.
     * @param   selectTimeout The timeout (in milliseconds) for the select operation
     *          in the run loop. This should be set to something low so that other
     *          timeouts are handled efficiently.
     */
    public NIOServer(NIOLifecycle lifecycle, int port, long timeout, long selectTimeout)
    throws IOException {
        this.lifecycle = lifecycle;
        this.timeout = timeout;
        this.selectTimeout = selectTimeout;
        this.port = port;
        this.selector = Selector.open();

        SocketAddress addr = new InetSocketAddress(port);
        ServerSocketChannel channel = ServerSocketChannel.open();
        channel.configureBlocking(false);
        channel.socket().bind(addr);
        this.acceptKey = channel.register(selector, SelectionKey.OP_ACCEPT);

        // Start ourselves
        this.running = true;
        this.shutdownSignal = false;
        setDaemon(false);
        start();
    }


    /**
     * @return  True if the server is running, false otherwise.
     */
    public boolean isRunning() {
        return running;
    }

    /**
     * Shuts down the server in a clean fashion.
     */
    public void shutdown() {
        this.shutdownSignal = true;
        this.selector.wakeup();
    }

    /**
     * @return  The IO timeout of the server.
     */
    public long getTimeout() {
        return this.timeout;
    }

    /**
     * @return  The port that the server is listening on.
     */
    public int getPort() {
        return this.port;
    }

    /**
     * The main run loop of the thread that grabs the work and processes it.
     */
    public void run() {
        logger.log(Level.FINE, "NIOServer started on port " + port);

        while (!this.shutdownSignal) {
            try {
                int num = this.selector.select(this.selectTimeout);
                if (num > 0) {
                    handleKeys();
                } else {
                    Thread.yield();
                }
            } catch (IOException ioe) {
                // Not sure if this is recoverable, but let's assume it is and
                // smother it.
                logger.log(Level.SEVERE, "IOException during select", ioe);
            }

            // Clean out the selector
            Set<SelectionKey> keys = this.selector.keys();
            synchronized (keys) {
                long now = System.currentTimeMillis();
                for (SelectionKey key : keys) {
                    if (key == this.acceptKey) {
                        continue;
                    }

                    if (!isValid(key, now)) {
                        finished(key);
                    }
                }
            }
        }

        this.running = false;

        try {
            Set<SelectionKey> keys = this.selector.keys();
            for (SelectionKey key : keys) {
                key.channel().close();
                key.cancel();
            }

            this.selector.close();
            logger.log(Level.FINE, "Shutdown NIOServer listening on port " + port);
        } catch (IOException ioe) {
            logger.log(Level.SEVERE, "Unable to close selector", ioe);
        }
    }

    /**
     * Loops over all the selected keys and handles each one.
     */
    private void handleKeys() {
        Set<SelectionKey> keySet = this.selector.selectedKeys();
        long now = System.currentTimeMillis();
        for (Iterator<SelectionKey> iter = keySet.iterator(); iter.hasNext();) {
            SelectionKey key = iter.next();
            iter.remove();

            if (key != this.acceptKey && !isValid(key, now)) {
                finished(key);
                continue;
            }

            try {
                NIOServerState state = (NIOServerState) key.attachment();
                if (key.isAcceptable()) {
                    accept(key);
                } else if (key.isReadable() || state.incoming.remaining() > 0) {
                    read(key);
                } else if (key.isWritable()) {
                    write(key);
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Exception in handleKeys", e);
                finished(key);
            }
        }
    }

    /**
     * Handles a key that is acceptable (incoming).
     */
    private void accept(SelectionKey key) throws IOException {
        ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
        SocketChannel channel = serverChannel.accept();
        channel.configureBlocking(false);

        if (logger.isLoggable(Level.FINE)) {
            logger.log(Level.FINE, "Client connected from [" +
                channel.socket().getRemoteSocketAddress() + "]");
        }

        NIOServerState state = new NIOServerState(this.timeout);
        state.transactionId = this.lifecycle.startTransaction();

        channel.register(this.selector, SelectionKey.OP_READ, state);
    }

    /**
     * Reads from the client.
     */
    private void read(SelectionKey key) throws IOException {
        NIOServerState state = (NIOServerState) key.attachment();
        SocketChannel channel = (SocketChannel) key.channel();

        state.incoming.clear();
        int num = channel.read(state.incoming);
        if (num > 0) {
            state.incoming.flip();

            // Setup the processor if this is the first read cycle.
            if (!state.reading) {
                state.reading = true;
                startProcessing(key, state);
            }

            state.inputStream.addByteBuffer(state.incoming);
        } else if (num == -1) {
            logger.finest("Shutting down read side since client closed the InputStream");
            key.interestOps(0);
            state.inputStream.close();
            state.incoming.limit(0);
        }

        if (logger.isLoggable(Level.FINEST)) {
            logger.finest("Client from " + channel.socket().getRemoteSocketAddress() + " wrote " +
                num + " bytes");
        }
    }

    private void startProcessing(SelectionKey key, NIOServerState state) {
        state.inputStream = new NIOInputStream();
        state.outputStream = new NIOOutputStream();

        DefaultNIOCallback callback = new DefaultNIOCallback(key, this);
        this.lifecycle.startProcessing(callback, state.transactionId, state.inputStream, state.outputStream);
    }

    /**
     * Writes back to the client.
     */
    private void write(SelectionKey key) throws IOException {
        NIOServerState state = (NIOServerState) key.attachment();
        SocketChannel channel = (SocketChannel) key.channel();

        if (state.outgoing != null) {
            if (state.outgoing.remaining() == 0) {
                state.outgoing = null;
            } else {
                channel.write(state.outgoing);
            }
        }

        if (state.outputStream != null && state.outgoing == null) {
            state.outgoing = state.outputStream.grabQuick();
            if (state.outgoing != null) {
                channel.write(state.outgoing);
            } else if (state.outputStream.isClosed()) {
                key.interestOps(0);
            }
        }

        // Are we complete done writing? If so, set the op to read again and clear the flag.
        if ((state.outgoing != null && state.outgoing.remaining() == 0) || (state.outgoing == null) &&
                state.doneWriting) {
            state.doneWriting = false;
            key.interestOps(SelectionKey.OP_READ);
        }
    }

    /**
     * Determines if the given key is valid or not. It does this based on the key
     * being valid {@link SelectionKey#isValid()}, the WorkState attachment being
     * not-timed out {@link NIOServerState#isTimedOut(long)} and the channel still
     * being open {@link SocketChannel#isOpen()}.
     *
     * @param   key The key to check for validity.
     * @param   now The current time in milliseconds.
     * @return  True if the key is valid, false otherwise.
     */
    private boolean isValid(SelectionKey key, long now) {
        NIOServerState state = (NIOServerState) key.attachment();
        return (key.isValid() && !state.isTimedOut(now) && key.channel().isOpen());
    }

    /**
     * Closes the channel, cancels the key and smothers all exceptions.
     */
    void finished(SelectionKey key) {
        key.cancel();

        if (logger.isLoggable(Level.FINEST)) {
            logger.log(Level.FINEST, "Closing connection to client [" +
                ((SocketChannel) key.channel()).socket().getInetAddress() + "]");
            Thread.dumpStack();
        }

        NIOServerState state = (NIOServerState) key.attachment();
        if (state != null) {
            // End the transaction if there is one
            if (state.transactionId != null) {
                this.lifecycle.endTransaction(state.transactionId);
            }

            InputStream is = state.inputStream;
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    logger.log(Level.SEVERE, "Unable to close NIOInputStrem");
                }
            }

            OutputStream os = state.outputStream;
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {
                    logger.log(Level.SEVERE, "Unable to close NIOOutputStrem");
                }
            }
        }

        try {
            SelectableChannel channel = key.channel();
            channel.close();
        } catch (IOException ioe) {
            // Smother, nothing can be done.
            logger.log(Level.SEVERE, "IOException during SocketChannel close", ioe);
        }
    }


    class NIOServerState {
        public final long startTime = System.currentTimeMillis();
        public final long expireTime;
        public final ByteBuffer incoming;
        public ByteBuffer outgoing;
        public volatile NIOInputStream inputStream;
        public volatile NIOOutputStream outputStream;
        public String transactionId;
        public boolean reading;
        public volatile boolean doneWriting;

        public NIOServerState(long timeout) {
            this.expireTime = startTime + timeout;
            this.incoming = ByteBuffer.allocate(768);
            this.incoming.limit(0);
        }

        public boolean isTimedOut(long now) {
            return (now >= this.expireTime);
        }
    }
}