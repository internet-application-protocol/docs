/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;


/**
 * <p>
 * This class is an exception that is thrown from the NIOClient
 * when it has too much work and nothing more can be added.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class QueueFullException extends Exception {
    /**
     * @inheritDoc
     */
    public QueueFullException() {
        super();
    }

    /**
     * @inheritDoc
     */
    public QueueFullException(String message) {
        super(message);
    }

    /**
     * @inheritDoc
     */
    public QueueFullException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @inheritDoc
     */
    public QueueFullException(Throwable cause) {
        super(cause);
    }
}