/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.nio;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * <p>
 * This
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class NIOInputStream extends InputStream {
    private static final ByteBuffer EMPTY = ByteBuffer.allocate(0);
    private LinkedBlockingQueue<ByteBuffer> queue = new LinkedBlockingQueue<ByteBuffer>();
    private ByteBuffer current;
    private volatile boolean closed;
    private volatile int available;

    void addByteBuffer(ByteBuffer buf) throws IOException {
        if (closed) {
            return;
        }

        try {
            int length = buf.remaining();
            ByteBuffer toAdd = ByteBuffer.allocate(length);
            toAdd.put(buf);
            toAdd.flip();
            queue.add(toAdd);
            available += length;
        } catch (IllegalStateException ise) {
            throw new IOException(ise.toString());
        }
    }

    public int read() throws IOException {
        if (closed) {
            return -1;
        }

        if (current == null || current.remaining() == 0) {
            if (!pollForCurrent()) {
                return -1;
            }
        }

        available--;
        return current.get() & 0xFF;
    }

    @Override
    public int read(byte ba[], int off, int len) throws IOException {
        if (closed && queue.peek() == null) {
            return -1;
        }

        // Block on the first character. This waits until a ByteBuffer was added and can be used to
        // pull bytes from. This is also a another check for closed, which is only checked just prior
        // to exit as well.
        int numRead = 0;
        if (pollForCurrent()) {
            int i;
            for (i = 0; i < current.remaining() && i < len; i++) {
                ba[off + i] = current.get();
            }

            numRead = i;

            if (i < len && queue.peek() != null) {
                numRead += read(ba, off + i, len - i);
            }
        }

        return numRead;
    }

    @Override
    public long skip(long n) throws IOException {
        // Be smart and only skip the bytes we have and nothing more.
        if (closed) {
            return 0;
        }

        int skipped = 0;
        if (available > 0) {
            if (current != null) {
                int skip = skipInCurrent((int) n);
                if (skip == -1) {
                    return -1;
                }

                skipped = skip;
                n -= skip;
            }

            while (available > 0 && n > 0) {
                pollForCurrent();
                int skip = skipInCurrent((int) n);
                if (skip == -1) {
                    break;
                }

                skipped += skip;
                n -= skip;
            }
        }

        return skipped;
    }

    @Override
    public int available() throws IOException {
        return available;
    }

    @Override
    public void close() throws IOException {
        closed = true;
        queue.clear();
        queue.add(EMPTY);
    }

    private boolean pollForCurrent() {
        while ((current == null || current.remaining() == 0) && !closed) {
            current = queue.poll();
        }

        return !closed;
    }

    private int skipInCurrent(int totalToSkip) {
        if (closed) {
            return -1;
        }

        int skipped;
        int length = current.remaining();
        if (length > 0 && length > totalToSkip) {
            skipped = length;
            current = null;
        } else {
            skipped = (int) totalToSkip;
            current.position(current.position() + (int) totalToSkip);
        }

        available -= skipped;
        return skipped;
    }
}