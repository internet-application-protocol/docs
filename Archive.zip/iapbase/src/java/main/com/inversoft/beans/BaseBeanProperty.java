/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.inversoft.beans.types.TypeConversionException;
import com.inversoft.beans.types.TypeConverter;
import com.inversoft.beans.types.TypeConverterRegistry;
import com.inversoft.util.ObjectTools;
import com.inversoft.util.ReflectionException;
import com.inversoft.util.ReflectionTools;

import static com.inversoft.beans.EventType.*;


/**
 * This class is the base class for the BeanProperty and the
 * NestedBeanProperty classes. It provides the standard methods
 * used by both classes and the standard properties
 *
 * @author  Brian Pontarelli
 */
public abstract class BaseBeanProperty {
    /**
     * Holds the name of the property that this bean property describes.
     */
    String propertyName;

    /**
     * Holds the Class that the property is contain in.
     */
    Class<?> beanClass;

    /**
     * Holds the Class type of the property that this bean property describes.
     */
    Class<?> propertyType;

    /**
     * The read method for the Bean property.
     */
    Method read;

    /**
     * The write method for the Bean property.
     */
    Method write;

    /**
     * The collection flag.
     */
    boolean collection;

    /**
     * This holds the list of property listeners for the bean property
     */
    List<PropertyListener> propertyListeners = new ArrayList<PropertyListener>();

    /**
     * This holds the list of conversion listeners for the bean property
     */
    List<ConversionListener> conversionListeners = new ArrayList<ConversionListener>();


    /**
     * Constuctor with initial properties. This constructor should be called
     * by the sub-classes if they want to setup the propertyName and beanClass
     * members during construction.
     */
    protected BaseBeanProperty(String propertyName, Class<?> beanClass)
    throws BeanException {
        this.propertyName = propertyName;
        this.beanClass = beanClass;
        initialize();
    }

    /**
     * Initializes the collection boolean and propertyType once the read method
     * is setup in base classes.
     */
    void initialize() {
        this.propertyType = this.read.getReturnType();
        this.collection = ObjectTools.isCollection(propertyType);
    }


    /**
     * <p>
     * Gets the name of the property. If this is a simple BeanProperty, than the
     * name is just the name of the property.
     * </p>
     *
     * <p>
     * <b>For BeanProperty</b><br/>
     * getName() -> name<br/>
     * <b> For IndexedBeanProperty</b><br/>
     * getFoo(indices) -> foo<br/>
     * <b>For NestedBeanProperty</b><br/>
     * getFoo().getBar().getName() -> foo.bar.name<br/>
     * </p>
     *
     * <p>
     * New sub-classes can override this method, but it is advisable to use the
     * default version because it returns the property name that was used during
     * construction.
     * </p>
     *
     * <p>
     * <b>NOTE:</b> If a sub-classes uses the default constructor and does not make
     * use of the propertyName member of this class, then this method should be
     * overridden (if applicable).
     * </p>
     *
     * @return  The name of the property
     */
    public String getPropertyName() {
        return propertyName;
    }

    /**
     * <p>
     * Gets the type of the property, which may be null depending on the type of
     * property. If this BaseBeanProperty is actually a {@link BeanProperty
     * BeanProperty} or an {@link IndexedBeanProperty IndexedBeanProperty} then
     * this method returns the properties defined type. This does not return the
     * runtime type of the property.
     * </p>
     *
     * <p>
     * For example:<br/>
     * public String getName() {} -> java.lang.String<br/>
     * </p>
     *
     * <p>
     * This method does not work for nested properties because each property in
     * the nesting can have a different runtime type. Therefore, this method
     * attempts to determine the declared type. However, in some cases, this will
     * be impossible.
     * </p>
     *
     * <p>
     * Here's an example of a declared property whose type can be retrieved.<br/>
     * getFoo().getBar().getName()<br/>
     * public Bean1 getFoo()<br/>
     * public Bean2 getBar()<br/>
     * public String getName()<br/>
     * The property type is found to be a String.<br/>
     * </p>
     *
     * <p>
     * Here's an example of a declared property whose type can NOT be retrieved.<br/>
     * getFoo().getBar().getArray()[1].getIndexed(2).getName()<br/>
     * public Object getFoo()<br/>
     * public Object getBar()<br/>
     * public Object[] getArray()<br/>
     * public Object getIndexed(int indices)<br/>
     * public String getName()<br/>
     * The property type can not be determined until runtime so that we can figure
     * out what the actually objects returned from all those methods are.
     * </p>
     *
     * @return  The type of the property
     */
    public Class<?> getPropertyType() {
        return propertyType;
    }

    /**
     * Gets the full name of the property. This is most useful for sub-classes
     * because it allows them to specify a custom name for the property rather
     * than using the propertyName member variable. The default implementation
     * here simply returns the propertyName member variable.
     *
     * @return  The full name of the property, which is usually just the
     *          propertyName member variable, but sub-classes can override this
     *          method to change the name however they see fit.
     */
    public String getFullName() {
        return propertyName;
    }

    /**
     * Returns the class of the bean that this property is contained in
     */
    public Class<?> getBeanClass() {
        return beanClass;
    }

    /**
     * Returns the read method of the bean property.
     */
    public Method getReadMethod() {
        return read;
    }

    /**
     * Returns the write method name of the bean property.
     */
    public Method getWriteMethod() {
        return write;
    }

    /**
     * Creates an instance of the class that this BeanProperty's property is
     * contained in.
     *
     * @return  A new instance of the class
     * @throws  BeanException If there was a problem instantiating the class
     */
    public Object instantiate() throws BeanException {
        try {
            return ReflectionTools.instantiate(beanClass);
        } catch (ReflectionException re) {
            throw new BeanException(re);
        }
    }

    /**
     * Adds a property listener to the list of listeners for this property. This
     * method is not thread safe. If you need to have a thread safe implementation,
     * please use one of the Synchronized sub-classes.
     *
     * @param   listener The new property listener to add to the list
     */
    public void addPropertyListener(PropertyListener listener) {
        synchronized (propertyListeners) {
            propertyListeners.add(listener);
        }
    }

    /**
     * Removes the given property listener from the list of property listeners. This
     * method is not thread safe. If you need to have a thread safe implementation,
     * please use one of the Synchronized sub-classes.
     *
     * @param   listener The property listener to remove from the list
     */
    public void removePropertyListener(PropertyListener listener) {
        synchronized (propertyListeners) {
            propertyListeners.remove(listener);
        }
    }

    /**
     * Returns an iterator for the list of property listeners. This method is not
     * thread safe. If you need to have a thread safe implementation, please use
     * one of the Synchronized sub-classes.
     *
     * @return  An interator for the list of property listeners
     */
    public List<PropertyListener> getPropertyListeners() {
        synchronized (propertyListeners) {
            return new ArrayList<PropertyListener>(propertyListeners);
        }
    }

    /**
     * Returns true if there are any property listeners for this property. This
     * method is not thread safe. If you need to have a thread safe implementation,
     * please use one of the Synchronized sub-classes.
     *
     * @return  True or false depending on if there are property listeners or not
     */
    public boolean hasPropertyListeners() {
        synchronized (propertyListeners) {
            return !propertyListeners.isEmpty();
        }
    }

    /**
     * Adds a conversion listener to the list of listeners for this property. This
     * method is not thread safe. If you need to have a thread safe implementation,
     * please use one of the Synchronized sub-classes.
     *
     * @param   listener The new conversion listener to add to the list
     */
    public void addConversionListener(ConversionListener listener) {
        synchronized (conversionListeners) {
            conversionListeners.add(listener);
        }
    }

    /**
     * Removes the given conversion listener from the list of conversion listeners.
     *
     * @param   listener The conversion listener to remove from the list
     */
    public void removeConversionListener(ConversionListener listener) {
        synchronized (conversionListeners) {
            conversionListeners.remove(listener);
        }
    }

    /**
     * Returns a List containing all the {@link ConversionListener}s. This list
     * is not live, changes will not affect this BeanProperty.
     */
    public List<ConversionListener> getConversionListeners() {
        synchronized (conversionListeners) {
            return new ArrayList<ConversionListener>(conversionListeners);
        }
    }

    /**
     * Returns true if there are any conversion listeners for this property.
     */
    public boolean hasConversionListeners() {
        synchronized (conversionListeners) {
            return !conversionListeners.isEmpty();
        }
    }

    /**
     * Converts the given value parameter (parameter) to a type that is accepted
     * by the set method of this property. This method attempts to convert the value
     * regardless of the value being null. However, this method short circuits and
     * returns the value unchanged if value is runtime assignable to the type
     * of this BaseBeanProperty.
     *
     * @param   value The value object to convert
     * @param   bean The bean object that this parameter object is being converted for
     *          and is usually used when firing events
     * @return  The value parameter converted to the correct type
     * @throws  TypeConversionException If there was a problem converting the parameter
     */
    protected Object convertParameter(final Object value, final Object bean,
            Class<?> type)
    throws TypeConversionException {

        Object newValue = null;

        // The converter does this, but pre-emptively checking these conditions will
        // speed up conversion times
        if (!type.isInstance(value)) {

            if (hasConversionListeners()) {
                fireConversionEvent(PRE_CONVERT, value, newValue, bean);
            }

            TypeConverter<?> converter = TypeConverterRegistry.lookup(type);
            if (converter == null) {
                throw new TypeConversionException("No type converter found for the type: "
                    + type.getName());
            }

            try {
                newValue = converter.convert(value, type);
            } catch (TypeConversionException tce) {

                if (hasConversionListeners()) {
                    fireConversionEvent(BAD_CONVERT, value, newValue, bean);
                }

                throw tce;
            }
        } else {
            newValue = value;
        }

        if (hasConversionListeners()) {
            fireConversionEvent(POST_CONVERT, value, newValue, bean);
        }

        return newValue;
    }

    /**
     * Fires off a property event using the type constants of this class and the
     * parameters given. Most of these parameters are used by all bean properties,
     * except the indices parameter which is only used with indexed properties.
     *
     * @param   type The type of event to fire. Must be either the GET or SET
     *          constants of this class
     * @param   oldValue The old value of the property, which is the same as the newValue
     *          for all events except the SET event
     * @param   newValue The new value of the property, which is normally the current
     *          value of the property except for the SET event
     * @param   bean The bean object that the event is occurring for
     * @param   index The indices if this is an IndexedBeanProperty (use -1 for all other
     *          types of properties)
     * @throws  IllegalArgumentException If the type is not a valid property event
     *          type and there are listeners
     */
    protected void firePropertyEvent(final EventType type, final Object oldValue,
            final Object newValue, final Object bean, final Object index)
    throws BeanException {
        if (type == null) {
            throw new IllegalArgumentException("Invalid event type");
        }

        // Loop through the property listeners and fire off the events
        PropertyEvent event = new PropertyEvent(this, oldValue,
            newValue, bean, index);
        synchronized (propertyListeners) {
            for (PropertyListener listener : propertyListeners) {
                switch (type) {
                case GET:
                    listener.handleGet(event);
                    break;
                case SET:
                    listener.handleSet(event);
                    break;
                }
            }
        }
    }

    /**
     * Fires off a conversion event using the type constants of this class and the
     * parameters given.
     *
     * @param   type The type of event to fire. Must be either the PRE_CONVERT,
     *          POST_CONVERT or BAD_CONVERT constants of this class
     * @param   oldValue The old value of the property, which is the parameter value
     *          before conversion
     * @param   newValue The new value of the property, which is the parameter value
     *          after conversion unless this is called for the PRE_CONVERT and
     *          BAD_CONVERT events and then it should be null.
     * @param   bean The bean object that the event is occurring for
     * @throws  IllegalArgumentException If the type is not a valid conversion event type
     *          and there are listeners
     */
    protected void fireConversionEvent(final EventType type, final Object oldValue,
            final Object newValue, final Object bean) {
        if (type == null) {
            throw new IllegalArgumentException("Invalid event type");
        }

        // Loop through the conversion listeners and fire off the events
        ConversionEvent event = new ConversionEvent(this, oldValue,
            newValue, bean);
        synchronized (conversionListeners) {
            for (ConversionListener listener : conversionListeners) {
                switch (type) {
                case PRE_CONVERT:
                    listener.handlePreConversion(event);
                    break;
                case POST_CONVERT:
                    listener.handlePostConversion(event);
                    break;
                case BAD_CONVERT:
                    listener.handleFailedConversion(event);
                    break;
                }
            }
        }
    }
}