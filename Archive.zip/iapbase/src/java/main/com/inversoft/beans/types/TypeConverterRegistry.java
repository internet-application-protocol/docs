/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


import java.util.Hashtable;
import java.util.Map;

import com.inversoft.util.ReflectionException;


/**
 * This class is the manager for all the TypeConverters. It
 * uses a Hashtable to store the converters and therefore is
 * thread safe. A converter for a given type will be retrieved
 * when the manager is queried for that type and all sub class
 * of that type, unless another converter is registered for
 * a sub class of the type. For example, registering a convert
 * for the type Number would ensure that Integer, Double, Float,
 * etc. used that converter for conversions. If a converter
 * was registered for Number and another converter for Double,
 * the converter for Number would handle all sub-class of
 * Number (Integer, etc.) except Double.
 *
 * @author  bpontarelli
 */
public class TypeConverterRegistry {

    private static Map<Class<?>, TypeConverter<?>> converters =
        new Hashtable<Class<?>, TypeConverter<?>>();

    // Initialize the basic type converters including Number, String and Boolean
    static {
        try {
            BooleanTypeConverter tc = new BooleanTypeConverter();
            converters.put(Boolean.class, tc);
            converters.put(Boolean.TYPE, tc);
        } catch (ReflectionException re) {
            System.err.println("WARNING - boolean type converter not found");
        }

        try {
            NumberTypeConverter tc = new NumberTypeConverter();
            converters.put(Number.class, tc);
            converters.put(Byte.TYPE, tc);
            converters.put(Double.TYPE, tc);
            converters.put(Float.TYPE, tc);
            converters.put(Integer.TYPE, tc);
            converters.put(Long.TYPE, tc);
            converters.put(Short.TYPE, tc);
        } catch (ReflectionException re) {
            System.err.println("WARNING - Number type converter not found");
        }

        try {
            CharacterTypeConverter tc = new CharacterTypeConverter();
            converters.put(Character.class, tc);
            converters.put(Character.TYPE, tc);
        } catch (ReflectionException re) {
            System.err.println("WARNING - character type converter not found");
        }

        try {
            StringTypeConverter tc = new StringTypeConverter();
            converters.put(String.class, tc);
        } catch (ReflectionException re) {
            System.err.println("WARNING - String type converter not found");
        }
    }

    /** Static class */
    private TypeConverterRegistry() {
    }

    /**
     * <p>
     * Returns the type converter for the given type. This converter is either
     * the converter associated with the given type of associated with a super
     * class of the given type (not interfaces). This principal also works with
     * arrays. If the type is an array, then what happens is that the array type
     * is asked for its component type using the method getComponentType and this
     * type is used to query the manager. So, the converter registered for Number
     * is returned Double[] is queried (because Double is queried and since no
     * converter was register for it, then Number is checked).
     * </p>
     *
     * <p>
     * Normal types work the exact same way. First the type is checked and then
     * its parents are checked until Object is reached, in which case null is
     * returned.
     * </p>
     *
     * <p>
     * Primitive values are treated as their wrapper classes. So, if int.class
     * is passed into this method (queried) then either a converter registered
     * for Integer, or Number or null is returned depending on what converters
     * have been registered so far.
     * </p>
     *
     * @param   type The type to start with when looking for converters
     * @return  The converter or null if one was not found
     */
    public static TypeConverter<?> lookup(Class<?> type) {
        Class<?> localType = type;
        TypeConverter<?> converter = null;

        // The local type becomes null when it is an interface or a primitive and the
        // super class is asked for
        while (localType != null && localType != Object.class) {
            converter = converters.get(localType);
            if (converter == null) {
                localType = localType.getSuperclass();
            } else {
                break;
            }
        }

        return converter;
    }

    /**
     * Registers the given converter with the given type
     *
     * @param   type The type to register the converter for
     * @param   converter The convert to register with the given type
     * @return  The converter that was already registered with the given type
     *          or null if this is the first converter being registered for
     *          that type
     */
    public static TypeConverter<?> register(Class<?> type,
            TypeConverter<?> converter) {
        return converters.put(type, converter);
    }

    /**
     * Unregisters the given converter with the given type
     *
     * @param   type The type to unregister the converter
     * @return  The converter that was registered with the given type or null
     *          if no converter was registered for the given type
     */
    public static TypeConverter<?> unregister(Class<?> type) {
        return converters.remove(type);
    }
}