/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * <p>
 * This class is the event that is generated when a bean
 * property is retrieved or set.
 * </p>
 *
 * <p>
 * The {@link BaseEvent#getOldValue() getOldValue} and {@link
 * BaseEvent#getNewValue() getNewValue} methods in {@link
 * BaseEvent BaseEvent} class are different for this event
 * and are described here:
 * </p>
 *
 * <p>
 * <code>getOldValue</code> - Returns the value of the
 * property. This value is the same whether a call to
 * getPropertyValue or setPropertyValue is called. It is
 * always the current value of the property before any
 * action takes place
 * </p>
 *
 * <p>
 * <code>getNewValue</code> - Returns the new value of the
 * property. This is equal to the value of getOldValue for
 * get events. For set events this contains the value that
 * was set into the property (which with auto-conversion is
 * the value after conversion)
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class PropertyEvent extends BaseEvent {

    private Object index;


    /**
     * Creates a new property event using the values given. For indexed properties,
     * the index should be an Integer instance. For all others, this can be null
     * or other Object indices.
     */
    public PropertyEvent(BaseBeanProperty property, Object oldValue,
            Object newValue, Object bean, Object index) {
        super(property, oldValue, newValue, bean);
        this.index = index;
    }


    /**
     * Returns the indices of the property the event occurred for. This is only used
     * by the indexed properties or BeanProperties that are Collections and an
     * indices is available for. This could be an Integer or any Object that was
     * used as a key into a Map for instance
     */
    public Object getIndex() {
        return index;
    }
}