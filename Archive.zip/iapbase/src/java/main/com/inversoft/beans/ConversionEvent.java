/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * <p>
 * This class is the event that is generated when a bean
 * property is being set AND the value is being automatically
 * converted.
 * </p>
 *
 * <p>
 * The {@link BaseEvent#getOldValue() getOldValue} and {@link
 * BaseEvent#getNewValue() getNewValue} methods in {@link
 * BaseEvent BaseEvent} class are different for this event
 * and are described
 * here:
 * </p>
 *
 * <p>
 * <tt>getOldValue</tt> - Returns the value of the parameter
 * that is being converted BEFORE it is converted. This value
 * will remain the same for the pre, post and failed conversion
 * events.
 * </p>
 *
 * <p>
 * <tt>getNewValue</tt> - Returns the value of the parameter
 * that is being converted AFTER it is converted. For
 * pre-conversion events this will be equal to the value of
 * getOldValue because the conversion has not yet taken place.
 * For post-conversion events, this will have the value of the
 * parameter AFTER it has been converted. For failed-conversion
 * events, this will be equal to the value of getOldValue
 * because the conversion failed before completing.
 * </p>
 *
 * <p>
 * It is also important to remember that if a conversion
 * fails, only the pre-conversion and failed-conversion events
 * will occur. If the conversion succeeded, then only the
 * pre-conversion and post-conversion events will occur.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class ConversionEvent extends BaseEvent {

    /**
     * Creates a new conversion event using the values given.
     */
    public ConversionEvent(final BaseBeanProperty property, final Object oldValue,
            final Object newValue, final Object bean) {
        super(property, oldValue, newValue, bean);
    }
}
