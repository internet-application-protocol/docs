/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


/**
 * <p>
 * This class is a simple pass through converter for converting
 * Strings to Strings.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class StringTypeConverter extends BaseTypeConverter<String> {
    /**
     * <p>
     * Returns the value parameter.
     * </p>
     *
     * @param   value The String value returned.
     * @param   convertTo Not used.
     * @return  The value parameter.
     */
    public String convertFromString(String value, Class<?> convertTo) {
        return value;
    }

    /**
     * <p>
     * Returns the value parameter.
     * </p>
     *
     * @param   value The String value returned.
     * @return  The value parameter.
     */
    public String convertToString(String value) throws TypeConversionException {
        return value;
    }
}