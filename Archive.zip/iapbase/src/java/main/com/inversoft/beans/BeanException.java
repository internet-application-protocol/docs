/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import com.inversoft.util.ReflectionException;


/**
 * This class is the basic exception that gets thrown from
 * the beans pacakge
 *
 * @author  Brian Pontarelli
 */
public class BeanException extends ReflectionException {

    /**
     * Creates a new <tt>BeanException</tt> without detail message.
     */
    public BeanException() {
    }


    /**
     * Constructs a <tt>BeanException</tt> with the specified detail message.
     *
     * @param   msg The detail message.
     */
    public BeanException(String msg) {
        super(msg);
    }

    /**
     * Constructs a <tt>BeanException</tt> with the specified error message and
     * also the specified root cause exception. The root cause exception is
     * generally for TypeConversionException's root cause or something that
     * might have caused a <tt>BeanException</tt>
     *
     * @param   msg The detail message
     * @param   cause (Optional) The root cause exception to be wrapped
     *          inside this exception
     */
    public BeanException(String msg, Throwable cause) {
        super(msg, cause);
    }

    /**
     * Constructs a <tt>BeanException</tt> with the specified error message and
     * also the specified root cause exception. The root cause exception is
     * generally for TypeConversionException's root cause or something that
     * might have caused a <tt>BeanException</tt>
     *
     * @param   cause (Optional) The root cause exception to be wrapped
     * inside this exception
     */
    public BeanException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructs a <tt>BeanException</tt> with the specified error message,
     * root cause exception and target exception. The root cause exception is
     * generally for TypeConversionException's root cause or something that might
     * have caused a <tt>BeanException</tt>. The target exception is an exception
     * that was thrown from the getter or setter methods during reflection.
     *
     * @param   msg The detail message
     * @param   cause (Optional) The root cause exception to be wrapped inside this exception
     * @param   target (Optional) The target exception to be wrapped inside this exception
     */
    public BeanException(String msg, Throwable cause, Throwable target) {
        super(msg, cause, target);
    }

    /**
     * This is a convience constructor that will create a new BeanException that
     * is identical to the given ReflectionException, basically like a forced
     * downcast constructor or a super-class copy constructor.
     *
     * @param   re The ReflectionException to copy into this BeanException
     */
    public BeanException(ReflectionException re) {
        super(re.getMessage(), re.getCause(), re.getTarget());
    }
}
