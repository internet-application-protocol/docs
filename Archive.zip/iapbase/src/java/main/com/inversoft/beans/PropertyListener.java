/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.util.EventListener;


/**
 * <p>
 * This interface is an event listener for property events.
 * These events take place when a BeanProperty or similar
 * class is retrieving or updating (setting) a properties
 * value. The different types of events that this listener
 * watchs are:
 * </p>
 *
 * <ul>
 * <li>Property retrieval</li>
 * <li>Property setting/changing</li>
 * </ul>
 *
 * @author  Brian Pontarelli
 */
public interface PropertyListener extends EventListener {

    /**
     * This handle method is called when the property value is being retrieved
     * by calling the getter for the property
     */
    void handleGet(PropertyEvent event);

    /**
     * This handle method is called when the property value is being changed
     * by calling the setter for the property
     */
    void handleSet(PropertyEvent event);
}
