/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.beans.types;


/**
 * This is the basic exception that gets thrown from the
 * TypeConverter conversion methods. It supports exception
 * stacks and will need to be rebuilt when 1.4 is fully
 * supported.
 *
 * @author  Brian Pontarelli
 */
public class TypeConversionException extends RuntimeException {

    /** Creates new TypeConversionException */
    public TypeConversionException() {
    }

    /** Creates a new TypeConversionException with the given error message */
    public TypeConversionException(String msg) {
        super(msg);
    }

    /**
     * Creates a new TypeConversionException with the given error message and root
     * cause exception
     */
    public TypeConversionException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
