/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.util.Map;
import java.util.WeakHashMap;

import com.inversoft.beans.types.TypeConversionException;

import static com.inversoft.beans.EventType.*;


/**
 * This class is used to access an indexed JavaBean property.
 * Normal indexed JavaBean properties take a single int
 * parameter, in addition to the value parameter for setters,
 * that indicates the indices into an array or collection of
 * values.
 *
 * @author  Brian Pontarelli
 */
public class IndexedBeanProperty extends BaseBeanProperty {

    /**
     * The cache Map for the IndexedBeanProperty objects (unsynchronized).
     */
    private static Map<String, IndexedBeanProperty> cache =
        new WeakHashMap<String, IndexedBeanProperty>();

    /**
     * Returns an instance of the IndexedBeanProperty for the given propertyName and
     * bean Class. This object might be cached, depending on the implementation
     * of this method. Therefore, you must take into account a cached or non-
     * cached object.
     *
     * This returns a type of BeanProperty because of the getProperty method in
     * the BeanProperty that this extends. So, it must be cast. However, you can
     * use getIndexedInstance instead.
     *
     * @param   propertyName The property name of the IndexedBeanProperty
     * @param   beanClass The bean Class
     * @return  The IndexedBeanProperty and never null
     * @throws  BeanException If the creation of the obejct fails
     */
    public static IndexedBeanProperty getIndexedInstance(final String propertyName,
            final Class<?> beanClass)
    throws BeanException {
        if (propertyName == null || propertyName.indexOf(".") != -1) {
            throw new BeanException("Invalid propertyName: " + propertyName);
        }

        synchronized (cache) {
            String key = beanClass.toString() + "#" + propertyName;
            IndexedBeanProperty bp = cache.get(key);
            if (bp == null) {
                bp = new IndexedBeanProperty(propertyName, beanClass);
                cache.put(key, bp);
            }

            return bp;
        }
    }


    /**
     * <p>
     * Constructs a new indexed bean property using the property name and bean class
     * given.
     * </p>
     *
     * <p>
     * If the bean class does not have a write method (set method) than the property
     * is considered read-only. The bean class MUST have a read method (get method)
     * or this method will throw and exception. This method calls the super-class
     * constructor with the same signature.
     * </p>
     *
     * @param   propertyName The name of the indexed JavaBean property
     * @param   beanClass The Class object used to find the read and write methods
     *          for the indexed JavaBean property
     * @throws  BeanException If the property is invalid or does not exist in
     *          the bean class given
     */
    public IndexedBeanProperty(String propertyName, Class beanClass)
    throws BeanException {
        super(propertyName, beanClass); // The super constructor calls initialize
    }


    /**
     * Sets up the methods.
     */
    @Override void initialize() {
        this.read = JavaBeanTools.findIndexedReadMethod(propertyName, beanClass);
        super.initialize();
        try {
            write = JavaBeanTools.findIndexedWriteMethod(propertyName, beanClass,
                propertyType);
        } catch (BeanException be) {
            // smother the exception so that this property is read only
        }
    }

    /**
     * Always returns true
     */
    public boolean isIndexable(Object bean) {
        return true;
    }

    /**
     * Returns the value of the indexed JavaBean property at the given indices
     *
     * @param   bean The instance of the JavaBean to retrieve the indexed property
     *          from.
     * @param   index The indices of the JavaBean property to retrieve, this is also the
     *          parameter to the getter
     * @throws  BeanException If there was an error getting the JavaBean property or
     *          the getter/is method threw a checked Exception
     */
    public Object getPropertyValue(final Object bean, final int index)
    throws BeanException {
        return getPropertyValue(bean, new Integer(index));
    }

    /**
     * This method is not implemented and will throw an exception
     */
    public Object getPropertyValue(final Object bean) throws BeanException {
        throw new BeanException("This operation not supported, getPropertyValue " +
            "must have an indices for property named: " + getPropertyName());
    }

    /**
     * If the key given is an instance of Integer, this get the intValue from that
     * object and calls {@link #getPropertyValue(Object, int)
     * getPropertyValue(Object, int)}. If the key is null this calls
     * {@link #getPropertyValue(Object) getPropertyValue(Object)}
     */
    public Object getPropertyValue(final Object bean, final Object key)
    throws BeanException {
        Integer index;
        try {
            index = (Integer) key;
        } catch (ClassCastException cce) {
            throw new BeanException("This operation not supported, getPropertyValue " +
                "must have an integer indices for property named: " + getPropertyName());
        }

        Object value = JavaBeanTools.callIndexedGetter(this, bean, index);
        if (hasPropertyListeners()) {
            firePropertyEvent(GET, value, value, bean, index);
        }

        return value;
    }

    /**
     * Sets the value of the indexed JavaBean property at the given indices with
     * the given value
     *
     * @param   bean The instance of the JavaBean to set the indexed property on
     * @param   index The indices to set to value of
     * @param   value The value to set the indexed property to
     * @param   convert Determines whether or not value should be converted
     *          to the type that the setter requires or not
     * @throws  BeanException If there was an error setting the JavaBean property or
     *          the setter method threw a checked Exception
     * @throws  TypeConversionException If there was a problem auto-converting the
     *          property value
     */
    public void setPropertyValue(final Object bean, final int index, Object value,
            final boolean convert) throws BeanException, TypeConversionException {
        setPropertyValue(bean, new Integer(index), value, convert);
    }

    /**
     * Sets the value of the indexed JavaBean property at the given indices with
     * the given value. This value is set without doing any conversion. This
     * method is the same as calling the other setPropertyValue method with the
     * convert parameter set to false
     *
     * @param   bean The instance of the JavaBean to set the indexed property on
     * @param   index The indices to set to value of
     * @param   value The value to set the indexed property to
     * @throws  BeanException If there was an error setting the JavaBean property or
     *          the setter method threw a checked Exception
     */
    public void setPropertyValue(final Object bean, final int index,
            final Object value)
    throws BeanException {
        try {
            setPropertyValue(bean, index, value, false);
        } catch (TypeConversionException tce) {
            assert false : "FATAL: should never throw TypeConversionException" +
                " because this method does no conversion";
        }
    }

    /**
     * This method is not implemented and will throw an exception
     */
    public void setPropertyValue(final Object bean, final Object value,
            final boolean convert)
    throws BeanException {
        throw new BeanException("This operation not supported, setPropertyValue " +
            "must have an indices for property named: " + getPropertyName());
    }

    /**
     * If the key given is an instance of Integer, this get the intValue from that
     * object and calls {@link #setPropertyValue(Object, int, Object, boolean)
     * setPropertyValue(Object, int, Object, boolean)}. If the key is null this calls
     * {@link #setPropertyValue(Object, Object, boolean)
     * getPropertyValue(Object, Object, boolean)}
     */
    public void setPropertyValue(final Object bean, final Object key,
            final Object value, final boolean convert)
    throws BeanException, TypeConversionException {
        Integer index;
        try {
            index = (Integer) key;
        } catch (ClassCastException cce) {
            throw new BeanException("This operation not supported, " +
                "setPropertyValue must have an indices for property named: " +
                getPropertyName());
        }


        // If we are autoConverting, convert the parameter
        Object newValue = value;
        if (convert) {
            newValue = convertParameter(value, bean, propertyType);
        }

        // Store the old value if there are property listeners
        Object oldValue = null;
        if (hasPropertyListeners()) {
            oldValue = JavaBeanTools.callIndexedGetter(this, bean, index);
        }

        JavaBeanTools.callIndexedSetter(this, bean, index, newValue);

        if (hasPropertyListeners()) {
            firePropertyEvent(SET, oldValue, newValue, bean, index);
        }
    }
}