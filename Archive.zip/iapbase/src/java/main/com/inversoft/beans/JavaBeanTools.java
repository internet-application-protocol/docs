/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.beans.Introspector;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.inversoft.util.ReflectionException;
import com.inversoft.util.ReflectionTools;
import com.inversoft.util.StringTools;


/**
 * This class is a library of tools that can be used when working with
 * JavaBeans.
 *
 * @author  Brian Pontarelli
 */
public class JavaBeanTools {

    /**
     * The string that starts standard Java bean retrieval methods <tt>get</tt>
     */
    public static final String GET_STRING = "get";

    /**
     * The string that starts standard Java bean update methods <tt>set</tt>
     */
    public static final String SET_STRING = "set";
    public static final int GET_LENGTH = GET_STRING.length();

    /**
     * The string that starts standard Java bean boolean retrieval methods
     * <tt>is</tt>
     */
    public static final String IS_STRING = "is";
    public static final int IS_LENGTH = IS_STRING.length();

    /**
     * The string that starts non-standard Java bean handle methods <tt>handle</tt>
     */
    public static final String HANDLE_STRING = "handle";
    public static final int HANDLE_LENGTH = HANDLE_STRING.length();

    /** Singleton toolkit */
    private JavaBeanTools() {
        // static class
    }


    /**
     * Reflects on the class name given to find the Class object. Throws a
     * BeanException if the class could not be reflected on.
     *
     * @param   beanClass The name of the class as a String.
     * @return  The Class and never null.
     * @throws  BeanException If the reflection failed.
     */
    public static Class<?> forName(final String beanClass) throws BeanException {
        try {
            return Class.forName(beanClass);
        } catch (ClassNotFoundException cnfe) {
            throw new BeanException(cnfe.getMessage(), cnfe);
        }
    }

    /**
     * Using the given Method, it returns the name of the java bean property.<BR>
     * Examples:<p>
     * getFoo -> foo<br>
     * getX -> x<br>
     * getURL -> URL<br>
     * @param   method The method to translate
     * @return  The property name or null if this was not a valid property Method
     */
    public static String getPropertyName(final Method method) {
        String name = method.getName();

        // Determine what type of property it is
        if (name.startsWith(IS_STRING)) {

            // Make sure that it is a proper property method
            if (name.length() <= IS_LENGTH ||
                    Character.isLowerCase(name.charAt(IS_LENGTH))) {
                return null;
            }

            return Introspector.decapitalize(name.substring(IS_LENGTH));

        } else if (name.startsWith(GET_STRING) || name.startsWith(SET_STRING)) {

            // Make sure that it is a proper property method
            if (name.length() <= GET_LENGTH ||
                    Character.isLowerCase(name.charAt(GET_LENGTH))) {
                return null;
            }

            return Introspector.decapitalize(name.substring(GET_LENGTH));

        }

        return null; // Invalid property name, return null
    }

    /**
     * Capitalizes the first letter of the given String. If the String starts
     * with white space, then it is returned as is.
     *
     * @param   lowerCase The string to capitalize
     * @return  The capitalized string
     * @throws  NullPointerException If the parameter is null
     */
    public static String capitalize(final String lowerCase) {

        char [] chars = lowerCase.toCharArray();
        chars[0] = Character.toUpperCase(chars[0]);

        return new String(chars);
    }

    /**
     * Using the propertyName, returns the Java Bean standard getter method name. If
     * the parameter String starts with white space or only contains white space or
     * is empty, the it is simply concatenated to the GET constant of this class. It
     * is the job of the calling code to make certain that the parameter is a properly
     * formatted String if that check is desired.
     * @param   propertyName The property name to make into the name of the getter
     *          method
     * @return  The name of the getter method or null if propertyName is empty or null
     * @throws  NullPointerException If the parameter is null
     */
    public static String makeGetter(final String propertyName) {
        return GET_STRING + capitalize(propertyName);
    }

    /**
     * Using the propertyName, returns the Java Bean standard setter method name. If
     * the parameter String starts with white space or only contains white space or
     * is empty, the it is simply concatenated to the SET constant of this class. It
     * is the job of the calling code to make certain that the parameter is a properly
     * formatted String if that check is desired.
     * @param   propertyName The property name to make into the name of the setter
     *          method
     * @return  The name of the setter method or null if propertyName is empty or null
     * @throws  NullPointerException If the parameter is null
     */
    public static String makeSetter(final String propertyName) {
        return SET_STRING + capitalize(propertyName);
    }

    /**
     * Using the propertyName, returns the Java Bean standard boolean getter
     * method name. If the parameter String starts with white space or only
     * contains white space or is empty, the it is simply concatenated to the
     * IS constant of this class. It is the job of the calling code to make
     * certain that the parameter is a properly formatted String if that check
     * is desired.
     *
     * @param   propertyName The property name to make into the name of the is
     *          method
     * @return  The name of the is method or null if propertyName is empty or null
     * @throws  NullPointerException If the parameter is null
     */
    public static String makeIs(final String propertyName) {
        return IS_STRING + capitalize(propertyName);
    }

    /**
     * Using the propertyName, returns the non-standard Java Bean handle method
     * name. If the parameter String starts with white space or only contains
     * white space or is empty, the it is simply concatenated to the HANDLE
     * constant of this class. It is the job of the calling code to make certain
     * that the parameter is a properly formatted String if that check is desired.
     *
     * @param   propertyName The property name to make into the name of the handle
     *          method
     * @return  The name of the handle method or null if propertyName is empty or null
     * @throws  NullPointerException If the parameter is null
     */
    public static String makeHandle(final String propertyName) {
        return HANDLE_STRING + capitalize(propertyName);
    }

    /**
     * Check if the method is a proper java bean getter-property method. This
     * means that it starts with get, has the form getFoo or getFOO, has no
     * parameters and returns a non-void value.
     *
     * @param   method The method to check
     * @return  True if valid, false otherwise
     */
    public static boolean isValidGetter(final Method method) {
        return ((method.getName().startsWith(GET_STRING) ||
                 method.getName().startsWith(IS_STRING)) &&
            getPropertyName(method) != null &&
            method.getParameterTypes().length == 0 &&
            method.getReturnType() != Void.TYPE);
    }

    /**
     * Check if the method is a proper java bean indexed getter method. This
     * means that it starts with get, has the form getFoo or getFOO, has one
     * parameter, an indices, and returns a non-void value.
     *
     * @param   method The method to check
     * @return  True if valid, false otherwise
     */
    public static boolean isValidIndexedGetter(final Method method) {
        return ((method.getName().startsWith(GET_STRING) ||
                 method.getName().startsWith(IS_STRING)) &&
            getPropertyName(method) != null &&
            method.getParameterTypes().length == 1 &&
            method.getParameterTypes()[0] == int.class &&
            method.getReturnType() != Void.TYPE);
    }

    /**
     * Does the same check as {@link #isValidGetter(Method) isValidGetter()} is
     * checkName is true, but does not check the name if checkName is false. The
     * only benefit of not checking the name is the performance increase. Checking
     * the name is a simple procedure but requires a number of string comparisons
     * and method calls.
     *
     * @param   method The method to check
     * @param   checkName Whether or not to check the method's name
     * @return  True if the method is a valid getter and false otherwise
     */
    public static boolean isValidGetter(final Method method,
            final boolean checkName) {
        if (checkName) {
            return isValidGetter(method);
        }

        return (method.getParameterTypes().length == 0 &&
            method.getReturnType() != Void.TYPE);
    }

    /**
     * Does the same check as {@link #isValidIndexedGetter(Method)
     * isValidIndexedGetter()} if checkName is true, but does not check the name
     * if checkName is false. The only benefit of not checking the name is the
     * performance increase. Checking the name is a simple procedure but requires
     * a number of string comparisons and method calls.
     *
     * @param   method The method to check
     * @param   checkName Whether or not to check the method name
     * @return  True if the method is a valid indexed getter and false otherwise
     */
    public static boolean isValidIndexedGetter(final Method method,
            final boolean checkName) {

        if (checkName) {
            return isValidIndexedGetter(method);
        }

        return (method.getParameterTypes().length == 1 &&
            method.getParameterTypes()[0] == int.class &&
            method.getReturnType() != Void.TYPE);
    }

    /**
     * Check if the method is a proper java bean setter-property method. This
     * means that it starts with set, has the form setFoo or setFOO, takes a
     * single parameter and returns void
     *
     * @param   method The method to check
     * @return  True if valid, false otherwise
     */
    public static boolean isValidSetter(final Method method) {
        return (method.getName().startsWith(SET_STRING) &&
            getPropertyName(method) != null &&
            method.getParameterTypes().length == 1 &&
            method.getReturnType() == Void.TYPE);
    }

    /**
     * Check if the method is a proper java bean indexed setter method. This
     * means that it starts with set, has the form setFoo or setFOO, takes a
     * two parameters, an indices and a value and returns void
     *
     * @param   method The method to check
     * @return  True if valid, false otherwise
     */
    public static boolean isValidIndexedSetter(final Method method) {
        return (method.getName().startsWith(SET_STRING) &&
            getPropertyName(method) != null &&
            method.getParameterTypes().length == 2 &&
            method.getParameterTypes()[0] == int.class &&
            method.getReturnType() == Void.TYPE);
    }

    /**
     * Does the same check as {@link #isValidSetter(Method) isValidSetter()} is checkName
     * is true, but does not check the name if checkName is false. The only benefit of
     * not checking the name is the performance increase. Checking the name is a simple
     * procedure but requires a number of string comparisons and method calls.
     *
     * @param   method The method to check
     * @param   checkName Whether or not to check the method name
     * @return  True if the method is a valid setter and false otherwise
     */
    public static boolean isValidSetter(final Method method, final boolean checkName) {
        if (checkName) {
            return isValidSetter(method);
        }

        return (method.getParameterTypes().length == 1 &&
            method.getReturnType() == Void.TYPE);
    }

    /**
     * Does the same check as {@link #isValidIndexedSetter(Method)
     * isValidIndexedSetter()} if checkName is true, but does not check the name
     * if checkName is false. The only benefit of not checking the name is the
     * performance increase. Checking the name is a simple procedure but requires
     * a number of string comparisons and method calls.
     *
     * @param   method The method to check
     * @param   checkName Whether or not to check the method name
     * @return  True if the method is a valid indexed setter and false otherwise
     */
    public static boolean isValidIndexedSetter(final Method method,
            final boolean checkName) {

        if (checkName) {
            return isValidIndexedSetter(method);
        }

        return (method.getParameterTypes().length == 2 &&
            method.getParameterTypes()[0] == int.class &&
            method.getReturnType() == Void.TYPE);
    }

    /**
     * Finds either a get method or is method in the class given for the given
     * property name. All white space on the property String parameter is trimmed
     * automatically when locating the Method.
     *
     * @param   property The name of the property to find the write method for
     * @param   beanClass The class object for the bean
     * @return  The read Method for the given property name and never null
     * @throws  BeanException If the write method can not be found
     * @throws  NullPointerException If the property String is null
     */
    public static Method findReadMethod(final String property,
            final Class<?> beanClass)
    throws BeanException {
        // Trim the string and check if the String is empty
        if (StringTools.isEmpty(property)) {
            throw new BeanException("The property name String is empty or contains " +
                "only white space and is not valid");
        }

        String getter = makeGetter(property);
        Method method;

        try {
            method = beanClass.getMethod(getter, (Class[]) null);
        } catch (SecurityException se) {
            throw new BeanException(se.getMessage(), se);
        } catch (NoSuchMethodException nsme) {

            String is = makeIs(property);

            // The getter failed, try the is version
            try {
                method = beanClass.getMethod(is, (Class[]) null);
            } catch (SecurityException se) {
                throw new BeanException(se);
            } catch (NoSuchMethodException nsme2) {
                throw new BeanException("Getter/is for property named: " + property
                    + " does not exist in class: " + beanClass.getName(), nsme2);
            }
        }

        if (!isValidGetter(method, /*checkName=*/false)) {
            throw new BeanException("Getter/is for property named: " + property
                + " is not a valid Java bean getter");
        }

        return method;
    }

    /**
     * Finds a get method in the class given for the given property.
     *
     * @param   property The name of the property to find the indexed write method for
     * @param   beanClass The class object for the bean
     * @return  The indexed read Method for the given property name and never null
     * @throws  BeanException If the read method can not be found
     */
    public static Method findIndexedReadMethod(final String property,
            final Class<?> beanClass)
    throws BeanException {

        // Trim the string and check if the String is empty
        if (StringTools.isEmpty(property)) {
            throw new BeanException("The property name String is empty or contains " +
                "only white space and is not valid");
        }

        String getter = makeGetter(property);
        Class [] params = {int.class};
        Method method;

        try {
            method = beanClass.getMethod(getter, params);
        } catch (SecurityException se) {
            throw new BeanException(se);
        } catch (NoSuchMethodException nsme) {

            String is = makeIs(property);

            // The getter failed, try the is version
            try {
                method = beanClass.getMethod(is, params);
            } catch (SecurityException se) {
                throw new BeanException(se);
            } catch (NoSuchMethodException nsme2) {
                throw new BeanException("Indexed getter for property named: " +
                    property + " does not exist in class: " + beanClass.getName(),
                    nsme);
            }
        }

        if (!isValidIndexedGetter(method, /*checkName=*/false)) {
            throw new BeanException("Indexed getter for property named: " + property
                + " is not a valid Java bean getter");
        }

        return method;
    }

    /**
     * Finds a set method for the given property and parameter type
     *
     * @param   property The name of the property to find
     * @param   beanClass The class object for the bean
     * @param   type The parameter type to use when locating the write method
     * @return  The write Method for the given property name and type and never null
     * @throws  BeanException If the write method can not be found
     */
    public static Method findWriteMethod(final String property,
            final Class<?> beanClass, final Class<?> type)
    throws BeanException {

        if (type == null) {
            throw new BeanException("Setters must have a parameter type");
        }

        // Trim the string and check if the String is empty
        if (StringTools.isEmpty(property)) {
            throw new BeanException("The property name String is empty or contains " +
                "only white space and is not valid");
        }

        String setter = makeSetter(property);
        Method method;

        try {
            method = beanClass.getMethod(setter, new Class[]{type});
        } catch (SecurityException se) {
            throw new BeanException(se.getMessage(), se);
        } catch (NoSuchMethodException nsme) {
            throw new BeanException("Setter for property named: " + property
                + " does not exist in class: " + beanClass.getName(), nsme);
        }

        if (!isValidSetter(method, /*checkName=*/false)) {
            throw new BeanException("Setter for property named: " + property
                + " is not a valid Java bean setter");
        }

        return method;
    }

    /**
     * Finds a set indexed method for the given property and parameter type
     *
     * @param   property The name of the property to find
     * @param   beanClass The class object for the bean
     * @param   type The parameter type to use when locating the write method
     * @return  The indexed write Method for the given property name and type and never null
     * @throws  BeanException If the write method can not be found
     */
    public static Method findIndexedWriteMethod(final String property,
            final Class<?> beanClass, final Class<?> type)
    throws BeanException {

        if (type == null) {
            throw new BeanException("Setters must have a parameter type");
        }

        // Trim the string and check if the String is empty
        if (StringTools.isEmpty(property)) {
            throw new BeanException("The property name String is empty or contains " +
                "only white space and is not valid");
        }

        String setter = makeSetter(property);
        Class [] params = {int.class, type};
        Method method;

        try {
            method = beanClass.getMethod(setter, params);
        } catch (SecurityException se) {
            throw new BeanException(se.getMessage(), se);
        } catch (NoSuchMethodException nsme) {
            throw new BeanException("Indexed setter for property named: " + property
                + " does not exist in class: " + beanClass.getName(), nsme);
        }

        if (!isValidIndexedSetter(method, /*checkName=*/false)) {
            throw new BeanException("Indexed setter for property named: " + property
                + " is not a valid Java bean setter");
        }

        return method;
    }

    /**
     * Another convience method that calls a java bean getter and returns the value.
     * This version uses the BeanProperty class to determine the property read
     * method.
     *
     * @param   prop The BeanProperty object to use
     * @param   bean The java bean object to call it on
     * @return  The return value from calling the getter method for the given property
     * @throws  BeanException If there was a problem calling the getter
     */
    public static Object callGetter(final BeanProperty prop, final Object bean)
    throws BeanException {
        Method read = prop.getReadMethod();
        if (read == null) {
            StringBuffer buf = new StringBuffer(128);
            buf.append("Getter/is for property named: ").append(prop.getPropertyName());
            buf.append(" does not exist for class: ").append(bean.getClass().getName());
            throw new BeanException(buf.toString());
        }

        return invokeMethod(read, bean, null);
    }

    /**
     * Another convience method that calls an indexed java bean getter and returns
     * the value. This version uses the IndexedBeanProperty class to determine the
     * property read method.
     *
     * @param   prop The BeanProperty object to use
     * @param   bean The java bean object to call it on
     * @param   index The indices to be passed to the getter method
     * @return  The return value from calling the indexed getter method for the given
     *          property
     * @throws  BeanException If there was a problem calling the getter
     */
    public static Object callIndexedGetter(final IndexedBeanProperty prop,
            final Object bean, final Integer index)
    throws BeanException {
        Method read = prop.getReadMethod();
        if (read == null) {
            StringBuffer buf = new StringBuffer(128);
            buf.append("Indexed getter for property named: ").append(prop.getPropertyName());
            buf.append(" does not exist for class: ").append(bean.getClass().getName());
            throw new BeanException(buf.toString());
        }

        // Package up the indices
        Object [] params = {index};

        return invokeMethod(read, bean, params);
     }

    /**
     * Another convience method for calling a setter on a java bean. This method
     * uses the BeanProperty object to determine the write method
     *
     * @param   prop The BeanProperty object to use when calling the setter
     * @param   bean The object to call it on
     * @param   param The parameter to the setter (java bean standard)
     * @throws  BeanException If the property a read only property or if the setter
     *          called threw an exception or if the param is the incorrect type for
     *          the setter method
     */
    public static void callSetter(final BeanProperty prop, final Object bean,
            final Object param)
    throws BeanException {

        Method write = prop.getWriteMethod();
        if (write == null) {
            StringBuffer buf = new StringBuffer(128);
            buf.append("Setter for property named: ").append(prop.getPropertyName());
            buf.append(" does not exist for class: ").append(bean.getClass().getName());
            throw new BeanException(buf.toString());
        }

        invokeMethod(write, bean, new Object[] {param});
    }

    /**
     * Another convience method for calling a setter on a java bean. This method
     * uses the BeanProperty object to determine the write method.
     *
     * @param   prop The BeanProperty object to use when calling the setter
     * @param   bean The object to call it on
     * @param   index The indices of the property to set
     * @param   param The parameter to the setter (java bean standard)
     * @throws  BeanException If the property a read only property or if the setter
     *          called threw an exception or if the param is the incorrect type for
     *          the setter method
     */
    public static void callIndexedSetter(final IndexedBeanProperty prop,
            final Object bean, final Integer index, final Object param)
    throws BeanException {

        Method write = prop.getWriteMethod();
        if (write == null) {
            StringBuffer buf = new StringBuffer(128);
            buf.append("Indexed setter for property named: ").append(prop.getPropertyName());
            buf.append(" does not exist for class: ").append(bean.getClass().getName());
            throw new BeanException(buf.toString());
        }

        Object [] params = {index, param};

        invokeMethod(write, bean, params);
    }

    /**
     * Calls the ReflectionTools method but converts any thrown ReflectionExceptions
     * to BeanExceptions for this package. This is package level because it contains
     * too much low level concepts (ie the Method object) that it should be protected
     * to ensure that it in fact only invokes JavaBean methods and only throws
     * BeanExceptions, etc.
     *
     * @param   method The method to invoke
     * @param   bean The object to invoke the method on
     * @param   params The params to the method
     * @return  The return value from the method
     * @throws  BeanException If any mishap occurred whilst Reflecting sire.
     *          All the exceptions that could be thrown whilst invoking will be
     *          wrapped inside the ReflectionException
     */
    static Object invokeMethod(final Method method, final Object bean,
            final Object [] params)
    throws BeanException {
        try {
            return ReflectionTools.invokeMethod(method, bean, params);
        } catch (ReflectionException re) {
            throw new BeanException(re);
        }
    }

    /**
     * Using the given nested property name, this returns the local property name
     * and the remainder of the nested property name, if any. This is done by returning
     * a instance of the top level class NameInfo of this class
     *
     * @param   propertyName The nested (or local) property name to extract the local
     *          and nested property names from.
     * @return  The NameInfo class for the names
     */
    public static NameInfo splitNameFront(String propertyName) {
        NameInfo nh = new NameInfo();
        nh.indexOfDot = propertyName.indexOf(".");

        // Determine if the property name describes a local property or a sub-property
        if (nh.indexOfDot == -1) {
            nh.localPropertyName = propertyName;
            nh.nested = false;
        } else {
            nh.localPropertyName = propertyName.substring(0, nh.indexOfDot);
            nh.nestedPropertyName = propertyName.substring(nh.indexOfDot + 1);
            nh.nested = true;
        }

        return nh;
    }

    /**
     * Using the given nested property name, this returns the nested property
     * name and the last local property name, if any. This is done by returning
     * a instance of the top level class NameInfo of this class
     *
     * @param   propertyName The nested (or local) property name to extract the
     *          local and nested property names from.
     * @return  The NameInfo class for the names
     */
    public static NameInfo splitNameBack(String propertyName) {
        NameInfo nh = new NameInfo();
        nh.indexOfDot = propertyName.lastIndexOf(".");

        // Determine if the property name describes a local property or a sub-property
        if (nh.indexOfDot == -1) {
            nh.localPropertyName = propertyName;
            nh.nested = false;
        } else {
            nh.nestedPropertyName = propertyName.substring(0, nh.indexOfDot);
            nh.localPropertyName = propertyName.substring(nh.indexOfDot + 1);
            nh.nested = true;
        }

        return nh;
    }

    /**
     * Using the given nested property name, this returns each of the property
     * names broken out and stored in a String array.
     *
     * @param   propertyName The nested (or local) property name to extract the
     *          local and nested property names from.
     * @return  The array of property names
     */
    public static String[] splitNameComplete(String propertyName) {
        StringTokenizer st = new StringTokenizer(propertyName, ".");
        String[] props = new String[st.countTokens()];
        int i = 0;
        while (st.hasMoreTokens()) {
            props[i] = st.nextToken();
            i++;
        }

        return props;
    }

    /**
     * Given the property name string, the indices and property name are extracted
     * and returned in the a new PropertyInfo. If the given propertyName string
     * does not contain an indices, then the indices member of the PropertyInfo
     * returned will be empty. Inside the IndexHelper, the property name is stored
     * in the propertyName member and the indices is stored in the indices member.
     *
     * @param   propertyName The name of the property to search for the indices
     * @return  The given PropertyInfo instance that contains all the new information
     * @throws  BeanException If the property name contains an invalid indices or an
     *          unclosed indices notation (i.e. '[1')
     */
    public static PropertyInfo retrievePropertyInfo(String propertyName)
    throws BeanException {

        // Determine whether or not the property is indexed or not
        PropertyInfo propertyInfo = new PropertyInfo();
        int bracet = propertyName.indexOf('[');
        final int firstBracet = bracet;
        if (bracet == -1) {
            propertyInfo.indices = null;
            propertyInfo.propertyName = propertyName;
            return propertyInfo;
        }

        while (bracet != -1) {
            int bracetTwo = propertyName.indexOf(']', bracet);
            if (bracetTwo == -1) {
                throw new BeanException("The bean property name string: " + propertyName
                    + " contains an invalid indices");
            }

            String indexStr = propertyName.substring(bracet + 1, bracetTwo);
            int length = indexStr.length();
            char ch = indexStr.charAt(0);
            if (ch == '"' || ch == '\'') {
                char lastCh = indexStr.charAt(length - 1);
                if (lastCh != '"' && lastCh != '\'') {
                    throw new BeanException("Invalid indices value: " + indexStr);
                }

                propertyInfo.indices.add(indexStr.substring(1, length - 1));
            } else {
                try {
                    propertyInfo.indices.add(Integer.valueOf(indexStr));
                } catch (NumberFormatException nfe) {
                    propertyInfo.indices.add(indexStr);
                }
            }

            bracet = propertyName.indexOf('[', bracetTwo);
        }

        propertyInfo.propertyName = propertyName.substring(0, firstBracet);

        return propertyInfo;
    }

    /**
     * Using the given property name, this breaks the property name down into
     * manageable pieces. These are the individual instances of the PropertyInfo
     * inner class which store the property name and the indices (which could be
     * null or any object). This is broken on the '.' character accordiing to
     * the JavaBean standard.
     *
     * @param   propertyName The property name strng to break down.
     * @return  A new ArrayList of PropertyInfo objects
     * @throws  BeanException If the property string is invalid
     */
    public static List<PropertyInfo> retrieveAllPropertyInfo(String propertyName)
    throws BeanException {
        List<PropertyInfo> info = new ArrayList<PropertyInfo>();
        StringTokenizer ts = new StringTokenizer(propertyName, ".");

        while (ts.hasMoreTokens()) {
            // Grab the indices from the property
            PropertyInfo pi = retrievePropertyInfo(ts.nextToken());
            info.add(pi);
        }

        return info;
    }


    //-------------------------------------------------------------------------
    //                              Inner classes
    //-------------------------------------------------------------------------

    /**
     * This class is a small helper class that is used in the beans pacakge for
     * assisting with indexing operations.
     */
    public static class PropertyInfo {

        /**
         * This stores the list of indices when this class is used to break a
         * property name apart from an indices
         */
        public List<Object> indices = new ArrayList<Object>();

        /**
         * This stores the property name that is broken apart from a single indices or
         * List of indices
         */
        public String propertyName;
    }

    /**
     * This class is a small helper class that is used in the beans pacakge for
     * assisting with property names
     */
    public static class NameInfo {

        /**
         * Stores whether or not this property is within a nesting or a single
         * property
         */
        public boolean nested;

        /**
         * This stores the indices of the . character in the original property name
         * string. This indices is not valid for either of the Strings in this
         * class
         */
        public int indexOfDot;

        /**
         * This stores the local property name after a nested property name has
         * been broken up into pieces
         */
        public String localPropertyName;

        /**
         * This stores the remainder of a nested property name after a nested
         * it has been broken. This is basically the original minus (the local
         * property name plus the . character). ie<p>
         * original - (local + ".")
         */
        public String nestedPropertyName;
    }
}
