/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


import com.inversoft.util.StringTools;


/**
 * This class is the type covnerter for booleans. It only
 * contains one method that converts a string to a boolean.
 * All other conversion is handled by the BaseTypeConverter
 * class. Therefore, this class will handle all the conversions
 * described in the TypeConverter interface except conversion
 * from an array to an object when the array has a length
 * greater than one. This is the same deficiency that
 * BaseTypeConverter posses.
 *
 * @author  Brian Pontarelli
 */
public class BooleanTypeConverter extends BaseTypeConverter<Boolean> {
    /**
     * <p>
     * Converts the given string to a boolean. If the convertTo type is Boolean.TYPE,
     * then this method will convert the string to a Boolean object and NEVER
     * return null. This way there are no exceptions when attempting to set a
     * primitive type to null. If the convertTo type is an array, then this
     * method calls convertToArray. If the convertTo type is not Boolean.TYPE
     * it is ignored. If the convertTo type is not Boolean.TYPE and the passed
     * in string is either null, empty or contains only white space, this method
     * returns null.
     * </p>
     *
     * @param   value The String value to convert
     * @param   convertTo The type to convert the value to
     * @return  The converted value
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type
     */
    public Boolean convertFromString(final String value, final Class<?> convertTo)
    throws TypeConversionException {
        // If the string is null or empty, return null
        if (StringTools.isEmpty(value)) {
            if (convertTo == Boolean.TYPE) {
                return Boolean.FALSE;
            }

            return null;
        }

        // Check if it is a valid boolean string
        if (StringTools.isValidBoolean(value)) {
            return Boolean.valueOf(value);
        }

        throw new TypeConversionException(value + " is not a valid boolean type");
    }

    /**
     * <p>
     * Converts the given Boolean to a String. If the Boolean is null, then null
     * is returned. Otherwise, Boolean.toString() is called.
     * </p>
     *
     * @param   value The value to convert to a String.
     * @return  The converted value.
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type.
     */
    public String convertToString(final Boolean value)
    throws TypeConversionException {
        return value == null ? null : value.toString();
    }
}