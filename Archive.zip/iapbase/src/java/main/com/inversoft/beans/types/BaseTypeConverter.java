/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


/**
 * <p>
 * This class is the base type converter for all the type
 * converters it is also the type converter that handles
 * strings and arrays of strings. This converter contains
 * implementation for all the type converter methods and
 * also includes standard implementations for the convert,
 * convertArray, convertArrayToArray, convertToArray and
 * convertStringToArray. In most cases, these methods do
 * not need to be overridden. See each method for details
 * on what exactly the method does in order to help
 * determine if overriding is necessary.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public abstract class BaseTypeConverter<T> implements TypeConverter<T> {

    /**
     * <p>
     * If the convertTo class is an array, this method calls convertToArray passing
     * it the value and the convertTo component type (by calling the getComponentType
     * method of java.lang.Class).
     * </p>
     *
     * <p>
     * If the value is an instanceof an array, this method calls the convertArray
     * method passing it the value, cast to an array and the convertTo type.<p>
     * Otherwise, this method calls convertString passing it the value toString and
     * the convertTo type.
     * </p>
     *
     * <p>
     * If the value is null, then convertString is called to handle primitive
     * values and any converts that wish to handle null values differently. If
     * the value is an instance of the convertTo type, this returns the value.
     * </p>
     *
     * <p>
     * Sub-classes should only override this method if they intend to handle conversion
     * between two Object types, both of which are NOT String. For example, if a
     * sub-class wished to convert Integer objects to Long objects, it could do that
     * in this method. It is a good idea however, that sub-classes call this
     * implementation if they do not handle the conversion.
     * </p>
     *
     * @param   value The value to convert
     * @param   convertTo The type to convert the value to
     * @return  The converted value or null if the value is null. This returns value
     *          if value is an instance of the convertTo type
     * @throws  TypeConversionException If there was a problem converting the given
     *          value to the given type
     */
    public T convert(final Object value, final Class<?> convertTo)
    throws TypeConversionException {
        // If the value is null, no use in converting it
        if (value == null) {
            return convertFromString((String) value, convertTo);
        }

        // Handles the case where the value is the same type or sub-type as the convertTo
        if (convertTo.isInstance(value)) {
            return (T) value;
        }

        return convertFromString(value.toString(), convertTo);
    }
}