/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * This class is a blank implementation of the
 * ConversionListener interface It is abstract and implements
 * every method of the listener with an empty implementation
 *
 * @author  Brian Pontarelli
 */
public abstract class ConversionListenerAdapter implements ConversionListener {

    /**
     * This handle method is called when the property value being set is going
     * to be auto-converted but has not been converted yet.
     */
    public void handlePreConversion(ConversionEvent event) {}

    /**
     * This handle method is called when the property value being set has just been
     * successfully auto-converted
     */
    public void handlePostConversion(ConversionEvent event) {}

    /**
     * This handle method is called when the property value being set has been
     * converted and the conversion failed
     */
    public void handleFailedConversion(ConversionEvent event) {}
}
