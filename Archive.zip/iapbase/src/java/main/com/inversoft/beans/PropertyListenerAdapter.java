/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * This class is a blank implementation of the PropertyListener
 * interface. It is abstract and implements every method
 * of the listener with an empty implementation
 *
 * @author  Brian Pontarelli
 */
public abstract class PropertyListenerAdapter implements PropertyListener {

    /**
     * This handle method is called when the property value is being retrieved
     * by calling the getter for the property
     */
    public void handleGet(PropertyEvent event) {}

    /**
     * This handle method is called when the property value is being changed
     * by calling the setter for the property
     */
    public void handleSet(PropertyEvent event) {}
}
