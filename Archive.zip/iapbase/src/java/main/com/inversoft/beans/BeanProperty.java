/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.util.Map;
import java.util.WeakHashMap;

import com.inversoft.beans.types.TypeConversionException;

import static com.inversoft.beans.EventType.*;


/**
 * This class is used to describe, and manipulate JavaBean
 * properties. The properties that this class handles are
 * normal properties and NOT nested properties (see {@link
 * NestedBeanProperty NestedBeanProperty} for more
 * information on nested bean properties).
 *
 * @author  Brian Pontarelli
 */
public class BeanProperty extends BaseBeanProperty {
    /**
     * The cache Map for the BeanProperty objects (unsynchronized).
     */
    private static Map<String, BeanProperty> cache =
        new WeakHashMap<String, BeanProperty>();


    //--------------------------------------------------------------------------
    //                               Cache Methods
    //--------------------------------------------------------------------------

    /**
     * Returns an instance of the BeanProperty for the given propertyName and
     * bean Class. This object might be cached, depending on the implementation
     * of this method. Therefore, you must take into account a cached or non-
     * cached object.
     *
     * @param   propertyName The property name of the BeanProperty
     * @param   beanClass The bean Class
     * @return  The BeanProperty and never null
     * @throws  BeanException If the creation of the obejct fails
     */
    public static BeanProperty getInstance(final String propertyName,
            final Class<?> beanClass)
    throws BeanException {
        if (propertyName == null || propertyName.indexOf(".") != -1) {
            throw new BeanException("Invalid propertyName: " + propertyName);
        }

        // If not caching, just create the objects
        synchronized (cache) {
            String key = beanClass.toString() + "#" + propertyName;
            BeanProperty bp = cache.get(key);
            if (bp == null) {
                bp = new BeanProperty(propertyName, beanClass);
                cache.put(key, bp);
            }

            return bp;
        }
    }


    /**
     * <p>
     * Constructs a new bean property using the property name and the bean class
     * given.
     * </p>
     *
     * <p>
     * If the bean class does not have a write method (set method) than the property
     * is considered read-only. The bean class MUST have a read method (get method)
     * or this method will throw and exception. This method calls the super-class
     * constructor with the same signature.
     * </p>
     *
     * @param   propertyName The name of the JavaBean property
     * @param   beanClass The Class object used to find the read and write methods
     *          for the JavaBean property
     * @throws  BeanException If the property is invalid or does not exist in the
     *          bean class given
     */
    public BeanProperty(String propertyName, Class<?> beanClass)
    throws BeanException {
        super(propertyName, beanClass);
    }


    /**
     * Sets up the methods.
     */
    @Override void initialize() {
        this.read = JavaBeanTools.findReadMethod(propertyName, beanClass);
        super.initialize();
        try {
            write = JavaBeanTools.findWriteMethod(propertyName, beanClass, propertyType);
        } catch (BeanException be) {
            // smother the exception so that this property is read only
        }
    }

    /**
     * Returns the value of the Java bean property for the given bean instance.
     *
     * @param   bean The instance of the Java bean to retrieve the property from
     * @return  The value of the property retrieved by calling the read method of
     *          the property
     * @throws  BeanException If there was an error getting the Java bean property or
     *          the getter/is method threw a checked Exception
     */
    public Object getPropertyValue(final Object bean) throws BeanException {
        Object value = JavaBeanTools.callGetter(this, bean);

        if (hasPropertyListeners()) {
            firePropertyEvent(GET, value, value, bean, null);
        }

        return value;
    }

    /**
     * This operation is not supported except on IndexedBeanProperty. This is
     * here for code ease in JavaBean and that is why it is package level.
     * IndexedBeanProperty opens it to public.
     *
     * @throws  BeanException Always
     */
    public Object getPropertyValue(final Object bean, final Object key)
    throws BeanException {
        throw new BeanException("Operation not supported except in IndexedBeanProperty");
    }

    /**
     * Sets the value of the Java bean property to the given value
     *
     * @param   bean The instance of the Java bean to set the property on
     * @param   value The value to set the property to
     * @param   convert Determines whether or not value should be converted
     *          to the type that the setter requires or not
     * @throws  BeanException If there was an error setting the Java bean property or
     *          the setter method threw a checked Exception
     * @throws  TypeConversionException If there was a problem auto-converting the
     *          property value
     */
    public void setPropertyValue(final Object bean, Object value, final boolean convert)
    throws BeanException, TypeConversionException {

        // If we are autoConverting, convert the parameter
        if (convert) {
            value = convertParameter(value, bean, propertyType);
        }

        // Store the old value if there are property listeners
        Object oldValue = null;

        if (hasPropertyListeners()) {
            oldValue = JavaBeanTools.callGetter(this, bean);
        }

        JavaBeanTools.callSetter(this, bean, value);

        if (hasPropertyListeners()) {
            firePropertyEvent(SET, oldValue, value, bean, null);
        }
    }

    /**
     * Sets the value of the bean property to the given value. This value is set
     * without doing any conversion. This method is the same as calling the other
     * setPropertyValue method with the convert parameter set to false
     *
     * @param   bean The instance of the JavaBean to set the property on
     * @param   value The value to set the property to
     * @throws  BeanException If there was an error setting the JavaBean property or
     *          the setter method threw a checked Exception
     */
    public void setPropertyValue(final Object bean, final Object value)
    throws BeanException {
        try {
            setPropertyValue(bean, value, false);
        } catch (TypeConversionException tce) {
            assert false : "FATAL: should never throw TypeConversionException" +
                " because this method does no conversion";
        }
    }
}