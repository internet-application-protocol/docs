/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


/**
 * <p>
 * This enumeration identifies the different types of events
 * that are fired during JavaBean handling.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum EventType {
    /**
     * Used to denote a get event when sub-classes are firing events
     */
    GET,

    /**
     * Used to denote a set event when sub-classes are firing events
     */
    SET,

    /**
     * Used to denote a conversion event is about to take place when sub-classes
     * are firing events
     */
    PRE_CONVERT,

    /**
     * Used to denote a conversion event has just taken place when sub-classes
     * are firing events
     */
    POST_CONVERT,

    /**
     * Used to denote a conversion event has failed to take place when sub-classes
     * are firing events
     */
    BAD_CONVERT;
}