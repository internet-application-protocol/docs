/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.util.EventObject;


/**
 * This class is the base event that all events will extends
 * from. It contains the fundamental items that all events
 * should have. Since this event derives from the EeventObject,
 * the source of the event is the BaseBeanProperty object
 * that created the event.
 *
 * @author  Brian Pontarelli
 */
public abstract class BaseEvent extends EventObject {

    private BaseBeanProperty property;
    private Object oldValue;
    private Object newValue;
    private Object bean;

    /**
     * Creates a new base event using the values given
     */
    public BaseEvent(BaseBeanProperty property, Object oldValue, Object newValue,
            Object bean) {
        super(property);
        this.property = property;
        this.oldValue = oldValue;
        this.newValue = newValue;
        this.bean = bean;
    }

    /** Retrieves the name of the property the event occurred for */
    public String getPropertyName() {
        return property.getPropertyName();
    }

    /**
     * Returns the type of the property the event occurred for. This may be null
     * if the property type is unknown. For example, nested properties are always
     * unknown because they type may change at runtime.
     */
    public Class<?> getPropertyType() {
        return property.getPropertyType();
    }

    /** Returns the full name of the property the event occurred for */
    public String getFullName() {
        return property.getFullName();
    }

    /**
     * Returns the old value. This is different for each type of event, so
     * please consult the sub-classes for a more complete description of
     * this method.
     */
    public Object getOldValue() {
        return oldValue;
    }

    /**
     * Returns the new value. This is different for each type of event, so
     * please consult the sub-classes for a more complete description of
     * this method.
     */
    public Object getNewValue() {
        return newValue;
    }

    /**
     * Returns the bean object whose property the event occurred for.
     */
    public Object getBean() {
        return bean;
    }
}
