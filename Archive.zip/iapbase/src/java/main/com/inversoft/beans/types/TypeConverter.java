/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


/**
 * <p>
 * TypeConverters are used to convert objects from one type
 * to another, convert strings to objects and to convert from
 * objects and strings to arrays of objects. The way that
 * this is setup is that a TypeConverter implementation is
 * registered with the TypeConverterRegistry. The manager can
 * then be queried for a particular TypeConveter (see {@link
 * TypeConverterRegistry TypeConveterManager} for more information
 * about retrieval). Next, the TypeConverter can be used
 * for conversions using one of four methods described
 * below. Any given TypeConverter may be used to convert to
 * many different types because of the way that the
 * TypeConverterRegistry searches for TypeConverters. Because
 * of this flexibility when converting, the TypeConverter
 * must be told what type to convert to. This is the reason
 * for the second convertTo parameter on all of the convert
 * methods.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public interface TypeConverter<T> {

    /**
     * <p>
     * Converts the given object to the given type. The type can be any type
     * that is support by the TypeConverter, but generally is a type that is the
     * type or a sub-type of the type the converter is registered for. For example,
     * let's say the converter is registered to java.lang.Number, then the
     * converter should be able to convert Integer, Long, Double, etc; unless
     * a converter is registered for each one of these. So, we could call the
     * converter with ("0.5", Double.class) in order to convert the string to
     * a Double object.
     * </p>
     *
     * <p>
     * It is common practice to call the {@link #convertFromString(String, Class<T>)
     * method from this method passing it value.toString and convertTo. Of course
     * this is not required and is up to the implementing class to determine how
     * best to convert the value to the given type.
     * </p>
     *
     * <p>
     * It is also common practice to call the {@link #convertToString(Object) if
     * the convertTo parameter given is String.class.
     * </p>
     *
     * @param   value The value to convert.
     * @param   convertTo The type to convert the value to.
     * @return  The converted value.
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type.
     */
    T convert(Object value, Class<?> convertTo) throws TypeConversionException;

    /**
     * <p>
     * Converts the given String to the given type. The type can be any type
     * that is support by the TypeConverter, but generally is a type that is the
     * type or a sub-type of the type the converter is registered for. For example,
     * let's say the converter is registered to java.lang.Number, then this
     * converter should be able to convert Integer, Long, Double, etc. unless
     * a converter is registered for each one of these. So, we could call the
     * converter with ("0.5", Double.class) in order to convert the string to
     * a Double object.
     * </p>
     *
     * @param   value The String value to convert.
     * @param   convertTo The type to convert the value to.
     * @return  The converted value.
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type.
     */
    T convertFromString(String value, Class<?> convertTo)
    throws TypeConversionException;


    /**
     * <p>
     * Converts the given type to a String. The type can be any type that is
     * support by the TypeConverter, but generally is a type that is the type or
     * a sub-type of the type the converter is registered for. For example,
     * let's say the converter is registered to java.lang.Number, then this
     * converter should be able to convert Integer, Long, Double, etc. unless
     * a converter is registered for each one of these. So, we could call the
     * converter with (New Double(0.5), Double.class) in order to convert the
     * Double to a String.
     * </p>
     *
     * @param   value The value to convert to a String.
     * @return  The converted value.
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type.
     */
    String convertToString(T value) throws TypeConversionException;
}