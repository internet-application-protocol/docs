/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


import com.inversoft.util.StringTools;


/**
 * This class is the main character converter. It is able to
 * convert strings to the java.lnag.Character wrapper class.
 * This is done by simply taking the string and transferring
 * the single character to a Character object. This fails if
 * the String is longer than one character though. Since this
 * class sub-classes BaseTypeConverter it is able to convert
 * to and from arrays. See the parent for more information.
 *
 * @author  Brian Pontarelli
 */
public class CharacterTypeConverter extends BaseTypeConverter<Character> {

    /**
     * <p>
     * Converts the string to the given type. This method first calls the parents
     * convertString method to handle the empty and array cases. If the parent
     * method returns value, then this method will convert the string to a
     * character. If the string is longer than one character an exception is thrown.
     * If the convertTo type is a primitive and the value string is null or empty,
     * then this method returns a new Character wrapper set to the initial value
     * of the primitive (\u0000)
     * </p>
     *
     * @param   value The String value to convert
     * @param   convertTo The type to convert the value to
     * @return  The converted value
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type
     */
    public Character convertFromString(final String value, final Class<?> convertTo)
    throws TypeConversionException {
        boolean empty = StringTools.isEmpty(value);
        if (empty && convertTo == Character.TYPE) {
            return new Character('\u0000');
        } else if (empty) {
            return null;
        }

        // Check the length
        if (value.length() > 1) {
            throw new TypeConversionException("Setter expected a single" +
                " character but receieved string with value: " + value);
        }

        return new Character(value.charAt(0));
    }

    /**
     * <p>
     * Converts the given Character to a String. If the String is null, null is
     * returned. Otherwise, the Character.toString() method is called.
     * </p>
     *
     * @param   value The value to convert to a String.
     * @return  The converted value.
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type.
     */
    public String convertToString(final Character value)
    throws TypeConversionException {
        return value == null ? null : value.toString();
    }
}
