/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans.types;


import com.inversoft.util.StringTools;


/**
 * This class is the main number converter. It is able to
 * convert strings to primitive types or sub-classes of
 * java.lang.Number. Primitive types are handled by
 * conversion to the equivalent wrapper class. In most cases
 * the valueOf method is used on the appropriate wrapper
 * class in order to convert the string value. Since this
 * class sub-classes BaseTypeConverter it is able to convert
 * to and from arrays. See the parent for more information.
 *
 * @author  Brian Pontarelli
 */
public class NumberTypeConverter extends BaseTypeConverter<Number> {

    /**
     * <p>
     * Converts the string to the given type. If the given type is an array type
     * then this method returns the result of calling convertStringToArray.
     * Otherwise, the string is converted to the correct type. If the string passed
     * in is either null, empty or only whitespace, then this method returns null,
     * unless the given type is a primitive type, then a wrapper class with the the
     * default value for the primitive (usually 0) is returned.
     * </p>
     *
     * @param   value The String value to convert
     * @param   convertTo The type to convert the value to
     * @return  The converted value
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type
     */
    public Number convertFromString(final String value, final Class<?> convertTo)
    throws TypeConversionException {
        // If the string is null or empty, then the conversion is null
        boolean emptyNull = StringTools.isEmpty(value);
        if (emptyNull && !convertTo.isPrimitive()) {
            return null;
        }

        // Not an array so convert the string to the correct type
        try {
            if (convertTo == Byte.class || convertTo == Byte.TYPE) {
                return (emptyNull) ? new Byte((byte) 0) : Byte.valueOf(value);
            } else if (convertTo == Short.class || convertTo == Short.TYPE) {
                return (emptyNull) ? new Short((short) 0) : Short.valueOf(value);
            } else if (convertTo == Integer.class || convertTo == Integer.TYPE) {
                return (emptyNull) ? new Integer(0) : Integer.valueOf(value);
            } else if (convertTo == Long.class || convertTo == Long.TYPE) {
                return (emptyNull) ? new Long(0l) : Long.valueOf(value);
            } else if (convertTo == Float.class || convertTo == Float.TYPE) {
                return (emptyNull) ? new Float(0.0f) : Float.valueOf(value);
            } else if (convertTo == Double.class || convertTo == Double.TYPE) {
                return (emptyNull) ? new Double(0.0): Double.valueOf(value);
            }
        } catch (Exception e) {
            throw new TypeConversionException("Error converting to type: " +
                convertTo.getName(), e);
        }

        throw new TypeConversionException("Type: " + convertTo.getName()
            + " not supported by the NumberTypeConverter");
    }

    /**
     * <p>
     * Converts the given Number to a String. If the Number is null, null is
     * returned. Otherwise, the Number.toString() method is called.
     * </p>
     *
     * @param   value The value to convert to a String.
     * @return  The converted value.
     * @throws  TypeConversionException If there was a problem converting the
     *          given value to the given type.
     */
    public String convertToString(final Number value) throws TypeConversionException {
        return value == null ? null : value.toString();
    }
}