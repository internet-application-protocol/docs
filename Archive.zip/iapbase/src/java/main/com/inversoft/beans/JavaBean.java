/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.beans;


import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import com.inversoft.beans.types.TypeConversionException;
import com.inversoft.util.ObjectTools;
import com.inversoft.util.ReflectionException;
import com.inversoft.util.ReflectionTools;


/**
 * <p>
 * This class can be used to facilitate getting and setting
 * of JavaBean properties. It is an object representation
 * of a JavaBean and allows the developer to add new
 * properties, get property values and set property values.
 * This class also models indexed and nested JavaBeans
 * properties as well as nested JavaBeans themselves
 * </p>
 *
 * <p>
 * Nested JavaBeans are when a JavaBean property is another
 * JavaBean. In normal Java code, retrieval would look
 * something like:
 * </p>
 *
 * <p>
 * <code>bean1.getProperty().getProperty2()...getPropertyN().</code>
 * </p>
 *
 * <p>
 * The bean1 instance is the base JavaBean for this example.
 * Within this JavaBean there is a property named property1,
 * whose return type is another JavaBean. This is repeated
 * until a leaf property is hit. Leaf properties return
 * object instances that do not contain any JavaBean
 * properties. Although all leaf properties do not meet
 * this requirement a property that does is automatically a
 * leaf property.
 * </p>
 *
 * <p>
 * A property might return an instance of an object that
 * does contain JavaBean properties, but in the context of
 * a particular application, these are not accessed using
 * the JBeans package or through reflection. These
 * properties are also considered leaf properties.
 * </p>
 *
 * <p>
 * Using this class these properties can be retrieved using
 * the standard JavaBean notation of property.property2...propertyN
 * (for the example above)
 * </p>
 *
 * <p>
 * It should also be noted that the properties already
 * accessed or added are stored so that continued access is
 * quicker than using the NestedBeanProperty class. This
 * also means that this class will only store the information
 * about the properties and nested JavaBeans requested. It
 * does NOT build a complete list of the properties and
 * nested JavaBeans of a particular class at any time. It
 * is not recommended that this class be heavily used
 * because of the space usage of storing all the properties
 * and nested JavaBeans. If it the local and nested
 * properties are relatively few, then this class can offer
 * speed benefits. If not, this class is not a good solution
 * because of its memory consumption.
 * </p>
 *
 * <p>
 * <b>NOTE:</b><br>
 * When this class creates new JavaBean instances for nested
 * properties, the new instances have the same value for the
 * strict property as the parent JavaBean instance.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class JavaBean {

    /**
     * The cache Map for the JavaBean objects
     */
    private static Map<Class<?>, JavaBean> cache =
        new WeakHashMap<Class<?>, JavaBean>();

    protected Class<?> beanClass;


    /**
     * Fetchs a JavaBean object, which may have been cached, depending on the
     * implementation, for the given Class instance.
     *
     * @param   beanClass The Class to fetch the JavaBean instance for
     *          retrieving property values and a child bean is null
     * @return  The JavaBean instance and never null
     */
    public static JavaBean getInstance(Class<?> beanClass) {
        synchronized (cache) {
            JavaBean javaBean = cache.get(beanClass);
            if (javaBean == null) {
                javaBean = new JavaBean(beanClass);
                cache.put(beanClass, javaBean);
            }

            return javaBean;
        }
    }


    /**
     * Creates new JavaBean using the given bean class object and with strict set
     * to false. This constructor does nothing but setup the JavaBean for access. As
     * mentioned in the class comment, this does not build a list of properties or
     * nested JavaBeans. This occurs when either the properties are added or used
     * to get and set values.
     *
     * @param   beanClass The Class object used to find the properties and nested
     *          JavaBeans
     */
    public JavaBean(Class<?> beanClass) {
        this.beanClass = beanClass;
    }


    /**
     * Gets the bean class that this JavaBean is for
     */
    public Class<?> getBeanClass() {
        return beanClass;
    }

    /**
     * Gets the bean class that this JavaBean is for as a String
     */
    public String getClassName() {
        return beanClass.getName();
    }

    /**
     * <p>
     * Returns the bean property described by the propertyName String parameter.
     * This parameter can be either a property of this JavaBean or a property
     * of a nested JavaBean. See the class comment for a description of nested
     * JavaBeans.
     * </p>
     *
     * <p>
     * If the BeanProperty has not been added to either this JavaBean or a child
     * JavaBean, it will be created and likewise, any JavaBean children that do
     * not exist yet, will also be created and added. This is done in order to
     * allow access to the BeanProperty. Not that if the BeanProperty does not
     * exist in the Class of this JavaBean or a child JavaBean an exception is
     * thrown.
     * </p>
     *
     * @param   propertyName The name of the property that is a local or nested property
     * @return  Either the local bean property or the nested bean property and never null
     * @throws  BeanException If there was a problem finding or creating the bean
     *          property
     */
    public BaseBeanProperty getBeanProperty(final String propertyName)
    throws BeanException {

        JavaBeanTools.NameInfo ni = JavaBeanTools.splitNameFront(propertyName);

        // Determine if the property name describes a local property or a sub-property
        if (!ni.nested) {
            return findProperty(ni.localPropertyName);
        }

        // Attempt to look up this beans child JavaBean
        JavaBean child = findChildJavaBean(ni.localPropertyName, null);

        // Recurse into the child we just retrieved or created
        return child.getBeanProperty(ni.nestedPropertyName);
    }

    /**
     * <p>
     * Returns the indexed bean property described by the propertyName String
     * parameter. This parameter can be either a property of this JavaBean or a
     * property of a nested JavaBean. See the class comment for a description of
     * nested JavaBeans.
     * </p>
     *
     * <p>
     * If the IndexedBeanProperty has not been added to either this JavaBean or a
     * child JavaBean, it will be created and likewise, any JavaBean children that
     * do not exist yet, will also be created and added. This is done in order to
     * allow access to the IndexedBeanProperty. Not that if the property does not
     * exist in the Class of this JavaBean or a child JavaBean or it is not indexed
     * an exception is thrown.
     * </p>
     *
     * @param   propertyName The name of the property that is a local or nested
     *          indexed property
     * @return  Either the local indexed bean property or the nested indexed bean
     *          property and never null
     * @throws  BeanException If there was a problem finding or creating the
     *          indexed bean property
     */
    public IndexedBeanProperty getIndexedBeanProperty(final String propertyName)
    throws BeanException {

        JavaBeanTools.NameInfo ni = JavaBeanTools.splitNameFront(propertyName);

        // Determine if the property name describes a local property or a sub-property
        if (!ni.nested) {

            // This will never throw a class cast exception because the findProperty
            // method is guarenteed to return an IndexedBeanProperty if the boolean
            // parameter is true
            BaseBeanProperty bp = findProperty(ni.localPropertyName);
            if (!(bp instanceof IndexedBeanProperty)) {
                throw new BeanException("Property is not indexed");
            }

            return (IndexedBeanProperty) bp;
        }

        // Attempt to look up this beans child JavaBean
        JavaBean child = findChildJavaBean(ni.localPropertyName, null);

        // Recurse into the child we just retrieved or created
        return child.getIndexedBeanProperty(ni.nestedPropertyName);
    }

    /**
     * Returns a List that contains all the non-indexed bean properties from this
     * JavaBean.
     *
     * @return  A List of all the non-indexed bean properties.
     */
    public List<BeanProperty> getAllBeanProperties() {
        Method[] methods = this.beanClass.getMethods();
        List<BeanProperty> props = new ArrayList<BeanProperty>();
        Set<String> propsAdded = new HashSet<String>();
        for (Method method : methods) {
            if (method.getName().equals("getClass")) {
                continue;
            }

            if (JavaBeanTools.isValidGetter(method) || JavaBeanTools.isValidSetter(method)) {
                String propName = JavaBeanTools.getPropertyName(method);
                if (propsAdded.contains(propName)) {
                    continue;
                } else {
                    propsAdded.add(propName);
                }

                props.add(BeanProperty.getInstance(propName, this.beanClass));
            }
        }

        return props;
    }

    /**
     * <p>
     * Returns whether or not the property described by the propertyName String
     * parameter is an indexed bean property or not. This property can be a
     * property of this JavaBean or a property of a nested JavaBean. See the
     * class comment for a description of nested JavaBeans.
     * </p>
     *
     * <p>
     * If the property was not added to the JavaBean yet, then this method adds
     * it so that it can determine whether or not it is indexed. Also, if the
     * propertyName is not valid, then an exception is thrown.
     * </p>
     *
     * @param   propertyName The name of the property that is a local or nested property
     *          and is being check to see if it is indexed or not
     * @return  True if the bean property is indexed, false otherwise
     * @throws  BeanException If the propertyName is not a valid local or nested
     *          property
     */
    public boolean isBeanPropertyIndexed(String propertyName) throws BeanException {

        JavaBeanTools.NameInfo ni = JavaBeanTools.splitNameFront(propertyName);

        // Determine if the property name describes a local property or a sub-property
        if (!ni.nested) {

            // This will return the BeanProperty which could be indexed or not
            BaseBeanProperty bp = findProperty(ni.localPropertyName);
            return (bp instanceof IndexedBeanProperty);
        }

        // Attempt to look up this beans child JavaBean
        JavaBean child = findChildJavaBean(ni.localPropertyName, null);

        // Recurse into the child we just retrieved or created
        return child.isBeanPropertyIndexed(ni.nestedPropertyName);
    }

    /**
     * Checks if the given bean property is a valid bean property for this JavaBean
     * or a child JavaBean. This method also checks if the given type the type
     * or sub-type of the type for the property. If the BeanProperty has not
     * been added to the JavaBean or to a child JavaBean it is created and added.
     *
     * @param   propertyName The property to check and possibly add to this the
     *          java bean
     * @param   type The type to check against the property
     * @throws  BeanException If the property does not exist in this java bean or
     *          if the property type is not the same as or assignable to the given
     *          type
     */
    public void checkBeanProperty(final String propertyName, final Class<?> type)
    throws BeanException {

        BaseBeanProperty prop = getBeanProperty(propertyName);

        if (!prop.getPropertyType().isAssignableFrom(type)) {
            throw new BeanException(type.getName() + " is not a valid type for" +
                " the bean property named " + propertyName);
        }
    }

    /**
     * Returns the child JavaBean described by the propertyName String parameter.
     * This parameter can be either a property of this JavaBean or a nested
     * property name. See the class comment for a description of nested JavaBeans.
     *
     * @param   propertyName The name of the property that is a child bean or the
     *          name of a nested property that is a child bean of one of this
     *          beans children
     * @return  Either the local child JavaBean or the nested child JavaBean and
     *          never null
     * @throws  BeanException If there was a problem finding the sub-bean or there
     *          was a problem creating BeanProperty objects for properties of this
     *          bean or one of its children or problems creating JavaBean obejcts
     *          for one of this beans child beans
     */
    public JavaBean getChildJavaBean(final String propertyName)
    throws BeanException {

        JavaBeanTools.NameInfo ni = JavaBeanTools.splitNameFront(propertyName);

        // Attempt to look up this beans child JavaBean
        JavaBean child = findChildJavaBean(ni.localPropertyName, null);

        // If this is a nested child, recurse into the child we just retrieved or created.
        // Otherwise it was local, so just return the child
        return ((ni.nested) ?
            child.getChildJavaBean(ni.nestedPropertyName) : child);
    }

    /**
     * Returns a new instance of the Java bean class that this JavaBean instance was
     * cosntructed for. This is done using the default constructor for the Java bean.
     * If there was any problems a BeanException is thrown
     *
     * @return  A new instance of the Java bean for this JavaBean instance
     * @throws  BeanException If there was a problem creating the instance
     */
    public Object instantiate() throws BeanException {
        try {
            return ReflectionTools.instantiate(beanClass);
        } catch (ReflectionException re) {
            throw new BeanException(re);
        }
    }


    //--------------------------------------------------------------------------
    //              Property Modification and Retrieval Methods
    //--------------------------------------------------------------------------

    /**
     * <p>
     * Retrieves the local or nested bean property using the property name and the
     * bean object (which will be used to retrieve and/or store child objects).
     * </p>
     *
     * <p>
     * This method assumes a non-strict handling. If you want to make this strict
     * use {@link #getPropertyValue(String, Object, boolean) this} method.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to retrieve
     * @param   bean The bean to retrieve the property value from
     * @return  The value of the property
     * @throws  BeanException If there was a problem retrieving the value
     */
    public Object getPropertyValue(final String propertyName, final Object bean)
    throws BeanException {
        return getPropertyValue(propertyName, bean, false, (List<List<Object>>) null);
    }

    /**
     * <p>
     * Retrieves the local or nested bean property using the property name and the
     * bean object (which will be used to retrieve and/or store child objects).
     * </p>
     *
     * <p>
     * This method uses the strict parameter to determine the strictness handling.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to retrieve
     * @param   bean The bean to retrieve the property value from
     * @param   strict Determines the strictness of this operation
     * @return  The value of the property
     * @throws  BeanException If there was a problem retrieving the value
     */
    public Object getPropertyValue(final String propertyName, final Object bean,
            final boolean strict)
    throws BeanException {
        return getPropertyValue(propertyName, bean, strict, (List<List<Object>>) null);
    }

    /**
     * <p>
     * Retrieves the local or nested bean property using the property name, the
     * bean object (which will be used to retrieve and/or store child objects)
     * and the list of indices which will be used for any indexed properties.
     * The array is used in sequential order as the indices whenever a indices
     * property is encountered.
     * </p>
     *
     * <p>
     * This method assumes a non-strict handling. If you want to make this strict
     * use {@link #getPropertyValue(String, Object, boolean) this} method.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to retrieve
     * @param   bean The bean to retrieve the property value from
     * @param   indices (Optional) The list of indices used for indexed properties.
     *          This is two dimensional so that it is modeled correctly. Each
     *          property that may need an indices is the first array. Each indices
     *          that that property needs is the second array. The fist array must
     *          have the same length as the number of nested properties. If a
     *          property in the nesting does not require an index, that entry in
     *          the list should be null.
     * @return  The value of the property
     * @throws  BeanException If there was a problem retrieving the value
     */
    public Object getPropertyValue(final String propertyName, final Object bean,
        final int[][] indices)
    throws BeanException {
        List<List<Object>> list = convertArray(indices);
        return getPropertyValue(propertyName, bean, false, list);
    }

    /**
     * <p>
     * Retrieves the local or nested bean property using the property name, the
     * bean object (which will be used to retrieve and/or store child objects)
     * and the list of indices which will be used for any indexed properties.
     * The array is used in sequential order as the indices whenever a indices
     * property is encountered.
     * </p>
     *
     * <p>
     * This method uses the strict parameter to determine the strictness handling.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to retrieve
     * @param   bean The bean to retrieve the property value from
     * @param   indices (Optional) The list of indices used for indexed properties.
     *          This is two dimensional so that it is modeled correctly. Each
     *          property that may need an indices is the first array. Each indices
     *          that that property needs is the second array. The fist array must
     *          have the same length as the number of nested properties. If a
     *          property in the nesting does not require an index, that entry in
     *          the list should be null.
     * @param   strict Determines the strictness of this operation
     * @return  The value of the property
     * @throws  BeanException If there was a problem retrieving the value
     */
    public Object getPropertyValue(final String propertyName, final Object bean,
            final boolean strict, final  int[][] indices)
    throws BeanException {
        List<List<Object>> list = convertArray(indices);
        return getPropertyValue(propertyName, bean, strict, list);
    }

    /**
     * <p>
     * Retrieves the local or nested bean property using the property name, the
     * bean object (which will be used to retrieve and/or store child objects)
     * and the list of indices which will be used for any indexed properties. The
     * array is used in sequential order as the indices whenever a indices property is
     * encountered.
     * </p>
     *
     * <p>
     * This method assumes a non-strict handling. If you want to make this strict
     * use {@link #getPropertyValue(String, Object, boolean) this} method.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to retrieve
     * @param   bean The bean to retrieve the property value from
     * @param   indices (Optional) The list of indices used for indexed properties.
     *          This is must bea two dimensional so that it is modeled correctly. Each
     *          property that may need an indices is the first List. Each indices
     *          that that property needs is the second List. This List must have
     *          the same length as the number of nested properties. If a property
     *          in the nesting does not require an index, that entry in the list
     *          should be null.
     * @return  The value of the property
     * @throws  BeanException If there was a problem retrieving the value
     */
    public Object getPropertyValue(final String propertyName, final Object bean,
            final List<List<Object>> indices)
    throws BeanException {
        return getPropertyValue(propertyName, bean, false, indices);
    }

    /**
     * <p>
     * Retrieves the local or nested bean property using the property name, the
     * bean object (which will be used to retrieve and/or store child objects)
     * and the list of indices which will be used for any indexed properties. The
     * array is used in sequential order as the indices whenever a indices property is
     * encountered.
     * </p>
     *
     * <p>
     * This method uses the strict parameter to determine the strictness handling.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to retrieve
     * @param   bean The bean to retrieve the property value from
     * @param   indices (Optional) The list of indices used for indexed properties.
     *          This is must be two dimensional so that it is modeled correctly. Each
     *          property that may need an indices is the first List. Each indices
     *          that that property needs is the second List. (ie List inside List)
     * @param   strict Determines the strictness of this operation
     * @return  The value of the property
     * @throws  BeanException If there was a problem retrieving the value
     */
    public Object getPropertyValue(final String propertyName, final Object bean,
            final boolean strict, final List<List<Object>> indices)
    throws BeanException {
        JavaBeanTools.NameInfo ni = JavaBeanTools.splitNameFront(propertyName);
        JavaBeanTools.PropertyInfo pi =
            JavaBeanTools.retrievePropertyInfo(ni.localPropertyName);

        List<List<Object>> subList = indices;
        boolean listEmpty = (indices == null || indices.size() == 0);
        if (pi.indices == null && !listEmpty) {
            pi.indices = indices.get(0);
            subList = indices.subList(1, indices.size());
        }

        Object value = getLocalPropertyValue(pi, bean);
        if (ni.nested) {
            if (value != null) {
                JavaBean child = JavaBean.getInstance(value.getClass());
                value = child.getPropertyValue(ni.nestedPropertyName, value,
                    strict, subList);
            } else if (strict) {
                throw new BeanException("Null property value encountered for " +
                    "strict JavaBean. Property name was: " + propertyName);
            }
        }

        return value;
    }

    /**
     * <p>
     * Sets the local or nested property to the given value on the given bean instance.
     * This method does no conversion and is the same as calling the other
     * setPropertyValue method with the convert parameter set to false.
     * </p>
     *
     * <p>
     * This method assumes a non-strict handling. If you want to make this strict
     * use {@link #setPropertyValue(String, Object, Object, boolean, boolean)
     * this} method. See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to set (local or nested)
     * @param   bean The bean to set the property on
     * @param   value The value to set the property to
     * @throws  BeanException If there was a problem setting the property or
     *          creating child objects
     */
    public void setPropertyValue(final String propertyName, final Object bean,
            final Object value)
    throws BeanException {
        try {
            setPropertyValue(propertyName, bean, value, false, false,
                (List<List<Object>>) null);
        } catch (TypeConversionException tce) {
            assert false : "FATAL: should never throw TypeConversionException" +
                " because this method does no conversion";
        }
    }

    /**
     * <p>
     * Sets the local or nested property using the property name, the bean object
     * (which will be used to retrieve and/or store the child objects if this
     * is a nested property), the value with which to set the property, the convert
     * flag to determine whether or not to convert the value to the appropriate
     * type before setting.
     * </p>
     *
     * <p>
     * This method assumes a non-strict handling. If you want to make this strict
     * use {@link #setPropertyValue(String, Object, Object, boolean, boolean)
     * this} method. See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to set (local or nested)
     * @param   bean The bean to set the property on
     * @param   value The value to set the property to
     * @param   convert Determines whether or not to convert the value to the type
     *          of the property
     * @throws  BeanException If there was a problem setting the property or
     *          creating child objects
     * @throws  TypeConversionException If there was an error attempting to auto
     *          convert the value being set
     */
    public void setPropertyValue(final String propertyName, final Object bean,
            final Object value, final boolean convert)
    throws BeanException, TypeConversionException {
        setPropertyValue(propertyName, bean, value, convert, false,
            (List<List<Object>>) null);
    }

    /**
     * <p>
     * Sets the local or nested property using the property name, the bean object
     * (which will be used to retrieve and/or store the child objects if this
     * is a nested property), the value with which to set the property, the convert
     * flag to determine whether or not to convert the value to the appropriate
     * type before setting.
     * </p>
     *
     * <p>
     * This method uses the strict parameter to determine the strictness handling.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to set (local or nested)
     * @param   bean The bean to set the property on
     * @param   value The value to set the property to
     * @param   convert Determines whether or not to convert the value to the type
     *          of the property
     * @param   strict Determines the strictness of this operation
     * @throws  BeanException If there was a problem setting the property or
     *          creating child objects
     * @throws  TypeConversionException If there was an error attempting to auto
     *          convert the value being set
     */
    public void setPropertyValue(final String propertyName, final Object bean,
            final Object value, final boolean convert, final boolean strict)
    throws BeanException, TypeConversionException {
        setPropertyValue(propertyName, bean, value, convert, strict,
            (List<List<Object>>) null);
    }

    /**
     * <p>
     * Sets the local or nested property using the property name, the bean object
     * (which will be used to retrieve and/or store the child objects if this
     * is a nested property), the array of indices for any indexed properties, the
     * value with which to set the property, the convert flag to determine whether
     * or not to convert the value to the appropriate type before setting.
     * </p>
     *
     * <p>
     * This method assumes a non-strict handling. If you want to make this strict
     * use {@link #setPropertyValue(String, Object, Object, boolean, boolean)
     * this} method. See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to set (local or nested)
     * @param   bean The bean to set the property on
     * @param   indices (Optional) The array of indices that will be used for any
     *          indexed properties
     * @param   value The value to set the property to
     * @param   convert Determines whether or not to convert the value to the type
     *          of the property
     * @throws  BeanException If there was a problem setting the property or
     *          creating child objects
     * @throws  TypeConversionException If there was an error attempting to auto
     *          convert the value being set
     */
    public void setPropertyValue(final String propertyName, final Object bean,
            final Object value, final boolean convert, final int[][] indices)
    throws BeanException, TypeConversionException {
        List<List<Object>> list = convertArray(indices);
        setPropertyValue(propertyName, bean, value, convert, false, list);
    }

    /**
     * <p>
     * Sets the local or nested property using the property name, the bean object
     * (which will be used to retrieve and/or store the child objects if this
     * is a nested property), the array of indices for any indexed properties, the
     * value with which to set the property, the convert flag to determine whether
     * or not to convert the value to the appropriate type before setting.
     * </p>
     *
     * <p>
     * This method uses the strict parameter to determine the strictness handling.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to set (local or nested)
     * @param   bean The bean to set the property on
     * @param   indices (Optional) The array of indices that will be used for any
     *          indexed properties
     * @param   value The value to set the property to
     * @param   convert Determines whether or not to convert the value to the type
     *          of the property
     * @param   strict Determines the strictness of this operation
     * @throws  BeanException If there was a problem setting the property or
     *          creating child objects
     * @throws  TypeConversionException If there was an error attempting to auto
     *          convert the value being set
     */
    public void setPropertyValue(final String propertyName, final Object bean,
            final Object value, final boolean convert, final boolean strict,
            final int[][] indices)
    throws BeanException, TypeConversionException {
        List<List<Object>> list = convertArray(indices);
        setPropertyValue(propertyName, bean, value, convert, strict, list);
    }

    /**
     * <p>
     * Sets the local or nested property using the property name, the bean
     * object (which will be used to retrieve and/or store the child objects if
     * this is a nested property), the list of indices for any indexed properties,
     * the value with which to set the property, the convert flag to determine
     * whether or not to convert the value to the appropriate type before setting.
     * </p>
     *
     * <p>
     * This method assumes a non-strict handling. If you want to make this strict
     * use {@link #setPropertyValue(String, Object, Object, boolean, boolean)
     * this} method. See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to set (local or nested)
     * @param   bean The bean to set the property on
     * @param   indices (Optional) The array of indices that will be used for any
     *          indexed properties
     * @param   value The value to set the property to
     * @param   convert Determines whether or not to convert the value to the type
     *          of the property
     * @throws  BeanException If there was a problem setting the property or
     *          creating child objects
     * @throws  TypeConversionException If there was an error attempting to auto
     *          convert the value being set
     */
    public void setPropertyValue(final String propertyName, final Object bean,
            final Object value, final boolean convert,
            final List<List<Object>> indices)
    throws BeanException, TypeConversionException {
        recurseToSet(propertyName, bean, value, convert, false, indices);
    }

    /**
     * <p>
     * Sets the local or nested property using the property name, the bean
     * object (which will be used to retrieve and/or store the child objects if
     * this is a nested property), the list of indices for any indexed properties,
     * the value with which to set the property, the convert flag to determine
     * whether or not to convert the value to the appropriate type before setting.
     * </p>
     *
     * <p>
     * This method uses the strict parameter to determine the strictness handling.
     * See the class comment for more information.
     * </p>
     *
     * @param   propertyName The name of the property to set (local or nested)
     * @param   bean The bean to set the property on
     * @param   indices (Optional) The array of indices that will be used for any
     *          indexed properties
     * @param   value The value to set the property to
     * @param   convert Determines whether or not to convert the value to the type
     *          of the property
     * @param   strict Determines the strictness of this operation
     * @throws  BeanException If there was a problem setting the property or
     *          creating child objects
     * @throws  TypeConversionException If there was an error attempting to auto
     *          convert the value being set
     */
    public void setPropertyValue(final String propertyName, final Object bean,
            final Object value, final boolean convert, final boolean strict,
            final List<List<Object>> indices)
    throws BeanException, TypeConversionException {
        recurseToSet(propertyName, bean, value, convert, strict, indices);
    }

    /**
     * This does the recursive work of setting the property. This calls the
     * child JavaBean's until the end is reached and then calls set.
     */
    private void recurseToSet(final String propertyName, final Object bean,
            final Object value, final boolean convert, final boolean strict,
            final List<List<Object>> indices)
    throws BeanException, TypeConversionException {
        JavaBeanTools.NameInfo ni = JavaBeanTools.splitNameFront(propertyName);
        JavaBeanTools.PropertyInfo pi =
            JavaBeanTools.retrievePropertyInfo(ni.localPropertyName);

        boolean hasIndices = (indices != null && indices.size() > 0);
        List<List<Object>> subList = null;

        if (pi.indices == null && hasIndices) {
            pi.indices = indices.get(0);
            subList = indices.subList(1, indices.size());
        }

        if (ni.nested) {
            Object beanInstance = getLocalPropertyValueCreate(pi, bean, strict);

            JavaBean child = JavaBean.getInstance(beanInstance.getClass());
            child.recurseToSet(ni.nestedPropertyName, beanInstance, value, convert,
                strict, subList);
        } else {
            setLocalPropertyValue(pi, bean, value, convert, strict);
        }
    }


    //-------------------------------------------------------------------------
    //                   Helper Methods (not to be overridden)
    //-------------------------------------------------------------------------

    /**
     * Converts the given int array to a List of Integer objects
     */
    final List<List<Object>> convertArray(int[][] indices) {
        List<List<Object>> list = null;
        if (indices != null && indices.length > 0) {
            list = new ArrayList<List<Object>>();
            for (int i = 0; i < indices.length; i++) {
                List<Object> subList = new ArrayList<Object>();
                list.add(subList);

                for (int j = 0; j < indices[i].length; j++) {
                    subList.add(new Integer(indices[i][j]));
                }
            }
        }

        return list;
    }

    /*
     * Returns the bean property with the given name and if it does not exist,
     * it attempts to create it, store it and then return the newly created one.
     * If the indexed parameter is true, then the property returned must be indexed
     * or an exception is thrown. If it is false, then the property returned
     * can be either indexed or not.
     */
    private BaseBeanProperty findProperty(String propertyName) throws BeanException {
        BaseBeanProperty property;

        // Try indexed properties first then normal
        try {
            property = IndexedBeanProperty.getIndexedInstance(propertyName, beanClass);
        } catch (BeanException be) {
            property = BeanProperty.getInstance(propertyName, beanClass);
        }

        return property;
    }

    /*
     * Finds the child java bean with the given property name or creates a new
     * java bean child with the given type, stores it with the given name and
     * returns it
     */
    private JavaBean findChildJavaBean(final String propertyName,
            final Class<?> type)
    throws BeanException {
        Class<?> newType = type;
        if (newType == null) {
            BaseBeanProperty prop = findProperty(propertyName);
            newType = prop.getPropertyType();
        }

        // The new JavaBean has the same strictness as this JavaBean
        return JavaBean.getInstance(newType);
    }

    private boolean hasMoreIndices(List<?> indices, int count) {
        return (indices != null && count < indices.size());
    }

    /**
     * Retrieves the local bean property value, handling arrays, collections and
     * normal proeprties. This does no creation or setting. If a null is ever
     * encountered, it is returned.
     */
    private Object getLocalPropertyValue(final JavaBeanTools.PropertyInfo pi,
            final Object bean)
    throws BeanException {
        BaseBeanProperty bp = findProperty(pi.propertyName);

        int count = 0;
        boolean indexed = (bp instanceof IndexedBeanProperty);
        Object value;
        IndexedBeanProperty ip;
        Object rootIndex;
        if (indexed) {
            if (!hasMoreIndices(pi.indices, count)) {
                throw new BeanException("Property named: " + pi.propertyName +
                    " is indexed, but no indices supplied");
            }

            ip = (IndexedBeanProperty) bp;
            rootIndex = pi.indices.get(0);
            value = ip.getPropertyValue(bean, rootIndex);
            count++;
        } else {
            value = ((BeanProperty) bp).getPropertyValue(bean);
        }

        if (value != null && hasMoreIndices(pi.indices, count)) {
            int length = pi.indices.size();
            Object ds = value;
            Object subDS = null;
            while (ObjectTools.isDataStructure(ds) && (count < length)) {
                try {
                    subDS = ObjectTools.getValueFromCollection(ds,
                        pi.indices.get(count));
                } catch (IllegalArgumentException iae) {
                    throw new BeanException(iae.getMessage() + " for property " +
                        "named: " + pi.propertyName);
                }

                count++;
                if (ObjectTools.isDataStructure(subDS) && (count < length)) {
                     ds = subDS;
                }
            }

            value = subDS;
        }

        return value;
    }

    /**
     * Retrieves the local bean property value, handling arrays, collections and
     * normal proeprties. This could have the after effect of creating objects
     * and setting them into the property.
     */
    private Object getLocalPropertyValueCreate(final JavaBeanTools.PropertyInfo pi,
            final Object bean, final boolean strict)
    throws BeanException {
        BaseBeanProperty bbp = findProperty(pi.propertyName);

        int count = 0;
        boolean indexed = (bbp instanceof IndexedBeanProperty);
        Object value;
        IndexedBeanProperty ip = null;
        BeanProperty bp = null;
        Object rootIndex = null;

        // If the property is indexed, grab the index and cast. Also verify that
        // there is an index to use
        if (indexed) {
            if (!hasMoreIndices(pi.indices, count)) {
                throw new BeanException("Property named: " + pi.propertyName +
                    " is indexed, but no indices supplied");
            }

            ip = (IndexedBeanProperty) bbp;
            rootIndex = pi.indices.get(0);
            value = ip.getPropertyValue(bean, rootIndex);
            count++;
        } else {
            bp = (BeanProperty) bbp;
            value = bp.getPropertyValue(bean);
        }

        // If we are dealing with a collection or array of some kind, traverse
        // and possibly create the collection/array and possibly store this newly
        // created array in the property. Otherwise just return the property value
        // like normal
        if (hasMoreIndices(pi.indices, count)) {
            int length = pi.indices.size();
            ArrayAndIndex ai = traverseDataStructure(value, bp, ip, rootIndex, pi,
                bean, count, indexed, strict);

            try {
                value = ObjectTools.getValueFromCollection(ai.array,
                    pi.indices.get(length - 1));
            } catch (IllegalArgumentException iae) {
                throw new BeanException(iae.getMessage() + " for property " +
                    "named: " + pi.propertyName);
            } catch (IndexOutOfBoundsException ioobe) {
                // This could be because the DS was null
                value = null;
            }

            Class<?> type = ai.array.getClass();
            if (value == null && type.isArray()) {
                if (strict) {
                    throw new BeanException("Null value encountered and strictness" +
                        " set for property named: " + pi.propertyName);
                }

                try {
                    value = ReflectionTools.instantiate(type.getComponentType());
                    ObjectTools.setValueIntoCollection(ai.array,
                        pi.indices.get(length - 1), value);
                } catch (ReflectionException re) {
                    throw new BeanException(re);
                } catch (IllegalArgumentException iae) {
                    throw new BeanException(iae.getMessage() + " for property " +
                        "named: " + pi.propertyName);
                }
            } else if (value == null) {
                throw new BeanException("Null value encountered for property " +
                    "named: " + pi.propertyName + ". Unable to create because" +
                    " a data structure was encountered of type: " + type.getName() +
                    ". Only arrays can be auto-generated.");
            }
        } else if (value == null) {
            if (strict) {
                throw new BeanException("Null value encountered and strictness" +
                    " set for property named: " + pi.propertyName);
            }

            try {
                Class<?> type = bbp.getPropertyType();
                value = ReflectionTools.instantiate(type);
            } catch (ReflectionException re) {
                throw new BeanException(re);
            }

            if (indexed) {
                ip.setPropertyValue(bean, rootIndex, value, false);
            } else {
                bp.setPropertyValue(bean, value, false);
            }
        }

        return value;
    }

    /**
     * This method sets the value into the local property.
     */
    private void setLocalPropertyValue(final JavaBeanTools.PropertyInfo pi,
            final Object bean, Object value, final boolean convert,
            final boolean strict)
    throws BeanException {
        BaseBeanProperty bbp = findProperty(pi.propertyName);
        int count = 0;
        boolean indexed = (bbp instanceof IndexedBeanProperty);
        IndexedBeanProperty ip = null;
        BeanProperty bp = null;
        Object rootIndex = null;

        // If the property is indexed, grab the index and cast. Also verify that
        // there is an index to use
        if (indexed) {
            if (!hasMoreIndices(pi.indices, count)) {
                throw new BeanException();
            }
            count++;
            rootIndex = pi.indices.get(0);
            ip = (IndexedBeanProperty) bbp;
        } else {
            bp = (BeanProperty) bbp;
        }

        // If we are dealing with a collection or array of some kind, traverse
        // and possibly create the collection/array and then store the value
        // into that. Otherwise just set as normal
        if (hasMoreIndices(pi.indices, count)) {
            Object propertyValue;
            if (indexed) {
                propertyValue = ip.getPropertyValue(bean, rootIndex);
            } else {
                propertyValue = bp.getPropertyValue(bean);
            }

            ArrayAndIndex ai = traverseDataStructure(propertyValue, bp, ip,
                rootIndex, pi, bean, count, indexed, strict);

            // Only convert if we can figure out the component type
            Class type = ai.array.getClass();
            if (convert && type != null && type.isArray() &&
                    type.getComponentType() != null) {
                value = bp.convertParameter(value, bean, type.getComponentType());
            }

            try {
                ObjectTools.setValueIntoCollection(ai.array,
                    pi.indices.get(ai.lastIndex), value);
            } catch (IllegalArgumentException iae) {
                throw new BeanException(iae.getMessage() + " for property " +
                    "named: " + pi.propertyName);
            }
        } else {
            if (indexed) {
                ip.setPropertyValue(bean, rootIndex, value, convert);
            } else {
                bp.setPropertyValue(bean, value, convert);
            }
        }
    }

    /**
     * <p>
     * This method traverse and optionally builds out the data structure given.
     * This can only build out if the data structure is at some point an array.
     * That point is the point directly before the construction point. For example:
     * </p>
     *
     * <p>
     * getList().get(0) instanceof Object[][] &&
     * ((Object[][]) getList().get(0))[0] == null
     * </p>
     *
     * <p>
     * In this case the object that is null is within an array and therefore we
     * can create the array and store it.
     * </p>
     *
     * <p>
     * One last thing to notice is that this method returns the Collection/array
     * directly before the last position (determined by the length of the indices
     * List). For example, if ds is a four dimensional array, this returns a
     * single dimensional array (ie Object[][][][] returns Object[] which could
     * be the value of array[0][1][2] if the indices are 0,1,2,3. The 3 index is
     * ignored)
     * </p>
     */
    private ArrayAndIndex traverseDataStructure(Object ds,
            final BeanProperty bp, final IndexedBeanProperty ip,
            final Object rootIndex, final JavaBeanTools.PropertyInfo pi,
            final Object bean, int startIndex, final boolean indexed,
            final boolean strict)
    throws BeanException {
        int stopIndex = pi.indices.size() - 1;
        Class<?> type = null;
        boolean create = (ds == null);
        boolean isNull = (ds == null);
        if (isNull) {
            type = bp.getPropertyType();
            if (!type.isArray()) {
                throw new BeanException("Unable to determine type to create for" +
                    " property named: " + pi.propertyName + ". Property type is " +
                    type.getName() + " and only properties whose type are arrays" +
                    " can be auto-generated.");
            }
        } else {
            Object subDS = ds;
            boolean inDS = ObjectTools.isDataStructure(ds);
            while (inDS && startIndex < stopIndex) {
                try {
                    subDS = ObjectTools.getValueFromCollection(ds,
                        pi.indices.get(startIndex));
                } catch (IllegalArgumentException iae) {
                    throw new BeanException(iae.getMessage() + " for property" +
                        " named: " + pi.propertyName);
                }

                inDS = ObjectTools.isDataStructure(subDS);
                if (inDS) {
                    ds = subDS;
                    startIndex++;
                }
            }

            if (subDS == null && ds.getClass().isArray()) {
                type = ds.getClass();
                create = true;
            }
        }

        if (create) {
            if (strict) {
                throw new BeanException("Null value encountered and strictness" +
                    " set for property named: " + pi.propertyName);
            }

            ObjectTools.ArrayInfo ai;
            try {
                ai = ObjectTools.createArray(type, pi.indices, startIndex);
            } catch (IllegalArgumentException iae) {
                throw new BeanException("Non-integer indices for property named: " +
                    pi.propertyName);
            }

            if (isNull) {
                if (indexed) {
                    ip.setPropertyValue(bean, rootIndex, ai.array, false);
                } else {
                    bp.setPropertyValue(bean, ai.array, false);
                }
            } else {
                try {
                    ObjectTools.setValueIntoCollection(ds, pi.indices.get(startIndex),
                        ai.array);
                } catch (IllegalArgumentException iae) {
                    throw new BeanException(iae.getMessage() + " for property " +
                        "named: " + pi.propertyName);
                }
            }

            ds = ai.array;
        }

        while (ObjectTools.isArray(ds) && startIndex < stopIndex) {
            Integer i = (Integer) pi.indices.get(startIndex);
            int index = i.intValue();
            Object subDS = Array.get(ds, index);
            if (ObjectTools.isArray(subDS)) {
                ds = subDS;
                startIndex++;
            }
        }

        ArrayAndIndex ai = new ArrayAndIndex();
        ai.array = ds;
        ai.lastIndex = startIndex;

        return ai;
    }

    private class ArrayAndIndex {
        Object array;
        int lastIndex;
    }
}