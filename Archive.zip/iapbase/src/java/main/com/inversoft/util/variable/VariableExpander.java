/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util.variable;

import java.util.ArrayList;
import java.util.List;

import com.inversoft.iap.Data;

/**
 * <p>
 * This class can be used to expand variables in a String.
 * The standardization of variables in Java and all but
 * been written down. Variables generally take the form:
 * </p>
 *
 * <pre>${variableName}</pre>
 *
 * <p>
 * However, how the variableName is translated into a String
 * value is determined by the application or the context.
 * This class simplifies this by allowing callers to pass
 * in the method of variable expansion using the {@link
 * ExpanderStrategy ExpanderStrategy} interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 1.0
 */
public final class VariableExpander {
    /**
     * The start of a variable String
     */
    public final static String START = "${";

    /**
     * The end of a variable String
     */
    public final static char END = '}';

    /**
     * <p>
     * Parses the given String and for each variable within the String calls the
     * expand method of the given {@link ExpanderStrategy ExpanderStrategy}. If
     * the strategy throws an exception, it is not caught and re-thrown but
     * simply allowed to be thrown through to the caller.
     * </p>
     *
     * <p>
     * If the strategy returns a null, the failure flag (failWhenNotFound) determines
     * whether or not the expander throws an exception or not. If the flag is true,
     * an exception is thrown. If the flag is false, the variables are replaced by the
     * the original variable name in the returned String.
     * </p>
     *
     * @param   str The String to expand the variables in.
     * @param   strategy The ExpanderStrategy to use for this expansion.
     * @param   failWhenNotFound A flag that determines if the variable expander fails when a variable
     *          is found by the strategy.
     * @return  The fully expanded String.
     * @throws  ExpanderException If the ExpanderStrategy throws an ExpanderException or if the
     *          strategy could not locate a variable and the failWhenNotFound flag is true.
     */
    public static String expand(String str, ExpanderStrategy strategy, boolean failWhenNotFound)
    throws ExpanderException {
        assert (strategy != null) : "strategy == null";

        if (str == null) {
            return null;
        }

        int startIndex = str.indexOf(START);
        int endIndex = -1;
        if (startIndex != -1) {
            endIndex = str.indexOf(END, startIndex + 2);
        }

        if (startIndex == -1 || endIndex == -1) {
            return str;
        }

        int length = str.length();
        int curPos = 0;
        String value;
        StringBuilder build = new StringBuilder(length);
        while (startIndex != -1 && endIndex != -1) {
            String variable = str.substring(startIndex + 2, endIndex);
            value = strategy.expand(variable);

            // If the variable in the view code cannot be expanded, then set the value back to the
            // variable unless the failure flag is set
            if (value == null && failWhenNotFound) {
                throw new ExpanderException("Variable is null [" + variable + "]");
            } else if (value == null) {
                value = START + variable + END;
            }

            build.append(str.substring(curPos, startIndex));
            build.append(value);

            curPos = endIndex + 1;

            startIndex = str.indexOf(START, curPos);
            if (startIndex != -1) {
                endIndex = str.indexOf(END, startIndex + 2);
            }
        }

        if (curPos < length) {
            build.append(str.substring(curPos));
        }

        return build.toString();
    }

    /**
     * <p>
     * Parses the given String and for each variable within the String calls the
     * expand method of the given {@link ExpanderStrategy ExpanderStrategy}. If
     * the strategy throws an exception, it is not caught and re-thrown but
     * simply allowed to be thrown through to the caller.
     * </p>
     *
     * <p>
     * If the strategy returns a null, the expander throws an exception.
     * </p>
     *
     * @param   str The String to expand the variables in.
     * @param   strategy The ExpanderStrategy to use for this expansion.
     * @return  The fully expanded String.
     * @throws  ExpanderException If the ExpanderStrategy throws an ExpanderException or if the
     *          strategy could not locate a variable.
     */
    public static String expand(String str, ExpanderStrategy strategy)
    throws ExpanderException {
        return expand(str, strategy, true);
    }

    /**
     * <p>
     * Parses the given StringBuilder and for each variable within the String calls
     * the expand method of the given {@link ExpanderStrategy ExpanderStrategy}.
     * If the strategy throws an exception, it is not caught and re-thrown but
     * simply allowed to be thrown through to the caller.
     * </p>
     *
     * <p>
     * If nulls are returned from the ExpanderStrategy, an exception is thrown.
     * </p>
     *
     * <p>
     * This method does not affect the contents of the StringBuilder passed in.
     * It makes a duplicate locally
     * </p>
     *
     * @param   build The StringBuilder to expand the variables in
     * @param   strategy The ExpanderStrategy to use for this expansion
     * @return  The fully expanded String
     * @throws  ExpanderException If the ExpanderStrategy throws an ExpanderException or a variable
     *          is returned as null from the ExpanderStrategy
     */
    public static String expand(StringBuilder build, ExpanderStrategy strategy)
    throws ExpanderException {
        return expand(build.toString(), strategy, true);
    }

    /**
     * <p>
     * Parses the given String locates all the variable in the string and returns them in a
     * list.
     * </p>
     *
     * @param   str The String to expand the variables in
     * @return  The list of variables.
     */
    public static List<String> findVariables(String str) {
        if (str == null) {
            return null;
        }

        int startIndex = str.indexOf(START);
        int endIndex = -1;
        if (startIndex != -1) {
            endIndex = str.indexOf(END, startIndex + 2);
        }

        if (startIndex == -1 || endIndex == -1) {
            return null;
        }

        int curPos = 0;
        List<String> names = new ArrayList<String>();
        while (startIndex != -1 && endIndex != -1) {
            names.add(str.substring(startIndex + 2, endIndex));
            curPos = endIndex + 1;
            startIndex = str.indexOf(START, curPos);
            if (startIndex != -1) {
                endIndex = str.indexOf(END, startIndex + 2);
            }
        }

        return names;
    }
}