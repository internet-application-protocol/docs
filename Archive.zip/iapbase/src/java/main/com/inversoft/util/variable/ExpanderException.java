/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util.variable;

/**
 * This class is the exception that is thrown from an
 * expansion operation when an ExpanderStrategy encounters
 * an error while attempting to expand a variable.
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 1.0
 */
public class ExpanderException extends Exception {

    /**
     * Constructs a new empty <code>ExpanderException</code>
     */
    public ExpanderException() {
        super();
    }

    /**
     * Constructs a new <code>ExpanderException</code> with the given error
     * message.
     *
     * @param   message The error message for the exception
     */
    public ExpanderException(String message) {
        super(message);
    }

    /**
     * Constructs a new <code>ExpanderException</code> with the given error
     * message and root cause
     *
     * @param   message The error message for the exception
     * @param   cause The root cause throwable
     */
    public ExpanderException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new <code>ExpanderException</code> with the given error
     * root cause
     *
     * @param   cause The root cause throwable
     */
    public ExpanderException(Throwable cause) {
        super(cause);
    }
}