/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.util;

import java.io.File;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.xml.sax.InputSource;

/**
 * <p>
 * This class is a toolkit that helps in translating between
 * XML and transport objects and vice versa using JAXB. The
 * transport objects must be JAXB binding objects compiled using
 * XJC.
 * </p>
 *
 * TODO Change the JAXBContext to be DI'd rather than statically initialized
 *
 * @author Brian Pontarelli
 * @since IAP 1.0
 * @version 1.0
 */
public class JAXBTools {
    private static final Map<Class<?>, JAXBContext> contexts = new HashMap<Class<?>, JAXBContext>();

    /**
     * This must be called statically prior to use. It must also be called such that all the contexts
     * that could be used in a JVM are added before any other methods on this class are called. THis
     * is because the Map that they are stored in is not synchronized.
     *
     * @param   objectFactory The ObjectFactory class to create a JAXBContext for.
     * @throws JAXBException If the context could not be created.
     */
    public static void addObjectFactory(Class<?> objectFactory) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(objectFactory);
        contexts.put(objectFactory, context);
    }

    /**
     * Marshals the JAXB transport object into an XML String.
     *
     * @param   transport The transport to marshal.
     * @param   schema The schema location to output into the generated XML.
     * @param   objectFactory The object factory class to pass to the marshaller.
     * @return The marshalled String.
     */
    public static String marshal(Object transport, String schema, Class<?> objectFactory) {
        StringWriter writer;
        try {
            JAXBContext context = getContext(objectFactory);
            Marshaller marshaller = context.createMarshaller();
            if (schema != null) {
                marshaller.setProperty(Marshaller.JAXB_NO_NAMESPACE_SCHEMA_LOCATION, schema);
            }

            writer = new StringWriter();
            marshaller.marshal(transport, writer);
        } catch (JAXBException e) {
            throw new IllegalStateException("Unable to marshal object", e);
        }

        return writer.toString().trim();
    }

    /**
     * Unmarshals the given XML into a Transport object.
     *
     * @param   xml The xml to unmarshal.
     * @param   objectFactory The object factory class to pass to the marshaller.
     * @return The transport object.
     */
    public static Object unmarshal(String xml, Class<?> objectFactory) {
        try {
            JAXBContext context = getContext(objectFactory);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            StringReader reader = new StringReader(xml);
            return unmarshaller.unmarshal(new InputSource(reader));
        } catch (JAXBException e) {
            throw new IllegalStateException("Unable to unmarshal xml", e);
        }
    }

    /**
     * Unmarshals the given XML InputStream into a Transport object.
     *
     * @param   inputStream The InputStream to read the XML to unmarshal.
     * @param   objectFactory The object factory class to pass to the marshaller.
     * @return The transport object.
     */
    public static Object unmarshal(InputStream inputStream, Class<?> objectFactory) {
        try {
            JAXBContext context = getContext(objectFactory);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            //MyInputStream mis = new MyInputStream(inputStream);
            //XMLStreamReader reader = XMLInputFactory.newInstance().createXMLStreamReader(mis);
            return unmarshaller.unmarshal(inputStream);
        } catch (JAXBException e) {
            throw new IllegalStateException("Unable to unmarshal xml", e);
        }
    }

    /**
     * Unmarshals the given XML into a Transport object.
     *
     * @param   xml The xml to unmarshal.
     * @param   objectFactory The object factory class to pass to the marshaller.
     * @return The transport object.
     */
    public static Object unmarshal(File xml, Class<?> objectFactory) {
        try {
            JAXBContext context = getContext(objectFactory);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            return unmarshaller.unmarshal(xml);
        } catch (JAXBException e) {
            throw new IllegalStateException("Unable to unmarshal xml", e);
        }
    }

    /**
     * Returns the context from the map.
     *
     * @param   objectFactory The ObjectFactory Class instance that is used as a key into the map.
     * @return The JAXBContext or null if it was never added.
     */
    private static JAXBContext getContext(Class<?> objectFactory) {
        return contexts.get(objectFactory);
    }
}