/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util;


/**
 * This class is a generic reflection exception that is to
 * be used to wrap up any exceptions that are thrown from
 * the java.lang.Class methods and java.lang.reflect.Method
 * methods.
 *
 * @author  Brian Pontarelli
 */
public class ReflectionException extends RuntimeException {

    protected Throwable target;


    /**
     * Constructs a new empty reflection exception
     */
    public ReflectionException() {
    }

    /**
     * Constructs a new reflection exception with the given error message
     *
     * @param   msg The error message for this Exception
     */
    public ReflectionException(String msg) {
        super(msg);
    }

    /**
     * <p>
     * Constructs a new reflection exception with the given error message and
     * given root cause exception. The root cause exception is the exception
     * used in the new JDK 1.4 exception stack. The exceptions that are normally
     * used for the root cause are all the exceptions that occur when doing
     * reflective operations
     * </p>
     *
     * @param   msg The exceptions error message
     * @param   cause The root cause throwable
     */
    public ReflectionException(String msg, Throwable cause) {
        super(msg, cause);
    }

    /**
     * <p>
     * Constructs a new reflection exception with the given error message and
     * given root cause exception. The root cause exception is the exception
     * used in the new JDK 1.4 exception stack. The exceptions that are normally
     * used for the root cause are all the exceptions that occur when doing
     * reflective operations
     * </p>
     *
     * @param   cause The root cause throwable
     */
    public ReflectionException(Throwable cause) {
        super(cause);
    }

    /**
     * <p>
     * Constructs a new reflection exception with the given error message and
     * given root cause exception.
     * </p>
     *
     * <p>
     * The root cause exception is the exception used in the new JDK 1.4 exception
     * stack. The exceptions that are normally used for the root cause are all
     * the exceptions that occur when doing reflective operations.
     * </p>
     *
     * <p>
     * The second exception parameter is the target exception. This is the
     * exception that is thrown from method that is invoked using the the {@link
     * ReflectionTools#invokeMethod(java.lang.reflect.Method, Object, Object [])
     * invokeMethod()}. That is, if the method invoked threw any exception,
     * that exception would be contained here.
     * </p>
     *
     * <p>
     * See the javadoc for the invokeMethod method for more information.
     * </p>
     *
     * @param   msg The exceptions error message
     * @param   cause The root cause throwable
     * @param   target The target exception from the invocation (if applicable)
     */
    public ReflectionException(String msg, Throwable cause, Throwable target) {
        super(msg, cause);
        this.target = target;
    }

    /**
     * Returns the target exception which is any exception that was thrown when
     * a method was invoked using reflection.
     *
     * @return  The Exception that was thrown from a Method invocation
     */
    public Throwable getTarget() {
        return target;
    }

    /**
     * Returns the full string of the exception as described by Throwable.toString()
     * and also appends
     */
    public String toFullString() {
        StringBuffer buf = new StringBuffer();
        buf.append(super.toString());
        buf.append("\nTarget: ");
        buf.append(target);
        return buf.toString();
    }
}