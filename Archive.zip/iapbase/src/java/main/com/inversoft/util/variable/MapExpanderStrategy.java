/*
 * Copyright (c) 2005, Inversoft
 */
package com.inversoft.util.variable;

import java.util.Map;

import com.inversoft.util.StringTools;
import com.inversoft.iap.Data;
import com.inversoft.iap.DataType;

/**
 * This class is a property expander that uses a Map of {@link Data} object values where the map key
 * is the key of the Data
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 1.0
 */
public class MapExpanderStrategy implements ExpanderStrategy {
    Map<String, Data> map;

    public MapExpanderStrategy(Map<String, Data> map) {
        this.map = map;
    }

    /**
     * Expands the given variable using the values in the Map. If nothing is found then an
     * exception is thrown.
     *
     * @param   variableName The name of the System Property whose value to return.
     * @return  The value from the Map.
     * @since   1.0
     */
    public String expand(String variableName) {
        assert (!StringTools.isEmpty(variableName)) : "variableName is empty";
        Data data = map.get(variableName);
        String value = null;
        if (data.getArrayDepth() > 0) {
            value = parseArray(variableName, data.getValue());
        } else {
            value = data.getValue().toString();
        }

        return value;
    }

    /**
     * Parses the array index values from a variable name and returns the value associated
     * to the referened array
     *
     * todo implement extraction strategy
     *
     * @param variableName the variable name
     * @param array the array object
     */
    private String parseArray(String variableName,  Object array) {
        return "AN ARRAY";
    }
}