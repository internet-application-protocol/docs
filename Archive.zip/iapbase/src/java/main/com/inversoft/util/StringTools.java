/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util;


/**
 * This is a static toolkit class that provides common string
 * methods for comparison and manipulation
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 2.0
 */
public class StringTools {

    /**
     * Returns true if the string pass in is null or empty
     */
    public static boolean isEmpty(String str) {
        return (str == null || str.trim().length() == 0);
    }

    /**
     * Returns true if the string pass in is null or empty or trimmed and empty
     */
    public static boolean isUntrimmedEmpty(String str) {
        return (str == null || str.length() == 0);
    }

    /**
     * Returns true if the string is a valid boolean expression according to the
     * valueOf method on java.lang.Boolean, false otherwise
     */
    public static boolean isValidBoolean(String str) {
        return
            (str != null &&
                (str.equalsIgnoreCase(StringConstants.TRUE_STRING) ||
                 str.equalsIgnoreCase(StringConstants.FALSE_STRING))
             );
    }

    /**
     * Returns the value of the string or if the string is null, it returns an empty
     * String
     */
    public static String cleanString(String str) {
        return (str == null) ? "" : str;
    }

    /**
     * <p>
     * If the values given only contains a single element and this element is
     * an empty string, this normally means that the values should be null. What
     * happens is the since the HTML spec sucks really bad, it sends over empty
     * text boxes as empty Strings rather than not sending them over. The reason
     * this sucks is that every other input type, if unselected or empty, does
     * not get sent over, text boxes do.
     * </p>
     *
     * <p>
     * So, if the array given has one element and it is empty or null (not trimmed
     * empty), then this method returns null.
     * </p>
     *
     * @param   values The values to check for null
     * @return  Maybe null (see above)
     */
    public static String [] convertEmpty(String [] values) {
        if (values != null && values.length == 1 && StringTools.isEmpty(values[0])) {
            values = null;
        }

        return values;
    }

    /**
     * Converts the contents of the given array of bytes to a String hexidecimal
     * representations. Each character of the String is a single hex value. Therefore,
     * the the pair of characters equals a single byte. This method is little-endian
     * (I think).
     *
     * @param   bytes The bytes to convert
     * @return  A String representation of the hex
     */
    public static String toHex(int[] bytes) {
        int dataLength = (bytes.length * 2);
        StringBuffer buf = new StringBuffer(dataLength);
        for (int i = 0; i < bytes.length; i++) {
            if (bytes[i] < 0 || bytes[i] > 255) {
                throw new IllegalArgumentException("Invalid byte value " + bytes[i]);
            }

            if (bytes[i] >= 16) {
                buf.append(Integer.toHexString(bytes[i] / 16));
                buf.append(Integer.toHexString(bytes[i] - ((bytes[i] / 16) * 16)));
            } else {
                buf.append(Integer.toHexString(bytes[i]));
            }
        }

        return buf.toString();
    }

    /**
     * Converts the given character from a hexidecimal value to a byte, which will
     * be a value in the set {0, 15} inclusive. This means the character must be
     * in the hexidecimal set {'0', 'f'}
     *
     * @param   hexValue The hex value to convert
     * @return  A byte that is equal to the hex value
     */
    public static char toHex(byte hexValue) {
        if (hexValue < 0 || hexValue >= 16) {
            throw new IllegalArgumentException("Invalid hex value");
        }

        String str = Integer.toHexString(hexValue);
        if (str.length() > 1) {
            throw new IllegalStateException("JVM toHexString method incorrect");
        }

        return str.charAt(0);
    }

    /**
     * Converts the contents of the given String from hexidecimal to an array
     * of bytes. Each character of the String is a single hex value. Therefore,
     * the the pair of characters equals a single byte. This method is little-endian
     * (I think).
     *
     * @param   hexString The hex String to convert
     * @return  An array of bytes
     */
    public static byte[] fromHex(String hexString) {
        int length = hexString.length();

        if ((length & 0x01) != 0) {
            throw new IllegalArgumentException("odd number of characters.");
        }

        byte[] out = new byte[length >> 1];

        // two characters form the hex value.
        for (int i = 0, j = 0; j < length; i++) {
            int f = Character.digit(hexString.charAt(j++), 16) << 4;
            f = f | Character.digit(hexString.charAt(j++), 16);
            out[i] = (byte) (f & 0xFF);
        }

        return out;
    }

    /**
     * Converts the given character from a hexidecimal value to a byte, which will
     * be a value in the set {0, 15} inclusive. This means the character must be
     * in the hexidecimal set {'0', 'F'}
     *
     * @param   hexValue The hex value to convert
     * @return  A byte that is equal to the hex value
     */
    public static byte fromHex(char hexValue) {
        byte b = (byte) Character.digit(hexValue, 16);
        if (b == -1) {
            throw new IllegalArgumentException("Invalid hex character");
        }

        return b;
    }
}