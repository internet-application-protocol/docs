/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util.variable;

import com.inversoft.iap.Data;

/**
 * <p>
 * This interface is used to expand a single value within
 * a String. Variables have the form
 * </p>
 * 
 * <pre>${variableName}</pre>
 * <p>
 * This interface is called from the {@link VariableExpander
 * VariableExpander} class whenever a variable is encountered
 * within a String (or other input). The entire variable is
 * not passed in, instead only the variableName is passed to
 * this interface. This reduces the amount of work for the
 * interface to do and places this common logic in the main
 * class. 
 * </p>
 * 
 * <p>
 * The strategy implementations can handle a variable however
 * they deem necessary and return the result of the expansion
 * as a String. Common examples are System property expanders
 * where the variable name equates to a System property and 
 * the value of the System property is returned.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 1.0
 */
public interface ExpanderStrategy {
    /**
     * Expands the given variable name into the implementation specific String
     * value.
     *
     * @param   variableName The name of the variable to expand
     * @return  The expanded value of the variable
     * @throws  ExpanderException If there were any problems during the expansion
     * @since   1.0
     */
    String expand(String variableName) throws ExpanderException;
}
