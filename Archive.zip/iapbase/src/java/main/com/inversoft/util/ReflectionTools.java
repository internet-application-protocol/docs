/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


/**
 * This class is a toolkit to help in reflection. All
 * JavaBean related methods and toolkit methods can be found
 * in the com.bp.beans package
 *
 * @author  Brian Pontarelli
 */
public class ReflectionTools {

    /**
     * Convience method that returns class given the class name
     *
     * @param   className The name of the class (ie Foo)
     * @return  The Class object for the class if it is found
     * @throws  ReflectionException If the class name is invalid
     */
    public static Class findClass(String className) throws ReflectionException {
        return findClass(className, null);
    }

    /**
     * Convience method that returns class given the package name and className
     *
     * @param   className The name of the class (ie Foo)
     * @param   packageName (Optional) The name of the package (ie com.xor.util)
     * @return  The Class object for the class if it is found
     * @throws  ReflectionException If the class name is invalid
     */
    public static Class findClass(String className, String packageName)
    throws ReflectionException {

        assert (className != null) : "className == null";

        Class klass;
        try {
            if (StringTools.isEmpty(packageName)) {
                klass = Class.forName(className);
            } else {
                klass = Class.forName(packageName + "." + className);
            }
        } catch (ClassNotFoundException cnfe) {
            throw new ReflectionException("Class not found: " + cnfe.getMessage(),
                cnfe);
        }

        return klass;
    }

    /**
     * Returns the given class' method with the name method and the parameters
     * params. This is really just a convience method so that code doesn't have
     * to catch all five thousand exceptions that Java reflection throws and
     * make nifty error messages, this does all of that for you and throws a
     * single, simple exception instead
     *
     * @param   klass The class object to get the method from
     * @param   method The name of the method to fetch
     * @param   params The params to the method (can be null if the method does
     *          not take any parameters)
     * @return  The Method
     * @throws  ReflectionException If anything went wrong in the reflection,
     *          like wrong arguments to the method or invalid method name. This
     *          exception has a very good message body that tells exactly what
     *          the hell you screwed up
     */
    public static Method getMethod(Class klass, String method, Class [] params)
    throws ReflectionException {
        try {
            return klass.getMethod(method, params);
        } catch (NoSuchMethodException nsme) {
            throw new ReflectionException("No such method: " + nsme.getMessage(),
                nsme);
        } catch (SecurityException se) {
            StringBuffer error = new StringBuffer();
            error.append("Security violation accessing method ");
            error.append(klass.getName());
            error.append("#");
            error.append(method);
            error.append("(");
            for (int i = 0; params != null && i < params.length; i++) {
                error.append(params[i].getName());
            }
            error.append(")");
            throw new ReflectionException(error.toString(), se);
        }
    }

    /**
     * Gets all the methods for the given class and handles all the nasty exceptions
     * that Java reflection can throw. This throws a nice exception.
     *
     * @param   klass The class to get the methods from (only the public ones)
     * @return  The methods
     * @throws  ReflectionException If anything bad happened during reflection
     */
    public static Method [] getMethods(Class klass) throws ReflectionException {
        try {
            return klass.getMethods();
        } catch (SecurityException se) {
            StringBuffer error = new StringBuffer();
            error.append("Security violation getting methods of class: ");
            error.append(klass.getName());
            throw new ReflectionException(error.toString(), se);
        }
    }

    /**
     * Using the Class, method name and parameters, this method attempts to locate
     * a method in the given Class. If this method is not found, this method
     * uses the Class object in the params array at the indices given and mutates
     * the params array to contain the super-class or super-interface. What this
     * does is allows methods that declare a specific Class or any of its parents
     * to be located.
     * </p>
     *
     * <p>
     * An example of this would be a Class named Parent who has one child class
     * named Child. This method would resolve this method if it exists in the
     * Class:
     * </p>
     * <code>public void doSomething(Child child)</code>
     * <p>
     * Or this method if the above method does not exist
     * </p>
     * <code>public void doSomething(Parent parent)</code>
     * <p>
     * The resolution can also handle this case as long as indices is 1:
     * </p>
     * <code>public void doSomething(String name, Parent parent)</code>
     * <code>public void doSomething(String name, Child child)</code>
     *
     * <strong>This does nto currently work with interfaces</strong>
     *
     * @param   klass The class object to get the method from
     * @param   method The name of the method to fetch
     * @param   params The params to the method (can be null if the method does
     *          not take any parameters)
     * @param   index This is the indices within the params array that is used to
     *          search for the method using super-classes or super-interfaces.
     * @return  The Method or null if it could not be found
     */
    public static Method findMethod(Class klass, String method, Class [] params,
            int index) {
        Class [] localParams = new Class[params.length];
        System.arraycopy(params, 0, localParams, 0, params.length);

        Class type = localParams[index];
        Method methodObj = null;
        while (type != null) {
            localParams[index] = type;

            try {
                methodObj = klass.getMethod(method, localParams);
                break;
            } catch (NoSuchMethodException nsme) {
                // Smother and move to the next method attempt
                type = localParams[index].getSuperclass();
            } catch (SecurityException se) {
                // Smother and move to the next method attempt
                type = localParams[index].getSuperclass();
            }
        }

        return methodObj;
    }

    /**
     * Another convience method because invoking a reflected method is a really
     * pain in the butt. It can throw like five billion exceptions and really
     * make coding a lame experience. So, I've wrapped all those exceptions up
     * and thrown a nice exception of my own making called ReflectionException.
     * Although, for debugging purposes, this method will re-throw invocation
     * target exceptions of type Error and RuntimeException. For example,
     * NullPointerExceptions and OutOfMemoryError are not wrapped in a
     * ReflectionException. Instead they are re-thrown. All other invocation
     * target exceptions are unwrapped from the InvocationTargetException class
     * and re-wrapped into a new ReflectionException as the target property.
     *
     * @param   method The method to invoke
     * @param   object The object to invoke the method on
     * @param   params The params to the method
     * @return  The return value from the method
     * @throws  ReflectionException If any mishap occurred whilst Reflecting sire.
     *          All the exceptions that could be thrown whilst invoking will be
     *          wrapped inside the ReflectionException
     * @throws  RuntimeException If the target of the InvocationTargetException is
     *          a RuntimeException, in which case, it is re-thrown
     * @throws  Error If the target of the InvocationTargetException is an Error,
     *          in which case, it is re-thrown
     */
    public static Object invokeMethod(Method method, Object object, Object [] params)
    throws ReflectionException, RuntimeException, Error {
        try {
            return method.invoke(object, params);
        } catch (IllegalAccessException iae) {
            StringBuffer error = new StringBuffer();
            error.append("Access error for method: ");
            error.append(method.toString());
            throw new ReflectionException(error.toString(), iae);
        } catch (IllegalArgumentException iare) {
            StringBuffer error = new StringBuffer();
            error.append("Error while calling method: ").append(method.toString());
            throw new ReflectionException(error.toString(), iare);
        } catch (InvocationTargetException ite) {

            // Check if the target is a runtime or error and re-throw it
            Throwable target = ite.getTargetException();

            if (target instanceof RuntimeException) {
                throw (RuntimeException) target;
            }

            if (target instanceof Error) {
                throw (Error) target;
            }

            StringBuffer error = new StringBuffer();
            error.append("Method ");
            error.append(method.toString());
            error.append(" threw exception: ");
            error.append(target.toString());
            throw new ReflectionException(error.toString(), ite, target);
        }
    }

    /**
     * Yep, another convience method that instantiates an object from a class
     * and this is just like all the others and wraps the exceptions into one
     * nice exception.
     *
     * @param   objectClass The class to instantiate
     * @return  The new instance of the class
     * @throws  ReflectionException If you did something really dumb like put
     *          a security restriction on the class or tried to call a class
     *          that doesn't have a default constructor of something lame like
     *          that.
     */
    public static <T> T instantiate(Class<T> objectClass) throws ReflectionException {
        try {
            return objectClass.newInstance();
        } catch (InstantiationException ie) {
            throw new ReflectionException("Error instantiating " +
                objectClass.getName(), ie);
        } catch (IllegalAccessException iae) {
            throw new ReflectionException("Access violation instantiating " +
                objectClass.getName(), iae);
        } catch (SecurityException se) {
            throw new ReflectionException("Security violation instantiating " +
                objectClass.getName(), se);
        }
    }

    /**
     * A convience method so that a class can be instantiated by name stored in
     * a string without all the exceptions having to be caught. Instead a single
     * ReflectionException is caught and contains a descriptive message about the
     * error.
     *
     * @param   className The name of the class to instantiate
     * @return  The new instance of the class
     * @throws  ReflectionException if something went wrong during name lookup
     *          or instantiation
     */
    public static Object instantiate(String className) throws ReflectionException {
        try {
            return instantiate(Class.forName(className));
        } catch (ClassNotFoundException cnfe) {
            throw new ReflectionException("Class " + className +
                " not found in class path", cnfe);
        }
    }

    /**
     * Converts the type given to the correct wrapper class for that type. If
     * the type given is not a primitive type then null is returned. If the type
     * given is a wrapper class, then null is returned.
     *
     * @param   type The type of convert to its wrapper class
     * @return  The wrapper type for the type given or null
    */
    public static Class<?> convertToWrapper(Class<?> type) {

        if (!type.isPrimitive()) {
            return null;
        }

        Class<?> klass = null;
        if (type.equals(Boolean.TYPE)) {
            klass = Boolean.class;
        } else if (type.equals(Byte.TYPE)) {
            klass = Byte.class;
        } else if (type.equals(Character.TYPE)) {
            klass = Character.class;
        } else if (type.equals(Short.TYPE)) {
            klass = Short.class;
        } else if (type.equals(Integer.TYPE)) {
            klass = Integer.class;
        } else if (type.equals(Long.TYPE)) {
            klass = Long.class;
        } else if (type.equals(Float.TYPE)) {
            klass = Float.class;
        } else if (type.equals(Double.TYPE)) {
            klass = Double.class;
        }

        return klass;
    }
}
