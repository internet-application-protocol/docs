/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util;


/**
 * This interface holds values used in common string operations
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 2.0
 */
public interface StringConstants {

    /** The string constant for true */
    String TRUE_STRING = "true";

    /** The string constant for false */
    String FALSE_STRING = "false";
}
