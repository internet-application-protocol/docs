/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util;

import java.util.Enumeration;
import java.util.Iterator;


/**
 * <p>
 * This class is an adapter from an Iterator to an 
 * Enumeration.
 * </p>
 * 
 * @author  Brian Pontarelli
 */
public class IteratorEnumeration implements Enumeration {
    
    private Iterator iterator;
    

    /**
     * Creates a new <code>IteratorEnumeration</code>.
     * 
     * @param   iterator The iterator to adapt
     */
    public IteratorEnumeration(Iterator iterator) {
        this.iterator = iterator;
    }

    /**
     * Returns true if the adapted Iterator has more elements, false otherwise.
     */
    public boolean hasMoreElements() {
        return iterator.hasNext();
    }

    /**
     * Returns the next item in the adapted Iterator.
     */
    public Object nextElement() {
        return iterator.next();
    }
}