/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util;


import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * This class is a toolkit that contains methods that help
 * when dealing with objects. It is similar to the {@link
 * StringTools StringTools} class of this package.
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 2.0
 */
public class ObjectTools {

    /**
     * Converts the given Object cleanly to a String. If the Object is null, the
     * String is empty. Else, it returns the value of the toString method
     *
     * @param   obj The Object to convert to a String
     * @return  The String value and never null
     */
    public static String cleanToString(Object obj) {

        if (obj == null) {
            return "";
        }

        return obj.toString();
    }

    /**
     * Converts the given Object to a String. If the Object is null, the String
     * is null. Else, it returns the value of the toString method
     *
     * @param   obj The Object to convert to a String
     * @return  The String value or null if the object is null
     */
    public static String toString(Object obj) {
        return (obj == null) ? null : obj.toString();
    }

    /**
     * <p>
     * Compares the two objects for equality. This comparison is done at the reference
     * level and the object level. If either object is null and the other is not,
     * this method returns false. If both objects are null, this method returns true.
     * If both objects are not null, the result is determined as follows:
     * </p>
     *
     * <ul>
     * <li>If obj1 is a String {@link #areObjectsEqual(String, Object) areObjectsEqual(
     * String, Object)} is called with (obj1, obj2)</li>
     * <li>If obj2 is a String {@link #areObjectsEqual(String, Object) areObjectsEqual(
     * String, Object)} is called with (obj2, obj1)</li>
     * <li>If obj1 is an array and obj2 is not, obj1 is searched for an element that is
     * equal to obj2 using the equals method</li>
     * <li>If obj2 is an array and obj1 is not, obj2 is searched for an element that is
     * equal to obj1 using the equals method</li>
     * <li>If obj1 is an array and obj2 is an array, all the elements in the arrays must
     * be equal using the equals method</li>
     * <li>The above array rules are repeated for Collection objects</li>
     * <li>If one is an array and the other a collection, all the elements in the array
     * and the collection must be equal using the equals method</li>
     * <li>If they are both simple objects, they are compared using the equals method</li>
     * <li>It should also be noted that no matter what comparison is being done, null values
     * are checked for. For example, if they both are arrays, then if array1[2] == null
     * and array2[2] == null, then the array elements are considered equal</li>
     * </ul>
     *
     * @param   obj1 The first object to be compared
     * @param   obj2 The second object to be compared
     * @return  True if the two parameters are equal using the above criteria
     */
    public static boolean areObjectsEqual(Object obj1, Object obj2) {

        // If they are equal (like both null) return true
        if (obj1 == obj2) {
            return true;
        }

        // Since they are both not null, if one is, return false
        if (obj1 == null || obj2 == null) {
            return false;
        }

        // Forward handling to the other method if one is a string
        if (obj1 instanceof String) {
            return areObjectsEqual((String) obj1, obj2);
        } else if (obj2 instanceof String) {
            return areObjectsEqual((String) obj2, obj1);
        }

        boolean is1Array = obj1.getClass().isArray();
        boolean is2Array = obj2.getClass().isArray();
        boolean is1Collection = (obj1 instanceof Collection);
        boolean is2Collection = (obj2 instanceof Collection);

        if (is1Array && is2Array) {
            return Arrays.equals((Object []) obj1, (Object []) obj2);
        } else if (is1Array && is2Collection) {
            return Arrays.equals((Object []) obj1, ((Collection<?>) obj2).toArray());
        } else if (is2Array && is1Collection) {
            return Arrays.equals(((Collection<?>) obj1).toArray(), (Object []) obj2);
        } else if (is1Array) {
            return arrayContains((Object []) obj1, obj2);
        } else if (is2Array) {
            return arrayContains((Object []) obj2, obj1);
        } else if (is1Collection && is2Collection) {
            return ((Collection<?>) obj1).containsAll((Collection<?>) obj2 );
        } else if (is1Collection) {
            return ((Collection<?>) obj1).contains(obj2);
        } else if (is2Collection) {
            return ((Collection<?>) obj2).contains(obj1);
        }

        return obj1.equals(obj2);
    }

    /**
     * <p>
     * Compares the the String and the object for equality. This comparison is done
     * at the reference level and the object level. If either object is null and the
     * other is not, this method returns false. If both objects are null, this method
     * returns true. If both objects are not null, the result is determined as follows:
     * </p>
     *
     * <ul>
     * <li>If obj2 is an array, the array is checked for an element whose toString value
     * is equal to the String</li>
     * <li>If obj2 is a Collection, the Collection is checked for an element whose toString
     * value is equal to the String</li>
     * <li>If obj2 is a simple Object, it's toString value is compared to the String</li>
     * <li>It should also be noted that no matter what comparison is being done, null values
     * are checked for. For example, if obj2 is an array, then if obj2[2] == null
     * and String == null, then the object is considered equal</li>
     * </ul>
     *
     * @param   string The String to compare
     * @param   obj The object to compare
     * @return  True if the two parameters are equal using the above criteria
     */
    public static boolean areObjectsEqual(String string, Object obj) {

        if (string == obj) {
            return true;
        }

        if (string == null || obj == null) {
            return false;
        }

        if (obj instanceof Object []) {
            return arrayContainsString((Object []) obj, string);
        } else if (obj instanceof Collection) {
            return arrayContainsString(((Collection) obj).toArray(), string);
        }

        return string.equals(obj.toString());
    }

    /**
     * <p>
     * Determines whether the specified array contains the specified objcet. This
     * is done as follows:
     * </p>
     *
     * <ul>
     * <li>If the obj is a string, the {@link #arrayContainsString(Object[], String)
     * arrayContainsString(Object[], String)} method is called</li>
     * <li>Otherwise, each array position is compared to the object using the equals
     * method</li>
     * </ul>
     *
     * @param   array The array to search
     * @param   obj The object to search for
     * @return  True if the array contains the object, false otherwise
     */
    public static boolean arrayContains(Object [] array, Object obj) {

        if (array == obj) {
            return true;
        }

        if (array == null || obj == null) {
            return false;
        }

        if (obj instanceof String) {
            return arrayContainsString(array, (String) obj);
        }

        for (int i = 0; i < array.length; i++) {

            if (array[i] != null && areObjectsEqual(array[i], obj)) {
                return true;
            }
        }

        return false;
    }

    /**
     * <p>
     * Determines whether the specified array contains the specified String. This
     * is done as follows:
     * </p>
     *
     * <ul>
     * <li>Each array position is compared to the String by converting it to a String
     * using the toString method and then comparing it to the given String</li>
     * </ul>
     *
     * @param   array The array to search
     * @param   string The String to search for
     * @return  True if the array contains the String, false otherwise
     */
    public static boolean arrayContainsString(Object [] array, String string) {

        if (array == null && string == null) {
            return true;
        }

        if (array == null || string == null) {
            return false;
        }

        for (int i = 0; i < array.length; i++) {

            if (array[i] != null && string.equals(array[i].toString())) {
                return true;
            }
        }

        return false;
    }

    /**
     * Given the array of primitive types given, this wraps each object and
     * returns them in an array of Number objects.
     *
     * @param   array The array of primitive types
     * @return  An array of Number objects or null
     */
    public static Number[] wrapArray(Object array) {
        Number[] numbers = null;
        if (array instanceof byte[]) {
            byte[] bytes = (byte[]) array;
            numbers = new Byte[bytes.length];
            for (int i = 0; i < bytes.length; i++) {
                numbers[i] = new Byte(bytes[i]);
            }
        } else if (array instanceof double[]) {
            double[] doubles = (double[]) array;
            numbers = new Double[doubles.length];
            for (int i = 0; i < doubles.length; i++) {
                numbers[i] = new Double(doubles[i]);
            }
        } else if (array instanceof float[]) {
            float[] floats = (float[]) array;
            numbers = new Float[floats.length];
            for (int i = 0; i < floats.length; i++) {
                numbers[i] = new Float(floats[i]);
            }
        } else if (array instanceof int[]) {
            int[] ints = (int[]) array;
            numbers = new Integer[ints.length];
            for (int i = 0; i < ints.length; i++) {
                numbers[i] = new Integer(ints[i]);
            }
        } else if (array instanceof long[]) {
            long[] longs = (long[]) array;
            numbers = new Long[longs.length];
            for (int i = 0; i < longs.length; i++) {
                numbers[i] = new Long(longs[i]);
            }
        } else if (array instanceof short[]) {
            short[] shorts = (short[]) array;
            numbers = new Short[shorts.length];
            for (int i = 0; i < shorts.length; i++) {
                numbers[i] = new Short(shorts[i]);
            }
        }

        return numbers;
    }

    /**
     * Given the wrapper types given, this unwraps each object into a primitive array and returns that
     * array.
     *
     * @param   array The array of wrapper types
     * @return  An array of primitive values or null
     */
    public static Object unwrapArray(Number[] array) {
        Object primitiveArray = null;
        if (array instanceof Byte[]) {
            byte[] numbers = new byte[array.length];
            for (int i = 0; i < array.length; i++) {
                numbers[i] = array[i].byteValue();
            }
            primitiveArray = numbers;
        } else if (array instanceof Double[]) {
            double[] numbers = new double[array.length];
            for (int i = 0; i < array.length; i++) {
                numbers[i] = array[i].doubleValue();
            }
            primitiveArray = numbers;
        } else if (array instanceof Float[]) {
            float[] numbers = new float[array.length];
            for (int i = 0; i < array.length; i++) {
                numbers[i] = array[i].floatValue();
            }
            primitiveArray = numbers;
        } else if (array instanceof Integer[]) {
            int[] numbers = new int[array.length];
            for (int i = 0; i < array.length; i++) {
                numbers[i] = array[i].intValue();
            }
            primitiveArray = numbers;
        } else if (array instanceof Long[]) {
            long[] numbers = new long[array.length];
            for (int i = 0; i < array.length; i++) {
                numbers[i] = array[i].longValue();
            }
            primitiveArray = numbers;
        } else if (array instanceof Short[]) {
            short[] numbers = new short[array.length];
            for (int i = 0; i < array.length; i++) {
                numbers[i] = array[i].shortValue();
            }
            primitiveArray = numbers;
        }

        return primitiveArray;
    }

    /**
     * Given the wrapper types given, this unwraps each object into a primitive array and returns that
     * array.
     *
     * @param   array The array of wrapper types
     * @return  An array of primitive values or null
     */
    public static char[] unwrapArray(Character[] array) {
        char[] numbers = new char[array.length];
        for (int i = 0; i < array.length; i++) {
            numbers[i] = array[i].charValue();
        }
        return numbers;
    }

    /**
     * Using the data structure (ie Collection or Map instance) and key given,
     * this retrieves the value from the data structure and returns it. If the
     * data structure is a Map, this uses the key as is. Otherwise this verifies
     * that the key is an Integer and then uses the intValue of that for the indices
     * into the List, Collection or array.
     *
     * @param   dataStructure The data structure instance to retrieve the value from
     * @param   key The indices/key to use to retrieve the value
     * @return  The value or null
     * @throws  IllegalArgumentException If the key is the wrong type for the
     *          Collection type or the dataStructure is not a List, Map,
     *          Collection or array
     * @throws  IndexOutOfBoundsException If the dataStructure is a List, Collection
     *          or an array and the index value is out of bounds
     */
    public static Object getValueFromCollection(final Object dataStructure,
            final Object key) {
        Object value = null;

        // Figure out what type the property is and handle it accordingly
        if (dataStructure instanceof Map) {
            value = ((Map<?,?>) dataStructure).get(key);
        } else {
            Class type = dataStructure.getClass();
            boolean isList = (List.class.isAssignableFrom(type));
            boolean isCollection = (Collection.class.isAssignableFrom(type));
            boolean isArray = (type.isArray());

            if (!isList && !isArray && !isCollection) {
                throw new IllegalArgumentException("Invalid data structure type: " +
                    type.getName());
            }

            int index = -1;
            try {
                index = ((Integer) key).intValue();
            } catch (ClassCastException cce) {
                throw new IllegalArgumentException("Invalid indices/key: " + key +
                    " for data strucutre of type " + type.getName());
            }

            if (isList) {
                value = ((List) dataStructure).get(index);
            } else if (isCollection) {

                // Iterator over the collection and retrieve the value
                Iterator iter = ((Collection) dataStructure).iterator();
                for (int i = 0; i < index && iter.hasNext(); i++) {
                    iter.next();
                }

                if (iter.hasNext()) {
                    value = iter.next();
                } else {
                    throw new IndexOutOfBoundsException("Index of out bounds: " +
                        index);
                }
            } else if (isArray) {
                value = ((Object[]) dataStructure)[index];
            }
        }

        return value;
    }

    /**
     * Sets the given value into the given array at the given index. This handles
     * primitive arrays by assuming that the value given is a wrapper object and
     * unwraps it.
     *
     * @param   array The array to set into
     * @param   index The index to set the value at
     * @param   value The value to set (possibly wrapped primitive but could be
     *          an Object as well)
     */
    public static void setIntoArray(Object array, int index, Object value) {
        Class type = array.getClass();
        if (!type.isArray()) {
            throw new IllegalArgumentException("Type not an array: " +
                type.getName());
        }

        Class compType = type.getComponentType();
        if (compType == Boolean.TYPE) {
            ((boolean[]) array)[index] = (Boolean) value;
        } else if (compType == Byte.TYPE) {
            ((byte[]) array)[index] = (Byte) value;
        } else if (compType == Character.TYPE) {
            ((char[]) array)[index] = (Character) value;
        } else if (compType == Double.TYPE) {
            ((double[]) array)[index] = (Double) value;
        } else if (compType == Float.TYPE) {
            ((float[]) array)[index] = (Float) value;
        } else if (compType == Integer.TYPE) {
            ((int[]) array)[index] = (Integer) value;
        } else if (compType == Long.TYPE) {
            ((long[]) array)[index] = (Long) value;
        } else if (compType == Short.TYPE) {
            ((short[]) array)[index] = (Short) value;
        } else {
            ((Object[]) array)[index] = value;
        }
    }

    /**
     * Using the data structure (ie Collection, Map or arary instance) and key
     * given, this sets the value given into the data structure. If the data
     * structure is a Map, this uses the key as is. Otherwise this verifies that
     * the key is an Integer and uses the intValue of that as the indices to set
     * into the List, or array. If this is a Collection, an exception is thrown.
     *
     * @param   dataStructure The data structure instance to retrieve the value
     *          from
     * @param   key The indices/key to use to retrieve the value
     * @param   value The value to set into the data structure
     * @throws  IllegalArgumentException If the type is Collection or if the key
     *          is the incorrect type or the data structure is not a valid data
     *          structure
     */
    public static void setValueIntoCollection(final Object dataStructure,
            final Object key, final Object value) {

        // Figure out what type the property is and handle it accordingly
        if (dataStructure instanceof Map) {
            ((Map<Object, Object>) dataStructure).put(key, value);
        } else {
            Class type = dataStructure.getClass();
            boolean isList = (List.class.isAssignableFrom(type));
            boolean isCollection = (Collection.class.isAssignableFrom(type));
            boolean isArray = (type.isArray());

            if (!isList && !isArray && !isCollection) {
                throw new IllegalArgumentException("Invalid data structure type: " +
                    type.getName());
            }

            int index = -1;
            if (key instanceof Integer) {
                index = ((Integer) key).intValue();
            } else {
                throw new IllegalArgumentException("Invalid indices/key: " + key +
                    " for data strucutre of type " + type.getName());
            }

            if (List.class.isAssignableFrom(type)) {
                ((List<Object>) dataStructure).set(index, value);
            } else if (Collection.class.isAssignableFrom(type)) {
                throw new IllegalArgumentException("You can not set a property " +
                    "of type Collection using an indices. Use a List instead");
            } else if (type.isArray()) {
                ObjectTools.setIntoArray(dataStructure, index, value);
            }
        }
    }

    /**
     * Determines if the type given is a Collection or Map.
     *
     * @param   type Class type to check
     * @return  True if the Class is assignable to Collection or Map
     */
    public static boolean isCollection(Class type) {
        return (Map.class.isAssignableFrom(type) ||
            Collection.class.isAssignableFrom(type));
    }

    /**
     * Determines if the type of the given bean is a Collection or Map.
     *
     * @param   object The Object whose Class to check
     * @return  True if the Class is assignable to Collection or Map
     */
    public static boolean isCollection(Object object) {
        if (object == null) {
            return false;
        }

        Class type = object.getClass();
        return (Map.class.isAssignableFrom(type) ||
            Collection.class.isAssignableFrom(type));
    }

    /**
     * Determines if the type of the given bean is an array.
     *
     * @param   object The Object whose Class to check
     * @return  True if the Class is assignable to an array
     */
    public static boolean isArray(Object object) {
        if (object == null) {
            return false;
        }

        Class type = object.getClass();
        return type.isArray();
    }

    /**
     * Determines if the type of the given bean is a Collection, Map or array,
     * effectively a data structure of some kind.
     *
     * @param   object The Object whose Class to check
     * @return  True if the Class is assignable to Collection or Map or an array
     */
    public static boolean isDataStructure(Object object) {
        if (object == null) {
            return false;
        }

        Class type = object.getClass();
        return (type.isArray() || isCollection(type));
    }

    /**
     * Creates an array instance that is the same as the type given. This means
     * that the type given should be an array (ie Collection[][][]). This uses
     * the List given to retrieve the dimensions of the array. The List given
     * contains the indices that may be later used to set the array and therefore
     * 1 is added to each value. If the type given is not as deep of an array as
     * the List has indices, the array is created as deep as the indicies allow
     * and the boolean flag inside the ArrayInfo struct called
     * {@link ArrayInfo#complete complete} will be false. Likewise, if the List
     * of indices is too large, the array is created and the complete flag is
     * also false. The only case where the flag is true is when the depth of the
     * array, the size of the indices list (minus start) are equal. i.e.<br/>
     * <code>(depth of type) == (indices.size() - start)</code><br/>.
     *
     * @param   type The type to create
     * @param   indices The list of indices to use
     * @param   start The place in the list to start
     * @return  A new ArrayInfo and never null. Failure is marked by the complete
     *          flag inside being false.
     * @throws  IllegalArgumentException If any of the indices in the List are
     *          not Integer objects
     */
    public static ArrayInfo createArray(final Class type, final List indices,
            final int start) {
        int size = indices.size();
        int[] dims = new int[indices.size() - start];
        ArrayInfo ai = new ArrayInfo();
        ai.type = type;

        int indexToUse = start;
        int dimsIndex = 0;
        Integer index;
        while (ai.type.isArray() && indexToUse != size) {
            try {
                index = (Integer) indices.get(indexToUse);
            } catch (ClassCastException cce) {
                throw new IllegalArgumentException("Invalid index: " + cce);
            }

            dims[dimsIndex] = index.intValue() + 1;
            ai.type = ai.type.getComponentType();
            dimsIndex++;
            indexToUse++;
        }

        // This sucks, but we need to check and possibly copy the dims array in
        // case we created it too long
        if (dimsIndex != dims.length) {
            int[] oldDims = dims;
            dims = new int[dimsIndex];
            System.arraycopy(oldDims, 0, dims, 0, dims.length);
        }

        ai.complete = (indexToUse == size && !ai.type.isArray());
        ai.array = Array.newInstance(ai.type, dims);
        return ai;
    }

    /**
     * Determines if the given type is a primitive or a wrapper class type.
     *
     * @param   type The type to check.
     * @return  True if the type is a primitive or a wrapper class type.
     */
    public static boolean isPrimitiveOrWrapper(Class<?> type) {
        return type.isPrimitive() || type.equals(Number.class) ||
            type.equals(Boolean.class) || type.equals(Character.class);
    }

    /**
     * A struct with information about arrays
     */
    public static class ArrayInfo {

        /**
         * The base type of the array. This should always return false for calls
         * to isArray()
         */
        public Class type;

        /**
         * The array itself
         */
        public Object array;

        /**
         * Denotes that the array create was not a complete array
         */
        public boolean complete;
    }
}