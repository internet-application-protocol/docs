/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


/**
 * This is a simple utility class that helps other class
 * find files relative to the class path.
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 2.0
 */
public class FileTools {

    /**
     * Returns the system-dependent version of the given file or path. This is
     * done by converting all the slash characters to the correct slash for the
     * current operating system
     *
     * @param   path The path to convert to the current operating system
     * @return  The converted path
     */
    public static String convertPath(String path) {

        String newPath;
        if (File.separatorChar == '\\') {
            newPath = path.replace('/', '\\');
        } else {
            newPath = path.replace('\\', '/');
        }

        return newPath;
    }

    /**
     * Copies the given from files contents to the given to file. This is done
     * in 1024 byte chucks. If the to file exists and has content, it is deleted
     * and replaced with the contents of the from file.
     *
     * @param   from The from File
     * @param   to The to File
     * @throws  IOException If there was a problem during the copy
     */
    public static void copy(File from, File to) throws IOException {

        // Delete the to file if it exists
        if (to.exists()) {
            to.delete();
        }

        FileReader reader = new FileReader(from);
        BufferedReader br = new BufferedReader(reader);
        FileWriter writer = new FileWriter(to);
        BufferedWriter bw = new BufferedWriter(writer);

        char [] buf = new char[1024];
        int count = 0;
        do {
            count = br.read(buf, 0, 1024);
            if (count != -1) {
                bw.write(buf, 0, count);
            }
        } while (count != -1 && count == 1024);

        bw.close();
        br.close();
        writer.close();
        reader.close();
    }

    /**
     * Used to retrieve the file extension of a particular file on disk.
     * If the file is a directory, doesn't exist, or doesn't contain an
     * extension delimited by a '.' then it will return null
     *
     * @param file the file to extract the file extension from
     * @return the file extension.  Returns null if the file parameter is
     * a directory or the file has no distinguishable extension
     */
    public static String getFileExtension(File file) {
        String fileExt = null;
        if (file.isFile()) {
            String[] splitFile = file.getName().split("\\.");
            fileExt = splitFile[splitFile.length - 1];
        }
        return fileExt;
    }

    /**
     * Deletes a directory and recursively deletes any and all files and
     * directories that are children of that directory (rm -rf)
     *
     * @param dir the root directory of the hierarchy to delete
     */
    public static void delTree(File dir) {
        // make sure it's a directory
        if (dir.isDirectory()) {
            // get all the files within that directory
            File[] files = dir.listFiles();
            // iterate on all the files and/or directories within this dir
            for (File file : files) {
                // if it's a file, delete it
                if (file.isFile()) {
                    file.delete();
                }
                // if it's a directory, the recurse into it and rinse repeat
                else if (file.isDirectory()) {
                    delTree(file);
                }
            }
            dir.delete();
        }
    }
}