/*
 * Copyright (c) 2003, Inversoft
 *
 * This software is distribuable under the GNU Lesser General Public License.
 * For more information visit gnu.org.
 */
package com.inversoft.util.variable;

import com.inversoft.util.StringTools;

/**
 * This class is the System property implementation of
 * the ExpanderStrategy interface. This expands the 
 * variable name into the value of a System property with
 * the same name.
 *
 * @author  Brian Pontarelli
 * @since   1.0
 * @version 1.0
 */
public class SystemPropertyExpanderStrategy implements ExpanderStrategy {
    /**
     * Expands the given variable into the value of the System property with
     * the same, name. If there is no system property with the given name, then 
     * an ExpanderException is thrown
     *
     * @param   variableName The name of the System Property whose value to return.
     * @return  The value of the System property with the name given.
     * @since   1.0
     */
    public String expand(String variableName) {
        assert (!StringTools.isEmpty(variableName)) : "variableName is empty";
        return System.getProperty(variableName);
    }
}