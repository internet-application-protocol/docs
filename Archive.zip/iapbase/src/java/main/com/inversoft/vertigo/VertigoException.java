/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.vertigo;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class VertigoException extends Exception {

    public VertigoException() {
        super();
    }

    public VertigoException(String message) {
        super(message);
    }

    public VertigoException(String message, Throwable cause) {
        super(message, cause);
    }

    public VertigoException(Throwable cause) {
        super(cause);
    }
}
