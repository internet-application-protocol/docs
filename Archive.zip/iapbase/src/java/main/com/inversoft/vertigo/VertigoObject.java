/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.vertigo;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

import com.inversoft.util.ReflectionTools;

/**
 * Represents all Objects contained within the Inversion of Control {@link VertigoContainer}
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class VertigoObject<C> {
    public static final String NO_MATCH_MSG = "No constructor defined that matches the parameter list specified";

    private Class<C> theClass;

    private Constructor theConstructor;

    private Object[] theParams;

    private Class<?>[] theParamTypes;

    public VertigoObject(Class<C> theClass, Object... params) throws VertigoException {
        this.theClass = theClass;
        this.theParams = params;
        setParamTypes();
        setConstructor();
    }

    /**
     * Populate the theParamTypes Class[] array
     */
    private void setParamTypes() {
        List<Class> paramTypeList = new ArrayList<Class>();
        for (Object param : theParams) {
            paramTypeList.add(param.getClass());
        }
        if (!paramTypeList.isEmpty()) {
            this.theParamTypes = paramTypeList.toArray(new Class[theParams.length]);
        }
    }

    /**
     * Sets the Constructor for this instance
     *
     * @throws VertigoException if there is a problem setting the theConstructor
     */
    private void setConstructor() throws VertigoException {
        try {
            // this works only if all the param types are Objects
            theConstructor = theClass.getConstructor(theParamTypes);
        } catch (NoSuchMethodException nsme) {
            // if NoSuchMethodException is thrown, then check for constructors
            // that have arrays and/or primatives as parameters
            Constructor[] constructors = theClass.getConstructors();
            int theClassConstructorParamCount = theParams.length;
            // iterate through all the class constructors
            for (Constructor constructor : constructors) {
                Class<?>[] parameterTypes = constructor.getParameterTypes();
                int aClassConstructorParamCount = parameterTypes.length;
                // if the theConstructor parameter count equals theParams count then verify that all the
                // class types within theConstructor parameter listing matches those in theParams
                if (aClassConstructorParamCount == theClassConstructorParamCount) {
                    if (aClassConstructorParamCount == 0 && theClassConstructorParamCount == 0) {
                        this.theConstructor = constructor;
                    } else {
                        boolean isMatch = false;
                        for (int i = 0; i < constructor.getParameterTypes().length; i++) {
                            Class<?> aClassParameterType = parameterTypes[i];
                            Class<?> theClassParameterType = theParamTypes[i];
                            if (aClassParameterType.isPrimitive()) {
                                aClassParameterType = ReflectionTools.convertToWrapper(aClassParameterType);
                            }

                            if (aClassParameterType.isAssignableFrom(theClassParameterType)) {
                                isMatch = true;
                            } else {
                                isMatch = false;
                                break;
                            }
                        }
                        if (isMatch) {
                            this.theConstructor = constructor;
                            break;
                        }
                    }
                }
                if (this.theConstructor != null) {
                    break;
                }
            }
        }
        if (theConstructor == null) {
            throw new VertigoException(NO_MATCH_MSG);
        }
    }

    /**
     * Returns the class for this instance
     *
     * @return the class
     */
    public Class<C> getTheClass() {
        return theClass;
    }

    /**
     * Returns the theConstructor for this instance
     *
     * @return the theConstructor
     */
    public Constructor getTheConstructor() {
        return theConstructor;
    }

    public Object[] getTheParams() {
        return theParams;
    }

    /**
     * Returns a Class array of the parameter types contained in the parameter list
     *
     * @return class array of parameter types
     */
    public Class<?>[] getTheParamTypes() {
        return theParamTypes;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof VertigoObject)) {
            return false;
        }

        final VertigoObject vertigoObject = (VertigoObject) o;

        if (theClass != null ? !theClass.equals(vertigoObject.theClass) : vertigoObject.theClass != null) {
            return false;
        }

        return true;
    }

    public int hashCode() {
        return (theClass != null ? theClass.hashCode() : 0);
    }
}
