/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.vertigo;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

/**
 * IoC Container that uses Constructor Injection via {@link VertigoObject}s
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class VertigoContainer {

    /**
     * Map containing VertigoObjects and their associated class instances
     */
    private Map<VertigoObject<?>, Object> classes = new HashMap<VertigoObject<?>, Object>();

    /**
     * VarArgs constructor
     *
     * @param vertigoObjects
     */
    public VertigoContainer(VertigoObject<?>... vertigoObjects) {
        register(vertigoObjects, false);
    }

    /**
     * Registers a single VertigoObject.  Can be used to instantiate the VertigoObject's associated class
     * Registration does not necessarily infer instantiation.  Objects will only get instantiated on registration
     * if the instantiate boolean is true.
     *
     * @param vertigoObject The VertigoObject to register
     * @param instantiateClass true if instantiation is desired, false otherwise
     */
    public void register(VertigoObject<?> vertigoObject, boolean instantiateClass) {
        if (instantiateClass) {
            classes.put(vertigoObject, instantiate(vertigoObject));
        } else {
            classes.put(vertigoObject, null);
        }

    }

    /**
     * Registers an array of VertigoObjects.  Can be used to instantiate the the associated VertigoObject's classes.
     * Registration does not necessarily infer instantiation.  Objects will only get instantiated on registration
     * if the instantiate boolean is true.
     *
     * @param vertigoObjects The VertigoObjects to instantiate
     * @param instantiate true if instantiation is desired, false otherwise
     */
    public void register(VertigoObject<?>[] vertigoObjects, boolean instantiate) {
        for (VertigoObject<?> vertigoObject : vertigoObjects) {
            register(vertigoObject, instantiate);
        }
    }

    /**
     * Returns the instance of the desired class.  VertigoException will be thrown If the class's
     * associated VertigoObject has not yet been registered
     *
     * @param aClass the class to retrieve the instance of
     * @return instance of the class
     */
    public <C> C get(Class<C> aClass) {
        C instance = null;
        VertigoObject<?> vertigoObject = getVertigoObject(aClass);
        if (vertigoObject != null) {
            instance = (C) classes.get(vertigoObject);
        }

        if (instance == null) {
            instance = (C) instantiate(aClass);
        }

        return instance;
    }

    /**
     * True if and only if the class has been registered.  Registration does not infer instantiation
     *
     * @param aClass
     * @return
     */
    public boolean contains(Class<?> aClass) {
        return (getVertigoObject(aClass) == null) ? false : true;
    }

    /**
     * Used to retrieve a VertigoObject from the classes map.  Will return null if the VertigoObject doesn't exist
     *
     * @param aClass The class defined in the VertigoObject
     * @return VertigoObject
     */
    private VertigoObject<?> getVertigoObject(Class<?> aClass) {
        VertigoObject<?> object = null;
        for (VertigoObject<?> vertigoObject : classes.keySet()) {
            if (vertigoObject.getTheClass().equals(aClass)) {
                object = vertigoObject;
            }
        }

        return object;
    }

    /**
     * Delegates to instiatiate via the VertigoObjects associated class
     *
     * @param aClass the class
     * @return Object representing the instance of the class
     */
    private Object instantiate(Class<?> aClass) {
        VertigoObject<?> vertigoObject = getVertigoObject(aClass);
        return instantiate(vertigoObject);
    }

    /**
     * Instantiates the class defined within the VertigoObject
     *
     * @param vertigoObject
     * @return
     */
    private <C> C instantiate(VertigoObject<C> vertigoObject) {
        C object = null;
        try {
            object = (C) vertigoObject.getTheConstructor().newInstance(vertigoObject.getTheParams());
        } catch (InstantiationException ie) {
            throw new AssertionError(ie.getMessage());
        } catch (IllegalAccessException iae) {
            throw new AssertionError(iae.getMessage());
        } catch (InvocationTargetException ite) {
            throw new AssertionError(ite.getMessage());
        }

        return object;
    }
}
