/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft;

/**
 * <p>
 * This class is a quick and simple struct for returning two values
 * from a method.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class Pair<T, U> {
    public final T first;
    public final U second;

    public Pair(T first, U second) {
        this.first = first;
        this.second = second;
    }
}