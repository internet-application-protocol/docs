/**
 * Copyright 2004 Inversoft, Inc.  All rights reserved.
 */

package com.inversoft.protocol.iap;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

import com.inversoft.iap.net.IapURLConnection;

/**
 * <p>
 * This class is the default Handler for all IAP protocol queries
 * </p>
 *
 * @author James Humphrey
 * @version 1.0
 * @see IapURLConnection
 * @since IAP 1.0
 */
public class Handler extends URLStreamHandler {

    /**
     * Opens a connection to the object referenced by the URL
     *
     * @param u URL that this handler connects to
     * @return IapURLConnection object
     * @throws IOException
     */
    protected URLConnection openConnection(URL u) throws IOException {
        return new IapURLConnection(u);
    }

    /**
     * Sets the default port number if none is specified in the URI String
     *
     * @return default port number
     */
    protected int getDefaultPort() {
        return 80;
    }


}