/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.AccessType;

/**
 * <p>
 * This class represents an X,Y coordinate that can be used
 * to represent a vector, point, or used inside another object
 * such as a {@link Size}.
 * </p>
 *
 * @author  Brian Pontarelli
 * @see     Size
 * @since   IAP 1.0
 * @version 1.0
 */
@XmlAccessorType(AccessType.FIELD)
public class Coord {
    @XmlAttribute(name = "x", required = true)
    private int x;
    @XmlAttribute(name = "y", required = true)
    private int y;

    /**
     * Needed for JAXB and possibly extension.
     */
    Coord() {
    }

    /**
     * Constructs a new <code>Coord</code>.
     *
     * @param   x The x value.
     * @param   y The y value.
     */
    public Coord(int x, int y) {
        assert (x >= 0) : "x < 0";
        assert (y >= 0) : "y < 0";
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the X part of the Coordinate.
     *
     * @return  X.
     */
    public int getX() {
        return x;
    }

    /**
     * Returns the Y part of the Coordinate.
     *
     * @return  Y.
     */
    public int getY() {
        return y;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Coord)) return false;

        final Coord coord = (Coord) o;

        if (x != coord.x) return false;
        if (y != coord.y) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = x;
        result = 29 * result + y;
        return result;
    }
}