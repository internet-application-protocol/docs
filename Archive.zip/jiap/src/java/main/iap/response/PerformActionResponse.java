/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.response;




/**
 * <p>
 * This interface defines the <code>PerformActionResponse</code>
 * that is created by an IAP server and passed to any handlers
 * listening for <code>Perform Action Requests</code>.
 * These are handlers that implement the {@link
 * iap.handler.PerformActionHandler} interface.
 * </p>
 *
 * <p>
 * This response allows IAP applications to respond after an
 * action performed by a user has been handled. The application
 * is allowed to programmatically determine the next view the
 * user should be taken to as well as any additional data that
 * was generated as a result of the action.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface PerformActionResponse extends IAPResponse {
    /**
     * Fetches the {@link ResponseData} object that can be used to provide detailed
     * information back to the client about the result of performing the action.
     *
     * @return  The ResponseData that can be used to send data to the client.
     */
    ResponseData getResponseData();
}