/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.response;


/**
 * <p>
 * This interface defines the <code>FetchDataResponse</code>
 * that is created by an IAP server and passed to handlers
 * listening for <code>Fetch Data Requests</code>.
 * These are handlers that implement the {@link
 * iap.handler.FetchDataHandler} interface.
 * </p>
 *
 * <p>
 * This response is used by IAP applications to return data
 * values from the server to the client. This is done using a
 * class that is constructed by an IAP server and can be
 * retrieved from this response object. This object is the
 * {@link ResponseData} object.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface FetchDataResponse extends IAPResponse {
    /**
     * Fetches the {@link ResponseData} object that can be used to provide detailed
     * data back to the client that it requested.
     *
     * @return  The ResponseData that can be used to send data to the client.
     */
    ResponseData getResponseData();
}