/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.response;

/**
 * <p>
 * This enumeration defines the rating levels that are possible
 * for an application. These are returned as part of the open
 * application response and are required.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum Rating {
    EC, E, T, M, AO
}