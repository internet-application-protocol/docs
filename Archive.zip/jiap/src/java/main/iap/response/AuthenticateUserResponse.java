/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.response;


/**
 * <p>
 * This interface defines the <code>AuthenticateUserResponse</code>
 * this is created by the IAP server and passed into any handler
 * listening for <code>Open Application Requests</code>.  These
 * are handlers that implement the {@link
 * iap.handler.AuthenticateUserHandler} interface.
 * </p>
 *
 * <p>
 * This interface allows applications to provide detailed error
 * messages and detailed exception information when authentication
 * fails. Successful authenticate is signaled to the client
 * by a successful response. By default all responses are
 * successful and therefore no action needs to be taken for
 * successful authentication requests.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface AuthenticateUserResponse extends IAPResponse {

    /**
     * Returns the previously set authentication failure reason. The failure reason
     * must have been set previously by calling the {@link
     * #setAuthenticationFailure(AuthenticationFailure)} method.
     *
     * @return  The failure reason.
     */
    AuthenticationFailure getAuthenticationFailure();

    /**
     * Sets the authentication failure reason. This reason is an enumerated type
     * that can provide more information to the client about specifically what
     * part of the users credentials failed. This can be left blank and the
     * authentication request can still be failed. In this case, the client will
     * assume an unknown failure reason.
     *
     * @param   failure The type of authentication failure.
     */
    void setAuthenticationFailure(AuthenticationFailure failure);

    /**
     * Fetches the {@link ResponseData} object that can be used to provide detailed
     * information back to the client about the authentication process. This can
     * be error messages, welcome messages, etc.
     *
     * @return  The ResponseData that can be used to send data to the client.
     */
    ResponseData getResponseData();
}