/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.response;


import java.io.InputStream;
import java.nio.ByteBuffer;


/**
 * <p>
 * This interface defines the <code>OpenViewResponse</code>
 * that is created by the IAP server and passed to any handler
 * listening for <code>Open Application Requests</code>.
 * These are handlers that implement the {@link
 * iap.handler.OpenViewHandler} interface.
 * </p>
 *
 * <p>
 * This handler allows applications to programmatically locate
 * and return the bytes for a specific view. However, the
 * IAP specification is very strict in that it does not allow
 * applications to dynamically generate views. This means
 * that for any view requested, the bytes returned must be
 * identical, on a byte for byte basis, each time that view
 * is requested. This requirement is impossible to enforce
 * unless checksums are done each time a view is requested.
 * Therefore, policing open view responses could greatly reduce
 * the overall performance of the application.
 * </p>
 *
 * <p>
 * An IAP server may choose to police open view responses but
 * this is not required. Instead, IAP applications should be
 * responsible citizens and ensure that a single view is not
 * generated at request time or if it is generated, it is
 * identical each time it is.
 * </p>
 *
 * <p>
 * Lastly, as an aside, you might be wondering why this interface
 * is provided at all if that requirement exists. It was added
 * because we know programs are responsible. Lazy, but
 * responsible. And we believe that this flexibility could
 * be used in ways that could not be forseen while writing the
 * interfaces. Therefore, we decided to leave in the ability
 * to handle open view requests completely. Just remember your
 * only causing your own headaches by breaking the IAP
 * specification rules.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface OpenViewResponse extends IAPResponse {
    /**
     * Retrieves the {@link ByteBuffer} that contains the bytes for the view. This ByteBuffer must
     * have been previously set using the {@link #setViewBytes(ByteBuffer)} method or null will be
     * returned.
     */
    ByteBuffer getViewBytes();

    /**
     * Sets a {@link java.nio.ByteBuffer} that contains the bytes for the view. This ByteBuffer can
     * be a memory mapped direct buffer to a file system file or it can be a ByteBuffer read from a
     * resource loaded via the class loader or other similar mechanism.
     *
     * @param   bytes The bytes of the view.
     * @throws  IllegalStateException If an OutputStream was already set as the source of the view
     *          bytes using the {@link #setInputStream(InputStream)} method.
     */
    void setViewBytes(ByteBuffer bytes);

    /**
     * Returns the InputStream that was previously set by an open view handler. This output stream
     * will be used by the container to read in the view. It is closed when the read is finished (i.e
     * the end of the stream is reached).
     *
     * @return  The InputStream that the view is read from.
     * @throws  IllegalStateException If the view's bytes were already set by calling the
     *          {@link #setViewBytes(ByteBuffer)} method.
     */
    InputStream getInputStream();

    /**
     * Sets an InputStream that the container will use to read in the view. This InputStream can
     * reference any resource and will be closed by the container when the read operation has completed
     * and the end of the stream is reached.
     *
     * @param   inputStream Thee InputStream the container will read the bytes of the view from.
     */
    void setInputStream(InputStream inputStream);

    /**
     * Returns a previously set value for the content type that the handler
     * is writing into the response.
     *
     * @return  The content type.
     */
    String getContentType();

    /**
     * Sets the content type that the handler is writing into the response.
     *
     * @param   contentType The content type.
     */
    void setContentType(String contentType);
}