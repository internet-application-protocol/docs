/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.response;




/**
 * <p>
 * This interface defines the <code>OpenApplicationResponse</code>
 * that is created by the server and passed to any handler that
 * is listening to <code>Open Application Requests</code>.
 * These are handlers that implement the {@link
 * iap.handler.OpenApplicationHandler} interface.
 * </p>
 *
 * <p>
 * This interface allows the initial view identifier to be
 * programmatically determined and returned to the client.
 * There is currently requirement that an open application
 * request must always return the same initial view identifier
 * for all requests, which means that the open application
 * handlers can determine the initial view programmatically.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface OpenApplicationResponse extends IAPResponse {

    /**
     * Retrieves the initial view identifier that will be returned to the client.
     * This value is either set by handler code by calling the {@link
     * #setViewId(String)} method, the IAP server from the iap.xml configuration
     * file or by the handler using the {@link
     * iap.handler.annotation.OpenApplication} annotation.
     *
     * @return  The initial view identifier or null if none has yet been set by
     *          the application or the server.
     */
    String getViewId();

    /**
     * Sets the initial view identifier that the client will open when a successful
     * open application response is received. This method can be called by any
     * handler that is listening for open application requests. If a handler calls
     * this method, the value it sets will override any value from the iap.xml
     * file or the {@link iap.handler.annotation.OpenApplication} annotation
     * defined for the handler.
     *
     * @param   viewId The initial view identifier to pass back to the client.
     */
    void setViewId(String viewId);

    /**
     * Returns the cacheable flag. This flag is set by calling the
     * {@link #setCacheable(boolean)} method and defaults to true. This returns
     * any previously set flag value or the default.
     *
     * @return  The cacheable flag.
     */
    boolean isCacheable();

    /**
     * Sets the cacheable flag to the given value. The default value is true.
     *
     * @param   cacheable The new cacheable flag value.
     */
    void setCacheable(boolean cacheable);

    /**
     * Returns the previously set redirect information.
     *
     * @return  The redirect or null.
     */
    Redirect getRedirect();

    /**
     * Sets in a new redirect that will be passed to the client.
     *
     * @param   redirect The redirect.
     */
    void setRedirect(Redirect redirect);

    /**
     * Returns the previously set application reference. An application reference
     * allows an application to inform the client to open a second application in
     * addition to the initial application.
     *
     * @return  The redirect or null.
     */
    Redirect getApplicationReference();

    /**
     * Sets in a new application reference that will be passed to the client.
     *
     * @param   ref The application reference redirect.
     */
    void setApplicationReference(Redirect ref);

    /**
     * Returns the rating previously set into the open application response or the
     * rating configured as part of the application deployment configuration or
     * included any annotations for the open application handler.
     *
     * @return  The rating.
     */
    Rating getRating();

    /**
     * Sets a new rating for the application. If a rating was previously set either
     * using this API, through configuration or by annotation, setting a new rating
     * in using this method will override that value.
     *
     * @param   rating The rating.
     */
    void setRating(Rating rating);
}