/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.response;




/**
 * <p>
 * This interface defines the mechanism that allows IAP server
 * handlers to transfer data to clients. Data here are key-value
 * pairs, but the key is a JavaBean style property name.
 * Therefore, the methods will all accept and return primitive
 * values or complex types (i.e. JavaBeans).
 * </p>
 *
 * <p>
 * Keys are unique to the entire application and are not
 * influenced by the {@link DataScope} parameter of the set
 * methods. The {@link DataScope} parameter is only provided
 * to allow application code on the server to inform the client
 * how it must handle the data value.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface ResponseData {

    /**
     * Retrieves the value from the response data that was stored under the given
     * key. This method behaves exactly the same as the
     * {@link iap.request.RequestData#getValue(String, Class<?>)} method.
     * That method has full documentation about how it behaves. Consult the
     * JavaDoc for that method for more details.
     *
     * @param   key The key that the value was previously stored under.
     * @param   type The type of the value being retrieved, used to construct
     *          complex types but required for all requests.
     * @return  The value or null if a value was never set for this key.
     * @throws  NullPointerException If key is null.
     */
    <T> T getValue(String key, Class<T> type);

    /**
     * Retrieves the scope of the value stored under the given key.
     *
     * @param   key The key that the value was previously stored under.
     * @return  The scope of the value or null if a value was never set for this
     *          key.
     * @throws  NullPointerException If key is null.
     */
    DataScope getScope(String key);

    /**
     * <p>
     * Sets the given value into the response data under the given key. This method
     * uses the default DataScope of {@link DataScope#APPLICATION} implying that
     * the value will be maintained on the client until the application is closed.
     * </p>
     *
     * <p>
     * The value given can be a primitive type, in which case the key becomes
     * either a local or nested key. Or it can be a complex type, in which case
     * the key becomes a complex key. Here are examples of both:
     * </p>
     *
     * <pre>
     * public class User {
     *     public Address getAddress();
     *     public void setAddress(Address address);
     *     public String getName();
     *     public void setName(String name);
     * }
     *
     * public class Address {
     *     public String getCity();
     *     public void setCity(String city);
     *     public String getState();
     *     public void setState(String state);
     * }
     *
     * // Local value
     * setValue("age", 12);
     *
     * // Nested value
     * setValue("user.address.city", "Denver");
     *
     * // Complex types
     * Address addr = ...;
     * setValue("user.address", address);
     *
     * User user = ...;
     * setValue("user", user);
     * </pre>
     *
     * <p>
     * The two complex examples will completely populate the ResponseData with
     * the entire structure of the complex types. Every property that returns a
     * primitive or array of primitives will be added as a nested value. Every
     * property that returns a complex type will be recursively added as another
     * complex type. For example, the final setValue call with the user will
     * result in these values being added to the ResponseData:
     * </p>
     *
     * <ul>
     * <li>user</li>
     * <li>user.name</li>
     * <li>user.address</li>
     * <li>user.address.city</li>
     * <li>user.address.state</li>
     * </ul>
     *
     * @param   key The key to store the value under.
     * @param   value The value to store. Nulls are allowed and should be used
     *          for servers to signal to clients that the value should be removed
     *          and code that relies on it should receive null when they ask for
     *          it next.
     * @param   type The type of the object being set, required for null values
     *          especially arrays, but required for all calls.
     * @param   scope The scope of the value.
     * @throws  NullPointerException If key is null.
     */
    <T> void setValue(String key, T value, Class<T> type, DataScope scope);
}