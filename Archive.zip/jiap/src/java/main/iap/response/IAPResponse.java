/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.response;


import iap.TransportType;


/**
 * <p>
 * The base IAP Response interface that defines the commmon
 * methods standard to all IAP Responses.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface IAPResponse {
    /**
     * Returns the response type. Implementations should return the specific type
     * to denote which of the sub-interfaces of this interface they implement.
     */
    TransportType getResponseType();

    /**
     * Returns the current status of this response. By default all responses are
     * successful and this method will return true unless false has been passed
     * to the {@link #setSuccess(boolean)} method.
     *
     * @return  The current success state (defaults to true).
     */
    public boolean isSuccess();
    
    /**
     * Sets whether or not the IAP request was successful or not. The IAP
     * specitication defines explicit status codes for failures, but from an
     * application level, all requests can be considered successful or not. The
     * status codes are mainly used by the IAP server to inform the client of
     * specific server related problems.
     *
     * @param   success True if the request was successful, false otherwise.
     */
    void setSuccess(boolean success);
}