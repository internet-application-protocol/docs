/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.response;


/**
 * <p>
 * This interface defines the <code>CloseApplicationResponse</code>
 * that is created by an IAP server and passed to handlers
 * listening for <code>Close Application Requests</code>. These
 * are handlers that implement the {@link
 * iap.handler.CloseApplicationHandler} interface.
 * </p>
 *
 * <p>
 * This response is used to inform the client that the
 * application has been successfully closed. Currently this
 * is just a marker interface because the close application
 * response does not contain additional information beyond
 * the success/failure flag.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface CloseApplicationResponse extends IAPResponse {
}