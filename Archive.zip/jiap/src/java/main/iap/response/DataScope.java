/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.response;

/**
 * <p>
 * This enumeration defines the different scopes that data
 * lives on the client. The valid scopes and there meanings
 * are defined in the table below.
 * </p>
 *
 * <table>
 * <tr><td>Scope</td><td>Meaning</td></tr>
 * <tr>
 *   <td>VIEW</td><
 *   <td>
 *      View scope means that the data lives only for the
 *      duration of the view. Therefore, the client is free
 *      to purge the data value once the user moves to a new
 *      view.
 *   </td>
 * </tr>
 * <tr>
 *   <td>APPLICATION</td><
 *   <td>
 *      Application scope means that the data lives for the
 *      entire duration that the user is interacting with the
 *      application. The client is only allowed to purge the
 *      data when the user closes the application.
 *   </td>
 * </tr>
 *
 * @author  Brian Pontarelli
 * @see
 * @since   IAP 1.0
 * @version 1.0
 */
public enum DataScope {
    /**
     * View scope (see class comment)
     */
    VIEW,

    /**
     * Application scope (see class comment)
     */
    APPLICATION;

    /**
     * Resolves the DataScope for the String given. The String is first upper
     * cased and then compared against the enum values. If the String is null,
     * then APPLICATION is returned. Otherwise, if the String is "VIEW" (uppercased)
     * then VIEW is returned and finally if it is anything else, APPLICATION is
     * returned.
     *
     * @param   scope The scope to look up.
     * @return  The scope and never null.
     */
    public static DataScope find(String scope) {
        if (scope != null && scope.toUpperCase().equals(VIEW.name())) {
            return VIEW;
        }

        return APPLICATION;
    }
}