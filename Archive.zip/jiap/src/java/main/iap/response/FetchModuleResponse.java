/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.response;


import java.io.InputStream;
import java.nio.ByteBuffer;


/**
 * <p>
 * This interface defines the <code>FetchModuleResponse</code>
 * that is created by an IAP server and passed to handlers
 * listening for <code>Fetch Module Requests</code>. These
 * are handlers that implement the {@link
 * iap.handler.FetchModuleHandler} interface.
 * </p>
 *
 * <p>
 * These handlers and this response object are used by
 * applications to pass back modules to clients. These
 * modules are client and language specific and are
 * considered a byte stream with respect to the application
 * and server.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface FetchModuleResponse extends IAPResponse {
    /**
     * Retrieves the {@link ByteBuffer} that contains the bytes for the module. This
     * ByteBuffer must have been previously set using the {@link
     * #setModuleBytes(ByteBuffer)} method or null will be returned.
     */
    ByteBuffer getModuleBytes();

    /**
     * Sets a {@link ByteBuffer} that contains the bytes for the module. This
     * ByteBuffer is translated into base 64 encoding so that it can be passed
     * as part of the XML response. This ByteBuffer can be a memory mapped direct
     * buffer to a file system file or it can be a ByteBuffer read from a resource
     * loaded via the class loader.
     *
     * @param   bytes The bytes of the module.
     * @throws  IllegalStateException If an InputStream was ever set using the
     *          {@link #setInputStream(InputStream)} method.
     */
    void setModuleBytes(ByteBuffer bytes);

    /**
     * Returns the InputStream that was previously set by an fetch module handler. This output stream
     * will be used by the container to read in the module. It is closed when the read is finished (i.e
     * the end of the stream is reached).
     *
     * @return  The InputStream that the module is read from.
     * @throws  IllegalStateException If the view's bytes were already set by calling the
     *          {@link #setModuleBytes(ByteBuffer)} method.
     */
    InputStream getInputStream();

    /**
     * Sets an InputStream that the container will use to read in the module. This InputStream can
     * reference any resource and will be closed by the container when the read operation has completed
     * and the end of the stream is reached.
     *
     * @param   inputStream Thee InputStream the container will read the bytes of the module from.
     */
    void setInputStream(InputStream inputStream);
}