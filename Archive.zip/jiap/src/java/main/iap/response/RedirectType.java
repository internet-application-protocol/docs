/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.response;


/**
 * <p>
 * This enumeration holds the different types of redirects
 * that are allowed to occur as part of the open application
 * response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @see     iap.response.OpenApplicationResponse
 * @see     iap.response.Redirect
 * @since   IAP 1.0
 * @version 1.0
 */
public enum RedirectType {
    /**
     * Redirect in a new window type.
     */
    NEW,

    /**
     * Redirect in an existing window type.
     */
    EXISTING;
}