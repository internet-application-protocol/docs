/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.response;


/**
 * <p>
 * This enumeration defines the different possible authentication
 * failure types.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum AuthenticationFailure {
    /**
     * Password failed
     */
    PASSWORD,

    /**
     * Username failure
     */
    USERNAME,

    /**
     * Username and password failure
     */
    USERNAME_PASSWORD;
}