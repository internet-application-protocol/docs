/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package iap.response;

/**
 * <p>
 * This interface defines the <code>ReconnectSessionResponse</code>
 * that is created by an IAP server and passed to handlers
 * listening for <code>Reconnect Session Requests</code>. These
 * are handlers that implement the {@link
 * iap.handler.ReconnectSessionHandler} interface.
 * </p>
 *
 * <p>
 * This response indicates to the client whether or not a session has
 * been reconnected or not.  Currently this
 * is just a marker interface because the reconnect session
 * response does not contain additional information beyond
 * the success/failure flag.
 * </p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface ReconnectSessionResponse extends IAPResponse {
}
