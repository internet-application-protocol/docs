/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.response;


import java.net.URL;

import iap.annotation.XmlElement;


/**
 * <p>
 * This class is a Redirect that can be created and set into
 * the OpenApplicationResponse to inform the client that it
 * needs to load another application.
 * </p>
 *
 * @author  Brian Pontarelli
 * @see     iap.response.OpenApplicationResponse
 * @since   IAP 1.0
 * @version 1.0
 */
@XmlElement(name = "redirect")
public class Redirect {
    private URL url;


    /**
     * Constructs a new <code>Redirect</code> with the given code and type.
     *
     * @param   url The URL of the Redirect. This should always be an IAP URL
     *          because other URL types are not handled by IAP clients. This is
     *          asserted during the pre-condition checks.
     * @asserts If the url or type are null or if the URL protocol is not "iap".
     */
    public Redirect(URL url) {
        assert (url != null) : "url == null";
        assert (url.getProtocol().equals("iap")) : "Invalid URL";
        this.url = url;
    }


    /**
     * Returns the URL of this redirect.
     *
     * @return  The URL.
     */
    public URL getUrl() {
        return url;
    }
}