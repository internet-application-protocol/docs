/**
 * Date Created: Aug 9, 2005
 * Created By:   James Humphrey (humphjj)
 */

package iap.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

/**
 * Helper annotation to define xml mappings for xml attribute components.
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(value = {ElementType.TYPE, ElementType.FIELD})
public @interface XmlAttribute {

    /**
     * The namespace associated to this attribute
     */
    String namespace() default "";

    /**
     * Denotes whether an attribute is required or not
     */
    boolean isRequired() default true;
}
