/**
 * Copyright (c) 2004, Inversoft, All rights reserved.
 */
package iap.request;


/**
 * <p>
 * This interface is the IAPSession.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface IAPSession {

    /**
     * Retrieves the attribute from the IAPSession that was previous set into
     * the session using the {@link #setAttribute(String, Object)} method. If no
     * attribute was previously set under that key, null is returned.
     *
     * @param   key The key that the attribute was previoulsy stored under inside
     *          the IAPSession.
     * @return  The attribute or null.
     */
    Object getAttribute(String key);

    /**
     * Sets an attribute into the IAPSession. This attribute is a server side
     * attribute that is not available to the IAP client.
     *
     * @param   key The key to store the attribute under inside the IAPSession.
     * @param   value The value of the attribute.
     */
    void setAttribute(String key, Object value);

    /**
     * Retrieves the timeout for this session. This is the length of the timeout
     * in milliseconds.
     *
     * @return  The timeout length.
     */
    long getTimeout();

    /**
     * Sets the timeout for this session. This timeout value is the length of the
     * timeout from the start of this request. Each new request, begins the timeout
     * again from this value. So, if 60000 (60 seconds) is used, each request will
     * renew the session so that it will expire 60 seconds from the start of that
     * request.
     *
     * @param   timeout The timeout length.
     */
    void setTimeout(long timeout);
}