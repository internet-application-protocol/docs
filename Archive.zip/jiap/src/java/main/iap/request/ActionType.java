/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package iap.request;

/**
 * Enum to be used to type-check a Perform Action Request perform action type
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */
public enum ActionType {
    /**
     * Asynchronous action type
     */
    ASYNCHRONOUS,

    /**
     * Synchronous action type
     */
    SYNCHRONOUS
}
