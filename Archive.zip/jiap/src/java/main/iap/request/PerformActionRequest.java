/*
 * Copyright (c) 2004, Inversoft, All rights reserved.
 */
package iap.request;




/**
 * <p>
 * This interface defines the <code>PerformActionRequest</code>
 * that is created by the IAP server and passed to any handler
 * listening for <code>Perform Action Requests</code>.
 * These are handlers that implement the {@link
 * iap.handler.PerformActionHandler} interface.
 * </p>
 *
 * <p>
 * This interface provides the action name and type to the
 * handlers. The type allows handlers to preference different
 * actions based on whether or not the client is waiting
 * for a response or not. This interface also provides the
 * data that the client provided as part of the perform action
 * request. This request data object defines the abstraction
 * layer between Strings and Objects and should be consulted
 * to determine how best to handle values passed in during
 * the request.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface PerformActionRequest extends IAPRequest {
    /**
     * Returns the name of the action that was performed by the client.
     *
     * @return  The name of the action.
     */
    String getActionName();

    /**
     * Returns the ActionType for the action being submitted.
     *
     * @return  The action type.
     */
    ActionType getActionType();

    /**
     * Returns the Id of the view that the action was performed from by the
     * client.
     *
     * @return  The Id of the view.
     */
    String getViewId();

    /**
     * Returns the RequestData object that can be used to fetch data passed from
     * the client to the server during the PerformActionRequest.
     *
     * @return  The request data.
     */
    RequestData getRequestData();
}