/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.request;


/**
 * <p>
 * This interface defines the mechanism that allows IAP
 * applications running on the server to fetch data that IAP
 * clients passed as part of various IAP requests. Data here
 * are key-value pairs, but the key is a JavaBean style
 * property name. Therefore, the data can be fetched property
 * by property, or as a JavaBean. There are two methods for
 * handling JavaBeans, one that attempts to construct a new
 * JavaBean (which is the same method as the single property
 * method) and one that takes an existing JavaBean.
 * </p>
 *
 * <p>
 * When a new JavaBean is being created, rather than try to
 * guess at the correct types, all nested properties must
 * not be null. If a null value is encountered, then a {@link
 * BeanException} is thrown.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface RequestData {

    /**
     * <p>
     * Retrieves the value from the request data that was sent by the client
     * under the given key. If the key is a single property, then that property
     * is retrieved. In that case, the type given must be a primitive type or
     * an array.
     * </p>
     *
     * <p>
     * This method also takes a complex name and attempts to build out a JavaBean
     * for that name. There are a few rules for this mechanism.
     * </p>
     *
     * <ol>
     * <li>If the key given is a single property in the RequestData, and the type
     *     given is not a primitive or an array of primitives, an exception is
     *     thrown.</li>
     * <li>If the key given is a nested property in the RequestData, and the type
     *     given is a primitive or an array of primitives, an exception is
     *     thrown.</li>
     * <li>If the key given is a nested property in the RequestData, and the type
     *     given is a complex type, but does not contain ALL of the nested
     *     properties an exception is thrown (i.e. key is foo and there is a
     *     foo.bar in the RequestData but the com.examples.Foo class doesn't have
     *     a method named setBar).</li>
     * <li>If the key given is a nested property in the RequestData, and the type
     *     given is a complex type but one of the nested objects returns null,
     *     an exception is thrown (i.e. key is foo and there is a foo.bar.value
     *     in the RequestData but the getBar method in com.examples.Foo returns
     *     null).</li>
     * </ol>
     *
     * <p>
     * Here is an example of a various properties and how they are returned when
     * queried:
     * </p>
     *
     * <pre>
     * age - local property that is an int. Retrieved by calling:
     *     int age = getValue("age", int.class);
     *
     * user.address.city - nested property that is a String. Retrieve by calling:
     *     String city = getValue("user.address.city", String.class);
     *
     * user.address - complex type. The entire address Object is returned.
     *     Address addr = getValue("user.address", Address.class);
     *     // addr.getCity() will return the value from RequestData under the key
     *     // user.address.city
     *
     * user - complex type. The entire user object is returned.
     *     User user = getValue("user", User.class);
     *     // user.getAddress().getCity() will return the value from RequestData
     *     // under the key user.address.city
     *
     * Code for nested examples:
     *
     * public class User {
     *     public Address getAddress();
     *     public void setAddress(Address address);
     * }
     *
     * public class Address {
     *     public String getCity();
     *     public void setCity(String city);
     * }
     * </pre>
     *
     * @param   key The key that the value was stored under.
     * @param   type The type of the value being retrieved, used to construct
     *          complex types but required for all requests.
     * @return  The value or null if a value was never set for this key.
     * @throws  NullPointerException If key is null.
     */
    <T> T getValue(String key, Class<T> type);

    /**
     * <p>
     * Populates the given complex type Object from the RequestData values. The
     * handling of keys and values is the same as the other method except that
     * this must be a complex type key and rather than constructing the JavaBean
     * it populates an existing JavaBean.
     * </p>
     *
     * @param   key The key (local, nested or wildcard) to set the value(s) into
     *          the given JavaBean.
     * @param   bean The JavaBean to set the value(s) into.
     */
    void populateJavaBean(String key, Object bean);
}