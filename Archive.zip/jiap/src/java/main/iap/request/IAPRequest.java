/**
 * Copyright (c) 2004, Inversoft, Inc.  All rights reserved.
 */
package iap.request;


import iap.TransportType;


/**
 * <p>
 * This interface defines the base IAPRequest. It defines the
 * common methods that all requests must define.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface IAPRequest {

    /**
     * Returns the type of this request. Sub-classes implement this method and
     * are guaranteed (as long as there are unit tests) to return a valid type.
     *
     * @return The type of request that this instance of the IAPRequest is.
     */
    TransportType getRequestType();

    /**
     * Returns the IAPSession object
     *
     * @return  The IAPSession.
     */
    IAPSession getSession();
}