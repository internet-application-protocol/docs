/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.request;


/**
 *
 * Enum used to type-check a device constraint on a particular
 * client.
 *
 * @author  James Humphrey
 * @since   IAP 1.0
 * @version 1.0
 */
public enum DeviceType {
    /**
     * Handheld device type.
     */
    HANDHELD,

    /**
     * Desktop device type
     */
    DESKTOP,

    /**
     * Phone device type
     */
    PHONE
}