/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.model;


import javax.security.auth.Subject;

import iap.VersionNumber;
import iap.request.AuthenticateUserRequest;


/**
 * <p>
 * This class is the model object that represents the currently
 * running container. This object is a singleton that is setup
 * by the server and can be used anywhere inside the running
 * IAP server.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class Container {
    private static ThreadLocal<Container> instance = new ThreadLocal<Container>();


    /**
     * Returns the singleton instance of the container. This method can be used
     * by applications to find out information about the container as well as
     * work with the container during application execution (such as authenticating
     * users).
     *
     * @return  The container instance.
     * @asserts If the container was not setup by the server.
     */
    public static Container getInstance() {
        assert (instance != null) : "instance == null";
        return instance.get();
    }

    /**
     * Sets up the container instance. Must be called by the IAP server prior to
     * application startup.
     *
     * @param   instance The container instance.
     */
    protected static void setInstance(Container instance) {
        Container.instance.set(instance);
    }

    /**
     * <p>
     * Protected so that only sub-classes can construct an instance of the
     * Container.
     * </p>
     */
    protected Container() {
    }

    /**
     * <p>
     * Associates the given Subject with the container and the IAPSession from
     * the given request. This allows applications to authenticate the user
     * themselves and then let the container know that the user was authenticated.
     * No more need to use JAAS, or J2EE form authentication, or implement crazy
     * container interfaces to authenticate. Just call this method.
     * </p>
     *
     * @param   subject The Subject that was authenticated. Inside the Subject
     *          must be two Principals. One javax.iap.auth.UsernamePrincipal and
     *          one javax.iap.auth.PasswordPrincipal.
     * @param   request The AuthenticateUserRequest that authenticated the user.
     */
    public abstract void authenticate(Subject subject, AuthenticateUserRequest request);

    /**
     * Returns the name of the application running for the current Thread (found
     * using the Thread.currentThread() method). Since the Container exists
     * across applications, this method retrieves the name of the application
     * being executed by the current execute thread.
     *
     * @return  The current application name.
     */
    public abstract String getApplicationName();

    /**
     * Returns the version number of the application running for the current
     * Thread (found using the Thread.currentThread() method). Since the Container
     * exists across applications, this method retrieves the version number of
     * the application being executed by the current execute thread.
     *
     * @return  The current application version.
     */
    public abstract VersionNumber getApplicationVersion();
}