/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.AccessType;

import iap.annotation.XmlElement;

/**
 * <p>
 * This class is a simple struct that holds an X and Y values
 * that represent minimum and maximum coordinates.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
@XmlElement(name = "size")
public class Size {
    private Coord min;
    private Coord max;

    /**
     * Needed for JAXB and possibly for extension.
     */
    Size() {
    }

    /**
     * Constructs a new <code>Size</code> that consists of two coords. One for the
     * minimum X and Y and one for the maximum. One of the values must be given
     * but both are not requied.
     *
     * @param   min The minimum values for X and Y.
     * @param   max The maximum values for X and Y.
     */
    public Size(Coord min, Coord max) {
        assert (min != null || max != null) : "min == null || max == null";
        this.min = min;
        this.max = max;
    }

    /**
     * Gets the minimum coordinate value that is the minimum X and Y position.
     *
     * @return  The minimum.
     */
    public Coord getMin() {
        return min;
    }

    /**
     * Gets the maximum coordinate value that is the maximum X and Y position.
     *
     * @return  The maximum.
     */
    public Coord getMax() {
        return max;
    }

    /**
     * {@inheritDoc}
     */
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Size)) {
            return false;
        }

        final Size size = (Size) o;

        if (!max.equals(size.max)) {
            return false;
        }
        if (!min.equals(size.min)) {
            return false;
        }

        return true;
    }

    /**
     * {@inheritDoc}
     */
    public int hashCode() {
        int result;
        result = min.hashCode();
        result = 29 * result + max.hashCode();
        return result;
    }
}