/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap;

/**
 * <p>
 * This enum identifies the various types of IAP requests and
 * responses.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public enum TransportType {
    /**
     * Denotes an open application.
     */
    OPEN_APPLICATION,

    /**
     * Denotes an open view.
     */
    OPEN_VIEW,

    /**
     * Denotes a fetch view data.
     */
    FETCH_DATA,

    /**
     * Denotes a perform action.
     */
    PERFORM_ACTION,

    /**
     * Denotes a fetch module.
     */
    FETCH_MODULE,

    /**
     * Denotes an authenticate user.
     */
    AUTHENTICATE_USER,

    /**
     * Denotes a close application.
     */
    CLOSE_APPLICATION,

    /**
     * Denotes a reconnect session.
     */
    RECONNECT_SESSION,

    /**
     * Denotes a meta-data
     */
    METADATA;

    /**
     * Uses the XML element name to determined the IAP request/response type.
     *
     * @param   elementName The root element name from an XML message.
     * @return  The IAPType or null if the element name is invalid or null.
     */
    public static TransportType findFromXML(String elementName) {
        TransportType type = null;
        if ("authenticateUserRequest".equals(elementName) ||
                "authenticateUserResponse".equals(elementName)) {
            type = AUTHENTICATE_USER;
        } else if ("closeApplicationRequest".equals(elementName) ||
                "closeApplicationResponse".equals(elementName)) {
            type = CLOSE_APPLICATION;
        } else if ("fetchDataRequest".equals(elementName) ||
                "fetchDataResponse".equals(elementName)) {
            type = FETCH_DATA;
        } else if ("fetchModuleRequest".equals(elementName) ||
                "fetchModuleResponse".equals(elementName)) {
            type = FETCH_MODULE;
        } else if ("openApplicationRequest".equals(elementName) ||
                "openAppicationResponse".equals(elementName)) {
            type = OPEN_APPLICATION;
        } else if ("openViewRequest".equals(elementName) ||
                "openViewResponse".equals(elementName)) {
            type = OPEN_VIEW;
        } else if ("performActionRequest".equals(elementName) ||
                "performActionResponse".equals(elementName)) {
            type = PERFORM_ACTION;
        } else if ("reconnectSessionRequest".equals(elementName) ||
                "reconnectSessionResponse".equals(elementName)) {
            type = RECONNECT_SESSION;
        } else if ("metaDataRequest".equals(elementName) ||
                "metaDataResponse".equals(elementName)) {
            type = METADATA;
        }
        return type;
    }
}