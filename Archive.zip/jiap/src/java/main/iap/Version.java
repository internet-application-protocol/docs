/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap;



/**
 * @author James Humphrey
 * @version 1.0
 * @since IAP 1.0
 */
public abstract class Version implements Comparable<Version> {
    /**
     * Version Delimiter.  Periods need escaping so that the regex api
     * recognizes it correctly
     */
    public static final String DELIMETER = ".";

    /**
     * Exception message for Major version number exception cases
     */
    public final static String majorExMsg = "Major version number cannot be less than 1";

    /**
     * Exception message for Minor version number exception cases
     */
    public final static String minorExMsg = "Minor version number cannot be less than 0";

    /**
     * Exception message for Sub-Minor version number exception cases
     */
    public final static String subMinorExMsg = "Sub-Minor version number cannot be less than 0";

    /**
     * Major version number.  This must be set in the sub type's constructor
     */
    private final Integer major;

    /**
     * Minor version number
     */
    private final Integer minor;

    /**
     * Sub-minor version number
     */
    private final Integer subMinor;

    /**
     * version number String format.  Default to empty string
     */
    private final String version;


    /**
     * Constructs a new <code>Version</code> object with the given major, minor
     * and sub-minor values.
     *
     * @param   major (Optional) Major version number.
     * @param   minor (Optional) Minor version number.
     * @param   subMinor (Optional) Sub-minor version number.
     */
    protected Version(Integer major, Integer minor, Integer subMinor) {
        this.major = major;
        this.minor = minor;
        this.subMinor = subMinor;

        validate();
        this.version = buildVersionString();
    }


    /**
     * Returns the version number of the application
     *
     * @return the version number generated
     */
    public String getVersion() {
        return this.version;
    }

    /**
     * Returns Major version number
     *
     * @return Major version number
     */
    public Integer getMajor() {
        return this.major;
    }

    /**
     * Returns minor version number
     *
     * @return Minor version number
     */
    public Integer getMinor() {
        return this.minor;
    }

    /**
     * Returns Sub-Minor version number
     *
     * @return Sub-Minor version number
     */
    public Integer getSubMinor() {
        return this.subMinor;
    }

    /**
     * Builds the version number using the major, minor, and sub-minor vars
     * Sub-class must implement.
     *
     * @return  The verion String.
     */
    protected abstract String buildVersionString();

    /**
     * <p>
     * validates the major, minor and subMinor version numbers accordingly
     * Sub-class must implement
     * </p>
     * <ul>
     *  <li>Major must be greater than or equal to 1</li>
     *  <li>Minor must be greater than 0</li>
     * <li>Sub-minor must be greater than 0 </ul>
     */
    protected abstract void validate() throws InvalidVersionException;

    /**
     * returns a string representation
     *
     * @return version number string
     * @param version
     */
    public static String encode(Version version) {
        return version.getVersion();
    }


    /**
     * Logic to check for equality between 2 Version types  Version types are
     * equal if their version numbers are equal
     *
     * @param o the object to be compared for equality
     * @return boolean true or false depending on equality
     */
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }

        // if the object supplied is this object
        if (this == o) return true;
        // make sure the object supplied is an instace of Version
        if (!(o instanceof Version)) return false;

        final Version anotherVersion = (Version) o;

        // now check to see if compareTo() returns EQUAL_TO
        if (this.compareTo(anotherVersion) != 0) return false;

        return true;
    }

    /**
     * Generates the hashcode for this version number. This is based on the major,
     * minor and sub-minor values.
     *
     * @return  The hashcode.
     */
    public int hashCode() {
        int result;
        result = (major != null ? major.hashCode() : 0);
        result = 29 * result + (minor != null ? minor.hashCode() : 0);
        result = 29 * result + (subMinor != null ? subMinor.hashCode() : 0);
        result = 29 * result + (version != null ? version.hashCode() : 0);
        return result;
    }

    /**
     * <p/> Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object. <p/> Explicit types
     * always order higher (are greater than) those types that are wildcards
     * since wildcards can be greater to, equal to, and less than all at once.
     * <p/>
     *
     * @param anotherVersion the Object to be compared.
     * @return a negative integer, zero, or a positive integer as this object is
     *         less than, equal to, or greater than the specified object.
     */
    public int compareTo(Version anotherVersion) {
        // get the major, minor, and sub-minor Integer values
        // of the object we are comparing 'this' to
        Integer anotherMajor = anotherVersion.getMajor();
        Integer anotherMinor = anotherVersion.getMinor();
        Integer anotherSubMinor = anotherVersion.getSubMinor();

        // compare major's first
        int value = this.major.compareTo(anotherMajor);
        if (value != 0) {
            return value;
        }

        // compare minors:
        // check for both minors being the same integer, this.minor being a
        // wildcard, and this.minor being a zero while another's minor
        // is a wildcard.
        value = this.minor.compareTo(anotherMinor);
        if (value != 0) {
            return value;
        }

        // compare subMinors
        value = this.subMinor.compareTo(anotherSubMinor);
        if (value != 0) {
            return value;
        }

        // if it gets to here both versions are equal
        return 0;
    }

    /**
     * Returns a string representation of the object.
     *
     * @return  a string representation of the object.
     */
    public String toString() {
        return this.getVersion();
    }
}