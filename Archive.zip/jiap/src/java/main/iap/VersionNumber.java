/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap;

import iap.annotation.XmlElement;

/**
 * <p>
 * Version Number of the application.  Each version number
 * has the following major, minor, and sub-minor format as
 * dictated in the IAP specification using Augmented BNF:
 * </p>
 *
 * <p>INTEGER ["." INTEGER ["." INTEGER]]</p>
 *
 * <p>
 * This class throws an InvalidVersionException if the
 * following format is not met:
 * </p>
 *
 * <ul>
 *   <li>Major must be greater than or equal to 1</li>
 *   <li>Minor must be greater than 0</li>
 *   <li>Sub-minor must be greater than 0</li>
 * </ul>
 *
 * @author  James Humphrey
 * @since   IAP 1.0
 * @version 1.0
 */
@XmlElement(name = "versionNumber")
public final class VersionNumber extends Version {

    /**
     * Constructor is called if just the Major version number is sufficient
     *
     * @param major Major version number
     */
    public VersionNumber(Integer major) throws InvalidVersionException {
        this(major, 0, 0);
    }

    /**
     * Constructor is called if just the Major and Minor version number is
     * sufficient
     *
     * @param major Major version number
     * @param minor Minor version number
     */
    public VersionNumber(Integer major, Integer minor)
            throws InvalidVersionException {
        this(major, minor, 0);
    }

    /**
     * Constructor is called if Major, Minor and Sub-minor are needed
     *
     * @param major    Major version number
     * @param minor    Minor version number
     * @param subMinor Sub-minor version number
     */
    public VersionNumber(Integer major, Integer minor, Integer subMinor)
    throws InvalidVersionException {
        super(
            major,
            (minor == null) ? 0 : minor,
            (subMinor == null) ? 0 : subMinor);
    }

    /**
     * Decodes a String version object into a Version object
     *
     * @param version the version string to be decoded
     * @throws InvalidVersionException if the specified is not a valid format
     */
    public static VersionNumber decode(String version)
            throws InvalidVersionException {

        String[] versionNumbers;
        Integer major;
        Integer minor;
        Integer subMinor;
        String delimeter;
        final String invalidVersionMsg = "Version specified is not a valid format";

        // first check for null
        if (version == null) {
            throw new InvalidVersionException(invalidVersionMsg);
        }

        // check if delimeter is a period and escape if so
        if (DELIMETER.equals(".")) {
            delimeter = "\\.";
        } else {
            delimeter = DELIMETER;
        }

        // split up the version string tokens by the periods with max 3 splits
        versionNumbers = version.split(delimeter, 3);

        // return new Version type based on array token values
        //  - versionNumber.length = 1
        //      it can only be a major or exception
        //  - versionNumber.length = 2
        //      it can only be a major and minor, or an exception
        //  - versionNumber.length = 3
        //      it can only be a major and minor and subminor, or an exception
        // - versionNumber.length > 3
        //      it's an exception
        if (versionNumbers.length == 1) {
            try {
                major = new Integer(versionNumbers[0]);

                return new VersionNumber(major);
            } catch (NumberFormatException nfe) {
                throw new InvalidVersionException(invalidVersionMsg);
            }
        } else if (versionNumbers.length == 2) {
            try {
                major = new Integer(versionNumbers[0]);
                minor = new Integer(versionNumbers[1]);

                return new VersionNumber(major, minor);
            } catch (NumberFormatException nfe) {
                throw new InvalidVersionException(invalidVersionMsg);
            }
        } else if (versionNumbers.length == 3) {
            try {
                major = new Integer(versionNumbers[0]);
                minor = new Integer(versionNumbers[1]);
                subMinor = new Integer(versionNumbers[2]);

                return new VersionNumber(major, minor, subMinor);
            } catch (NumberFormatException nfe) {
                throw new InvalidVersionException(invalidVersionMsg);
            }
        } else {
            throw new InvalidVersionException(invalidVersionMsg);
        }
    }

    /**
     * Builds the version number using the major, minor, and sub-minor vars
     */
    protected String buildVersionString() {
        // concatenate major, minor, subMinor and delimeter appropriately
        return getMajor() + DELIMETER + getMinor() + DELIMETER + getSubMinor();
    }

    /**
     * <p>
     * validates the major, minor and subMinor version numbers accordingly
     * </p>
     * <ul>
     *  <li>Major must be greater than or equal to 1</li>
     *  <li>Minor must be greater or equal to 0</li>
     *  <li>Sub-minor must be greater or equal to 0</li>
     * </ul>
     */
    protected void validate() throws InvalidVersionException {
        // validate major
        if (getMajor() == null) {
            throw new InvalidVersionException(majorExMsg);
        }
        // validate major
        if (getMajor() < 1) {
            throw new InvalidVersionException(majorExMsg);
        }
        // validate minor
        if (getMinor() < 0) {
            throw new InvalidVersionException(minorExMsg);
        }
        // validate subMinor
        if (getSubMinor() < 0) {
            throw new InvalidVersionException(subMinorExMsg);
        }
    }
}