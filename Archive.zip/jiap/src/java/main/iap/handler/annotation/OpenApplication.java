/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler.annotation;


import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import iap.response.Rating;


/**
 * <p>
 * This meta-data is used to config and manage the open
 * application handlers. This allows an open application
 * to define the viewId that it will return for every
 * request, rather than programmatically setting the viewId
 * into the response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface OpenApplication {
    String viewId();
    Rating rating();
    Parameter[] parameters() default {};
}