/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.handler.annotation;



/**
 * <p>
 * This annotation is for the PerformActionHandler class so that
 * it can declare the views and actions on those views that it
 * handles.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public @interface PerformAction {
    ViewAction[] viewActions();
    Parameter[] parameters() default {};
}