/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package iap.handler.annotation;

/**
 * <p>
 * This annotation is used by the PerformAction annotation to
 * declare a view and action pair. Both of these values can be
 * regular expressions.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public @interface ViewAction {
    String view();
    String action();
}