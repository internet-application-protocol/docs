/**
 * Date Created: May 25, 2005
 * Created By:   James Humphrey
 */

package iap.handler.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * This meta-data is used to config and manage the reconnect session
 * handlers. This allows reconnect session handlers
 * to define a session duration that will return for every
 * request, rather than programmatically setting it into the response.
 * </p>
 *
 * @author James Humphrey
 * @version 1.0
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ReconnectSession {
    Parameter[] parameters() default {};
}
