/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


import iap.request.OpenApplicationRequest;
import iap.response.OpenApplicationResponse;


/**
 * <p>
 * This interface defines the OpenApplicationHandler, which
 * are the methods used for IAPHandlers to handle open
 * application requests.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface OpenApplicationHandler extends IAPHandler {

    /**
     * <p>
     * Called by the IAP container when an open application request is
     * submitted by a client. This method should handle the open application
     * request and provide an appropriate open application response. In most
     * cases the response requires only a view identifier and status code to be
     * correct. In light of these circumstances, an open application handler can
     * specify an auto-wiring of view identifier if it is unnecessary for the
     * application to programmatically determine the view identifier. This is
     * done using the OpenApplication annotation. By specifying an auto-wire
     * configuration for the handler, the container skips the invocation of this
     * method when handling open application requests and instead uses the
     * configuration from the annotation to formulate a response.
     * </p>
     *
     * @param   request The OpenApplicationRequest that should be used to parse
     *          out the request parameters in order to formulate an appropriate
     *          response.
     * @param   response The OpenApplicationResponse that must be populated with
     *          the necessary information prior to returning from this method.
     *          An instance of the response is passed into this method and the
     *          response should then be populated and this method should return.
     * @throws  IAPHandlerException If processing of the open view request
     *          failed for any reason, implementing classes should throw an
     *          instance of IAPHandlerException. Implementations should try to wrap
     *          all exceptions into a IAPHandlerException because it is not specified
     *          how different servers handle RuntimeExceptions.
     */
    void doOpenApplication(OpenApplicationRequest request, OpenApplicationResponse response)
    throws IAPHandlerException;
}