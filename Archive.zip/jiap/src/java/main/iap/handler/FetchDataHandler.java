/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


import iap.request.FetchDataRequest;
import iap.response.FetchDataResponse;


/**
 * <p>
 * This interface defines the FetchDataHandler, which
 * are the methods used for IAPHandlers to handle fetch
 * data requests.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface FetchDataHandler extends IAPHandler {

    /**
     * <p>
     * Called by the IAP container when an fetch data request is submitted by a
     * client. This method should handle the fetch data request and provide an
     * appropriate fetch data response.
     * </p>
     *
     * @param   request The FetchDataRequest that should be used to parse
     *          out the request parameters in order to formulate an appropriate
     *          response.
     * @param   response The FetchDataResponse that must be populated with
     *          the necessary information prior to returning from this method.
     *          An instance of the response is passed into this method and the
     *          response should then be populated and this method should return.
     * @throws  IAPHandlerException If processing of the fetch data request
     *          failed for any reason, implementing classes should throw an
     *          instance of IAPHandlerException. Implementations should try to wrap
     *          all exceptions into a IAPHandlerException because it is not specified
     *          how different servers handle RuntimeExceptions.
     */
    void doFetchData(FetchDataRequest request, FetchDataResponse response)
    throws IAPHandlerException;
}