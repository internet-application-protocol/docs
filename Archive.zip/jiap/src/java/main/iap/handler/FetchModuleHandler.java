/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


import iap.request.FetchModuleRequest;
import iap.response.FetchModuleResponse;


/**
 * <p>
 * This interface defines the FetchModuleHandler, which
 * are the methods used for IAPHandlers to handle fetch
 * module requests.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface FetchModuleHandler extends IAPHandler {

    /**
     * <p>
     * Called by the IAP container when an fetch module request is
     * submitted by a client. This method should handle the fetch module
     * request and provide an appropriate fetch module response. In most cases
     * the response requires only the bytes of the module to be correct. In light
     * of these circumstances, a fetch module handler can specify an auto-wiring
     * of a module file if it is unnecessary for the application to
     * programmatically determine the module file. This is done using the
     * FetchModuleAnnotation. By specifying an auto-wire configuration for the
     * handler, the container skips the invocation of this method when handling
     * fetch module requests and instead uses the configuration from the
     * annotation to formulate a response.
     * </p>
     *
     * <p>
     * <i>Recall that for a given module identifier, all requests across all
     * applications must return the exact same module (on a byte for byte basis).
     * Programmatically determining the module to return only allows an
     * application to load configuration that defines module id to file mapping
     * or something similar. Applications are not allow to programmatically
     * generate the module bytes or change the module that is returned.</i>
     * </p>
     *
     * @param   request The FetchModuleRequest that should be used to parse
     *          out the request parameters in order to formulate an appropriate
     *          response.
     * @param   response The FetchModuleResponse that must be populated with
     *          the necessary information prior to returning from this method.
     *          An instance of the response is passed into this method and the
     *          response should then be populated and this method should return.
     * @throws  IAPHandlerException If processing of the fetch module request
     *          failed for any reason, implementing classes should throw an
     *          instance of IAPHandlerException. Implementations should try to wrap
     *          all exceptions into a IAPHandlerException because it is not specified
     *          how different servers handle RuntimeExceptions.
     */
    void doFetchModule(FetchModuleRequest request, FetchModuleResponse response)
    throws IAPHandlerException;
}