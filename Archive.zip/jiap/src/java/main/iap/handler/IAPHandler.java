/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


import java.util.Map;

import iap.handler.annotation.Handler;


/**
 * <p>
 * This interface defines an IAPHandler. This handler is similar
 * to the J2EE servlet, but has two fundamental differences.
 * </p>
 *
 * <ul>
 * <li>This handler does not support request dispatchers.
 * Request dispatchers are an HTTP centric concept and have
 * no meaning for IAP.</li>
 * <li>IAP handlers are comprised of classes that implement
 * one or more interfaces rather than a single interface.
 * This allows the different services to handle specific
 * request types rather than being forced to handle all
 * request types.</li>
 * </ul>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface IAPHandler {

    /**
     * <p>
     * Called by the IAP container when the IAPHandler is first put into
     * service. This method should be implemented to provide detailed creation
     * functionality. This method also receives a list of parameters that are
     * retrieved by the container from the iap.xml configuration file or the
     * {@link Handler} annotation. This annotation is inspected by the container
     * at load time and all parameters from it are appended to any parameters
     * loaded from the iap.xml configuration file.
     * </p>
     *
     * <p>
     * This method is called only once per JVM per instance of the IAPHandler.
     * This means that a handler is never taken out of service and then put back
     * into service.
     * </p>
     *
     * @param   parameters The parameters from the annotations as well as the
     *          iap.xml configuration file.
     * @throws  IAPHandlerException If there were any problems creating the handler.
     */
    void create(Map<String,String> parameters) throws IAPHandlerException;

    /**
     * <p>
     * Called by the IAP container when the IAPHandler is taken out of service.
     * This method should be implemented to provide detailed destruction
     * functionality such as freeing of resources or closing of connections. In
     * most cases this method is called when the server is shutdown, but a handler
     * can be taken out of service forcefully and this method is called before
     * removing the handler from active service.
     * </p>
     *
     * <p>
     * If this method throws an exception, the IAPHandler is still removed from
     * service, but the text of the exception is displayed to the user to inform
     * them of the problem encountered during removal of the servlet.
     * </p>
     *
     * @throws  IAPHandlerException If there was any problem shutting down.
     */
    void destory() throws IAPHandlerException;
}