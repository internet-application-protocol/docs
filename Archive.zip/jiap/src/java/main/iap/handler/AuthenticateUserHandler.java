/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


import iap.request.AuthenticateUserRequest;
import iap.response.AuthenticateUserResponse;


/**
 * <p>
 * This interface defines the AuthenticateUserHandler, which
 * are the methods used for IAPHandlers to handle perform
 * action requests.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface AuthenticateUserHandler extends IAPHandler {

    /**
     * <p>
     * Called by the IAP container when a authenticate user request is
     * submitted by a client. This method should handle the authenticate user
     * request and provide an appropriate authenticate user response.
     * </p>
     *
     * @param   request The AuthenticateUserRequest that should be used to fetch
     *          the request parameters in order to formulate an appropriate
     *          response.
     * @param   response The AuthenticateUserResponse that must be populated with
     *          the necessary information prior to returning from this method.
     *          An instance of the response is passed into this method and the
     *          response should then be populated and this method should return.
     * @throws  IAPHandlerException If processing of the authenticate user request
     *          failed for any reason, implementing classes should throw an
     *          instance of IAPHandlerException. Implementations should try to wrap
     *          all exceptions into a IAPHandlerException because it is not specified
     *          how different servers handle RuntimeExceptions.
     */
    void doAuthenticateUser(AuthenticateUserRequest request, AuthenticateUserResponse response)
    throws IAPHandlerException;
}