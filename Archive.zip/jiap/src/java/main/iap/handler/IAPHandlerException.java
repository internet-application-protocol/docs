/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


/**
 * <p>
 * This exception should be used for exceptional cases during
 * the construction, destuction and execution of any of the
 * IAPHandler interfaces.
 * </p>
 *
 * @author  Brian Pontarelli
 * @see     iap.handler.IAPHandler
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPHandlerException extends RuntimeException {
    /**
     * Constructs a new exception with <code>null</code> as its detail message.
     * The cause is not initialized, and may subsequently be initialized by a
     * call to {@link #initCause}.
     */
    public IAPHandlerException() {
        super();
    }

    /**
     * Constructs a new exception with the specified detail message.  The
     * cause is not initialized, and may subsequently be initialized by
     * a call to {@link #initCause}.
     *
     * @param   message The detail message. The detail message is saved for
     *          later retrieval by the {@link #getMessage()} method.
     */
    public IAPHandlerException(String message) {
        super(message);
    }

    /**
     * Constructs a new exception with the specified detail message and
     * cause.  <p>Note that the detail message associated with
     * <code>cause</code> is <i>not</i> automatically incorporated in
     * this exception's detail message.
     *
     * @param  message The detail message (which is saved for later retrieval
     *         by the {@link #getMessage()} method).
     * @param  cause The cause (which is saved for later retrieval by the
     *         {@link #getCause()} method).  (A <tt>null</tt> value is
     *         permitted, and indicates that the cause is nonexistent or
     *         unknown.)
     * @since  1.4
     */
    public IAPHandlerException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new exception with the specified cause and a detail
     * message of <tt>(cause==null ? null : cause.toString())</tt> (which
     * typically contains the class and detail message of <tt>cause</tt>).
     * This constructor is useful for exceptions that are little more than
     * wrappers for other throwables (for example, {@link
     * java.security.PrivilegedActionException}).
     *
     * @param  cause The cause (which is saved for later retrieval by the
     *         {@link #getCause()} method).  (A <tt>null</tt> value is
     *         permitted, and indicates that the cause is nonexistent or
     *         unknown.)
     * @since  1.4
     */
    public IAPHandlerException(Throwable cause) {
        super(cause);
    }
}