/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


import java.util.Map;

import iap.request.AuthenticateUserRequest;
import iap.request.CloseApplicationRequest;
import iap.request.FetchDataRequest;
import iap.request.FetchModuleRequest;
import iap.request.OpenApplicationRequest;
import iap.request.OpenViewRequest;
import iap.request.ReconnectSessionRequest;
import iap.response.AuthenticateUserResponse;
import iap.response.CloseApplicationResponse;
import iap.response.FetchDataResponse;
import iap.response.FetchModuleResponse;
import iap.response.OpenApplicationResponse;
import iap.response.OpenViewResponse;
import iap.response.ReconnectSessionResponse;


/**
 * <p>
 * This class is the main IAPHandler class that can be
 * exetended by any class wishing to provide server side
 * handling of IAP requests.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class GenericIAPHandler implements AuthenticateUserHandler,
        CloseApplicationHandler, FetchModuleHandler, FetchDataHandler,
    OpenApplicationHandler, OpenViewHandler, ReconnectSessionHandler {

    /**
     * <p>
     * Implements the doAuthenticateUser method with a no-op.
     * </p>
     */
    public void doAuthenticateUser(AuthenticateUserRequest request,
            AuthenticateUserResponse response)
    throws IAPHandlerException {
    }

    /**
     * <p>
     * Implements the create method with a no-op.
     * </p>
     */
    public void create(Map<String, String> parameters) throws IAPHandlerException {
    }

    /**
     * <p>
     * Implements the destroy method with a no-op.
     * </p>
     */
    public void destory() throws IAPHandlerException {
    }

    /**
     * <p>
     * Implements the doCloseApplication method with a no-op.
     * </p>
     */
    public void doCloseApplication(CloseApplicationRequest request,
            CloseApplicationResponse response)
    throws IAPHandlerException {
    }

    /**
     * <p>
     * Implements the doFetchModule method with a no-op.
     * </p>
     */
    public void doFetchModule(FetchModuleRequest request,
            FetchModuleResponse response)
    throws IAPHandlerException {
    }

    /**
     * <p>
     * Implements the doFetchData method with a no-op.
     * </p>
     */
    public void doFetchData(FetchDataRequest request,
            FetchDataResponse response)
    throws IAPHandlerException {
    }

    /**
     * <p>
     * Implements the doOpenApplication method with a no-op.
     * </p>
     */
    public void doOpenApplication(OpenApplicationRequest request,
            OpenApplicationResponse response)
    throws IAPHandlerException {
    }

    /**
     * <p>
     * Implements the doOpenView method with a no-op.
     * </p>
     */
    public void doOpenView(OpenViewRequest request, OpenViewResponse response)
    throws IAPHandlerException {
    }

    /**
     * <p>
     * Implements the doReconnectSession method with a no-op.
     * </p>
     */
    public void doReconnectSession(ReconnectSessionRequest request,
                                   ReconnectSessionResponse response)
            throws IAPHandlerException {
        // stub

    }
}