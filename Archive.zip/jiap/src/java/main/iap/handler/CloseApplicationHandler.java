/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


import iap.request.CloseApplicationRequest;
import iap.response.CloseApplicationResponse;


/**
 * <p>
 * This interface defines the CloseApplicationHandler, which
 * are the methods used for IAPHandler to handle close
 * application requests.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface CloseApplicationHandler extends IAPHandler {

    /**
     * <p>
     * Called by the IAP container when a close application request is
     * submitted by a client. This method should handle the close application
     * request and provide an appropriate close application response.
     * </p>
     *
     * @param   request The CloseApplicationRequest that should be used to parse
     *          out the request parameters in order to formulate an appropriate
     *          response.
     * @param   response The CloseApplicationResponse that must be populated with
     *          the necessary information prior to returning from this method.
     *          An instance of the response is passed into this method and the
     *          response should then be populated and this method should return.
     * @throws  IAPHandlerException If processing of the close application request
     *          failed for any reason, implementing classes should throw an
     *          instance of IAPHandlerException. Implementations should try to wrap
     *          all exceptions into a IAPHandlerException because it is not specified
     *          how different servers handle RuntimeExceptions.
     */
    void doCloseApplication(CloseApplicationRequest request, CloseApplicationResponse response)
    throws IAPHandlerException;
}