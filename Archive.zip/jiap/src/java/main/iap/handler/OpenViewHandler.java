/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap.handler;


import iap.request.OpenViewRequest;
import iap.response.OpenViewResponse;


/**
 * <p>
 * This interface defines the OpenViewHandler, which are the
 * methods used for IAPHandlers to handle open view requests.
 * </p>
 *
 * <p>
 * This handler allows applications to programmatically locate
 * and return the bytes for a specific view. However, the
 * IAP specification is very strict in that it does not allow
 * applications to dynamically generate views. This means
 * that for any view requested, the bytes returned must be
 * identical, on a byte for byte basis, each time that view
 * is requested. This requirement is impossible to enforce
 * unless checksums are done each time a view is requested.
 * Therefore, policing open view responses could greatly reduce
 * the overall performance of the application.
 * </p>
 *
 * <p>
 * An IAP server may choose to police open view responses but
 * this is not required. Instead, IAP applications should be
 * responsible citizens and ensure that a single view is not
 * generated at request time or if it is generated, it is
 * identical each time it is.
 * </p>
 *
 * <p>
 * Lastly, as an aside, you might be wondering why this interface
 * is provided at all if that requirement exists. It was added
 * because we know programs are responsible. Lazy, but
 * responsible. And we believe that this flexibility could
 * be used in ways that could not be forseen while writing the
 * interfaces. Therefore, we decided to leave in the ability
 * to handle open view requests completely. Just remember your
 * only causing your own headaches by breaking the IAP
 * specification rules.
 * </p>
 * 
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface OpenViewHandler extends IAPHandler {

    /**
     * <p>
     * Called by the IAP container when an open view request is submitted by
     * a client. This method should handle the open view request and provide an
     * appropriate open view response. In most cases the response requires only
     * the view body and a flag as to whether or not a view has associated data
     * to be correct. In light of these circumstances, an open view handler can
     * specify an auto-wiring of a view file if it is unnecessary for the
     * application to programmatically determine the view body and data flag.
     * This is done using the OpenViewAnnotation. By specifying an auto-wire
     * configuration for the handler, the container skips the invocation of this
     * method when handling open view requests and instead uses the configuration
     * from the annotation to formulate a response.
     * </p>
     *
     * <p>
     * <i>Recall that for a given view identifier, all requests to the same
     * application and same application version for that identifier must return
     * the exact same view body and data flag. Programmatically determining the
     * view body and data flag only allow an application to load configuration
     * that determines view id to file mapping or something similar. Applications
     * are not allow to programmatically generate the view body or change the
     * view body returned.</i>
     * </p>
     *
     * @param   request The OpenViewRequest that should be used to parse out the
     *          request parameters in order to formulate an appropriate response.
     * @param   response The OpenViewResponse that must be populated with the
     *          necessary information prior to returning from this method.
     *          An instance of the response is passed into this method and the
     *          response should then be populated and this method should return.
     * @throws  iap.handler.IAPHandlerException If processing of the open view request
     *          failed for any reason, implementing classes should throw an
     *          instance of IAPHandlerException. Implementations should try to wrap
     *          all exceptions into a IAPHandlerException because it is not specified
     *          how different servers handle RuntimeExceptions.
     */
    void doOpenView(OpenViewRequest request, OpenViewResponse response)
    throws IAPHandlerException;
}