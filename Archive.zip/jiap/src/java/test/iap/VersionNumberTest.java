/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package iap;


import junit.framework.TestCase;


/**
 * VersionNumber test case
 *
 * @author James Humphrey
 * @version 1.0
 * @since IAP 1.0
 */
public class VersionNumberTest extends TestCase {

    private static final String majorExMsg = "Major version number cannot be less than 1";

    private static final String minorExMsg = "Minor version number cannot be less than 0";

    private static final String subMinorExMsg = "Sub-Minor version number cannot be less than 0";

    private static final String invalidVersionMsg = "Version specified is not a valid format";


    public VersionNumberTest(String name) {
        super(name);
    }


    public void testVersionNumber() throws InvalidVersionException {
        // test 1 exception
        try {
            new VersionNumber(-1);
            fail("error in test 1 exception");
        } catch (InvalidVersionException e) {
            assertEquals(majorExMsg, e.getMessage());
        }
        // test 2 exception
        try {
            new VersionNumber(0, 1, 1);
            fail("error in test 2 exception");
        } catch (InvalidVersionException e) {
            assertEquals(majorExMsg, e.getMessage());
        }

        // test 3 exception
        try {
            new VersionNumber(1, -1);
            fail("error in test 3 exception");
        } catch (InvalidVersionException e) {
            assertEquals(minorExMsg, e.getMessage());
        }

        // test 4 exception
        try {
            new VersionNumber(1, 1, -5);
            fail("error in test 4 exception");
        } catch (InvalidVersionException e) {
            assertEquals(subMinorExMsg, e.getMessage());
        }

        // test normal construction and getVersion()
        assertEquals("3.0.0", new VersionNumber(3).getVersion());
        assertEquals("3.0.0", new VersionNumber(3, 0).getVersion());
        assertEquals("3.0.1", new VersionNumber(3, 0, 1).getVersion());
        assertEquals("1.0.0", new VersionNumber(1, 0, 0).getVersion());
        assertEquals("3.0.0", new VersionNumber(3, 0, 0).getVersion());
        assertEquals("3.0.0", new VersionNumber(3, null, null).getVersion());
        assertEquals("3.0.1", new VersionNumber(3, null, 1).getVersion());

        // test the equals() operation
        VersionNumber testVersion = new VersionNumber(1, null, null);
        assertTrue(testVersion.equals(testVersion)); // test itself
        assertTrue(new VersionNumber(1, 1).equals(new VersionNumber(1, 1)));
        assertFalse(new VersionNumber(1, 1).equals(new VersionNumber(1, null)));
        assertFalse(new VersionNumber(1, null).equals(new VersionNumber(1, 1)));
        assertTrue(new VersionNumber(1, null, null).equals(new VersionNumber(1, null, null)));
        assertFalse(new VersionNumber(1).equals(new VersionNumber(2)));
        assertFalse(new VersionNumber(2).equals(new VersionNumber(1)));
        assertTrue(new VersionNumber(5).equals(new VersionNumber(5)));


        // test decoder

        // test 5 exception
        try {
            VersionNumber.decode(null);
            fail("error in test 5 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 6 exception
        try {
            VersionNumber.decode("james");
            fail("error in test 6 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 7 exception
        try {
            VersionNumber.decode("1.asdf");
            fail("error in test 7 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 8 exception
        try {
            VersionNumber.decode("1.1.ponchie");
            fail("error in test 8 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 9 exception
        try {
            VersionNumber.decode("james.1.1.ponchie");
            fail("error in test 9 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        // test 10 exception
        try {
            VersionNumber.decode("1.humpdy.2");
            fail("error in test 10 exception");
        } catch (InvalidVersionException e) {
            assertEquals(invalidVersionMsg, e.getMessage());
        }

        assertEquals("1.1.0", VersionNumber.decode("1.1").getVersion());
        assertEquals("1.0.0", VersionNumber.decode("1").getVersion());
        assertEquals("1.1.1", VersionNumber.decode("1.1.1").getVersion());
        assertEquals("1.1.11", VersionNumber.decode("1.1.11").getVersion());
        assertEquals("1.10.1", VersionNumber.decode("1.10.1").getVersion());
        assertEquals("1001.1.43", VersionNumber.decode("1001.1.43").getVersion());

        // test the compareTo operation
        // example: '1.1' compared to '2' should yield LESS_THAN
        //          since version '1.1' is less than version '2'
        // test the compareTo operation
        // example: '1.1' compared to '2' should yield LESS_THAN
        //          since version '1.1' is less than version '2'

        assertTrue(VersionNumber.decode("1.0").compareTo(VersionNumber.decode("1.1")) < 0);
        assertTrue(VersionNumber.decode("1.1").compareTo(VersionNumber.decode("1.0")) > 0);

        assertEquals(0, VersionNumber.decode("1.1").compareTo(VersionNumber.decode("1.1")));

        assertEquals(0, VersionNumber.decode("1").compareTo(VersionNumber.decode("1.0.0")));
        assertEquals(0, VersionNumber.decode("1.0.0").compareTo(VersionNumber.decode("1")));

        assertTrue(VersionNumber.decode("1.0.0").compareTo(VersionNumber.decode("2")) < 0);
        assertTrue(VersionNumber.decode("2").compareTo(VersionNumber.decode("1.0.0")) > 0);

        assertTrue(VersionNumber.decode("1.1").compareTo(VersionNumber.decode("2")) < 0);
        assertTrue(VersionNumber.decode("2").compareTo(VersionNumber.decode("1.1")) > 0);

        assertTrue(VersionNumber.decode("1").compareTo(VersionNumber.decode("1.1")) < 0);
        assertTrue(VersionNumber.decode("1.1").compareTo(VersionNumber.decode("1")) > 0);

        assertTrue(VersionNumber.decode("2.1.1").compareTo(VersionNumber.decode("2.1")) > 0);
        assertTrue(VersionNumber.decode("2.1").compareTo(VersionNumber.decode("2.1.1")) < 0);

        assertTrue(VersionNumber.decode("2.1.1").compareTo(VersionNumber.decode("2.1.0")) > 0);
        assertTrue(VersionNumber.decode("2.1.0").compareTo(VersionNumber.decode("2.1.1")) < 0);

        assertTrue(VersionNumber.decode("2.2.2").compareTo(VersionNumber.decode("2.2.1")) > 0);
        assertTrue(VersionNumber.decode("2.2.1").compareTo(VersionNumber.decode("2.2.2")) < 0);

        // test toString()
        assertEquals("1.1.1", VersionNumber.decode("1.1.1").toString());
        assertEquals("1.0.0", new VersionNumber(1, null, null).toString());

        // test encode/decode
        assertEquals("2.3.4", VersionNumber.encode(VersionNumber.decode("2.3.4")));
    }
}