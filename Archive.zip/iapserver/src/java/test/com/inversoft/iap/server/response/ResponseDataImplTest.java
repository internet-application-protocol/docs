/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;

import junit.framework.TestCase;

import iap.response.DataScope;
import iap.response.ResponseData;

import com.inversoft.iap.DataBody;

/**
 * <p>
 * This class is a testcase for the response data impl.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class ResponseDataImplTest extends TestCase {
    /**
     * Constructs a new <code>ResponseDataImplTest</code> that executes the test with the given
     * name.
     *
     * @param   name The name of the test to run.
     */
    public ResponseDataImplTest(String name) {
        super(name);
    }


    public void testSetValueSimple() {
        DataBody db = new DataBody();
        ResponseData data = new ResponseDataImpl(db);
        data.setValue("myBoolean", Boolean.FALSE, Boolean.class, DataScope.APPLICATION);
        data.setValue("myByte", (byte) -1, Byte.class, DataScope.VIEW);
        data.setValue("myChar", '%', Character.class, DataScope.APPLICATION);
        data.setValue("myShort", (short) -128, Short.class, DataScope.APPLICATION);
        data.setValue("myInt", 1000001, Integer.class, DataScope.APPLICATION);
        data.setValue("myLong", 42000000042l, Long.class, DataScope.APPLICATION);
        data.setValue("myFloat", 3.141592f, Float.class, DataScope.APPLICATION);
        data.setValue("myDouble", 0.2, Double.class, DataScope.APPLICATION);
        data.setValue("myString", "IAP Rocks!", String.class, DataScope.APPLICATION);

        assertEquals(Boolean.FALSE, db.getValue("myBoolean"));
        assertEquals(DataScope.APPLICATION, db.getScope("myBoolean"));
        assertEquals((byte) -1, db.getValue("myByte"));
        assertEquals(DataScope.VIEW, db.getScope("myByte"));
        assertEquals('%', db.getValue("myChar"));
        assertEquals(DataScope.APPLICATION, db.getScope("myChar"));
        assertEquals((short) -128, db.getValue("myShort"));
        assertEquals(DataScope.APPLICATION, db.getScope("myShort"));
        assertEquals(1000001, db.getValue("myInt"));
        assertEquals(DataScope.APPLICATION, db.getScope("myInt"));
        assertEquals(42000000042l, db.getValue("myLong"));
        assertEquals(DataScope.APPLICATION, db.getScope("myLong"));
        assertEquals(3.141592f, db.getValue("myFloat"));
        assertEquals(DataScope.APPLICATION, db.getScope("myFloat"));
        assertEquals(0.2, db.getValue("myDouble"));
        assertEquals(DataScope.APPLICATION, db.getScope("myDouble"));
        assertEquals("IAP Rocks!", db.getValue("myString"));
        assertEquals(DataScope.APPLICATION, db.getScope("myString"));

        // Test arrays
        data.setValue("myIntArray", new int[]{1, 2, 3, 5}, int[].class, DataScope.APPLICATION);
        assertEquals(1, ((int[]) db.getValue("myIntArray"))[0]);
        assertEquals(2, ((int[]) db.getValue("myIntArray"))[1]);
        assertEquals(3, ((int[]) db.getValue("myIntArray"))[2]);
        assertEquals(5, ((int[]) db.getValue("myIntArray"))[3]);
        assertEquals(DataScope.APPLICATION, db.getScope("myIntArray"));
        assertEquals(1, db.getArrayDepth("myIntArray"));

        data.setValue("myStringArray", new String[][]{{"1", "2"}, {"3", null, "4"}, null}, String[][].class,
            DataScope.APPLICATION);
        assertEquals("1", ((String[][]) db.getValue("myStringArray"))[0][0]);
        assertEquals("2", ((String[][]) db.getValue("myStringArray"))[0][1]);
        assertEquals("3", ((String[][]) db.getValue("myStringArray"))[1][0]);
        assertNull(((String[][]) db.getValue("myStringArray"))[1][1]);
        assertEquals("4", ((String[][]) db.getValue("myStringArray"))[1][2]);
        assertNull(((String[][]) db.getValue("myStringArray"))[2]);
        assertEquals(DataScope.APPLICATION, db.getScope("myStringArray"));
        assertEquals(2, db.getArrayDepth("myStringArray"));
    }

    public void testSetValueComplex() {
        User user = new User();
        user.setMale(true);
        user.setAge(28);
        user.getAddress().setCity("Chicago");
        user.getAddress().setState("Illinois");

        DataBody db = new DataBody();
        ResponseData data = new ResponseDataImpl(db);
        data.setValue("user", user, User.class, DataScope.VIEW);

        assertTrue((Boolean) db.getValue("user.male"));
        assertEquals(DataScope.VIEW, db.getScope("user.male"));
        assertEquals(28, db.getValue("user.age"));
        assertEquals(DataScope.VIEW, db.getScope("user.age"));
        assertEquals("Chicago", db.getValue("user.address.city"));
        assertEquals(DataScope.VIEW, db.getScope("user.address.city"));
        assertEquals("Illinois", db.getValue("user.address.state"));
        assertEquals(DataScope.VIEW, db.getScope("user.address.state"));
    }

    public void testSetValueNullSimple() {
        DataBody db = new DataBody();
        ResponseData data = new ResponseDataImpl(db);
        data.setValue("myBoolean", null, Boolean.class, DataScope.APPLICATION);
        data.setValue("myByte", null, Byte.class, DataScope.VIEW);
        data.setValue("myChar", null, Character.class, DataScope.APPLICATION);
        data.setValue("myShort", null, Short.class, DataScope.APPLICATION);
        data.setValue("myInt", null, Integer.class, DataScope.APPLICATION);
        data.setValue("myLong", null, Long.class, DataScope.APPLICATION);
        data.setValue("myFloat", null, Float.class, DataScope.APPLICATION);
        data.setValue("myDouble", null, Double.class, DataScope.APPLICATION);
        data.setValue("myString", null, String.class, DataScope.APPLICATION);

        assertNull(db.getValue("myBoolean"));
        assertEquals(DataScope.APPLICATION, db.getScope("myBoolean"));
        assertNull(db.getValue("myByte"));
        assertEquals(DataScope.VIEW, db.getScope("myByte"));
        assertNull(db.getValue("myChar"));
        assertEquals(DataScope.APPLICATION, db.getScope("myChar"));
        assertNull(db.getValue("myShort"));
        assertEquals(DataScope.APPLICATION, db.getScope("myShort"));
        assertNull(db.getValue("myInt"));
        assertEquals(DataScope.APPLICATION, db.getScope("myInt"));
        assertNull(db.getValue("myLong"));
        assertEquals(DataScope.APPLICATION, db.getScope("myLong"));
        assertNull(db.getValue("myFloat"));
        assertEquals(DataScope.APPLICATION, db.getScope("myFloat"));
        assertNull(db.getValue("myDouble"));
        assertEquals(DataScope.APPLICATION, db.getScope("myDouble"));
        assertNull(db.getValue("myString"));
        assertEquals(DataScope.APPLICATION, db.getScope("myString"));
    }

    public void testSetValueNullComplex() {
        User user = new User();
        user.setMale(true);
        user.setAge(28);
        user.getAddress().setCity(null);
        user.getAddress().setState(null);

        DataBody db = new DataBody();
        ResponseData data = new ResponseDataImpl(db);
        data.setValue("user", user, User.class, DataScope.VIEW);

        assertTrue((Boolean) db.getValue("user.male"));
        assertEquals(DataScope.VIEW, db.getScope("user.male"));
        assertEquals(28, db.getValue("user.age"));
        assertEquals(DataScope.VIEW, db.getScope("user.age"));
        assertNull(db.getValue("user.address.city"));
        assertEquals(DataScope.VIEW, db.getScope("user.address.city"));
        assertNull(db.getValue("user.address.state"));
        assertEquals(DataScope.VIEW, db.getScope("user.address.state"));
    }
}