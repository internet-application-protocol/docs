/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.logging.Logger;
import java.util.logging.Level;

import junit.framework.TestCase;

import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import iap.VersionNumber;
import iap.request.ActionType;
import iap.request.DeviceType;
import iap.response.DataScope;
import iap.response.Rating;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataBody;
import com.inversoft.iap.DataType;
import com.inversoft.iap.request.VersionSpecification;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.ServerConfigBuilder;
import com.inversoft.iap.testhtml.TestAuthHandler;
import com.inversoft.iap.testhtml.TestHtmlActionHandler;
import com.inversoft.iap.transport.ActionInfo;
import com.inversoft.iap.transport.ApplicationInfo;
import com.inversoft.iap.transport.AuthenticateUserRequest;
import com.inversoft.iap.transport.AuthenticateUserResponse;
import com.inversoft.iap.transport.Certificate;
import com.inversoft.iap.transport.ClientConstraint;
import com.inversoft.iap.transport.ClientCredentials;
import com.inversoft.iap.transport.DataRequest;
import com.inversoft.iap.transport.DataRequestBody;
import com.inversoft.iap.transport.FetchDataRequest;
import com.inversoft.iap.transport.FetchDataResponse;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.OpenViewRequest;
import com.inversoft.iap.transport.OpenViewResponse;
import com.inversoft.iap.transport.PerformActionRequest;
import com.inversoft.iap.transport.PerformActionResponse;
import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.ReconnectSessionResponse;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.UserInfo;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.iap.transport.util.IAPTransportException;
import com.inversoft.iap.transport.util.TransportTools;
import com.inversoft.nio.ParseException;
import com.inversoft.nio.QueueFullException;

/**
 * <p>
 * This is a testcase for the IAPServer
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPServerTest extends TestCase {
    private static final boolean VALIDATE = true;

    /**
     * Constructs a new <code>IAPServerTest</code>.
     */
    public IAPServerTest(String name) {
        super(name);
    }

    public void testSimpleOpenApplicationTransaction() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
//        Logger.getLogger("com.sun.xml.bind").setLevel(Level.FINEST);
//        Logger.getLogger("javax.xml.bind").setLevel(Level.FINEST);
//        Logger.getLogger("com.inversoft.iap.xml").setLevel(Level.FINEST);

        System.setProperty("iap.server.config", "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        final IAPServer server = new IAPServer(serverConfig);

        Thread.sleep(100);

        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the open application request
        OpenApplicationRequest request = new OpenApplicationRequest();
        request.setApplicationInfo(new ApplicationInfo());
        request.getApplicationInfo().setApplicationId("test-app1");
        request.getApplicationInfo().setVersionNumber(VersionNumber.decode("1.0.1"));
        request.setClientConstraint(new ClientConstraint());
        request.getClientConstraint().setDeviceConstraint(DeviceType.DESKTOP);
        request.getClientConstraint().setProtocolConstraint(new VersionSpecification(1));
        request.getClientConstraint().setMaximumRating(Rating.M);

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote");

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        OpenApplicationResponse res = (OpenApplicationResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read");
        assertTrue(res.getSuccessGroup().getApplicationDescription().isIsCacheable());
        assertEquals(Rating.M, res.getSuccessGroup().getRatingInfo().getRating());
        assertEquals("1.0", res.getStatus().getCode());
        assertEquals("index.iapl", res.getSuccessGroup().getViewInfo().getViewId());

        // send the open view request
        OpenViewRequest viewReq = new OpenViewRequest();
        viewReq.setSessionId(res.getSuccessGroup().getSessionId());
        viewReq.setViewInfo(res.getSuccessGroup().getViewInfo());

        TransportTools.serialize(viewReq, os, VALIDATE);
        os.flush();
        System.out.println("Wrote viewReq");

        OpenViewResponse resView = (OpenViewResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read viewReq");
        ByteBuffer expected = ByteBuffer.wrap("Test IAPL file".getBytes());
        assertNotNull(resView.getViewBody().getViewData());
        assertEquals(expected, resView.getViewBody().getViewData().getValue());

        // send the fetch data request
        FetchDataRequest dataReq = new FetchDataRequest();
        dataReq.setSessionId(res.getSuccessGroup().getSessionId());
        dataReq.setDataRequestBody(new DataRequestBody());
        DataRequest dataRequest1 = new DataRequest();
        dataRequest1.setName("data1");
        DataRequest dataRequest2 = new DataRequest();
        dataRequest2.setName("data2");
        dataReq.getDataRequestBody().getDataRequest().add(dataRequest1);
        dataReq.getDataRequestBody().getDataRequest().add(dataRequest2);

        TransportTools.serialize(dataReq, os, VALIDATE);
        os.flush();
        System.out.println("Wrote dataReq");

        FetchDataResponse resData = (FetchDataResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read resData");
        assertEquals(2, resData.getDataBody().getAllData().size());
        assertEquals(0, resData.getDataBody().getAllData().get(0).getArrayDepth());
        assertEquals("data1", resData.getDataBody().getAllData().get(0).getKey());
        assertEquals(DataScope.APPLICATION, resData.getDataBody().getAllData().get(0).getScope());
        assertEquals(DataType.STRING, resData.getDataBody().getAllData().get(0).getType());
        assertEquals("value1", resData.getDataBody().getAllData().get(0).getValue());

        assertEquals(0, resData.getDataBody().getAllData().get(1).getArrayDepth());
        assertEquals("data2", resData.getDataBody().getAllData().get(1).getKey());
        assertEquals(DataScope.VIEW, resData.getDataBody().getAllData().get(1).getScope());
        assertEquals(DataType.STRING, resData.getDataBody().getAllData().get(1).getType());
        assertEquals("value2", resData.getDataBody().getAllData().get(1).getValue());

        // Close it all down
        //Thread.sleep(2000);
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    public void testWrongOpenApplicationTransaction() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
//        Logger.getLogger("com.inversoft.nio").setLevel(Level.FINEST);
//        Logger.getLogger("com.inversoft.iap.xml").setLevel(Level.FINEST);

        System.setProperty("iap.server.config", "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        final IAPServer server = new IAPServer(serverConfig);

        Thread.sleep(100);

        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the open application request
        OpenApplicationRequest request = new OpenApplicationRequest();
        request.setApplicationInfo(new ApplicationInfo());
        request.getApplicationInfo().setApplicationId("test-app1");
        request.getApplicationInfo().setVersionNumber(VersionNumber.decode("2.0.1"));
        request.setClientConstraint(new ClientConstraint());
        request.getClientConstraint().setDeviceConstraint(DeviceType.DESKTOP);
        request.getClientConstraint().setProtocolConstraint(new VersionSpecification(1));
        request.getClientConstraint().setMaximumRating(Rating.M);

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote");

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        OpenApplicationResponse res = (OpenApplicationResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read");
        assertEquals("2.1", res.getStatus().getCode());
        assertEquals("1.0.1", res.getStatus().getValue());

        // Send the open application request
        request.getApplicationInfo().setVersionNumber(VersionNumber.decode("1.0.1"));

        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote second");

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        res = (OpenApplicationResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read second");
        assertTrue(res.getSuccessGroup().getApplicationDescription().isIsCacheable());
        assertEquals(Rating.M, res.getSuccessGroup().getRatingInfo().getRating());
        assertEquals("1.0", res.getStatus().getCode());
        assertEquals("index.iapl", res.getSuccessGroup().getViewInfo().getViewId());

        OpenViewRequest viewReq = new OpenViewRequest();
        viewReq.setSessionId(res.getSuccessGroup().getSessionId());
        viewReq.setViewInfo(res.getSuccessGroup().getViewInfo());

        TransportTools.serialize(viewReq, os, VALIDATE);
        os.flush();
        System.out.println("Wrote viewReq");

        OpenViewResponse resView = (OpenViewResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read viewReq");
        ByteBuffer expected = ByteBuffer.wrap("Test IAPL file".getBytes());
        assertNotNull(resView.getViewBody().getViewData());
        assertEquals(expected, resView.getViewBody().getViewData().getValue());

        FetchDataRequest dataReq = new FetchDataRequest();
        dataReq.setSessionId(res.getSuccessGroup().getSessionId());
        dataReq.setDataRequestBody(new DataRequestBody());
        DataRequest dataRequest1 = new DataRequest();
        dataRequest1.setName("data1");
        DataRequest dataRequest2 = new DataRequest();
        dataRequest2.setName("data2");
        dataReq.getDataRequestBody().getDataRequest().add(dataRequest1);
        dataReq.getDataRequestBody().getDataRequest().add(dataRequest2);

        TransportTools.serialize(dataReq, os, VALIDATE);
        os.flush();
        System.out.println("Wrote dataReq");

        FetchDataResponse resData = (FetchDataResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read resData");
        assertEquals(2, resData.getDataBody().getAllData().size());
        assertEquals(0, resData.getDataBody().getAllData().get(0).getArrayDepth());
        assertEquals("data1", resData.getDataBody().getAllData().get(0).getKey());
        assertEquals(DataScope.APPLICATION, resData.getDataBody().getAllData().get(0).getScope());
        assertEquals(DataType.STRING, resData.getDataBody().getAllData().get(0).getType());
        assertEquals("value1", resData.getDataBody().getAllData().get(0).getValue());

        assertEquals(0, resData.getDataBody().getAllData().get(1).getArrayDepth());
        assertEquals("data2", resData.getDataBody().getAllData().get(1).getKey());
        assertEquals(DataScope.VIEW, resData.getDataBody().getAllData().get(1).getScope());
        assertEquals(DataType.STRING, resData.getDataBody().getAllData().get(1).getType());
        assertEquals("value2", resData.getDataBody().getAllData().get(1).getValue());

        // Close it all down
        //Thread.sleep(2000);
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    public void testNonExistant() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
//        Logger.getLogger("com.inversoft.nio").setLevel(Level.FINEST);
//        Logger.getLogger("com.inversoft.iap.xml").setLevel(Level.FINEST);

        System.setProperty("iap.server.config", "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        final IAPServer server = new IAPServer(serverConfig);

        Thread.sleep(100);

        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the open application request
        OpenApplicationRequest request = new OpenApplicationRequest();
        request.setApplicationInfo(new ApplicationInfo());
        request.getApplicationInfo().setApplicationId("non-existant");
        request.getApplicationInfo().setVersionNumber(VersionNumber.decode("1.0.1"));
        request.setClientConstraint(new ClientConstraint());
        request.getClientConstraint().setDeviceConstraint(DeviceType.DESKTOP);
        request.getClientConstraint().setProtocolConstraint(new VersionSpecification(1));
        request.getClientConstraint().setMaximumRating(Rating.M);

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote");

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        OpenApplicationResponse res = (OpenApplicationResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read");
        assertEquals("2.3", res.getStatus().getCode());

        // Close it all down
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    public void testNoDefault() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
//        Logger.getLogger("com.inversoft.nio").setLevel(Level.FINEST);
//        Logger.getLogger("com.inversoft.iap.xml").setLevel(Level.FINEST);

        System.setProperty("iap.server.config", "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        final IAPServer server = new IAPServer(serverConfig);

        Thread.sleep(100);

        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the open application request
        OpenApplicationRequest request = new OpenApplicationRequest();
        request.setApplicationInfo(new ApplicationInfo());
        request.getApplicationInfo().setApplicationId("");
        request.setClientConstraint(new ClientConstraint());
        request.getClientConstraint().setDeviceConstraint(DeviceType.DESKTOP);
        request.getClientConstraint().setProtocolConstraint(new VersionSpecification(1));
        request.getClientConstraint().setMaximumRating(Rating.M);

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote");

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        OpenApplicationResponse res = (OpenApplicationResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read");
        assertEquals("2.3", res.getStatus().getCode());

        // Close it all down
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    public void testSimplePerformActionTransaction() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
//        Logger.getLogger("com.inversoft.nio").setLevel(Level.FINEST);
//        Logger.getLogger("com.inversoft.iap.xml").setLevel(Level.FINEST);

        System.setProperty("iap.server.config", "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        IAPServer server = new IAPServer(serverConfig);
        SessionId sessionId = openApplication();
        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the open application request
        PerformActionRequest request = new PerformActionRequest();
        request.setActionInfo(new ActionInfo());
        request.getActionInfo().setActionId("submit");
        request.getActionInfo().setActionType(ActionType.SYNCHRONOUS);
        request.setDataBody(new DataBody());
        request.getDataBody().addData(new Data("field1", Boolean.TRUE, DataType.BOOLEAN, 0, DataScope.VIEW));
        request.setSessionId(sessionId);
        request.setViewInfo(new ViewInfo());
        request.getViewInfo().setViewId("index.iapl");

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote");

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        PerformActionResponse res = (PerformActionResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read");
        assertTrue(TestHtmlActionHandler.called);
        assertEquals(2, res.getDataBody().getAllData().size());
        assertEquals(0, res.getDataBody().getAllData().get(0).getArrayDepth());
        assertEquals("result1", res.getDataBody().getAllData().get(0).getKey());
        assertEquals(DataScope.VIEW, res.getDataBody().getAllData().get(0).getScope());
        assertEquals(DataType.STRING, res.getDataBody().getAllData().get(0).getType());
        assertEquals("foo", res.getDataBody().getAllData().get(0).getValue());

        assertEquals(0, res.getDataBody().getAllData().get(1).getArrayDepth());
        assertEquals("result2", res.getDataBody().getAllData().get(1).getKey());
        assertEquals(DataScope.VIEW, res.getDataBody().getAllData().get(1).getScope());
        assertEquals(DataType.STRING, res.getDataBody().getAllData().get(1).getType());
        assertEquals("bar", res.getDataBody().getAllData().get(1).getValue());

        OpenViewRequest viewReq = new OpenViewRequest();
        viewReq.setSessionId(sessionId);
        viewReq.setViewInfo(new ViewInfo());
        viewReq.getViewInfo().setViewId("results.iapl");

        TransportTools.serialize(viewReq, os, VALIDATE);
        os.flush();
        System.out.println("Wrote viewReq");

        OpenViewResponse resView = (OpenViewResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read viewReq");
        ByteBuffer expected = ByteBuffer.wrap("Results IAPL file".getBytes());
        assertNotNull(resView.getViewBody().getViewData());
        assertEquals(expected, resView.getViewBody().getViewData().getValue());

        FetchDataRequest dataReq = new FetchDataRequest();
        dataReq.setSessionId(sessionId);
        dataReq.setDataRequestBody(new DataRequestBody());
        DataRequest dataRequest1 = new DataRequest();
        dataRequest1.setName("data1");
        DataRequest dataRequest2 = new DataRequest();
        dataRequest2.setName("data2");
        dataReq.getDataRequestBody().getDataRequest().add(dataRequest1);
        dataReq.getDataRequestBody().getDataRequest().add(dataRequest2);

        TransportTools.serialize(dataReq, os, VALIDATE);
        os.flush();
        System.out.println("Wrote dataReq");

        FetchDataResponse resData = (FetchDataResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read resData");
        assertEquals(2, resData.getDataBody().getAllData().size());
        assertEquals(0, resData.getDataBody().getAllData().get(0).getArrayDepth());
        assertEquals("data1", resData.getDataBody().getAllData().get(0).getKey());
        assertEquals(DataScope.APPLICATION, resData.getDataBody().getAllData().get(0).getScope());
        assertEquals(DataType.STRING, resData.getDataBody().getAllData().get(0).getType());
        assertEquals("value1", resData.getDataBody().getAllData().get(0).getValue());

        assertEquals(0, resData.getDataBody().getAllData().get(1).getArrayDepth());
        assertEquals("data2", resData.getDataBody().getAllData().get(1).getKey());
        assertEquals(DataScope.VIEW, resData.getDataBody().getAllData().get(1).getScope());
        assertEquals(DataType.STRING, resData.getDataBody().getAllData().get(1).getType());
        assertEquals("value2", resData.getDataBody().getAllData().get(1).getValue());

        // Close it all down
        //Thread.sleep(2000);
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    public void testDataTransaction() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
//        Logger.getLogger("com.inversoft.nio").setLevel(Level.FINEST);
//        Logger.getLogger("com.inversoft.iap.xml").setLevel(Level.FINEST);

        System.setProperty("iap.server.config", "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        IAPServer server = new IAPServer(serverConfig);
        SessionId sessionId = openApplication();
        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the fetch data request
        FetchDataRequest request = new FetchDataRequest();
        request.setSessionId(sessionId);
        request.setDataRequestBody(new DataRequestBody());
        DataRequest dr1 = new DataRequest();
        dr1.setName("data1");
        request.getDataRequestBody().getDataRequest().add(dr1);

        DataRequest dr2 = new DataRequest();
        dr2.setName("data2");
        request.getDataRequestBody().getDataRequest().add(dr2);

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote");

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        FetchDataResponse resData = (FetchDataResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read");
        assertEquals(2, resData.getDataBody().getAllData().size());
        assertEquals(0, resData.getDataBody().getAllData().get(0).getArrayDepth());
        assertEquals("data1", resData.getDataBody().getAllData().get(0).getKey());
        assertEquals(DataScope.APPLICATION, resData.getDataBody().getAllData().get(0).getScope());
        assertEquals(DataType.STRING, resData.getDataBody().getAllData().get(0).getType());
        assertEquals("value1", resData.getDataBody().getAllData().get(0).getValue());

        assertEquals(0, resData.getDataBody().getAllData().get(1).getArrayDepth());
        assertEquals("data2", resData.getDataBody().getAllData().get(1).getKey());
        assertEquals(DataScope.VIEW, resData.getDataBody().getAllData().get(1).getScope());
        assertEquals(DataType.STRING, resData.getDataBody().getAllData().get(1).getType());
        assertEquals("value2", resData.getDataBody().getAllData().get(1).getValue());

        // Close it all down
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    public void testAuthTransaction() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
//        Logger.getLogger("com.inversoft.nio").setLevel(Level.FINEST);
//        Logger.getLogger("com.inversoft.iap.xml").setLevel(Level.FINEST);

        System.setProperty("iap.server.config", "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        IAPServer server = new IAPServer(serverConfig);
        SessionId sessionId = openApplication();
        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the open application request
        AuthenticateUserRequest request = new AuthenticateUserRequest();
        request.setSessionId(sessionId);
        request.setUserInfo(new UserInfo());
        request.getUserInfo().setUsername("ponch");
        request.getUserInfo().setPassword("password123");

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote");

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        AuthenticateUserResponse res = (AuthenticateUserResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read");
        assertTrue(TestAuthHandler.called);
        assertEquals(2, res.getDataBody().getAllData().size());
        assertEquals(0, res.getDataBody().getAllData().get(0).getArrayDepth());
        assertEquals("flag", res.getDataBody().getAllData().get(0).getKey());
        assertEquals(DataScope.VIEW, res.getDataBody().getAllData().get(0).getScope());
        assertEquals(DataType.BOOLEAN, res.getDataBody().getAllData().get(0).getType());
        assertEquals(Boolean.TRUE, res.getDataBody().getAllData().get(0).getValue());

        assertEquals(0, res.getDataBody().getAllData().get(1).getArrayDepth());
        assertEquals("age", res.getDataBody().getAllData().get(1).getKey());
        assertEquals(DataScope.VIEW, res.getDataBody().getAllData().get(1).getScope());
        assertEquals(DataType.INT, res.getDataBody().getAllData().get(1).getType());
        assertEquals(42, res.getDataBody().getAllData().get(1).getValue());

        // Close it all down
        //Thread.sleep(2000);
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    public void testReconnectSessionTransaction() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
        System.setProperty("iap.server.config",
                "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        IAPServer server = new IAPServer(serverConfig);
        SessionId sessionId = openApplication();
        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the open application request
        ReconnectSessionRequest request = new ReconnectSessionRequest();
        request.setSessionId(sessionId);
        request.setClientCredentials(new ClientCredentials());
        request.getClientCredentials().setCertificate(new Certificate());
        request.getClientCredentials().getCertificate().setDateCreated(XMLGregorianCalendarImpl.parse("2004-08-13"));
        request.getClientCredentials().getCertificate().setDateExpires(XMLGregorianCalendarImpl.parse("2006-08-13"));
        request.getClientCredentials().getCertificate().setValue("Cert");

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();
        System.out.println("Wrote " + request.getType().toString());

        assertTrue(sc.isConnected());
        assertTrue(sc.isBound());
        assertFalse(sc.isInputShutdown());
        assertFalse(sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        ReconnectSessionResponse res = (ReconnectSessionResponse) TransportTools.handle(is, VALIDATE);
        System.out.println("Read " + res.getType().toString());

        // Close it all down
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    public void testBadMessage() throws IOException, InterruptedException, QueueFullException, ParseException, IAPTransportException {
        Logger.getLogger("com.inversoft.nio.NIOServer").setLevel(Level.ALL);

        System.setProperty("iap.server.config", "src/java/test/com/inversoft/iap/server/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        final IAPServer server = new IAPServer(serverConfig);

        Thread.sleep(100);

        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send some bad junk across the wire
        OutputStream os = sc.getOutputStream();
        byte[] ba = new byte[100];
        for (int i = 0; i < ba.length; i++) {
            ba[i] = 0;
        }

        os.write(ba);
        os.flush();

        Thread.sleep(500);
        System.out.println("cs conencted " + sc.isConnected());
        System.out.println("cs closed " + sc.isClosed());
        System.out.println("cs input " + sc.isInputShutdown());
        System.out.println("cs output " + sc.isOutputShutdown());

        InputStream is = sc.getInputStream();
        try {
            int i = is.read();
            assertEquals(-1, i);
        } catch (IOException e) {
            fail("Shouldn't have failed to read");
        }

        System.out.println("cs conencted " + sc.isConnected());
        System.out.println("cs closed " + sc.isClosed());
        System.out.println("cs input " + sc.isInputShutdown());
        System.out.println("cs output " + sc.isOutputShutdown());

        // Close it all down
        sc.close();
        os.close();
        is.close();

        Thread.sleep(1000);
        server.shutdown();

        Thread.sleep(100);
    }

    private SessionId openApplication() throws IOException, InterruptedException, IAPTransportException {
        Thread.sleep(100);

        InetAddress addr = InetAddress.getLocalHost();
        Socket sc = new Socket(addr, 8080);

        // Send the open application request
        OpenApplicationRequest request = new OpenApplicationRequest();
        request.setApplicationInfo(new ApplicationInfo());
        request.getApplicationInfo().setApplicationId("test-app1");
        request.getApplicationInfo().setVersionNumber(VersionNumber.decode("1.0.1"));
        request.setClientConstraint(new ClientConstraint());
        request.getClientConstraint().setDeviceConstraint(DeviceType.DESKTOP);
        request.getClientConstraint().setProtocolConstraint(new VersionSpecification(1));
        request.getClientConstraint().setMaximumRating(Rating.M);

        OutputStream os = sc.getOutputStream();
        TransportTools.serialize(request, os, VALIDATE);
        os.flush();

        InputStream is = sc.getInputStream();
        OpenApplicationResponse res = (OpenApplicationResponse) TransportTools.handle(is, VALIDATE);

        os.close();
        is.close();
        sc.close();
        return res.getSuccessGroup().getSessionId();
    }
}