/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.handler;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.config.ApplicationConfig;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ConfigurationException;
import com.inversoft.iap.server.config.HandlerConfig;
import com.inversoft.iap.server.config.RegexHandlerConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.ViewActionHandlerConfig;
import com.inversoft.iap.server.config.jaxb.ServerBind;

/**
 * <p>
 * This class is a test case for the IAPHandlerManager.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPHandlerManagerTest extends TestCase {
    /**
     * Constructs a new <code>IAPHandlerManagerTest</code>.
     */
    public IAPHandlerManagerTest(String name) {
        super(name);
    }

    public void testFetchHandler() throws ConfigurationException {
        Map<String, String> params = new HashMap<String, String>();
        params.put("test1", "value1");
        params.put("test2", "value2");

        VersionNumber ver = VersionNumber.decode("1.0.0");
        ApplicationDeploymentConfig adc = makeADC(params, ver, "test");
        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);

        ServerBind info = new ServerBind();
        info.setName("server1");
        info.setPort(80);
        ServerConfig sc = new ServerConfig(apps, info);
        IAPHandlerManager rhm = new IAPHandlerManager(sc);
        TestAuthenticateUserHandler ah = (TestAuthenticateUserHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "auth");
        assertNotNull(ah);
        assertTrue(ah.created);
        TestCloseApplicationHandler ch = (TestCloseApplicationHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "close");
        assertNotNull(ch);
        assertTrue(ah.created);
        TestFetchDataHandler dh = (TestFetchDataHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "data");
        assertNotNull(dh);
        assertTrue(ah.created);
        TestFetchModuleHandler1 mh1 = (TestFetchModuleHandler1) rhm.fetchHandler(new ApplicationKey("test", ver), "module1");
        assertNotNull(mh1);
        assertTrue(ah.created);
        TestFetchModuleHandler2 mh2 = (TestFetchModuleHandler2) rhm.fetchHandler(new ApplicationKey("test", ver), "module2");
        assertNotNull(mh2);
        assertTrue(ah.created);
        TestOpenApplicationHandler oh = (TestOpenApplicationHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "app");
        assertNotNull(oh);
        assertTrue(ah.created);
        TestOpenViewHandler1 vh1 = (TestOpenViewHandler1) rhm.fetchHandler(new ApplicationKey("test", ver), "view1");
        assertNotNull(vh1);
        assertTrue(ah.created);
        TestOpenViewHandler2 vh2 = (TestOpenViewHandler2) rhm.fetchHandler(new ApplicationKey("test", ver), "view2");
        assertNotNull(vh2);
        assertTrue(ah.created);
        TestPerformActionHandler1 ph1 = (TestPerformActionHandler1) rhm.fetchHandler(new ApplicationKey("test", ver), "action1");
        assertNotNull(ph1);
        assertTrue(ah.created);
        TestPerformActionHandler2 ph2 = (TestPerformActionHandler2) rhm.fetchHandler(new ApplicationKey("test", ver), "action2");
        assertNotNull(ph2);
        assertTrue(ah.created);
        TestReconnectSessionHandler rs = (TestReconnectSessionHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "reconnect");
        assertNotNull(rs);
        assertTrue(ah.created);
    }

    public void testMultipleApps() throws ConfigurationException {
        Map<String, String> params = new HashMap<String, String>();
        params.put("test1", "value1");
        params.put("test2", "value2");
        VersionNumber ver = VersionNumber.decode("1.0.0");
        ApplicationDeploymentConfig adc = makeADC(params, ver, "test");

        Map<String, String> params2 = new HashMap<String, String>();
        params2.put("test1-2", "value1-2");
        params2.put("test2-2", "value2-2");
        VersionNumber ver2 = VersionNumber.decode("1.0.2");
        ApplicationDeploymentConfig adc2 = makeADC2(params2, ver2, "test2");

        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);
        apps.add(adc2);

        ServerBind info = new ServerBind();
        info.setName("server1");
        info.setPort(80);
        ServerConfig sc = new ServerConfig(apps, info);
        IAPHandlerManager rhm = new IAPHandlerManager(sc);
        TestAuthenticateUserHandler ah = (TestAuthenticateUserHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "auth");
        assertNotNull(ah);
        assertTrue(ah.created);
        TestCloseApplicationHandler ch = (TestCloseApplicationHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "close");
        assertNotNull(ch);
        assertTrue(ch.created);
        TestFetchDataHandler dh = (TestFetchDataHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "data");
        assertNotNull(dh);
        assertTrue(dh.created);
        TestFetchModuleHandler1 mh1 = (TestFetchModuleHandler1) rhm.fetchHandler(new ApplicationKey("test", ver), "module1");
        assertNotNull(mh1);
        assertTrue(mh1.created);
        TestFetchModuleHandler2 mh2 = (TestFetchModuleHandler2) rhm.fetchHandler(new ApplicationKey("test", ver), "module2");
        assertNotNull(mh2);
        assertTrue(mh2.created);
        TestOpenApplicationHandler oh = (TestOpenApplicationHandler) rhm.fetchHandler(new ApplicationKey("test", ver), "app");
        assertNotNull(oh);
        assertTrue(oh.created);
        TestOpenViewHandler1 vh1 = (TestOpenViewHandler1) rhm.fetchHandler(new ApplicationKey("test", ver), "view1");
        assertNotNull(vh1);
        assertTrue(vh1.created);
        TestOpenViewHandler2 vh2 = (TestOpenViewHandler2) rhm.fetchHandler(new ApplicationKey("test", ver), "view2");
        assertNotNull(vh2);
        assertTrue(vh2.created);
        TestPerformActionHandler1 ph1 = (TestPerformActionHandler1) rhm.fetchHandler(new ApplicationKey("test", ver), "action1");
        assertNotNull(ph1);
        assertTrue(ph1.created);
        TestPerformActionHandler2 ph2 = (TestPerformActionHandler2) rhm.fetchHandler(new ApplicationKey("test", ver), "action2");
        assertNotNull(ph2);
        assertTrue(ph2.created);

        TestAuthenticateUserHandler_2 ah_2 = (TestAuthenticateUserHandler_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "auth");
        assertNotNull(ah_2);
        assertTrue(ah_2.created);
        TestCloseApplicationHandler_2 ch_2= (TestCloseApplicationHandler_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "close");
        assertNotNull(ch_2);
        assertTrue(ch_2.created);
        TestFetchDataHandler_2 dh_2 = (TestFetchDataHandler_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "data");
        assertNotNull(dh_2);
        assertTrue(dh_2.created);
        TestFetchModuleHandler1_2 mh1_2 = (TestFetchModuleHandler1_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "module1");
        assertNotNull(mh1_2);
        assertTrue(mh1_2.created);
        TestFetchModuleHandler2_2 mh2_2 = (TestFetchModuleHandler2_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "module2");
        assertNotNull(mh2_2);
        assertTrue(mh2_2.created);
        TestOpenApplicationHandler_2 oh_2 = (TestOpenApplicationHandler_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "app");
        assertNotNull(oh_2);
        assertTrue(oh_2.created);
        TestOpenViewHandler1_2 vh1_2 = (TestOpenViewHandler1_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "view1");
        assertNotNull(vh1_2);
        assertTrue(vh1_2.created);
        TestOpenViewHandler2_2 vh2_2 = (TestOpenViewHandler2_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "view2");
        assertNotNull(vh2_2);
        assertTrue(vh2_2.created);
        TestPerformActionHandler1_2 ph1_2 = (TestPerformActionHandler1_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "action1");
        assertNotNull(ph1_2);
        assertTrue(ph1_2.created);
        TestPerformActionHandler2_2 ph2_2 = (TestPerformActionHandler2_2) rhm.fetchHandler(new ApplicationKey("test2", ver2), "action2");
        assertNotNull(ph2_2);
        assertTrue(ph2_2.created);
    }

    private ApplicationDeploymentConfig makeADC(Map<String, String> params, VersionNumber ver, String name) throws ConfigurationException {
        HandlerConfig authConfig = new HandlerConfig("auth", TestAuthenticateUserHandler.class, false, params);
        HandlerConfig closeConfig = new HandlerConfig("close", TestCloseApplicationHandler.class, false, params);
        HandlerConfig appConfig = new HandlerConfig("app", TestOpenApplicationHandler.class, false, params);
        HandlerConfig reconnectConfig = new HandlerConfig("reconnect",
                TestReconnectSessionHandler.class, false, params);
        HandlerConfig dataConfig = new HandlerConfig("data", TestFetchDataHandler.class, false, params);

        Set<RegexHandlerConfig> moduleConfigs = new HashSet<RegexHandlerConfig>();
        moduleConfigs.add(new RegexHandlerConfig("module1", TestFetchModuleHandler1.class, false, params, "[ab]c"));
        moduleConfigs.add(new RegexHandlerConfig("module2", TestFetchModuleHandler2.class, false, params, "[12]3"));

        Set<RegexHandlerConfig> viewConfigs = new HashSet<RegexHandlerConfig>();
        viewConfigs.add(new RegexHandlerConfig("view1", TestOpenViewHandler1.class, false, params, "[de]f"));
        viewConfigs.add(new RegexHandlerConfig("view2", TestOpenViewHandler2.class, false, params, "[45]6"));

        Set<ViewActionHandlerConfig> actionConfigs = new HashSet<ViewActionHandlerConfig>();
        actionConfigs.add(new ViewActionHandlerConfig("action1", TestPerformActionHandler1.class, false, params, "[ab]c", "[de]f"));
        actionConfigs.add(new ViewActionHandlerConfig("action2", TestPerformActionHandler2.class, false, params, "[12]3", "[45]6"));

        ApplicationConfig ac = new ApplicationConfig(authConfig, closeConfig, dataConfig, appConfig,
            moduleConfigs, viewConfigs, actionConfigs, Thread.currentThread().getContextClassLoader(),
            "viewId", ver, Rating.M, 1800000, reconnectConfig);
        return new ApplicationDeploymentConfig(name, new File("."), ac);
    }

    private ApplicationDeploymentConfig makeADC2(Map<String, String> params, VersionNumber ver, String name) throws ConfigurationException {
        HandlerConfig authConfig = new HandlerConfig("auth", TestAuthenticateUserHandler_2.class, false, params);
        HandlerConfig closeConfig = new HandlerConfig("close", TestCloseApplicationHandler_2.class, false, params);
        HandlerConfig appConfig = new HandlerConfig("app", TestOpenApplicationHandler_2.class, false, params);
        HandlerConfig dataConfig = new HandlerConfig("data", TestFetchDataHandler_2.class, false, params);
        HandlerConfig reconnectConfig = new HandlerConfig("reconnect",
                TestReconnectSessionHandler.class, false, params);

        Set<RegexHandlerConfig> moduleConfigs = new HashSet<RegexHandlerConfig>();
        moduleConfigs.add(new RegexHandlerConfig("module1", TestFetchModuleHandler1_2.class, false, params, "[ab]c"));
        moduleConfigs.add(new RegexHandlerConfig("module2", TestFetchModuleHandler2_2.class, false, params, "[12]3"));

        Set<RegexHandlerConfig> viewConfigs = new HashSet<RegexHandlerConfig>();
        viewConfigs.add(new RegexHandlerConfig("view1", TestOpenViewHandler1_2.class, false, params, "[de]f"));
        viewConfigs.add(new RegexHandlerConfig("view2", TestOpenViewHandler2_2.class, false, params, "[45]6"));

        Set<ViewActionHandlerConfig> actionConfigs = new HashSet<ViewActionHandlerConfig>();
        actionConfigs.add(new ViewActionHandlerConfig("action1", TestPerformActionHandler1_2.class, false, params, "[ab]c", "[de]f"));
        actionConfigs.add(new ViewActionHandlerConfig("action2", TestPerformActionHandler2_2.class, false, params, "[12]3", "[45]6"));

        ApplicationConfig ac = new ApplicationConfig(authConfig, closeConfig, dataConfig, appConfig,
            moduleConfigs, viewConfigs, actionConfigs, Thread.currentThread().getContextClassLoader(),
            "viewId", ver, Rating.M, 1800000, reconnectConfig);
        return new ApplicationDeploymentConfig(name, new File("."), ac);
    }
}