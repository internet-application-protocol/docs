/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import java.util.List;

import iap.handler.GenericIAPHandler;
import iap.handler.IAPHandlerException;
import iap.request.FetchDataRequest;
import iap.response.DataScope;
import iap.response.FetchDataResponse;

/**
 * <p>
 * This class is a test handler for fetching data.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class TestFetchDataHandler extends GenericIAPHandler {
    public void doFetchData(FetchDataRequest request, FetchDataResponse response) throws IAPHandlerException {
        List<String> names = request.getDataNames();
        for (String name : names) {
            response.getResponseData().setValue(name, "name is " + name, String.class, DataScope.APPLICATION);
        }
    }
}