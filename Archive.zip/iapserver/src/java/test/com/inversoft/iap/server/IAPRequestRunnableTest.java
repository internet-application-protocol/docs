/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import javax.xml.bind.JAXBException;

import junit.framework.TestCase;

import iap.VersionNumber;
import iap.request.DeviceType;
import iap.response.Rating;

import com.inversoft.iap.IAPTransactionManager;
import com.inversoft.iap.request.VersionSpecification;
import com.inversoft.iap.server.config.ApplicationConfig;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ConfigurationException;
import com.inversoft.iap.server.config.HandlerConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.jaxb.ServerBind;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.ApplicationDescription;
import com.inversoft.iap.transport.ApplicationInfo;
import com.inversoft.iap.transport.ClientConstraint;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.RatingInfo;
import com.inversoft.iap.transport.Status;
import com.inversoft.iap.transport.SuccessGroup;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.iap.transport.util.TransportTools;
import com.inversoft.iap.transport.util.IAPTransportException;
import com.inversoft.nio.ParseException;
import com.inversoft.nio.NIOCallback;

/**
 * <p>
 * This tests the IAP request runnable.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPRequestRunnableTest extends TestCase {
    /**
     * Constructs a new <code>IAPRequestRunnableTest</code>.
     */
    public IAPRequestRunnableTest(String name) {
        super(name);
    }

    public void testOpenApplication() throws ParseException, IOException, ConfigurationException, JAXBException, IAPTransportException {
        IAPTransactionManager tm = new IAPTransactionManager();
        String tid = tm.createTransactionID();

        OpenApplicationRequest request = new OpenApplicationRequest();
        request.setApplicationInfo(new ApplicationInfo());
        request.getApplicationInfo().setApplicationId("test-app");
        request.getApplicationInfo().setVersionNumber(VersionNumber.decode("1.0.1"));
        request.setClientConstraint(new ClientConstraint());
        request.getClientConstraint().setDeviceConstraint(DeviceType.DESKTOP);
        request.getClientConstraint().setProtocolConstraint(new VersionSpecification(1));
        request.getClientConstraint().setMaximumRating(Rating.M);

        ByteArrayOutputStream os = new ByteArrayOutputStream();
        TransportTools.serialize(request, os, false);

        HandlerConfig hc = new HandlerConfig("handler", TestOpenApplicationHandler.class, false,
            new HashMap<String, String>());
        ApplicationConfig ac = new ApplicationConfig(null, null, null, hc, null, null, null,
            Thread.currentThread().getContextClassLoader(), null, VersionNumber.decode("1.0.1"),
            Rating.M, 1800000, null);
        ApplicationDeploymentConfig adc = new ApplicationDeploymentConfig("test-app", new File("."), ac);
        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);
        ServerBind info = new ServerBind();
        info.setExecuteThreads(10);
        info.setName("test-server");
        info.setPort(80);
        info.setQueueSize(10);
        info.setSelectTimeout(10);
        info.setTimeout(10);
        ServerConfig sc = new ServerConfig(apps, info);

        OpenApplicationResponse response = new OpenApplicationResponse();
        response.setSuccessGroup(new SuccessGroup());
        response.getSuccessGroup().setApplicationDescription(new ApplicationDescription());
        response.getSuccessGroup().getApplicationDescription().setIsCacheable(true);
        response.getSuccessGroup().setRatingInfo(new RatingInfo());
        response.getSuccessGroup().getRatingInfo().setRating(Rating.M);
        response.setStatus(new Status());
        response.getStatus().setCode("1.0");
        response.getSuccessGroup().setViewInfo(new ViewInfo());
        response.getSuccessGroup().getViewInfo().setViewId("index.ral");

        ByteArrayInputStream is = new ByteArrayInputStream(os.toByteArray());
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        TestNIOCallback callback = new TestNIOCallback();
        IAPRequestRunnable runnable = new IAPRequestRunnable(callback, tid, is, bos,
            new IAPTransactionManager(), new SessionManager(10), new IAPHandlerManager(sc), sc);
        runnable.run();
        assertTrue(TestOpenApplicationHandler.called);
    }

    private class TestNIOCallback implements NIOCallback {
        public boolean read;
        public boolean wrote;
        public boolean failed;

        public void doneReading() {
            read = true;
        }

        public void doneWriting() {
            wrote = true;
        }

        public void failed() {
            failed = true;
        }
    }
}