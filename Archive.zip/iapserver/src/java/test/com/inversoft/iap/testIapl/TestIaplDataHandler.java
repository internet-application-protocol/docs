/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.testIapl;

import java.util.List;
import java.util.Map;

import iap.handler.FetchDataHandler;
import iap.handler.IAPHandlerException;
import iap.request.FetchDataRequest;
import iap.response.DataScope;
import iap.response.FetchDataResponse;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TestIaplDataHandler implements FetchDataHandler {

    private Map<String, String> mapping;

    /**
     * <p>
     * Called by the IAP container when an fetch data request is submitted by a
     * client. This method should handle the fetch data request and provide an
     * appropriate fetch data response.
     * </p>
     *
     * @param   request The FetchDataRequest that should be used to parse
     *          out the request parameters in order to formulate an appropriate
     *          response.
     * @param   response The FetchDataResponse that must be populated with
     *          the necessary information prior to returning from this method.
     *          An instance of the response is passed into this method and the
     *          response should then be populated and this method should return.
     * @throws  iap.handler.IAPHandlerException If processing of the fetch data request
     *          failed for any reason, implementing classes should throw an
     *          instance of IAPHandlerException. Implementations should try to wrap
     *          all exceptions into a IAPHandlerException because it is not specified
     *          how different servers handle RuntimeExceptions.
     */
    public void doFetchData(FetchDataRequest request, FetchDataResponse response) throws IAPHandlerException {
        List<String> names = request.getDataNames();
        for (String name : names) {
            String result = mapping.get(name);
            if (result == null) {
                result = "Could not find " + name;
            }

            response.getResponseData().setValue(name, result, String.class,
                    DataScope.VIEW);
            System.out.println("Added value " + name + " " + result);
        }
    }

    /**
     * <p>
     * Called by the IAP container when the IAPHandler is first put into
     * service. This method should be implemented to provide detailed creation
     * functionality. This method also receives a list of parameters that are
     * retrieved by the container from the iap.xml configuration file or the
     * {@link iap.handler.annotation.Handler} annotation. This annotation is inspected by the container
     * at load time and all parameters from it are appended to any parameters
     * loaded from the iap.xml configuration file.
     * </p>
     *
     * <p>
     * This method is called only once per JVM per instance of the IAPHandler.
     * This means that a handler is never taken out of service and then put back
     * into service.
     * </p>
     *
     * @param   parameters The parameters from the annotations as well as the
     *          iap.xml configuration file.
     * @throws  iap.handler.IAPHandlerException If there were any problems creating the handler.
     */
    public void create(Map<String, String> parameters) throws IAPHandlerException {
        mapping = parameters;

    }

    /**
     * <p>
     * Called by the IAP container when the IAPHandler is taken out of service.
     * This method should be implemented to provide detailed destruction
     * functionality such as freeing of resources or closing of connections. In
     * most cases this method is called when the server is shutdown, but a handler
     * can be taken out of service forcefully and this method is called before
     * removing the handler from active service.
     * </p>
     *
     * <p>
     * If this method throws an exception, the IAPHandler is still removed from
     * service, but the text of the exception is displayed to the user to inform
     * them of the problem encountered during removal of the servlet.
     * </p>
     *
     * @throws  iap.handler.IAPHandlerException If there was any problem shutting down.
     */
    public void destory() throws IAPHandlerException {
        // stub

    }
}
