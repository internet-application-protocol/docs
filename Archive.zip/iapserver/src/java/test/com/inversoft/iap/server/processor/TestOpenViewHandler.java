/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Map;

import junit.framework.Assert;

import iap.handler.GenericIAPHandler;
import iap.handler.IAPHandlerException;
import iap.handler.annotation.OpenView;
import iap.handler.annotation.ViewResource;
import iap.request.OpenViewRequest;
import iap.response.OpenViewResponse;

/**
 * <p>
 * This is a test handler.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
@OpenView(resources = {
    @ViewResource(viewId = "index.mapping", resource = "src/apps/test/test-app1/index.iapl")})
public class TestOpenViewHandler extends GenericIAPHandler {
    public static boolean setBody = false;
    public static boolean setOutputStream = false;
    public boolean created = false;

    public void create(Map<String, String> parameters) throws IAPHandlerException {
        Assert.assertEquals("value1", parameters.get("test1"));
        Assert.assertEquals("value2", parameters.get("test2"));
        created = true;
    }

    public void doOpenView(OpenViewRequest request, OpenViewResponse response)
    throws IAPHandlerException {
        if (setBody) {
            response.setContentType("text/xml");
            response.setViewBytes(ByteBuffer.wrap("content".getBytes()));
        } else if (setOutputStream) {
            response.setContentType("text/iapl");
            InputStream is = new ByteArrayInputStream("outputstream content".getBytes());
            response.setInputStream(is);
        }
    }
}