/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.testhtml;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

import iap.handler.FetchDataHandler;
import iap.handler.IAPHandlerException;
import iap.request.FetchDataRequest;
import iap.response.DataScope;
import iap.response.FetchDataResponse;

/**
 * <p/>
 * This class is a data handler for the testHtml application.
 * </p>
 *
 * @author Brian Pontarelli
 * @version 1.0
 * @since IAP 1.0
 */
public class TestHtmlDataHandler implements FetchDataHandler {
    private Map<String, String> mapping;

    public void doFetchData(FetchDataRequest request, FetchDataResponse response) throws IAPHandlerException {
        System.out.println(mapping.toString());
        List<String> names = request.getDataNames();
        // add the data to the response
        for (String name : names) {
            String result = mapping.get(name);
            if (result == null) {
                result = "Could not find " + name;
            }
            DataScope scope = DataScope.VIEW;
            if (name.equals("data1")) {
                scope = DataScope.APPLICATION;
            } else if (name.equals("host")) {
                scope = DataScope.APPLICATION;
            }
            response.getResponseData().setValue(name, result, String.class, scope);
            System.out.println("Added value " + name + " " + result);
        }
    }

    public void create(Map<String, String> parameters) throws IAPHandlerException {
        mapping = parameters;
        try {
            mapping.put("host", InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException uhe) {
            // stub
        }
    }

    public void destory() throws IAPHandlerException {
    }
}