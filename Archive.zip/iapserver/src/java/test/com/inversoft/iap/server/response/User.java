/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;

import com.inversoft.iap.server.request.Address;

/**
 * <p>
 * This class is a test JavaBean.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class User {
    private int age;
    private boolean male;
    private com.inversoft.iap.server.request.Address address = new Address();


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isMale() {
        return male;
    }

    public void setMale(boolean male) {
        this.male = male;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}