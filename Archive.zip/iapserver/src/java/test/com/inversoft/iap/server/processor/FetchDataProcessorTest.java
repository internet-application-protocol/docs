/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

import iap.VersionNumber;
import iap.response.DataScope;
import iap.response.Rating;

import com.inversoft.iap.DataType;
import com.inversoft.iap.response.FetchDataStatus;
import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.config.ApplicationConfig;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ConfigurationException;
import com.inversoft.iap.server.config.HandlerConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.jaxb.ServerBind;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.session.IAPSessionImpl;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.DataRequest;
import com.inversoft.iap.transport.DataRequestBody;
import com.inversoft.iap.transport.FetchDataRequest;
import com.inversoft.iap.transport.FetchDataResponse;
import com.inversoft.iap.transport.SessionId;

/**
 * <p>
 * This class is a test case for the fetch data processor.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class FetchDataProcessorTest extends TestCase {
    private ServerConfig sc;
    private IAPHandlerManager rhm;

    /**
     * Constructs a new <code>OpenViewTransportProcessorTest</code>.
     */
    public FetchDataProcessorTest(String name) {
        super(name);
    }

    public void testNoHandler() throws ConfigurationException {
        setupClasses(null);

        SessionManager sm = new SessionManager(300000);
        IAPSessionImpl si = sm.createSession(new ApplicationKey("test", VersionNumber.decode("1.0.0")), 300000);
        FetchDataRequest request = new FetchDataRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.0"), si.getSessionId().getStringId());
        request.setSessionId(session);

        DataRequestBody dbr = new DataRequestBody();
        DataRequest data = new DataRequest();
        data.setName("foo");
        dbr.getDataRequest().add(data);
        request.setDataRequestBody(dbr);

        FetchDataProcessor proc = new FetchDataProcessor(sm, rhm, sc);
        FetchDataResponse response = proc.handle(request);
        assertNotNull(response.getDataBody());
        assertEquals(0, response.getDataBody().getAllData().size());
        assertEquals(FetchDataStatus.SUCCESS.getCode(), response.getStatus().getCode());
    }

    public void testHandler() throws ConfigurationException {
        setupClasses(TestFetchDataHandler.class);

        SessionManager sm = new SessionManager(300000);
        IAPSessionImpl si = sm.createSession(new ApplicationKey("test", VersionNumber.decode("1.0.0")), 300000);
        FetchDataRequest request = new FetchDataRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.0"), si.getSessionId().getStringId());
        request.setSessionId(session);

        DataRequestBody dbr = new DataRequestBody();
        DataRequest data = new DataRequest();
        data.setName("foo");
        dbr.getDataRequest().add(data);
        DataRequest data2 = new DataRequest();
        data2.setName("bar");
        dbr.getDataRequest().add(data2);
        request.setDataRequestBody(dbr);

        FetchDataProcessor proc = new FetchDataProcessor(sm, rhm, sc);
        FetchDataResponse response = proc.handle(request);
        assertNotNull(response.getDataBody());
        assertEquals(2, response.getDataBody().getAllData().size());
        assertEquals(FetchDataStatus.SUCCESS.getCode(), response.getStatus().getCode());

        assertEquals(0, response.getDataBody().getAllData().get(0).getArrayDepth());
        assertEquals(DataScope.APPLICATION, response.getDataBody().getAllData().get(0).getScope());
        assertEquals(DataType.STRING, response.getDataBody().getAllData().get(0).getType());
        assertEquals("foo", response.getDataBody().getAllData().get(0).getKey());
        assertEquals("name is foo", response.getDataBody().getAllData().get(0).getValue());

        assertEquals(0, response.getDataBody().getAllData().get(1).getArrayDepth());
        assertEquals(DataScope.APPLICATION, response.getDataBody().getAllData().get(1).getScope());
        assertEquals(DataType.STRING, response.getDataBody().getAllData().get(1).getType());
        assertEquals("bar", response.getDataBody().getAllData().get(1).getKey());
        assertEquals("name is bar", response.getDataBody().getAllData().get(1).getValue());
    }

    public void testFailure() throws ConfigurationException {
        setupClasses(TestFetchDataHandler.class);

        SessionManager sm = new SessionManager(300000);
        IAPSessionImpl si = sm.createSession(new ApplicationKey("test", VersionNumber.decode("1.0.0")), 300000);
        FetchDataRequest request = new FetchDataRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.1"), si.getSessionId().getStringId());
        request.setSessionId(session);

        DataRequestBody dbr = new DataRequestBody();
        DataRequest data = new DataRequest();
        data.setName("foo");
        dbr.getDataRequest().add(data);
        request.setDataRequestBody(dbr);

        FetchDataProcessor proc = new FetchDataProcessor(sm, rhm, sc);
        FetchDataResponse response = proc.handle(request);
        assertNull(response.getDataBody());
        assertEquals(FetchDataStatus.FAILURE_SESSION_ID.getCode(), response.getStatus().getCode());
    }

    private void setupClasses(Class handler) throws ConfigurationException {
        Map<String, String> params = new HashMap<String, String>();
        params.put("test1", "value1");
        params.put("test2", "value2");

        HandlerConfig dataConfig = null;
        if (handler != null) {
            dataConfig = new HandlerConfig("app", handler, false, params);
        }

        VersionNumber ver = VersionNumber.decode("1.0.0");
        ApplicationConfig ac = new ApplicationConfig(null, null, dataConfig, null, null, null, null,
            Thread.currentThread().getContextClassLoader(), null, ver, Rating.T, 1800000, null);
        ApplicationDeploymentConfig adc = new ApplicationDeploymentConfig("test", new File("."), ac);

        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);

        ServerBind info = new ServerBind();
        info.setName("server1");
        info.setPort(80);
        this.sc = new ServerConfig(apps, info);
        this.rhm = new IAPHandlerManager(sc);
    }
}