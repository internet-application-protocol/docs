/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.testhtml;

import java.util.Map;

import junit.framework.Assert;

import iap.handler.IAPHandlerException;
import iap.handler.PerformActionHandler;
import iap.request.PerformActionRequest;
import iap.response.DataScope;
import iap.response.PerformActionResponse;

/**
 * <p/>
 * This is a test handler
 * </p>
 *
 * @author Brian Pontarelli
 * @version 1.0
 * @since IAP 1.0
 */
public class TestHtmlActionHandler implements PerformActionHandler {
    public static boolean called = false;

    public void doPerformAction(PerformActionRequest request, PerformActionResponse response)
    throws IAPHandlerException {
        called = true;
        Boolean b = request.getRequestData().getValue("field1", Boolean.class);
        System.out.println("b is " + b);
        Assert.assertNotNull(b);
        Assert.assertTrue(b);

        response.getResponseData().setValue("result1", "foo", String.class, DataScope.VIEW);
        response.getResponseData().setValue("result2", "bar", String.class, DataScope.VIEW);
    }

    public void create(Map<String, String> parameters) throws IAPHandlerException {
    }

    public void destory() throws IAPHandlerException {
    }
}