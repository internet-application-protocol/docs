/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.session;

import junit.framework.TestCase;

import iap.VersionNumber;

import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.transport.SessionId;

/**
 * <p>
 * This class tests the session manager.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class SessionManagerTest extends TestCase {
    /**
     * Constructs a new <code>SessionManagerTest</code>.
     */
    public SessionManagerTest(String name) {
        super(name);
    }

    /**
     * Test creation works.
     */
    public void testCreate() {
        SessionManager sm = new SessionManager(10);
        VersionNumber ver = VersionNumber.decode("2.0.1");
        long now = System.currentTimeMillis();
        IAPSessionImpl session = sm.createSession(new ApplicationKey("test", ver), 10);
        assertEquals("test", session.getSessionId().getApplicationId());
        assertEquals(ver, session.getSessionId().getVersionNumber());
        assertNotNull(session.getSessionId().getStringId());
        assertEquals(600000, session.getTimeout());
        assertEquals(now + 600000, session.getExpirePoint(), 1);
    }

    /**
     * Test creation works from a session ID.
     */
    public void testCreateFromSessionId() {
        SessionManager sm = new SessionManager(10);
        VersionNumber ver = VersionNumber.decode("2.0.1");
        SessionId id = new SessionId("test", ver, "foo");
        long now = System.currentTimeMillis();
        // '10' is in minutes
        IAPSessionImpl session = sm.createSession(id, 10);
        assertEquals("test", session.getSessionId().getApplicationId());
        assertEquals(ver, session.getSessionId().getVersionNumber());
        assertEquals("foo", session.getSessionId().getStringId());
        // 600000 is 10 minutes in millis
        assertEquals(600000, session.getTimeout());
        assertEquals(now + 600000, session.getExpirePoint(), 1);
    }

    /**
     * Test fetching works.
     */
    public void testFetch() {
        SessionManager sm = new SessionManager(100);
        VersionNumber ver = VersionNumber.decode("2.0.1");
        SessionId id = new SessionId("test", ver, "foo");
        IAPSessionImpl session = sm.createSession(id, 100);

        SessionManager.SessionStruct struct = sm.getSession(id);
        assertSame(session, struct.session);
        assertFalse(struct.expired);
    }

    /**
     * Test that sessions are expired.
     */
    public void testExpire() throws InterruptedException {
        SessionManager sm = new SessionManager(100);
        VersionNumber ver = VersionNumber.decode("2.0.1");
        SessionId id = new SessionId("test", ver, "foo");
        IAPSessionImpl session = sm.createSession(id, 0);

        SessionManager.SessionStruct struct = sm.getSession(id);
        assertSame(struct.session, session);
        assertFalse(struct.expired);

        Thread.sleep(20);

        struct = sm.getSession(id);
        assertNull(struct.session);
        assertTrue(struct.expired);
    }

    /**
     * Test that the cleaning works.
     */
    public void testClean() throws InterruptedException {
        SessionManager sm = new SessionManager(15);
        VersionNumber ver = VersionNumber.decode("2.0.1");
        SessionId id = new SessionId("test", ver, "foo");
        IAPSessionImpl session = sm.createSession(id, 0);

        SessionManager.SessionStruct struct = sm.getSession(id);
        assertSame(struct.session, session);
        assertFalse(struct.expired);

        Thread.sleep(30);

        struct = sm.getSession(id);
        assertNull(struct.session);
        assertTrue(struct.expired);
    }
}