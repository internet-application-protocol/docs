/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import iap.handler.GenericIAPHandler;
import iap.handler.IAPHandlerException;
import iap.handler.OpenApplicationHandler;
import iap.request.OpenApplicationRequest;
import iap.response.OpenApplicationResponse;
import iap.response.Rating;

/**
 * <p>
 * This is a test handler.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class TestOpenApplicationHandler extends GenericIAPHandler implements OpenApplicationHandler {
    public static boolean called = false;

    public void doOpenApplication(OpenApplicationRequest request, OpenApplicationResponse response)
    throws IAPHandlerException {
        response.setCacheable(true);
        response.setRating(Rating.M);
        response.setViewId("index.ral");
        called = true;
    }
}