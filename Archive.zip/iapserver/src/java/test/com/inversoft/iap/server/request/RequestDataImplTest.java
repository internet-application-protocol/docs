/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;

import junit.framework.TestCase;

import iap.request.RequestData;
import iap.response.DataScope;

import com.inversoft.iap.DataBody;
import com.inversoft.iap.DataType;

/**
 * <p>
 * This class tests the request data implementation.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class RequestDataImplTest extends TestCase {
    /**
     * Constructs a new <code>RequestDataImplTest</code> that executes the test with the given
     * name.
     *
     * @param   name The name of the test to run.
     */
    public RequestDataImplTest(String name) {
        super(name);
    }


    public void testGetValueSimple() {
        DataBody db = new DataBody();
        db.setValue("myBoolean", Boolean.FALSE, DataType.BOOLEAN, 0, DataScope.APPLICATION);
        db.setValue("myByte", (byte) 42, DataType.BYTE, 0, DataScope.APPLICATION);
        db.setValue("myChar", '$', DataType.CHAR, 0, DataScope.APPLICATION);
        db.setValue("myShort", (short) -14, DataType.SHORT, 0, DataScope.APPLICATION);
        db.setValue("myInt", 1000001, DataType.INT, 0, DataScope.APPLICATION);
        db.setValue("myLong", -42000000042l, DataType.LONG, 0, DataScope.APPLICATION);
        db.setValue("myFloat", -3.141592f, DataType.FLOAT, 0, DataScope.APPLICATION);
        db.setValue("myDouble", 0.4, DataType.DOUBLE, 0, DataScope.APPLICATION);
        db.setValue("myString", "IAP rocks!", DataType.STRING, 0, DataScope.APPLICATION);

        RequestData data = new RequestDataImpl(db);
        Object value = data.getValue("myBoolean", Boolean.class);
        assertNotNull(value);
        assertEquals(Boolean.FALSE, value);

        value = data.getValue("myByte", Byte.class);
        assertNotNull(value);
        assertEquals((byte) 42, value);

        value = data.getValue("myChar", Character.class);
        assertNotNull(value);
        assertEquals('$', value);

        value = data.getValue("myShort", Short.class);
        assertNotNull(value);
        assertEquals((short) -14, value);

        value = data.getValue("myInt", Integer.class);
        assertNotNull(value);
        assertEquals(1000001, value);

        value = data.getValue("myLong", Long.class);
        assertNotNull(value);
        assertEquals(-42000000042l, value);

        value = data.getValue("myFloat", Float.class);
        assertNotNull(value);
        assertEquals(-3.141592f, value);

        value = data.getValue("myDouble", Double.class);
        assertNotNull(value);
        assertEquals(0.4, value);

        value = data.getValue("myString", String.class);
        assertNotNull(value);
        assertEquals("IAP rocks!", value);
    }

    public void testGetValueComplex() {
        DataBody db = new DataBody();
        db.setValue("user.age", 42, DataType.INT, 0, DataScope.APPLICATION);
        db.setValue("user.male", Boolean.TRUE, DataType.BOOLEAN, 0, DataScope.APPLICATION);
        db.setValue("user.address.city", "Denver", DataType.STRING, 0, DataScope.APPLICATION);
        db.setValue("user.address.state", "Colorado", DataType.STRING, 0, DataScope.APPLICATION);

        RequestData data = new RequestDataImpl(db);
        User user = data.getValue("user", User.class);
        assertNotNull(user);
        assertEquals(42, user.getAge());
        assertTrue(user.isMale());
        assertEquals("Denver", user.getAddress().getCity());
        assertEquals("Colorado", user.getAddress().getState());

        Address address = data.getValue("user.address", Address.class);
        assertNotNull(address);
        assertEquals("Denver", address.getCity());
        assertEquals("Colorado", address.getState());
    }

    public void testGetValueWrongType() {
        DataBody db = new DataBody();
        db.setValue("myBoolean", Boolean.FALSE, DataType.BOOLEAN, 0, DataScope.APPLICATION);
        db.setValue("myByte", (byte) 42, DataType.BYTE, 0, DataScope.APPLICATION);
        db.setValue("myChar", '$', DataType.CHAR, 0, DataScope.APPLICATION);
        db.setValue("myShort", (short) -14, DataType.SHORT, 0, DataScope.APPLICATION);
        db.setValue("myInt", 1000001, DataType.INT, 0, DataScope.APPLICATION);
        db.setValue("myLong", -42000000042l, DataType.LONG, 0, DataScope.APPLICATION);
        db.setValue("myFloat", -3.141592f, DataType.FLOAT, 0, DataScope.APPLICATION);
        db.setValue("myDouble", 0.4, DataType.DOUBLE, 0, DataScope.APPLICATION);
        db.setValue("myString", "IAP rocks!", DataType.STRING, 0, DataScope.APPLICATION);

        RequestData data = new RequestDataImpl(db);
        try {
            String s = data.getValue("myBoolean", String.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }

        try {
            String s = data.getValue("myByte", String.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }

        try {
            String s = data.getValue("myChar", String.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }

        try {
            String s = data.getValue("myShort", String.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }

        try {
            String s = data.getValue("myInt", String.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }

        try {
            String s = data.getValue("myLong", String.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }

        try {
            String s = data.getValue("myFloat", String.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }

        try {
            String s = data.getValue("myDouble", String.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }

        try {
            Byte b = data.getValue("myString", Byte.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }
    }

    public void testGetValueNullSimple() {
        DataBody db = new DataBody();
        db.setValue("myBoolean", null, DataType.BOOLEAN, 0, DataScope.APPLICATION);
        db.setValue("myByte", null, DataType.BYTE, 0, DataScope.APPLICATION);
        db.setValue("myChar", null, DataType.CHAR, 0, DataScope.APPLICATION);
        db.setValue("myShort", null, DataType.SHORT, 0, DataScope.APPLICATION);
        db.setValue("myInt", null, DataType.INT, 0, DataScope.APPLICATION);
        db.setValue("myLong", null, DataType.LONG, 0, DataScope.APPLICATION);
        db.setValue("myFloat", null, DataType.FLOAT, 0, DataScope.APPLICATION);
        db.setValue("myDouble", null, DataType.DOUBLE, 0, DataScope.APPLICATION);
        db.setValue("myString", null, DataType.STRING, 0, DataScope.APPLICATION);

        RequestData data = new RequestDataImpl(db);
        Object value = data.getValue("myBoolean", Boolean.class);
        assertNull(value);

        value = data.getValue("myByte", Byte.class);
        assertNull(value);

        value = data.getValue("myChar", Character.class);
        assertNull(value);

        value = data.getValue("myShort", Short.class);
        assertNull(value);

        value = data.getValue("myInt", Integer.class);
        assertNull(value);

        value = data.getValue("myLong", Long.class);
        assertNull(value);

        value = data.getValue("myFloat", Float.class);
        assertNull(value);

        value = data.getValue("myDouble", Double.class);
        assertNull(value);

        value = data.getValue("myString", String.class);
        assertNull(value);
    }

    public void testGetValueNullComplex() {
        DataBody db = new DataBody();
        db.setValue("user.address.city", null, DataType.STRING, 0, DataScope.APPLICATION);
        db.setValue("user.address.state", null, DataType.STRING, 0, DataScope.APPLICATION);

        RequestData data = new RequestDataImpl(db);
        User user = data.getValue("user", User.class);
        assertNotNull(user);
        assertNull(user.getAddress().getCity());
        assertNull(user.getAddress().getState());

        Address address = data.getValue("user.address", Address.class);
        assertNotNull(address);
        assertNull(address.getCity());
        assertNull(address.getState());
    }

    public void testGetValueNoValue() {
        DataBody db = new DataBody();
        RequestData data = new RequestDataImpl(db);
        User user = data.getValue("user", User.class);
        assertNull(user);

        String str = data.getValue("myString", String.class);
        assertNull(str);
    }

    public void testPopulateJavaBeanFailure() {
        DataBody db = new DataBody();
        db.setValue("user.age", 42, DataType.INT, 0, DataScope.APPLICATION);
        db.setValue("user.male", Boolean.TRUE, DataType.BOOLEAN, 0, DataScope.APPLICATION);
        db.setValue("user.address.city", "Denver", DataType.STRING, 0, DataScope.APPLICATION);
        db.setValue("user.address.badProp", "Foo", DataType.STRING, 0, DataScope.APPLICATION);
        db.setValue("user.address.state", "Colorado", DataType.STRING, 0, DataScope.APPLICATION);

        try {
            RequestData data = new RequestDataImpl(db);
            data.getValue("user", User.class);
            fail("Should have failed");
        } catch (Exception e) {
            // Expected
        }
    }

    public void testPopulateJavaBean() {
        DataBody db = new DataBody();
        db.setValue("user.age", 42, DataType.INT, 0, DataScope.APPLICATION);
        db.setValue("user.male", Boolean.TRUE, DataType.BOOLEAN, 0, DataScope.APPLICATION);
        db.setValue("user.address.city", "Denver", DataType.STRING, 0, DataScope.APPLICATION);
        db.setValue("user.address.state", "Colorado", DataType.STRING, 0, DataScope.APPLICATION);

        RequestData data = new RequestDataImpl(db);
        User user = new User();
        data.populateJavaBean("user", user);
        assertNotNull(user);
        assertEquals(42, user.getAge());
        assertTrue(user.isMale());
        assertEquals("Denver", user.getAddress().getCity());
        assertEquals("Colorado", user.getAddress().getState());

        Address address = new Address();
        data.populateJavaBean("user.address", address);
        assertNotNull(address);
        assertEquals("Denver", address.getCity());
        assertEquals("Colorado", address.getState());
    }
}