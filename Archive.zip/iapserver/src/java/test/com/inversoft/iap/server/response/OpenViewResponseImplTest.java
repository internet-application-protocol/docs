/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import junit.framework.TestCase;

/**
 * <p>
 * This class tests the open view response impl
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenViewResponseImplTest extends TestCase {
    /**
     * Constructs a new <code>OpenViewResponseImplTest</code>.
     */
    public OpenViewResponseImplTest(String name) {
        super(name);
    }

    /**
     * Tests that the output stream works correctly.
     */
    public void testOutputStream() throws IOException {
        OpenViewResponseImpl res = new OpenViewResponseImpl();
        InputStream is = new ByteArrayInputStream("testing".getBytes());
        res.setInputStream(is);

        assertSame(is, res.getInputStream());
        assertNull(res.getViewBytes());
    }
}