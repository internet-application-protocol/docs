/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.testhtml;

import java.util.Map;

import junit.framework.Assert;

import iap.handler.AuthenticateUserHandler;
import iap.handler.IAPHandlerException;
import iap.request.AuthenticateUserRequest;
import iap.response.AuthenticateUserResponse;
import iap.response.DataScope;

/**
 * <p/>
 * This class is a test handler.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class TestAuthHandler implements AuthenticateUserHandler {

    public static boolean called = false;

    public void doAuthenticateUser(AuthenticateUserRequest request, AuthenticateUserResponse response)
    throws IAPHandlerException {
        called = true;
        Assert.assertEquals("ponch", request.getUsername());
        Assert.assertEquals("password123", request.getPassword());
        response.getResponseData().setValue("flag", true, boolean.class, DataScope.VIEW);
        response.getResponseData().setValue("age", 42, int.class, DataScope.VIEW);
    }

    public void create(Map<String, String> parameters) throws IAPHandlerException {
    }

    public void destory() throws IAPHandlerException {
    }
}