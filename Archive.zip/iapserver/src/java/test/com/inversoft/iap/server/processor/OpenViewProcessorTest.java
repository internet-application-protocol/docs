/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.config.ApplicationConfig;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ConfigurationException;
import com.inversoft.iap.server.config.RegexHandlerConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.jaxb.ServerBind;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.session.IAPSessionImpl;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.OpenViewRequest;
import com.inversoft.iap.transport.OpenViewResponse;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.ViewInfo;

/**
 * <p>
 * This class is a test case for the open view processor.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenViewProcessorTest extends TestCase {
    private ServerConfig sc;
    private IAPHandlerManager rhm;

    /**
     * Constructs a new <code>OpenViewTransportProcessorTest</code>.
     */
    public OpenViewProcessorTest(String name) {
        super(name);
    }

    public void testSettingViewId() throws ConfigurationException {
        setupClasses(TestOpenViewHandler.class);

        SessionManager sm = new SessionManager(300000);
        IAPSessionImpl si = sm.createSession(new ApplicationKey("test", VersionNumber.decode("1.0.0")), 300000);
        OpenViewRequest request = new OpenViewRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.0"), si.getSessionId().getStringId());
        request.setSessionId(session);

        ViewInfo vi = new ViewInfo();
        vi.setViewId("index.iapl");
        request.setViewInfo(vi);

        OpenViewProcessor proc = new OpenViewProcessor(sm, rhm, sc);
        TestOpenViewHandler.setBody = true;
        TestOpenViewHandler.setOutputStream = false;
        OpenViewResponse response = proc.handle(request);
        ByteBuffer expected = ByteBuffer.wrap("content".getBytes());
        assertEquals(expected, response.getViewBody().getViewData().getValue());
        assertEquals(expected.capacity(), response.getViewBody().getViewData().getContentLength());
        assertEquals("text/xml", response.getViewBody().getViewData().getContentType());
        assertEquals("1.0", response.getStatus().getCode());
    }

    public void testSessionId() throws ConfigurationException {
        setupClasses(TestOpenViewHandler.class);

        SessionManager sm = new SessionManager(300000);
        IAPSessionImpl sessionImpl = sm.createSession(new ApplicationKey("test", VersionNumber.decode("1.0.0")), 300000);

        OpenViewRequest request = new OpenViewRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.0"), sessionImpl.getSessionId().getStringId());
        request.setSessionId(session);

        ViewInfo vi = new ViewInfo();
        vi.setViewId("index.iapl");
        request.setViewInfo(vi);

        OpenViewProcessor proc = new OpenViewProcessor(sm, rhm, sc);
        TestOpenViewHandler.setBody = true;
        TestOpenViewHandler.setOutputStream = false;
        OpenViewResponse response = proc.handle(request);
        ByteBuffer expected = ByteBuffer.wrap("content".getBytes());
        assertEquals(expected, response.getViewBody().getViewData().getValue());
        assertEquals(expected.capacity(), response.getViewBody().getViewData().getContentLength());
        assertEquals("text/xml", response.getViewBody().getViewData().getContentType());
        assertEquals("1.0", response.getStatus().getCode());
    }

    public void testAnnotation() throws ConfigurationException, IOException {
        setupClasses(TestOpenViewHandler.class);

        SessionManager sm = new SessionManager(300000);
        IAPSessionImpl si = sm.createSession(new ApplicationKey("test", VersionNumber.decode("1.0.0")), 300000);
        OpenViewRequest request = new OpenViewRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.0"), si.getSessionId().getStringId());
        request.setSessionId(session);

        ViewInfo vi = new ViewInfo();
        vi.setViewId("index.mapping");
        request.setViewInfo(vi);

        OpenViewProcessor proc = new OpenViewProcessor(sm, rhm, sc);
        TestOpenViewHandler.setBody = false;
        TestOpenViewHandler.setOutputStream = false;
        OpenViewResponse response = proc.handle(request);
        assertNull(response.getViewBody().getViewData().getValue());
        assertNotNull(response.getViewBody().getViewData().getValueStream());

        byte[] b = new byte[1024];
        int length = response.getViewBody().getViewData().getValueStream().read(b);
        String value = new String(b, 0, length, "UTF-8");
        assertEquals("Test IAPL file", value);
        assertEquals(length, response.getViewBody().getViewData().getContentLength());
        assertEquals("text/iapl", response.getViewBody().getViewData().getContentType());
    }

    public void testOutputStream() throws ConfigurationException, IOException {
        setupClasses(TestOpenViewHandler.class);

        SessionManager sm = new SessionManager(300000);
        IAPSessionImpl si = sm.createSession(new ApplicationKey("test", VersionNumber.decode("1.0.0")), 300000);
        OpenViewRequest request = new OpenViewRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.0"), si.getSessionId().getStringId());
        request.setSessionId(session);

        ViewInfo vi = new ViewInfo();
        vi.setViewId("index.iapl");
        request.setViewInfo(vi);

        OpenViewProcessor proc = new OpenViewProcessor(sm, rhm, sc);
        TestOpenViewHandler.setBody = false;
        TestOpenViewHandler.setOutputStream = true;
        OpenViewResponse response = proc.handle(request);

        byte[] b = new byte[1024];
        int length = response.getViewBody().getViewData().getValueStream().read(b);
        String value = new String(b, 0, length, "UTF-8");
        assertEquals("outputstream content", value);
//        assertEquals(length, response.getViewBody().getViewData().getContentLength());
        assertEquals("text/iapl", response.getViewBody().getViewData().getContentType());
    }

    private void setupClasses(Class handler) throws ConfigurationException {
        Map<String, String> params = new HashMap<String, String>();
        params.put("test1", "value1");
        params.put("test2", "value2");

        Set<RegexHandlerConfig> viewConfigs = new HashSet<RegexHandlerConfig>();
        viewConfigs.add(new RegexHandlerConfig("app", handler, false, params, "ind.*"));
        VersionNumber ver = VersionNumber.decode("1.0.0");
        ApplicationConfig ac = new ApplicationConfig(null, null, null, null, null, viewConfigs, null,
            Thread.currentThread().getContextClassLoader(), null, ver, Rating.T, 1800000, null);
        ApplicationDeploymentConfig adc = new ApplicationDeploymentConfig("test", new File("."), ac);

        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);

        ServerBind info = new ServerBind();
        info.setName("server1");
        info.setPort(80);
        this.sc = new ServerConfig(apps, info);
        this.rhm = new IAPHandlerManager(sc);
    }
}