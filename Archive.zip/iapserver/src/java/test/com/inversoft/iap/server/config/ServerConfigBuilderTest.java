/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;

import javax.xml.bind.JAXBException;

import junit.framework.TestCase;

import iap.VersionNumber;

import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.transport.TransportFactory;
import com.inversoft.util.JAXBTools;

/**
 * <p>
 * This class tests the server configuration builder.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class ServerConfigBuilderTest extends TestCase {
    /**
     * Constructs a new <code>ServerConfigBuilderTest</code>.
     */
    public ServerConfigBuilderTest(String name) {
        super(name);
    }


    public void setUp() {
        try {
            JAXBTools.addObjectFactory(com.inversoft.iap.server.config.jaxb.ObjectFactory.class);
        } catch (JAXBException e) {
            fail(e.getMessage());
        }
    }
    public void testMultipleAppsExploded() {
        String fileName = "src/java/test/com/inversoft/iap/server/config/test-server.xml";
        System.setProperty("iap.server.config", fileName);

        ServerConfigBuilder scb = new ServerConfigBuilder();
        ServerConfig sc = scb.build();
        assertEquals("test", sc.getServerInfo().getName());
        assertEquals(8080, sc.getServerInfo().getPort());
        assertEquals((Integer) 100, sc.getServerInfo().getExecuteThreads());
        assertEquals((Integer) 10000, sc.getServerInfo().getQueueSize());
        assertEquals((Integer) 4000, sc.getServerInfo().getTimeout());
        assertEquals((Integer) 4, sc.getServerInfo().getSelectTimeout());

        ApplicationDeploymentConfig helloWorld = sc.getApplication(new ApplicationKey("helloWorld", VersionNumber.decode("1.0.1")));
        assertEquals("helloWorld", helloWorld.getName());
        assertEquals("1.0.1", helloWorld.getApplicationConfig().getVersion().toString());
        assertNull(helloWorld.getApplicationConfig().authUser());
        assertEquals("helloWorld.iapl", helloWorld.getApplicationConfig().getWelcomeView());

        ApplicationDeploymentConfig testApp1 = sc.getApplication(new ApplicationKey("test-app1", VersionNumber.decode("1.0.1")));
        assertEquals("test-app1", testApp1.getName());
        assertEquals("1.0.1", testApp1.getApplicationConfig().getVersion().toString());
        assertNotNull(testApp1.getApplicationConfig().authUser());
        assertNotNull(testApp1.getApplicationConfig().reconnectSession());

        ApplicationDeploymentConfig testApp2 = sc.getApplication(new ApplicationKey("test-app2", VersionNumber.decode("1.0.1")));
        assertEquals("test-app2", testApp2.getName());
        assertEquals("1.0.1", testApp2.getApplicationConfig().getVersion().toString());
        assertNull(testApp2.getApplicationConfig().closeApp());
        assertEquals("com.inversoft.iap.testhtml.TestHtmlDataHandler", testApp2.getApplicationConfig().fetchData().getClassName());
        assertEquals("value1", testApp2.getApplicationConfig().fetchData().getParameters().get("data1"));
        assertEquals("value2", testApp2.getApplicationConfig().fetchData().getParameters().get("data2"));
        ViewActionHandlerConfig[] vahc = testApp2.getApplicationConfig().performActions().toArray(new ViewActionHandlerConfig[0]);
        assertEquals(1, vahc.length);
        assertEquals("com.inversoft.iap.testhtml.TestApp2ActionHandler", vahc[0].getClassName());
        assertEquals("link1.action", vahc[0].getAction());
        assertEquals("results.iapl", vahc[0].getModule());

        ApplicationDeploymentConfig testHtml = sc.getApplication(new ApplicationKey("testHtml", VersionNumber.decode("1.0.1")));
        assertEquals("testHtml", testHtml.getName());
        assertEquals("1.0.1", testHtml.getApplicationConfig().getVersion().toString());
        assertNull(testHtml.getApplicationConfig().authUser());
        assertEquals("com.inversoft.iap.testhtml.TestHtmlDataHandler", testHtml.getApplicationConfig().fetchData().getClassName());
        assertEquals("an application scoped value for data1", testHtml.getApplicationConfig().fetchData().getParameters().get("data1"));
        assertEquals("a view scoped value for data2", testHtml.getApplicationConfig().fetchData().getParameters().get("data2"));

        ApplicationDeploymentConfig testIapl = sc.getApplication(new ApplicationKey("testIapl", VersionNumber.decode("1.0.4")));
        assertEquals("testIapl", testIapl.getName());
        assertEquals("1.0.4", testIapl.getApplicationConfig().getVersion().toString());
        assertNull(testIapl.getApplicationConfig().authUser());
        assertEquals("com.inversoft.iap.testIapl.TestIaplDataHandler", testIapl.getApplicationConfig().fetchData().getClassName());
        assertNull(testIapl.getApplicationConfig().fetchData().getParameters().get("data1"));
        assertNull(testIapl.getApplicationConfig().fetchData().getParameters().get("data2"));
        assertEquals("this is the value for data3", testIapl.getApplicationConfig().fetchData().getParameters().get("data3"));
        assertEquals("this is the value for data4", testIapl.getApplicationConfig().fetchData().getParameters().get("data4"));
    }

    public void testDefaultApp() {
        String fileName = "src/java/test/com/inversoft/iap/server/config/test-server.xml";
        System.setProperty("iap.server.config", fileName);

        ServerConfigBuilder scb = new ServerConfigBuilder();
        ServerConfig sc = scb.build();
        assertEquals("test", sc.getServerInfo().getName());
        assertEquals(8080, sc.getServerInfo().getPort());
        assertEquals((Integer) 100, sc.getServerInfo().getExecuteThreads());
        assertEquals((Integer) 10000, sc.getServerInfo().getQueueSize());
        assertEquals((Integer) 4000, sc.getServerInfo().getTimeout());
        assertEquals((Integer) 4, sc.getServerInfo().getSelectTimeout());

        ApplicationDeploymentConfig adc = sc.getDefaultApplication();
        assertEquals("test-app1", adc.getName());
        assertEquals("1.0.1", adc.getApplicationConfig().getVersion().toString());
        assertNotNull(adc.getApplicationConfig().authUser());
    }
}