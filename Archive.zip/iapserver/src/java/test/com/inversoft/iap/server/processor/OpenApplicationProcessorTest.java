/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.response.OpenApplicationStatus;
import com.inversoft.iap.server.config.ApplicationConfig;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ConfigurationException;
import com.inversoft.iap.server.config.HandlerConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.jaxb.DefaultApplicationBind;
import com.inversoft.iap.server.config.jaxb.ServerBind;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.ApplicationInfo;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenApplicationResponse;

/**
 * <p>
 * This class is a test case for the open app processor.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenApplicationProcessorTest extends TestCase {
    private ServerConfig sc;
    private IAPHandlerManager rhm;

    /**
     * Constructs a new <code>OpenApplicationTransportProcessorTest</code>.
     */
    public OpenApplicationProcessorTest(String name) throws ConfigurationException {
        super(name);
        setupClasses(TestOpenApplicationHandler.class);
    }

    public void testSettingViewId() {
        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("test");
        ai.setVersionNumber(VersionNumber.decode("1.0.0"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        TestOpenApplicationHandler.setViewId = true;
        OpenApplicationResponse response = proc.handle(request);
        assertEquals("/index.ral", response.getSuccessGroup().getViewInfo().getViewId());
        assertSame(Rating.E, response.getSuccessGroup().getRatingInfo().getRating());
    }

    public void testAnnotation() {
        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("test");
        ai.setVersionNumber(VersionNumber.decode("1.0.0"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        TestOpenApplicationHandler.setViewId = false;
        OpenApplicationResponse response = proc.handle(request);
        assertEquals("/annotation.ral", response.getSuccessGroup().getViewInfo().getViewId());
        assertSame(Rating.E, response.getSuccessGroup().getRatingInfo().getRating());
    }

    public void testWelcomeView() throws ConfigurationException {
        setupClasses(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("test");
        ai.setVersionNumber(VersionNumber.decode("1.0.0"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        TestOpenApplicationHandler2.setViewId = false;
        OpenApplicationResponse response = proc.handle(request);
        assertEquals("viewId", response.getSuccessGroup().getViewInfo().getViewId());
        assertSame(Rating.T, response.getSuccessGroup().getRatingInfo().getRating());
    }

    public void testRating() throws ConfigurationException {
        setupClasses(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("test");
        ai.setVersionNumber(VersionNumber.decode("1.0.0"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        TestOpenApplicationHandler2.setViewId = false;
        TestOpenApplicationHandler2.setRating = true;
        OpenApplicationResponse response = proc.handle(request);
        assertEquals("viewId", response.getSuccessGroup().getViewInfo().getViewId());
        assertSame(Rating.M, response.getSuccessGroup().getRatingInfo().getRating());
    }

    public void testNewerVersions() throws ConfigurationException {
        setupTwoApps(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("test");
        ai.setVersionNumber(VersionNumber.decode("1.0.0"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.FAILURE_NEWER_VERSION.getCode(), response.getStatus().getCode());
        assertEquals("1.3.0,2.0.1", response.getStatus().getValue());
    }

    public void testOlderVersions() throws ConfigurationException {
        setupTwoApps(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("test");
        ai.setVersionNumber(VersionNumber.decode("4.1.7"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.FAILURE_OLDER_VERSION.getCode(), response.getStatus().getCode());
        assertEquals("1.3.0,2.0.1", response.getStatus().getValue());
    }

    public void testSuccessNewerVersions() throws ConfigurationException {
        setupTwoApps(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("test");
        ai.setVersionNumber(VersionNumber.decode("1.3.0"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.SUCCESS_NEWER_VERSION.getCode(), response.getStatus().getCode());
        assertEquals("2.0.1", response.getStatus().getValue());
    }

    public void testNoVersions() throws ConfigurationException {
        setupTwoApps(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("test");
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.SUCCESS.getCode(), response.getStatus().getCode());
        assertNull(response.getStatus().getValue());
    }

    public void testNonExistant() throws ConfigurationException {
        setupTwoApps(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("non-existant");
        ai.setVersionNumber(VersionNumber.decode("1.0.0"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.FAILURE_NON_EXISTENT.getCode(), response.getStatus().getCode());
    }

    public void testNonExistantNoVersion() throws ConfigurationException {
        setupTwoApps(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("non-existant");
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.FAILURE_NON_EXISTENT.getCode(), response.getStatus().getCode());
    }

    public void testDefaultApplicationWithVersion() throws ConfigurationException {
        setupTwoAppsDefault(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("");
        ai.setVersionNumber(VersionNumber.decode("2.0.1"));
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.SUCCESS.getCode(), response.getStatus().getCode());
        System.out.println("Other versions  " + response.getStatus().getValue());
        assertEquals("test", response.getSuccessGroup().getSessionId().getApplicationId());
        assertEquals(VersionNumber.decode("2.0.1"), response.getSuccessGroup().getSessionId().getVersionNumber());
    }

    public void testDefaultApplicationNoVersion() throws ConfigurationException {
        setupTwoAppsDefault(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("");
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.SUCCESS_NEWER_VERSION.getCode(), response.getStatus().getCode());
        assertEquals("test", response.getSuccessGroup().getSessionId().getApplicationId());
        assertEquals(VersionNumber.decode("1.3.0"), response.getSuccessGroup().getSessionId().getVersionNumber());
    }

    public void testDefaultApplicationNoVersionNoConfigVersion() throws ConfigurationException {
        setupTwoAppsDefaultNoVersion(TestOpenApplicationHandler2.class);

        OpenApplicationRequest request = new OpenApplicationRequest();
        ApplicationInfo ai = new ApplicationInfo();
        ai.setApplicationId("");
        request.setApplicationInfo(ai);

        OpenApplicationProcessor proc = new OpenApplicationProcessor(
            new SessionManager(300000), rhm, sc);
        OpenApplicationResponse response = proc.handle(request);
        assertEquals(OpenApplicationStatus.SUCCESS.getCode(), response.getStatus().getCode());
        assertEquals("test", response.getSuccessGroup().getSessionId().getApplicationId());
        assertEquals(VersionNumber.decode("2.0.1"), response.getSuccessGroup().getSessionId().getVersionNumber());
    }

    private void setupClasses(Class handler) throws ConfigurationException {
        ApplicationDeploymentConfig adc = createADC(handler, "1.0.0");

        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);

        ServerBind info = new ServerBind();
        info.setName("server1");
        info.setPort(80);
        this.sc = new ServerConfig(apps, info);
        this.rhm = new IAPHandlerManager(sc);
    }

    private void setupTwoApps(Class handler) throws ConfigurationException {
        ApplicationDeploymentConfig adc = createADC(handler, "1.3.0");
        ApplicationDeploymentConfig adc2 = createADC(handler, "2.0.1");

        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);
        apps.add(adc2);

        ServerBind info = new ServerBind();
        info.setName("test-server");
        info.setPort(80);
        this.sc = new ServerConfig(apps, info);
        this.rhm = new IAPHandlerManager(sc);
    }

    private void setupTwoAppsDefault(Class handler) throws ConfigurationException {
        ApplicationDeploymentConfig adc = createADC(handler, "1.3.0");
        ApplicationDeploymentConfig adc2 = createADC(handler, "2.0.1");

        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);
        apps.add(adc2);

        ServerBind info = new ServerBind();
        info.setName("test-server");
        info.setPort(80);
        info.setDefaultApplication(new DefaultApplicationBind());
        info.getDefaultApplication().setName("test");
        info.getDefaultApplication().setVersion("1.3.0");
        this.sc = new ServerConfig(apps, info);
        this.rhm = new IAPHandlerManager(sc);
    }

    private void setupTwoAppsDefaultNoVersion(Class handler) throws ConfigurationException {
        ApplicationDeploymentConfig adc = createADC(handler, "1.3.0");
        ApplicationDeploymentConfig adc2 = createADC(handler, "2.0.1");

        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);
        apps.add(adc2);

        ServerBind info = new ServerBind();
        info.setName("test-server");
        info.setPort(80);
        info.setDefaultApplication(new DefaultApplicationBind());
        info.getDefaultApplication().setName("test");
        this.sc = new ServerConfig(apps, info);
        this.rhm = new IAPHandlerManager(sc);
    }

    private ApplicationDeploymentConfig createADC(Class handler, String version) throws ConfigurationException {
        Map<String, String> params = new HashMap<String, String>();
        params.put("test1", "value1");
        params.put("test2", "value2");

        HandlerConfig appConfig = new HandlerConfig("app", handler, false, params);
        VersionNumber ver = VersionNumber.decode(version);
        ApplicationConfig ac = new ApplicationConfig(null, null, null, appConfig, null, null, null,
            Thread.currentThread().getContextClassLoader(), "viewId", ver, Rating.T, 1800000, null);
        return new ApplicationDeploymentConfig("test", new File("."), ac);
    }
}