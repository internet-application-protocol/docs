/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.handler;

import java.util.Map;

import junit.framework.Assert;

import iap.handler.GenericIAPHandler;
import iap.handler.IAPHandlerException;

/**
 * <p>
 * This is a test handler.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class TestFetchDataHandler extends GenericIAPHandler {
    public boolean created = false;
    public void create(Map<String, String> parameters) throws IAPHandlerException {
        Assert.assertEquals("value1", parameters.get("test1"));
        Assert.assertEquals("value2", parameters.get("test2"));
        created = true;
    }
}