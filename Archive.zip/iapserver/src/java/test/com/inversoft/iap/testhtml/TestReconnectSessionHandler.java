/**
 * Date Created: May 25, 2005
 * Created By:   James Humphrey
 */

package com.inversoft.iap.testhtml;

import java.util.Map;

import iap.handler.IAPHandlerException;
import iap.handler.ReconnectSessionHandler;
import iap.request.ReconnectSessionRequest;
import iap.response.ReconnectSessionResponse;

/**
 *
 * @author James Humphrey
 * @version 1.0
 */

public class TestReconnectSessionHandler implements ReconnectSessionHandler {

    public void doReconnectSession(ReconnectSessionRequest request,
                                   ReconnectSessionResponse response)
            throws IAPHandlerException {
        // stub

    }

    public void create(Map<String, String> parameters)
            throws IAPHandlerException {
        // stub

    }
    
    public void destory() throws IAPHandlerException {
        // stub

    }
}
