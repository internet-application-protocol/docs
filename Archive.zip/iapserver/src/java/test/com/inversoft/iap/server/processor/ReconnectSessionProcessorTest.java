/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.server.processor;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.response.ReconnectSessionStatus;
import com.inversoft.iap.server.config.ApplicationConfig;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ConfigurationException;
import com.inversoft.iap.server.config.HandlerConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.jaxb.ServerBind;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.handler.TestReconnectSessionHandler;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.Certificate;
import com.inversoft.iap.transport.ClientCredentials;
import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.ReconnectSessionResponse;
import com.inversoft.iap.transport.SessionId;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */
public class ReconnectSessionProcessorTest extends TestCase {

    private ServerConfig sc;
    private IAPHandlerManager rhm;

    public void testNoHandler() throws ConfigurationException {
        setupClasses(null);

        ReconnectSessionRequest request = new ReconnectSessionRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.0"), "blah");
        request.setSessionId(session);
        request.setClientCredentials(new ClientCredentials());
        request.getClientCredentials().setCertificate(new Certificate());
        request.getClientCredentials().getCertificate().setDateCreated(XMLGregorianCalendarImpl.parse("2004-08-13"));
        request.getClientCredentials().getCertificate().setDateExpires(XMLGregorianCalendarImpl.parse("2006-08-13"));

        ReconnectSessionProcessor proc = new ReconnectSessionProcessor(new SessionManager(300000), rhm, sc);
        ReconnectSessionResponse response = proc.handle(request);
        assertNotNull(response.getStatus());
        assertEquals(ReconnectSessionStatus.SUCCESS.getCode(),
                response.getStatus().getCode());
    }

    public void testHandler() throws ConfigurationException {
        setupClasses(TestReconnectSessionHandler.class);

        ReconnectSessionRequest request = new ReconnectSessionRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.0"), "blah");
        request.setSessionId(session);


        ReconnectSessionProcessor proc = new ReconnectSessionProcessor(new SessionManager(300000), rhm, sc);
        ReconnectSessionResponse response = proc.handle(request);
        assertNotNull(response.getStatus());
    }

    public void testFailure() throws ConfigurationException {
        setupClasses(TestReconnectSessionHandler.class);

        ReconnectSessionRequest request = new ReconnectSessionRequest();
        SessionId session = new SessionId("test", VersionNumber.decode("1.0.1"), "blah");
        request.setSessionId(session);

        ReconnectSessionProcessor proc = new ReconnectSessionProcessor(new SessionManager(300000), rhm, sc);
        ReconnectSessionResponse response = proc.handle(request);
        assertNotNull(response.getStatus());
        assertEquals(ReconnectSessionStatus.FAILURE_SESSION_ID.getCode(), response.getStatus().getCode());
    }

    private void setupClasses(Class handler) throws ConfigurationException {
        Map<String, String> params = new HashMap<String, String>();
        params.put("test1", "value1");
        params.put("test2", "value2");

        HandlerConfig dataConfig = null;
        if (handler != null) {
            dataConfig = new HandlerConfig("app", handler, false, params);
        }

        VersionNumber ver = VersionNumber.decode("1.0.0");
        ApplicationConfig ac = new ApplicationConfig(null, null, dataConfig,
                null, null, null, null,
                Thread.currentThread().getContextClassLoader(), null, ver,
                Rating.T, 1800000, null);
        ApplicationDeploymentConfig adc = new ApplicationDeploymentConfig("test", new File("."), ac);

        Set<ApplicationDeploymentConfig> apps = new HashSet<ApplicationDeploymentConfig>();
        apps.add(adc);

        ServerBind info = new ServerBind();
        info.setName("server1");
        info.setPort(80);
        this.sc = new ServerConfig(apps, info);
        this.rhm = new IAPHandlerManager(sc);
    }
}
