/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.handler;


import java.util.Map;

import iap.handler.IAPHandlerException;
import iap.handler.OpenApplicationHandler;
import iap.handler.annotation.OpenApplication;
import iap.request.OpenApplicationRequest;
import iap.response.OpenApplicationResponse;
import iap.response.Rating;


/**
 * <p>
 * This class is to test that the annotations compile correctly.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
@OpenApplication(viewId="test", rating=Rating.E)
public class TestOpenApplicationHandler implements OpenApplicationHandler {

    public void doOpenApplication(OpenApplicationRequest request,
            OpenApplicationResponse response)
    throws IAPHandlerException {
    }


    public void create(Map<String, String> parameters) throws IAPHandlerException {
    }

    public void destory() throws IAPHandlerException {
    }
}