package com.inversoft.iap.server.config.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.AccessType;

@XmlType(name = "base-handler")
@XmlAccessorType(AccessType.FIELD)
public class BaseHandlerBind {
    protected List<ParameterBind> parameter = new ArrayList<ParameterBind>();
    @XmlAttribute() protected String classname;
    @XmlAttribute() protected String name;
    @XmlAttribute(name = "pre-start") protected boolean preStart;

    /**
     * Gets the value of the classname property.
     */
    public String getClassname() {
        return classname;
    }

    /**
     * Sets the value of the classname property.
     */
    public void setClassname(String value) {
        classname = value;
    }

    /**
     * Gets the value of the Parameter property.
     */
    public List<ParameterBind> getParameter() {
        return this.parameter;
    }

    /**
     * Gets the value of the preStart property.
     */
    public boolean isPreStart() {
        return preStart;
    }

    /**
     * Sets the value of the preStart property.
     */
    public void setPreStart(boolean value) {
        preStart = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}