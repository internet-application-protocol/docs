/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import javax.security.auth.Subject;

import iap.VersionNumber;
import iap.model.Container;
import iap.request.AuthenticateUserRequest;

/**
 * <p>
 * This class is a container implementation.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPContainer extends Container {
    private final ApplicationKey appKey;

    public IAPContainer(ApplicationKey appKey) {
        this.appKey = appKey;
    }

    public void initialize() {
        Container.setInstance(this);
    }

    public void authenticate(Subject subject, AuthenticateUserRequest request) {
    }

    public String getApplicationName() {
        return this.appKey.name;
    }

    public VersionNumber getApplicationVersion() {
        return this.appKey.version;
    }
}