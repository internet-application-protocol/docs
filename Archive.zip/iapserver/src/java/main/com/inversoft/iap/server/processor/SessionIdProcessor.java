/*
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import java.util.List;
import java.nio.ByteBuffer;

import iap.VersionNumber;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataBody;
import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.response.ResponseDataImpl;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.Request;
import com.inversoft.iap.transport.BaseResponse;
import com.inversoft.iap.transport.SessionId;

/**
 * <p>
 * This class is a base class for any processor that uses the
 * {@link SessionId} class to determine the application and version
 * that the request is targeted towards.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class SessionIdProcessor<T extends Request, U extends BaseResponse>
extends BaseProcessor<T, U> {

    /**
     * Constructs a new SessionIdProcessor.
     *
     * @param   sessionManager The SessionManager to use.
     * @param   handlerManager The IAPHandlerManager to use.
     * @param   serverConfig The SeverConfig for the currently running server.
     */
    SessionIdProcessor(SessionManager sessionManager, IAPHandlerManager handlerManager,
            ServerConfig serverConfig) {
        super(sessionManager, handlerManager, serverConfig);
    }

    /**
     * Determines the application specs using the SessionId object.
     *
     * @param   sessionId Used to determine the application specs.
     * @return  The application specs.
     */
    ApplicationKey determineApplicationSpecs(SessionId sessionId) {
        String name = sessionId.getApplicationId();
        VersionNumber version = sessionId.getVersionNumber();
        return new ApplicationKey(name, version);
    }

    /**
     * Locates the application configuration directly because any request that has a
     * SessionId is targeted to a specific application.
     *
     * @param   appKey The ApplicationKey of the application (name and version tuple).
     * @param   response The response to store failure in if the application specs are
     *          bogus. The code set into the response is "2.0".
     * @return  The configuration or null if the specs are bogus.
     */
    ApplicationDeploymentConfig determineApplication(ApplicationKey appKey, U response) {
        ApplicationDeploymentConfig adc = getServerConfig().getApplication(appKey);
        // if the ApplicationDeploymentConig is null then its a result of either
        // the application requested doesn't exist or there was a problem
        // with confinguring it correctly
        if (adc == null) {
            response.getStatus().setCode("2.2");
            response.getStatus().setValue("Unable to properly configure the " +
                    "application specified: " + appKey.name + " v" +
                    appKey.version.toString());
        }
        return adc;
    }
}