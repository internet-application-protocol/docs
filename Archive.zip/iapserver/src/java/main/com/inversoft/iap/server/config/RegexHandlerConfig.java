/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * This class is the handler configuration for handlers that
 * are matched passed on regex patterns. The regex could be a
 * module or view name for example.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class RegexHandlerConfig extends HandlerConfig {
    private final Pattern regex;

    /**
     * Constructs a new <code>ModuleHandlerConfig</code>.
     *
     * @param   name The name of the handler from the iap.xml file.
     * @param   klass The Handler class.
     * @param   preStart A flag that determines if the handler should be
     *          pre-started by the container at server startup.
     * @param   parameters The parameters map.
     * @param   regex The regex pattern that this handler is target for. This
     *          is a regular expression used to determine if a specific item is
     *          targeted to a handler or not. The item is not defined by this class.
     */
    public RegexHandlerConfig(String name, Class klass, boolean preStart,
            Map<String, String> parameters, String regex) {
        super(name, klass, preStart, parameters);
        this.regex = Pattern.compile(regex);
    }


    /**
     * Returns the regex pattern as it is defined in the iap.xml file.
     *
     * @return  The regex pattern.
     */
    public String getModule() {
        return this.regex.pattern();
    }

    /**
     * Uses the regex to determine if the given String is covered by this configuration
     * object.
     *
     * @param   str The String to determine if this handler config covers.
     * @return  True if this handler config covers the String, false otherwise.
     */
    public boolean handles(String str) {
        Matcher matcher = this.regex.matcher(str);
        return matcher.matches();
    }
}