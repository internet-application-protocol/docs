/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.session;


import java.util.HashMap;
import java.util.Map;

import iap.request.IAPSession;

import com.inversoft.iap.transport.SessionId;


/**
 * <p>
 * This class is an implementation of the IAPSession interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPSessionImpl implements IAPSession {
    private final Map<String, Object> session = new HashMap<String, Object>();
    private final SessionId sessionId;
    private long timeout;
    private long timeoutPoint;

    /**
     * Constructs a new <code>IAPSession</code> with the given Session Id.
     *
     * @param   sessionId The session Id.
     * @param   duration The initial duration of the session (in milliseconds).
     */
    public IAPSessionImpl(SessionId sessionId, long duration) {
        this.sessionId = sessionId;
        this.timeout = duration;
        this.timeoutPoint = System.currentTimeMillis() + duration;
    }

    public SessionId getSessionId() {
        return this.sessionId;
    }

    /**
     * Returns the instance in time that this session will expire.
     *
     * @return  The time in milliseconds since epoch that this session will expire.
     */
    public synchronized long getExpirePoint() {
        return this.timeoutPoint;
    }

    /**
     * Using the duration inside this session, this resets the expiration point
     * to now plus the timeout length.
     */
    public synchronized void resetExpirePoint() {
        this.timeoutPoint = System.currentTimeMillis() + this.timeout;
    }

    /**
     * Returns true if the session has expired.
     *
     * @return  True if the session has expired, false otherwise.
     */
    public synchronized boolean isExpired() {
        return System.currentTimeMillis() > timeoutPoint;
    }


    /**
     * @inheritDoc
     */
    public synchronized long getTimeout() {
        return this.timeout;
    }

    /**
     * @inheritDoc
     */
    public synchronized void setTimeout(long timeout) {
        this.timeout = timeout;
    }

    /**
     * @inheritDoc
     */
    public void setAttribute(String key, Object value) {
        this.session.put(key, value);
    }

    /**
     * @inheritDoc
     */
    public Object getAttribute(String key) {
        return this.session.get(key);
    }
}