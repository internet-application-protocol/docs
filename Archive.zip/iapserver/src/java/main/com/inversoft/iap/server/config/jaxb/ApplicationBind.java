package com.inversoft.iap.server.config.jaxb;

import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.AccessType;

@XmlType(name = "")
@XmlAccessorType(AccessType.FIELD)
public class ApplicationBind {
    @XmlAttribute(required = true) private String location;

    /**
     * Gets the value of the location property.
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     */
    public void setLocation(String value) {
        location = value;
    }
}