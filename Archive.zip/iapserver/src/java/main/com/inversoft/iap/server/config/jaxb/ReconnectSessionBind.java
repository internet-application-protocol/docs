/**
 * Date Created: May 25, 2005
 * Created By:   James Humphrey
 */

package com.inversoft.iap.server.config.jaxb;

import javax.xml.bind.annotation.XmlType;

/**
 * Extends BaseHandlerBind to inherit the BaseHandler xml characteristics
 *
 * @author James Humphrey
 * @version 1.0
 */
@XmlType(name = "reconnect-session-handler")
public class ReconnectSessionBind extends BaseHandlerBind {
    // stub since no additional attributes are defined in the
    // reconnect-session-handler element other than what's defined in
    // BaseHandler
}
