package com.inversoft.iap.server.config.jaxb;

import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAttribute;

@XmlType(name = "open-view-handler")
public class OpenViewHandlerBind extends BaseHandlerBind {
    @XmlAttribute(required = true) protected String view;

    /**
     * Gets the value of the view property.
     */
    public String getView() {
        return view;
    }

    /**
     * Sets the value of the view property.
     */
    public void setView(String value) {
        view = value;
    }
}