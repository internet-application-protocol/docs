/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;


import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.config.ApplicationConfig;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.Request;
import com.inversoft.iap.transport.BaseResponse;
import com.inversoft.iap.transport.Status;


/**
 * <p>
 * This class is the standard base class that forces all
 * processors to have a constructor that takes a
 * {@link SessionManager}.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class BaseProcessor<T extends Request, U extends BaseResponse> implements Processor<T, U> {
    private final SessionManager sessionManager;
    private final IAPHandlerManager handlerManager;
    private final ServerConfig serverConfig;

    /**
     * Constructs a new <code>BaseTransportProcessor</code> that uses the given
     * SessionManager for session operations and IAPHandlerManager for handler
     * operations.
     *
     * @param   sessionManager The SessionManager to use.
     * @param   handlerManager The IAPHandlerManager to use.
     */
    public BaseProcessor(SessionManager sessionManager, IAPHandlerManager handlerManager,
            ServerConfig serverConfig) {
        assert (sessionManager != null) : "sessionManager == null";
        this.sessionManager = sessionManager;
        this.handlerManager = handlerManager;
        this.serverConfig = serverConfig;
    }


    /**
     * Returns the SessionManager.
     *
     * @return  The SessionManager.
     */
    public SessionManager getSessionManager() {
        return sessionManager;
    }

    /**
     * Returns the IAPHandlerManager.
     *
     * @return  The IAPHandlerManager.
     */
    public IAPHandlerManager getHandlerManager() {
        return handlerManager;
    }

    /**
     * Returns the configuration for the currently running server.
     *
     * @return  The server configuration.
     */
    public ServerConfig getServerConfig() {
        return serverConfig;
    }

    /**
     * Implements the handle method finally so that all sub-classes must use the template
     * methods in order control the flow. This method is responsible for setting up the
     * class loader for the processing and tearing it down and therefore it must be final.
     *
     * @param   request The request to handle.
     * @return  The response.
     */
    public final U handle(T request) {
        ApplicationKey appSpec = determineApplicationSpecs(request);
        U response = createResponse();
        ApplicationDeploymentConfig adc = determineApplication(appSpec, response);
        if (adc == null) {
            return response;
        } else {
            int sessionDuration = adc.getApplicationConfig().getDefaultSessionDuration();
            response.getStatus().setSessionDuration(sessionDuration);
        }

        ClassLoader oldCL = setUp(adc.getApplicationConfig());
        try {
            handleInternal(request, response, appSpec, adc);
        } finally {
            tearDown(oldCL);
        }

        return response;
    }

    /**
     * To be implemented by sub-classes to locate the application name and
     * version number from the request that the sub-classes are implemented
     * to handle.
     *
     * @param   request The request object.
     * @return  A Tuple that contains the application name and the the
     * version number.
     */
    abstract ApplicationKey determineApplicationSpecs(T request);

    /**
     * Creates a response that will be returned from the processor.
     *
     * @return  A newly constructed response.
     */
    abstract U createResponse();

    /**
     * Locates the application configuration based on the application name and version
     * number. The response is also supplied so that implementations can add in status
     * codes and status text.
     *
     * @param   appKey The ApplicationKey of the application (name and version tuple).
     * @param   response The response.
     * @return  Returns the configuration if found or null if the name and version number
     *          don't resolve correctly. When null is returned the processor exits sending
     *          back the response.
     */
    abstract ApplicationDeploymentConfig determineApplication(ApplicationKey appKey, U response);

    /**
     * This is the main handle implementation that sub-classes must provide.
     *
     * @param   request The request.
     * @param   response The response.
     * @param   appKey The ApplicationKey of the application (name and version tuple).
     * @param   adc The application configuration.
     */
    abstract void handleInternal(T request, U response, ApplicationKey appKey,
        ApplicationDeploymentConfig adc);

    /**
     * Creates a new Response and sets up the Status object inside it.
     *
     * @param   type The type of response to create.
     * @return  The response and never null.
     */
    <T extends BaseResponse> T createResponse(Class<T> type) {
        try {
            T resTrans = type.newInstance();
            Status status = new Status();
            resTrans.setStatus(status);
            return resTrans;
        } catch (Exception e) {
            throw new AssertionError(e);
        }
    }

    /**
     * Sets up the processing by setting in the context classloader into the current thread,
     * which is the thread that will be excuting the application.
     *
     * @param   applicationConfig The application configuration to get the ClassLoader from.
     * @return  The previous classloader used during tear down.
     */
    ClassLoader setUp(ApplicationConfig applicationConfig) {
        Thread thread = Thread.currentThread();
        ClassLoader old = thread.getContextClassLoader();
        thread.setContextClassLoader(applicationConfig.getClassLoader());
        return old;
    }

    /**
     * Tears down the processing by replacing the old classloader with the classloader of
     * the IAP just executed by the processor.
     *
     * @param   classLoader The old class loader to set back into the thread.
     */
    void tearDown(ClassLoader classLoader) {
        Thread thread = Thread.currentThread();
        thread.setContextClassLoader(classLoader);
    }
}