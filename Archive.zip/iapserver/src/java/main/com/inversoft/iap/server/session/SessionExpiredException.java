/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.session;


/**
 * <p>
 * This exception is thrown whenever a session expires.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class SessionExpiredException extends Exception {
    /**
     * Constructs a new <Code>SessionExpiredException</code>.
     */
    public SessionExpiredException() {
    }
}