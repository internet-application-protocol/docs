/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;

/**
 * <p>
 * This class contains the default values for the server conifiguration.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class ServerConfigDefaults {
    /**
     * Returns the default number of threads that a server is started with.
     *
     * @return  10.
     */
    public static int getDefaultExecuteThreads() {
        return 10;
    }

    /**
     * Returns the default queue size that a server is started with.
     *
     * @return  200.
     */
    public static int getDefaultQueueSize() {
        return 200;
    }

    /**
     * Returns the default timeout for the server to maintain client connections.
     *
     * @return  300,000. (5 minutes)
     */
    public static int getDefaultTimeout() {
        return 300000;
    }

    /**
     * Returns the default timeout for the server to block during select operations.
     *
     * @return  10 milliseconds.
     */
    public static int getDefaultSelectTimeout() {
        return 10;
    }
}