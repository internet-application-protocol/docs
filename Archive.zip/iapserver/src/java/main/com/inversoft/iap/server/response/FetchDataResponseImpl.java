/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;


import iap.TransportType;
import iap.response.FetchDataResponse;
import iap.response.ResponseData;


/**
 * <p>
 * This class is an implementation of the FetchDataResponse
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class FetchDataResponseImpl extends BaseResponseImpl
implements FetchDataResponse {
    private ResponseData responseData;


    /**
     * Constructs a new <code>FetchDataResponseImpl</code> with the given
     * ResponseData object.
     *
     * @param   responseData The response data.
     */
    public FetchDataResponseImpl(ResponseData responseData) {
        this.responseData = responseData;
    }


    /**
     * Returns the response type, which for this implementation is the
     * {@link iap.TransportType#FETCH_DATA} type.
     */
    public TransportType getResponseType() {
        return TransportType.FETCH_DATA;
    }

    /**
     * @inheritDoc
     */
    public ResponseData getResponseData() {
        return responseData;
    }
}