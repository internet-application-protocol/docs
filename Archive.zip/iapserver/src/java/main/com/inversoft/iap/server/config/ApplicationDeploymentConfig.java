/*
 * Copyright (c) 2004-2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;

import java.io.File;

/**
 * <p>
 * This class is the configuration model for a single application
 * running inside a server.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class ApplicationDeploymentConfig implements Comparable<ApplicationDeploymentConfig> {
    private String name;
    private File location;
    private ApplicationConfig applicationConfig;

    public ApplicationDeploymentConfig(String name, File location, ApplicationConfig applicationConfig) {
        this.name = name;
        this.location = location;
        this.applicationConfig = applicationConfig;
    }

    public String getName() {
        return this.name;
    }

    public File getLocation() {
        return this.location;
    }

    public ApplicationConfig getApplicationConfig() {
        return applicationConfig;
    }

    /**
     * Compares the two configs by version number.
     *
     * @param   config The config to compare with.
     * @return  Positive if this version is bigger than that parameters version, zero if
     *          they are equal and negative if the parameter is bigger.
     */
    public int compareTo(ApplicationDeploymentConfig config) {
        return this.applicationConfig.getVersion().compareTo(config.applicationConfig.getVersion());
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ApplicationDeploymentConfig)) return false;

        final ApplicationDeploymentConfig applicationDeploymentConfig = (ApplicationDeploymentConfig) o;

        if (!applicationConfig.equals(applicationDeploymentConfig.applicationConfig)) return false;
        if (!name.equals(applicationDeploymentConfig.name)) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = name.hashCode();
        result = 29 * result + applicationConfig.hashCode();
        return result;
    }
}