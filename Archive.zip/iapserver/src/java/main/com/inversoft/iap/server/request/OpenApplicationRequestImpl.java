/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;


import iap.TransportType;
import iap.Size;
import iap.request.DeviceType;
import iap.request.IAPSession;
import iap.request.OpenApplicationRequest;


/**
 * <p>
 * This class is the implementation of the OpenApplicationRequest
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenApplicationRequestImpl extends BaseRequestImpl
implements OpenApplicationRequest {
    private Size size;
    private DeviceType device;


    /**
     * Constructs a new <code>OpenApplicationRequestImpl</code> that uses the given
     * IAPSession, size and device constraints.
     *
     * @param   session The session.
     * @param   size The size constraint.
     * @param   device The device constraint.
     */
    public OpenApplicationRequestImpl(IAPSession session, Size size,
            DeviceType device) {
        super(session);
        this.size = size;
        this.device = device;
    }


    /**
     * Returns the type of this request, which is {@link TransportType#OPEN_APPLICATION}
     * type.
     *
     * @return  The type of this request.
     */
    public TransportType getRequestType() {
        return TransportType.OPEN_APPLICATION;
    }

    /**
     * @inheritDoc
     */
    public Size getSizeConstraints() {
        return size;
    }

    /**
     * @inheritDoc
     */
    public DeviceType getDeviceConstraint() {
        return device;
    }
}