package com.inversoft.iap.server.config.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.inversoft.iap.server.config.ServerConfigDefaults;

@XmlRootElement(name = "server")
@XmlAccessorType(AccessType.FIELD)
public class ServerBind {
    private List<ApplicationBind> application = new ArrayList<ApplicationBind>();
    private DefaultApplicationBind defaultApplication;
    @XmlAttribute() private String listenAddress;
    @XmlAttribute(required = true) private String name;
    @XmlAttribute(required = true) private int port;
    @XmlAttribute() private Integer executeThreads;
    @XmlAttribute() private Integer queueSize;
    @XmlAttribute() private Integer selectTimeout;
    @XmlAttribute() private Integer timeout;

    /**
     * Gets the value of the Application property.
     */
    public List<ApplicationBind> getApplication() {
        return this.application;
    }

    public int getPort() {
        return port;
    }

    /**
     * Sets the value of the port property.
     */
    public void setPort(int value) {
        port = value;
    }

    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     */
    public void setName(String value) {
        name = value;
    }

    /**
     * Returns the number of execute threads, which defaults to 10 based on the ServerConfigDefaults
     * object.
     *
     * @return  The number of execute threads or the default number.
     */
    public Integer getExecuteThreads() {
        if (this.executeThreads == null) {
            return ServerConfigDefaults.getDefaultExecuteThreads();
        }

        return executeThreads;
    }

    /**
     * Sets the value of the executeThreads property.
     */
    public void setExecuteThreads(Integer value) {
        executeThreads = value;
    }

    /**
     * Returns the queue size, which defaults to 10 based on the {@link ServerConfigDefaults#getDefaultQueueSize()}
     * method.
     *
     * @return  The queue size or the default number.
     */
    public Integer getQueueSize() {
        if (this.queueSize == null) {
            return ServerConfigDefaults.getDefaultQueueSize();
        }

        return queueSize;
    }

    /**
     * Sets the value of the queueSize property.
     */
    public void setQueueSize(Integer value) {
        queueSize = value;
    }

    /**
     * Returns the number of milliseconds that the server will hold onto client connections before
     * closing them. This uses the method {@link ServerConfigDefaults#getDefaultTimeout()} if the
     * value isn't specified.
     *
     * @return  The time out or the default value.
     */
    public Integer getTimeout() {
        if (this.timeout == null) {
            return ServerConfigDefaults.getDefaultTimeout();
        }
        return this.timeout;
    }

    /**
     * Sets the value of the timeout property.
     */
    public void setTimeout(Integer value) {
        timeout = value;
    }

    /**
     * Returns the number of milliseconds that the server will block on select operations. This uses
     * the method {@link ServerConfigDefaults#getDefaultSelectTimeout()} if the value isn't specified.
     *
     * @return  The time out or the default value.
     */
    public Integer getSelectTimeout() {
        if (this.selectTimeout == null) {
            return ServerConfigDefaults.getDefaultSelectTimeout();
        }

        return this.selectTimeout;
    }

    /**
     * Sets the value of the selectTimeout property.
     */
    public void setSelectTimeout(Integer value) {
        selectTimeout = value;
    }

    /**
     * Gets the value of the listenAddress property.
     */
    public String getListenAddress() {
        return listenAddress;
    }

    /**
     * Sets the value of the listenAddress property.
     */
    public void setListenAddress(String value) {
        listenAddress = value;
    }

    /**
     * Gets the name and version of the default application, which might be null.
     */
    public DefaultApplicationBind getDefaultApplication() {
        return defaultApplication;
    }

    /**
     * Sets the name and version of the default application.
     */
    public void setDefaultApplication(DefaultApplicationBind defaultApplication) {
        this.defaultApplication = defaultApplication;
    }
}