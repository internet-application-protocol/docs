/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.session;


import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.transport.SessionId;


/**
 * <p>
 * This class is the session manager that builds and stores
 * sessions for an entire running instance of the IAP server.
 * The session Objects are created specifically for an IAP
 * application running in the server.
 * </p>
 *
 * <p>
 * Sessions are keyed off of the session id which is only
 * of the {@link SessionId} object and only the id portion
 * required by the specification. This part is enough to
 * identify the session uniquely in one running server.
 * </p>
 *
 * <p>
 * This object also attempts to clean out sessions using an
 * additional thread. This Thread is a scheduled thread that
 * runs at configurable intervals. It can also be forced to
 * run using the {@link #cleanup()} method.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class SessionManager {
    private final Map<SessionId, IAPSessionImpl> sessions = new HashMap<SessionId, IAPSessionImpl>();
    private final Lock lock = new ReentrantLock(true);
    private final ScheduledExecutorService cleaner = Executors.newSingleThreadScheduledExecutor();

    /**
     * Constructs a new <Code>SessionManager</code> that manages the sessions and
     * also attempts to clean up threads at the given interval. Negative intervals
     * mean never clean.
     *
     * @param   cleanInterval The interval to attempt to clean up sessions (in
     *          milliseconds).
     */
    public SessionManager(long cleanInterval) {
        this.cleaner.scheduleAtFixedRate(new SessionCleaner(), cleanInterval,
            cleanInterval, TimeUnit.MILLISECONDS);
    }

    /**
     * Creates a new IAPSessionImpl that references the given {@link SessionId}.
     * This session is stored into the session Map.
     *
     * @param   sessionId The existing session Id to create the new IAPSessionImpl
     *          using.
     * @return  The IAPSessionImpl and never null.
     */
    public IAPSessionImpl createSession(SessionId sessionId, int defaultDuration) {
        this.lock.lock();
        try {
            String id = sessionId.getStringId();
            if (sessions.get(id) != null) {
                throw new IllegalStateException("Found existing session, unable " +
                    "to create new session");
            }
            // convert duration to millis (1000 millis/sec * 60 sec/min)
            long durationInMillis = defaultDuration * 60000;
            IAPSessionImpl session = new IAPSessionImpl(sessionId, durationInMillis);
            sessions.put(sessionId, session);
            return session;
        } finally {
            this.lock.unlock();
        }
    }

    /**
     * Creates a new IAPSessionImpl that has a new {@link SessionId} that uses
     * the given applicationName and versionNumber. This session is stored into
     * the session Map.
     *
     * @param   appKey The ApplicationKey of the application (name and version tuple).
     * @return  The IAPSessionImpl and never null.
     */
    public IAPSessionImpl createSession(ApplicationKey appKey, int defaultDuration) {
        this.lock.lock();
        try {
            SessionId sessionId = new SessionId(appKey.name, appKey.version);
            return createSession(sessionId, defaultDuration);
        } finally {
            this.lock.unlock();
        }
    }

    /**
     * Retrieves a previously stored session that was stored by the Manager under
     * the given sessionId.
     *
     * @param   sessionId The key of the IAPSessionImpl
     * @return  The IAPSessionImpl or null if it doesn't exist.
     */
    public SessionStruct getSession(SessionId sessionId) {
        this.lock.lock();
        try {
            SessionStruct struct = new SessionStruct();
            struct.session = sessions.get(sessionId);
            // if the session doesn't yet exist
            if (struct.session == null) {
                struct.expired = true;
            } else {
                // Lock the session so that the application can't change
                // the timeout in the middle.
                synchronized (struct.session) {
                    if (struct.session.isExpired()) {
                        sessions.remove(sessionId);
                        struct.expired = true;
                        struct.session = null;
                    }

                    if (struct.session != null) {
                        struct.session.resetExpirePoint();
                    }
                }
            }

            return struct;
        } finally {
            this.lock.unlock();
        }
    }

    /**
     * Removes the session from active use. This returns the session after removing it.
     * If the session had already expired, null is returned.
     *
     * @param   sessionId The key of the IAPSessionImpl.
     * @return  The IAPSessionImpl or null if it doesn't exist.
     */
    public IAPSessionImpl removeSession(SessionId sessionId) {
        this.lock.lock();
        try {
            return this.sessions.remove(sessionId);
        } finally {
            this.lock.unlock();
        }
    }

    public void cleanup() {
        this.cleaner.schedule(new SessionCleaner(), 0, TimeUnit.MILLISECONDS);
    }


    /**
     * The cleaner thread that periodically cleans out expired sessions.
     */
    private class SessionCleaner implements Runnable {

        /**
         * Iterates over the session Map and tries to clean out any sessions that
         * are timed out.
         */
        public void run() {
            lock.lock();
            try {
                for (SessionId key : sessions.keySet()) {
                    IAPSessionImpl session = sessions.get(key);
                    if (session == null || session.isExpired()) {
                        sessions.remove(key);
                    }
                }
            } finally {
                lock.unlock();
            }
        }
    }

   /**
    * A simple struct for containing a session as well as a flag that
    * denotes whether or not the session was expired and re-created.
    */
   public class SessionStruct {
        public IAPSessionImpl session;
        public boolean expired;
    }
}