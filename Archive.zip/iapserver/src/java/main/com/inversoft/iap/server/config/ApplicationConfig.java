/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import iap.TransportType;
import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.transport.FetchModuleRequest;
import com.inversoft.iap.transport.OpenViewRequest;
import com.inversoft.iap.transport.PerformActionRequest;
import com.inversoft.iap.transport.Request;

/**
 * <p>
 * This class stores the configuration objects for the IAPServer.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class ApplicationConfig implements Comparable<ApplicationConfig> {
    private final HandlerConfig closeApp;
    private final HandlerConfig openApp;
    private final HandlerConfig authUser;
    private final HandlerConfig fetchData;
    private final HandlerConfig reconnectSession;
    private final Set<RegexHandlerConfig> fetchModules;
    private final Set<RegexHandlerConfig> openViews;
    private final Set<ViewActionHandlerConfig> performActions;
    private final Map<String, HandlerConfig> allHandlers;
    private final ClassLoader classloader;
    private final String welcomeView;
    private final VersionNumber version;
    private final Rating rating;
    private final int defaultSessionDuration;

    /**
     * Constructs a new registry that stores all of the given handlers and lists
     * of handlers. These lists are copied so that they are internally safe. They
     * are also stored internally as unmodifiable lists.
     *
     * All the lists and configs must be provided or this will assert. The reason
     * for this is that the IAPServer must pass in default configurations for
     * default handlers so that all request types can be handled in some manner.
     *
     * @param   authUser The authenticate user handler config (only one).
     * @param   closeApp The close application handler config (only one).
     * @param   fetchData The fetch data handler configs (only one).
     * @param   fetchModules The fetch module handler configs (multiple).
     * @param   openApp The open application handler config (only one).
     * @param   openViews The open view handler configs (multiple).
     * @param   performActions The perform action handler configs (multiple).
     * @param   welcomeView The default welcome view if there is not open application
     *          handler or if that handler does not set the welcome view.
     * @asserts If any parameter is null or empty.
     * @throws  ConfigurationException If the configuration given is invalid.
     */
    public ApplicationConfig(HandlerConfig authUser, HandlerConfig closeApp,
            HandlerConfig fetchData, HandlerConfig openApp,
            Set<RegexHandlerConfig> fetchModules,
            Set<RegexHandlerConfig> openViews,
            Set<ViewActionHandlerConfig> performActions,
            ClassLoader classloader, String welcomeView, VersionNumber version,
            Rating rating, int defaultSessionDuration,
            HandlerConfig reconnectSession) throws ConfigurationException {
        assert (classloader != null) : "classloader == null";
        assert (version != null) : "version == null";
        assert (rating != null) : "rating == null";

        this.version = version;
        this.rating = rating;
        this.defaultSessionDuration = defaultSessionDuration;

        this.authUser = authUser;
        this.closeApp = closeApp;
        this.openApp = openApp;
        this.fetchData = fetchData;
        this.reconnectSession = reconnectSession;
        this.classloader = classloader;
        this.welcomeView = welcomeView;

        int size = 3;
        if (fetchModules != null) {
            this.fetchModules =
                Collections.unmodifiableSet(new LinkedHashSet<RegexHandlerConfig>(fetchModules));
            size += this.fetchModules.size();
        } else {
            this.fetchModules = null;
        }

        if (openViews != null) {
            this.openViews =
                Collections.unmodifiableSet(new LinkedHashSet<RegexHandlerConfig>(openViews));
            size += this.openViews.size();
        } else {
            this.openViews = null;
        }

        if (performActions != null) {
            this.performActions =
                Collections.unmodifiableSet(new LinkedHashSet<ViewActionHandlerConfig>(performActions));
            size += this.performActions.size();
        } else {
            this.performActions = null;
        }

        Map<String, HandlerConfig> temp = new HashMap<String, HandlerConfig>(size);
        storeConfig(temp, authUser);
        storeConfig(temp, closeApp);
        storeConfig(temp, openApp);
        storeConfig(temp, fetchData);
        storeConfig(temp, reconnectSession);
        storeAllConfigs(temp, fetchModules);
        storeAllConfigs(temp, openViews);
        storeAllConfigs(temp, performActions);
        this.allHandlers = Collections.unmodifiableMap(temp);
    }

    private void storeAllConfigs(Map<String, HandlerConfig> map, Set<? extends HandlerConfig> configs)
    throws ConfigurationException {
        if (configs != null) {
            for (HandlerConfig config : configs) {
                storeConfig(map, config);
            }
        }
    }

    private void storeConfig(Map<String, HandlerConfig> map, HandlerConfig config)
    throws ConfigurationException {
        if (config != null) {
            if (map.containsKey(config.getName())) {
                throw new ConfigurationException("More than one handler named [" + config.getName() +
                    "] exists");
            }
            map.put(config.getName(), config);
        }
    }


    /**
     * Returns the classloader for this application. This classloader is used to
     * load and run all class for this application.
     *
     * @return  The classloader.
     */
    public ClassLoader getClassLoader() {
        return this.classloader;
    }

    /**
     * Returns the authenticate user handler config for this application if there
     * is one.
     *
     * @return  The authenticate user handler config or null.
     */
    public HandlerConfig authUser() {
        return this.authUser;
    }

    /**
     * Returns the close application handler config for this application if there
     * is one.
     *
     * @return  The close application handler config or null.
     */
    public HandlerConfig closeApp() {
        return this.closeApp;
    }

    /**
     * Returns the open application handler config for this application if there
     * is one.
     *
     * @return  The open application handler config or null.
     */
    public HandlerConfig openApp() {
        return this.openApp;
    }

    /**
     * Returns the reconnect handler config for this application if there is one
     *
     * @return the reconnect session handler config or null
     */
    public HandlerConfig reconnectSession() {
        return reconnectSession;
    }

    /**
     * Returns the Set of fetch module handler configs for this application. If
     * none were configured, then this method returns null.
     *
     * @return  The Set or null.
     */
    public Set<RegexHandlerConfig> fetchModules() {
        return this.fetchModules;
    }

    /**
     * Returns the fetch data handler config for this application.
     *
     * @return  The Handler and never null.
     */
    public HandlerConfig fetchData() {
        return fetchData;
    }

    /**
     * Returns the Set of open view handler configs for this application. If
     * none were configured, then this method returns null.
     *
     * @return  The Set or null.
     */
    public Set<RegexHandlerConfig> openViews() {
        return openViews;
    }

    /**
     * Returns the Set of perform action handler configs for this application. If
     * none were configured, then this method returns null.
     *
     * @return  The Set or null.
     */
    public Set<ViewActionHandlerConfig> performActions() {
        return performActions;
    }

    /**
     * Returns the welcome view.
     *
     * @return  The view ID or null.
     */
    public String getWelcomeView() {
        return welcomeView;
    }

    /**
     * Returns the version of the application.
     *
     * @return  The version of the application.
     */
    public VersionNumber getVersion() {
        return this.version;
    }

    /**
     * Returns the applications rating.
     *
     * @return  The rating.
     */
    public Rating getRating() {
        return this.rating;
    }

    /**
     * Returns the default session duration.
     *
     * @return  The duration from the configuration file or 30 minutes.
     */
    public int getDefaultSessionDuration() {
        return defaultSessionDuration;
    }

    /**
     * Looks up the handler config for the handler with the given name. This name
     * is the name assigned to the handler from the iap.xml file.
     *
     * @param   name The name of the handler.
     * @return  The HandlerConfig or null if none exists.
     */
    public HandlerConfig lookupHandlerConfig(String name) {
        return this.allHandlers.get(name);
    }

    /**
     * <p>
     * Finds the handler config that will handle the given IAP request transport
     * object. If the transport happens to be a regular expression type such as
     * the open view perform action, or fetch module type, it is cast to the correct
     * type and the values inside the transport are used when resolving handlers.
     * Lastly, for perform action types, the transport is cast to a PerformActionRequest
     * and the action is also fetched to help locate the handler.
     * </p>
     * <p>
     * For example, if the transport is an open view transport, then the {@link
     * ViewHandlerConfig} objects are fetched from the {@link #openViews()} method.
     * Each one is then called using the {@link RegexHandlerConfig#handles(String)}
     * method to determine if the configuration supports handling of the specific
     * view ID that is passed in using the item parameter.
     * </p>
     *
     * @param   transport Transport to use when locating a handler.
     * @return  The HandlerConfig if one is found, otherwise null.
     */
    public HandlerConfig lookupHandlerConfig(Request transport) {
        assert (transport != null) : "transport == null";
        TransportType type = transport.getType();
        HandlerConfig config = null;
        if (type == TransportType.AUTHENTICATE_USER) {
            config = authUser();
        } else if (type == TransportType.CLOSE_APPLICATION) {
            config = closeApp();
        } else if (type == TransportType.OPEN_APPLICATION) {
            config = openApp();
        } else if (type == TransportType.FETCH_DATA) {
            config = fetchData();
        } else if (type == TransportType.RECONNECT_SESSION) {
            config = reconnectSession();
        } else if (type == TransportType.FETCH_MODULE) {
            String item = ((FetchModuleRequest) transport).getModuleInfo().getModuleId();
            Set<RegexHandlerConfig> set = fetchModules();
            if (set != null) {
                for (RegexHandlerConfig moduleConfig : set) {
                    if (moduleConfig.handles(item)) {
                        config = moduleConfig;
                    }
                }
            }
        } else if (type == TransportType.OPEN_VIEW) {
            String item = ((OpenViewRequest) transport).getViewInfo().getViewId();
            Set<RegexHandlerConfig> set = openViews();
            if (set != null) {
                for (RegexHandlerConfig hc : set) {
                    if (hc.handles(item)) {
                        config = hc;
                    }
                }
            }
        } else if (type == TransportType.PERFORM_ACTION) {
            String item = ((PerformActionRequest) transport).getViewInfo().getViewId();
            String action = ((PerformActionRequest) transport).getActionInfo().getActionId();
            Set<ViewActionHandlerConfig> set = performActions();
            if (set != null) {
                for (ViewActionHandlerConfig hc : set) {
                    if (hc.handles(item) && hc.handlesAction(action)) {
                        config = hc;
                    }
                }
            }
        }

        return config;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ApplicationConfig)) return false;

        final ApplicationConfig applicationConfig = (ApplicationConfig) o;

        if (!version.equals(applicationConfig.version)) return false;

        return true;
    }

    public int hashCode() {
        return version.hashCode();
    }

    public int compareTo(ApplicationConfig applicationConfig) {
        return version.compareTo(applicationConfig.version);
    }
}