/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;


import iap.TransportType;
import iap.response.OpenApplicationResponse;
import iap.response.Rating;
import iap.response.Redirect;


/**
 * <p>
 * This class is an implementation of the OpenApplicationResponse
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenApplicationResponseImpl extends BaseResponseImpl
implements OpenApplicationResponse {
    private boolean cacheable;
    private Redirect redirect;
    private String viewId;
    private Rating rating;


    /**
     * Constructs a new <code>OpenApplicationResponseImpl</code>.
     */
    public OpenApplicationResponseImpl() {
    }


    /**
     * Returns the response type, which for this implementation is the
     * {@link iap.TransportType#OPEN_APPLICATION} type.
     */
    public TransportType getResponseType() {
        return TransportType.OPEN_APPLICATION;
    }

    /**
     * @inheritDoc
     */
    public String getViewId() {
        return viewId;
    }

    /**
     * @inheritDoc
     */
    public void setViewId(String viewId) {
        this.viewId = viewId;
    }

    /**
     * @inheritDoc
     */
    public boolean isCacheable() {
        return this.cacheable;
    }

    /**
     * @inheritDoc
     */
    public void setCacheable(boolean cacheable) {
        this.cacheable = cacheable;
    }

    /**
     * @inheritDoc
     */
    public Redirect getRedirect() {
        return this.redirect;
    }

    /**
     * @inheritDoc
     */
    public void setRedirect(Redirect redirect) {
        this.redirect = redirect;
    }

    /**
     * @inheritDoc
     */
    public Rating getRating() {
        return rating;
    }

    /**
     * @inheritDoc
     */
    public void setRating(Rating rating) {
        this.rating = rating;
    }

    /**
     * @inheritDoc
     */
    public Redirect getApplicationReference() {
        return null;
    }

    /**
     * @inheritDoc
     */
    public void setApplicationReference(Redirect ref) {
    }
}