/*
 * Copyright (c) 2004-2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.config.jaxb.DefaultApplicationBind;
import com.inversoft.iap.server.config.jaxb.ServerBind;

/**
 * <p>
 * This class is the configuration model for the server itself.
 * This maintains the information about a running server such
 * as the applications running, the listen port, the listen
 * address, etc.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class ServerConfig {
    private final Map<ApplicationKey, ApplicationDeploymentConfig> applications;
    private final ServerBind serverInfo;

    public ServerConfig(Set<ApplicationDeploymentConfig> applications, ServerBind serverInfo) {
        Map<ApplicationKey, ApplicationDeploymentConfig> apps =
            new HashMap<ApplicationKey, ApplicationDeploymentConfig>();
        for (ApplicationDeploymentConfig config : applications) {
            ApplicationKey key = new ApplicationKey(config.getName(),
                config.getApplicationConfig().getVersion());
            apps.put(key, config);
        }

        this.applications = Collections.unmodifiableMap(apps);
        this.serverInfo = serverInfo;
    }

    public ApplicationDeploymentConfig getApplication(ApplicationKey appKey) {
        return applications.get(appKey);
    }

    /**
     * Returns the default application, which might be null if one was not configured.
     *
     * @return  The default application.
     */
    public ApplicationDeploymentConfig getDefaultApplication() {
        DefaultApplicationBind defApp = serverInfo.getDefaultApplication();
        ApplicationDeploymentConfig adc = null;
        if (defApp != null) {
            if (defApp.getVersion() != null) {
                adc = applications.get(defApp.toApplicationKey());
            } else {
                SortedSet<ApplicationDeploymentConfig> apps = getAllApplications(defApp.getName());
                return apps.last();
            }
        }

        return adc;
    }

    /**
     * Returns all the applications that have the given name. This may include multiple
     * versions of that application's configuration, one for each version of the
     * application that is deployed inside the server.
     *
     * @param   name The name of the application
     * @return  A Set containing all the application configurations and never null.
     *          If the application name doesn't correspond to an application inside
     *          the server, than this returns an empty Set. This set is sorted by version
     *          number.
     */
    public SortedSet<ApplicationDeploymentConfig> getAllApplications(String name) {
        SortedSet<ApplicationDeploymentConfig> apps = new TreeSet<ApplicationDeploymentConfig>();
        Set<ApplicationKey> keys = this.applications.keySet();
        for (ApplicationKey key : keys) {
            if (key.name.equals(name)) {
                apps.add(this.applications.get(key));
            }
        }

        return apps;
    }

    /**
     * Returns the server information object.
     */
    public ServerBind getServerInfo() {
        return serverInfo;
    }

    /**
     * Returns the session clean interval for the server. This is the interval that
     * the server regularly sweeps all the in memory sessions and invalidates them.
     *
     * @return  The session clean interval.
     */
    public long getSessionCleanInterval() {
        return 300000;
    }
}