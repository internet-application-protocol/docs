/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import iap.TransportType;
import iap.request.FetchDataRequest;
import iap.request.IAPSession;


/**
 * <p>
 * This class is the implementation of the FetchDataRequest
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class FetchDataRequestImpl extends BaseRequestImpl
implements FetchDataRequest {
    private List<String> names;


    /**
     * Constructs a new <code>FetchDataRequestImpl</code> that uses the given
     * IAPSession and list of names.
     *
     * @param   session The session.
     * @param   names The list of names.
     */
    public FetchDataRequestImpl(IAPSession session, List<String> names) {
        super(session);
        this.names = Collections.unmodifiableList(new ArrayList<String>(names));
    }

    /**
     * Returns the type of this request, which is {@link TransportType#FETCH_DATA}
     * type.
     *
     * @return  The type of this request.
     */
    public TransportType getRequestType() {
        return TransportType.FETCH_DATA;
    }

    /**
     * @inheritDoc
     */
    public List<String> getDataNames() {
        return names;
    }
}