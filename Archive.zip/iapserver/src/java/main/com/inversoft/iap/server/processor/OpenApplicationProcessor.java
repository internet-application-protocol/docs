/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import iap.Size;
import iap.VersionNumber;
import iap.handler.OpenApplicationHandler;
import iap.handler.annotation.OpenApplication;
import iap.request.DeviceType;
import iap.response.Rating;
import iap.response.Redirect;

import com.inversoft.iap.response.OpenApplicationStatus;
import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.IAPContainer;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.jaxb.DefaultApplicationBind;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.request.OpenApplicationRequestImpl;
import com.inversoft.iap.server.response.OpenApplicationResponseImpl;
import com.inversoft.iap.server.session.IAPSessionImpl;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.ApplicationDescription;
import com.inversoft.iap.transport.ApplicationSpec;
import com.inversoft.iap.transport.ClientConstraint;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.RatingInfo;
import com.inversoft.iap.transport.RedirectGroup;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.SuccessGroup;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.util.StringTools;

/**
 * <p>
 * This class implements the functionality for the IAP server
 * to handle incoming open application requests.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenApplicationProcessor
extends BaseProcessor<OpenApplicationRequest, OpenApplicationResponse> {
    private static final Logger logger = Logger.getLogger(OpenApplicationProcessor.class.getName());

    /**
     * Constructs a new <code>OpenApplicationTransportProcessor</code> that uses
     * the given SessionManager for session operations and IAPHandlerManager for
     * handler operations.
     *
     * @param   sessionManager The SessionManager to use.
     * @param   handlerManager The IAPHandlerManager to use.
     * @param   serverConfig The SeverConfig for the currently running server.
     */
    public OpenApplicationProcessor(SessionManager sessionManager,
            IAPHandlerManager handlerManager, ServerConfig serverConfig) {
        super(sessionManager, handlerManager, serverConfig);
    }

    /**
     * Constructs a response.
     *
     * @return  A new response.
     */
    OpenApplicationResponse createResponse() {
        return createResponse(OpenApplicationResponse.class);
    }

    /**
     * Determines the application name and version number that the request is targeted to.
     *
     * @param   request The request to retrieve the name and version number from.
     * @return  The name and version number.
     */
    ApplicationKey determineApplicationSpecs(OpenApplicationRequest request) {
        // Normalize the name
        String name = request.getApplicationInfo().getApplicationId();
        if (name != null && name.startsWith("/")) {
            name = name.substring(1);
        }

        VersionNumber versionNumber = request.getApplicationInfo().getVersionNumber();
        if (StringTools.isEmpty(name) || name.equals("/")) {
            DefaultApplicationBind defaultApp = getServerConfig().getServerInfo().getDefaultApplication();
            if (defaultApp == null) {
                logger.log(Level.SEVERE, "Client requested the default application, but no " +
                    "application was configured to be the default.");
                name = null;
            } else {
                name = defaultApp.getName();
                String defaultVer = defaultApp.getVersion();
                if (versionNumber == null && !StringTools.isEmpty(defaultVer)) {
                    versionNumber = VersionNumber.decode(defaultVer);
                }
            }
        }

        VersionNumber version = null;
        if (versionNumber != null) {
            version = versionNumber;
        }

        ApplicationKey appKey = null;
        if (name != null) {
            appKey = new ApplicationKey(name, version);
            if (logger.isLoggable(Level.FINEST)) {
                logger.log(Level.FINEST, "Processing open application " +
                        "request for application [" + appKey + "]");
            }
        }

        return appKey;
    }

    /**
     * Locates the application configuration.
     *
     * @param   appKey The ApplicationKey of the application (name and version tuple).
     * @param   response The response object that is populated with error codes and such.
     * @return  The configuration if the application exists and matches version or null if
     *          the application isn't valid. The caller should bail in that case.
     */
    ApplicationDeploymentConfig determineApplication(ApplicationKey appKey, OpenApplicationResponse response) {
        ApplicationDeploymentConfig adc = null;
        SortedSet<VersionNumber> otherVersions = new TreeSet<VersionNumber>();
        if (appKey != null) {
            SortedSet<ApplicationDeploymentConfig> apps = getServerConfig().getAllApplications(appKey.name);
            if (appKey.version == null && apps != null && apps.size() > 0) {
                adc = apps.last();
            } else {
                for (ApplicationDeploymentConfig config : apps) {
                    VersionNumber ver = config.getApplicationConfig().getVersion();
                    if (ver.equals(appKey.version)) {
                        adc = config;
                    } else {
                        otherVersions.add(ver);
                    }
                }
            }
        }

        if (adc == null) {
            OpenApplicationStatus status = OpenApplicationStatus.FAILURE_NON_EXISTENT;
            if (otherVersions.size() > 0) {
                if (otherVersions.last().compareTo(appKey.version) > 0) {
                    status = OpenApplicationStatus.FAILURE_NEWER_VERSION;
                } else {
                    status = OpenApplicationStatus.FAILURE_OLDER_VERSION;
                }

                String versionList = buildVersions(otherVersions);
                response.getStatus().setValue(versionList);
            }

            response.getStatus().setCode(status.getCode());
            if (appKey != null) {
                logger.log(Level.SEVERE, "Request for non-existant application [" + appKey.name + " " +
                    appKey.version + "]");
            }
        } else if (otherVersions.size() > 0 && otherVersions.last().compareTo(appKey.version) > 0) {
            String versionList = buildVersions(otherVersions);
            response.getStatus().setCode(OpenApplicationStatus.SUCCESS_NEWER_VERSION.getCode());
            response.getStatus().setValue(versionList);
        } else {
            response.getStatus().setCode(OpenApplicationStatus.SUCCESS.getCode());
        }

        return adc;
    }

    /**
     * Handles the given open application request transport object. This method
     * handles the request by doing some stuff.
     *
     * @param   request The open application request transport object to handle.
     * @param   response The open application response that was generated by the super-class.
     * @param   adc The application configuration.
     */
    void handleInternal(OpenApplicationRequest request, OpenApplicationResponse response,
            ApplicationKey appKey, ApplicationDeploymentConfig adc) {
        // Creat a new key because the parameter key might not have the version number inside it
        // if the client only passed in the application name. This new key will have all the correct
        // information.
        ApplicationKey internalKey = new ApplicationKey(adc.getName(),
            adc.getApplicationConfig().getVersion());
        IAPContainer container = new IAPContainer(internalKey);
        container.initialize();

        OpenApplicationResponseImpl responseImpl = new OpenApplicationResponseImpl();
        OpenApplicationRequestImpl requestImpl = createRequest(request,
                internalKey,
                adc.getApplicationConfig().getDefaultSessionDuration());
        OpenApplicationHandler handler =
            (OpenApplicationHandler) getHandlerManager().fetchHandler(internalKey, request);

        OpenApplication oa = null;
        if (handler != null) {
            try {
                handler.doOpenApplication(requestImpl, responseImpl);
            } catch (Throwable t) {
                logger.log(Level.SEVERE, "Caught exception calling handler", t);
                response.getStatus().setCode(OpenApplicationStatus.FAILURE_OPENING.getCode());
            }

            oa = handler.getClass().getAnnotation(OpenApplication.class);
        }

        String viewId = responseImpl.getViewId();
        if (viewId == null) {
            if (oa != null) {
                viewId = oa.viewId();
            }

            if (viewId == null) {
                viewId = adc.getApplicationConfig().getWelcomeView();
            }
        }

        Rating rating = responseImpl.getRating();
        if (rating == null) {
            if (oa != null) {
                rating = oa.rating();
            }

            if (rating == null) {
                rating = adc.getApplicationConfig().getRating();
            }
        }

        // Populate the response transport
        if (responseImpl.getRedirect() != null) {
            Redirect redirect = new Redirect(responseImpl.getRedirect().getUrl());
            response.setRedirectGroup(new RedirectGroup());
            response.getRedirectGroup().setRedirect(redirect);
        } else {
            SessionId sessionId = new SessionId(adc.getName(), adc.getApplicationConfig().getVersion(),
                ((IAPSessionImpl) requestImpl.getSession()).getSessionId().getStringId());
            response.setSuccessGroup(new SuccessGroup());
            response.getSuccessGroup().setSessionId(sessionId);

            ApplicationDescription desc = new ApplicationDescription();
            desc.setIsCacheable(true);
            response.getSuccessGroup().setApplicationDescription(desc);

            RatingInfo ratingInfo = new RatingInfo();
            ratingInfo.setRating(rating);
            response.getSuccessGroup().setRatingInfo(ratingInfo);

            ViewInfo viewInfo = new ViewInfo();
            viewInfo.setViewId(viewId);
            response.getSuccessGroup().setViewInfo(viewInfo);

            if (responseImpl.getApplicationReference() != null) {
                ApplicationSpec reference = new ApplicationSpec();
                reference.setApplicationSpec(responseImpl.getApplicationReference().getUrl().toString());
                response.getSuccessGroup().setApplicationRef(reference);
            }
        }
    }

    private OpenApplicationRequestImpl createRequest(OpenApplicationRequest transport,
            ApplicationKey appKey, int defaultSessionDuration) {
        ClientConstraint cc = transport.getClientConstraint();
        Size size = null;
        DeviceType type = null;
        if (cc != null) {
            size = cc.getSizeConstraint();
            type = cc.getDeviceConstraint();
        }

        IAPSessionImpl session = getSessionManager().createSession(appKey, defaultSessionDuration);
        return new OpenApplicationRequestImpl(session, size, type);
    }

    private String buildVersions(Set<VersionNumber> otherVersions) {
        StringBuilder build = new StringBuilder();
        for (Iterator<VersionNumber> iter = otherVersions.iterator(); iter.hasNext(); ) {
            build.append(iter.next());
            if (iter.hasNext()) {
                build.append(",");
            }
        }

        return build.toString();
    }
}