/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.server.processor;

import java.util.logging.Level;
import java.util.logging.Logger;

import iap.handler.ReconnectSessionHandler;

import com.inversoft.iap.response.ReconnectSessionStatus;
import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.request.ReconnectSessionRequestImpl;
import com.inversoft.iap.server.response.ReconnectSessionResponseImpl;
import com.inversoft.iap.server.session.IAPSessionImpl;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.ReconnectSessionResponse;
import com.inversoft.iap.transport.SessionId;

/**
 * <p>
 * This class implements the functionality for the IAP server
 * to handle incoming reconnect session requests.
 * </p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ReconnectSessionProcessor
        extends SessionIdProcessor<ReconnectSessionRequest, ReconnectSessionResponse> {

    private static final Logger logger = Logger.getLogger(ReconnectSessionProcessor.class.getName());

    public ReconnectSessionProcessor(SessionManager sessionManager,
                                     IAPHandlerManager handlerManager,
                                     ServerConfig serverConfig) {
        super(sessionManager, handlerManager, serverConfig);
    }

    /**
     * Delegates
     *
     * @param   request The request object.
     * @return  A Tuple that contains the application name and the the version number.
     */
    public ApplicationKey determineApplicationSpecs(ReconnectSessionRequest request) {
        return determineApplicationSpecs(request.getSessionId());
    }

    /**
     * Delegates
     *
     * @return  A newly constructed response.
     */
    public ReconnectSessionResponse createResponse() {
        return createResponse(ReconnectSessionResponse.class);
    }

    /**
     * This is the main handle implementation that sub-classes must provide.
     *
     * @param   request The request.
     * @param   response The response.
     * @param   appKey The ApplicationKey of the application (name and version tuple).
     * @param   adc The application configuration.
     */
    public void handleInternal(ReconnectSessionRequest request,
                               ReconnectSessionResponse response,
                               ApplicationKey appKey,
                               ApplicationDeploymentConfig adc) {
        SessionId session = request.getSessionId();
        SessionManager.SessionStruct sessionStruct = getSessionManager().getSession(session);
        IAPSessionImpl iapSession = sessionStruct.session;
        int sessionDuration = adc.getApplicationConfig().getDefaultSessionDuration();

        // if the SessionStruct.expired = true then we know that the session
        // is not contained in the SessionManager.sessions map so recreate it
        if (sessionStruct.expired) {
            iapSession = getSessionManager().createSession(session, sessionDuration);
        }

        ReconnectSessionRequestImpl requestImpl = new ReconnectSessionRequestImpl(iapSession);
        ReconnectSessionResponseImpl responseImpl = new ReconnectSessionResponseImpl();
        ReconnectSessionHandler handler = (ReconnectSessionHandler) getHandlerManager().fetchHandler(appKey, request);
        ReconnectSessionStatus status = ReconnectSessionStatus.SUCCESS;

        if (handler != null) {
            try {
                handler.doReconnectSession(requestImpl, responseImpl);
            } catch (Throwable t) {
                logger.log(Level.SEVERE, "Error handling the session reconnect for application " + "[" +
                    adc.getName() + "]", t);
                status = ReconnectSessionStatus.FAILURE;
            }
        }

        response.getStatus().setCode(status.getCode());
        response.getStatus().setSessionDuration(sessionDuration);
    }
}
