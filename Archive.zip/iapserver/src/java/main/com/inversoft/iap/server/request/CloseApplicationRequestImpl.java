/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;


import iap.TransportType;
import iap.request.CloseApplicationRequest;
import iap.request.IAPSession;


/**
 * <p>
 * This is the implementation of the close application request
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class CloseApplicationRequestImpl extends BaseRequestImpl
implements CloseApplicationRequest {

    /**
     * Creates a new <code>CloseApplicationRequestImpl</code> that uses the given
     * IAPSession.
     *
     * @param   session The session.
     */
    public CloseApplicationRequestImpl(IAPSession session) {
        super(session);
    }

    /**
     * Returns the type of this request, which is {@link TransportType#CLOSE_APPLICATION}
     * type.
     *
     * @return  The type of this request.
     */
    public TransportType getRequestType() {
        return TransportType.CLOSE_APPLICATION;
    }
}