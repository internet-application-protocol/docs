/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.server.request;

import iap.TransportType;
import iap.request.IAPSession;
import iap.request.ReconnectSessionRequest;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ReconnectSessionRequestImpl extends BaseRequestImpl
        implements ReconnectSessionRequest {

    /**
     * Creates a new <code>ReconnectSessionRequestImpl</code> that uses the
     * given IAPSession.
     *
     * @param session The session.
     */
    public ReconnectSessionRequestImpl(IAPSession session) {
        super(session);
    }

    /**
     * Returns the {@link TransportType#RECONNECT_SESSION} type.
     *
     * @return The type of request that this instance of the IAPRequest is.
     */
    public TransportType getRequestType() {
        return TransportType.RECONNECT_SESSION;
    }
}
