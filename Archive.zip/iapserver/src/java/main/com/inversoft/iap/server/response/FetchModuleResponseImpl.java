/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;


import java.nio.ByteBuffer;

import iap.TransportType;
import iap.response.FetchModuleResponse;


/**
 * <p>
 * This class is an implementation of the FetchModuleResponse
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class FetchModuleResponseImpl extends BaseBinaryResponseImpl
implements FetchModuleResponse {
    /**
     * Returns the response type, which for this implementation is
     * {@link iap.TransportType.FETCH_MODULE}.
     */
    public TransportType getResponseType() {
        return TransportType.FETCH_MODULE;
    }

    /**
     * @inheritDoc
     */
    public ByteBuffer getModuleBytes() {
        return super.bytes;
    }

    /**
     * @inheritDoc
     */
    public void setModuleBytes(ByteBuffer bytes) {
        if (stream != null) {
            throw new IllegalStateException("Unable to set ByteBuffer after the" +
                "OutputStream has been written to.");
        }

        super.bytes = bytes;
    }
}