/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;


import iap.TransportType;
import iap.request.FetchModuleRequest;
import iap.request.IAPSession;


/**
 * <p>
 * This class is the implementation of the FetchModuleRequest
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class FetchModuleRequestImpl extends BaseRequestImpl
implements FetchModuleRequest {
    private String moduleId;


    /**
     * Constructs a new <code>FetchModuleRequestImpl</code> that uses the given
     * IAPSession and module ID.
     *
     * @param   session The session.
     * @param   moduleId The module ID.
     */
    public FetchModuleRequestImpl(IAPSession session, String moduleId) {
        super(session);
        this.moduleId = moduleId;
    }

    /**
     * Returns the type of this request, which is {@link TransportType#FETCH_MODULE}
     * type.
     *
     * @return  The type of this request.
     */
    public TransportType getRequestType() {
        return TransportType.FETCH_MODULE;
    }

    /**
     * @inheritDoc
     */
    public String getModuleId() {
        return moduleId;
    }
}