package com.inversoft.iap.server.config.jaxb;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "session")
public class SessionBind {
    protected int defaultDuration;

    /**
     * Gets the value of the defaultDuration property.
     */
    public int getDefaultDuration() {
        return defaultDuration;
    }

    /**
     * Sets the value of the defaultDuration property.
     */
    public void setDefaultDuration(int value) {
        defaultDuration = value;
    }
}