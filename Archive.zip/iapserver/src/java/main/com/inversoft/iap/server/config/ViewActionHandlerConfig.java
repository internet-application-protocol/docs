/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;


import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * <p>
 * This class is a specific class for all handlers that deal
 * with views and actions. Currently this is only the perform
 * action handler, but could be expanded to include other
 * handlers as well.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class ViewActionHandlerConfig extends RegexHandlerConfig {
    private final Pattern actionRegex;


    /**
     * Constructs a new <code>ViewHandlerConfig</code>.
     *
     * @param   name The name of the handler from the iap.xml file.
     * @param   klass The Handler class.
     * @param   preStart A flag that determines if the handler should be
     *          pre-started by the container at server startup.
     * @param   parameters The parameters map.
     * @param   view The view definition that this handler is target for. This
     *          is a regular expression used to determine if a specific view is
     *          targeted to a handler or not.
     * @param   action The action definition that this handler is target for.
     *          This is a regular expression used to determine if a specific
     *          action is targeted to a handler or not.
     */
    public ViewActionHandlerConfig(String name, Class klass, boolean preStart,
            Map<String, String> parameters, String view, String action) {
        super(name, klass, preStart, parameters, view);
        this.actionRegex = Pattern.compile(action);
    }


    /**
     * Returns the regex pattern that describes whether or not actions are covered
     * by the handler this configuration refers to.
     *
     * @return  The regex pattern.
     */
    public String getAction() {
        return actionRegex.pattern();
    }

    /**
     * Determines if the given action name is covered by the handler that this
     * configuration refers to.
     *
     * @param   actionName The action name to test for coverage.
     * @return  True if the action is covered by the handler, false otherwise.
     */
    public boolean handlesAction(String actionName) {
        Matcher matcher = this.actionRegex.matcher(actionName);
        return matcher.matches();
    }
}