/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;


import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import iap.TransportType;
import iap.handler.AuthenticateUserHandler;
import iap.handler.CloseApplicationHandler;
import iap.handler.FetchDataHandler;
import iap.handler.FetchModuleHandler;
import iap.handler.OpenApplicationHandler;
import iap.handler.OpenViewHandler;
import iap.handler.PerformActionHandler;
import iap.handler.ReconnectSessionHandler;

import com.inversoft.util.StringTools;


/**
 * <p>
 * This class is the configuration object for Handlers that
 * are configured via the iap.xml configuration file.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class HandlerConfig {
    private final boolean preStart;
    private final String name;
    private final Class klass;
    private final Map<String, String> parameters;

    /**
     * Constructs a new <code>HandlerConfig</code>.
     *
     * @param   name The name of the Handler.
     * @param   klass The Handler class.
     * @param   preStart A flag that determines if the handler should be
     *          pre-started by the container at server startup.
     * @param   parameters The parameters map.
     */
    public HandlerConfig(String name, Class klass, boolean preStart, Map<String, String> parameters) {
        assert (parameters != null) : "parameters == null";
        assert (!StringTools.isEmpty(name)) : "name is empty";

        this.name = name;
        this.klass = klass;
        this.preStart = preStart;

        Map<String, String> temp = new HashMap<String, String>();
        temp.putAll(parameters);
        this.parameters = Collections.unmodifiableMap(temp);
    }

    /**
     * Returns the name of the Handler as defined in the iap.xml file.
     *
     * @return  The name.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the implementing class of this Handler.
     *
     * @return The implementing class.
     */
    public String getClassName() {
        return klass.getName();
    }

    /**
     * Returns all the types of IAP requests and responses that this Handler can
     * handle. This is calculated using the interfaces that the class implements.
     *
     * @return  All the types that this handler implements.
     */
    public Set<TransportType> getHandlerTypes() {
        Set<TransportType> types = new HashSet<TransportType>(TransportType.values().length);
        Class[] interfaces = klass.getInterfaces();
        for (Class inter : interfaces) {
            if (inter == AuthenticateUserHandler.class) {
                types.add(TransportType.AUTHENTICATE_USER);
            } else if (inter == CloseApplicationHandler.class) {
                types.add(TransportType.CLOSE_APPLICATION);
            } else if (inter == FetchModuleHandler.class) {
                types.add(TransportType.FETCH_MODULE);
            } else if (inter == FetchDataHandler.class) {
                types.add(TransportType.FETCH_DATA);
            } else if (inter == OpenApplicationHandler.class) {
                types.add(TransportType.OPEN_APPLICATION);
            } else if (inter == OpenViewHandler.class) {
                types.add(TransportType.OPEN_VIEW);
            } else if (inter == PerformActionHandler.class) {
                types.add(TransportType.PERFORM_ACTION);
            } else if (inter == ReconnectSessionHandler.class) {
                types.add(TransportType.RECONNECT_SESSION);
            }
        }

        return types;
    }

    /**
     * Returns whether or not this handler is to be pre-started or not.
     *
     * @return  True if pre-started, false otherwise.
     */
    public boolean isPreStart() {
        return preStart;
    }

    /**
     * Returns an unmodifiable Map of the parameters for this Handler.
     *
     * @return  The Map of parameters.
     */
    public Map<String, String> getParameters() {
        return parameters;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HandlerConfig)) return false;

        final HandlerConfig handlerConfig = (HandlerConfig) o;

        if (!name.equals(handlerConfig.name)) return false;

        return true;
    }

    public int hashCode() {
        return name.hashCode();
    }
}