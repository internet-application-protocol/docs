/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * <p>
 * This class is a shutdown hook thread that signals the NIOServer
 * thread and then loops for 60 seconds to allow ample time for the
 * server to shutdown correctly.
 * </p>
 *
 * @author  Brian Pontarelli
 * @version 1.0
 * @since   IAP 1.0
 */
public class IAPShutdown extends Thread {
    private static final Logger logger = Logger.getLogger(IAPShutdown.class.getName());
    private IAPServer server;

    public IAPShutdown(IAPServer server) {
        this.server = server;
    }

    /**
     * Shuts down the server cleanly.
     */
    public void run() {
        logger.info("Starting shutdown of server...");

        server.shutdown();

        int count = 0;
        while (server.isRunning()) {
            if (count == 60) {
                break;
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                logger.log(Level.SEVERE, "Shutdown hook thread interrupted", e);
            }

            count++;
        }

        if (server.isRunning()) {
            logger.log(Level.SEVERE, "Server failed to gracefully shutdown. Terminating!");
        }

        logger.info("Server shutdown complete.");
    }
}