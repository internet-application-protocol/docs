/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBException;

import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.ServerConfigBuilder;
import com.inversoft.nio.NIOServer;
import com.inversoft.util.JAXBTools;

/**
 * <p>
 * This class is the main entry point for the IAP server.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class IAPServer extends NIOServer {
    private static final Logger logger = Logger.getLogger(IAPServer.class.getName());

    /**
     * Starts a new IAPServer.
     *
     * @param   config The IAPServer configuration information that contains the
     *          port, timeout, selectTimeout, handler, factory, execute thread pool
     *          size and work queue size.
     */
    public IAPServer(ServerConfig config) throws IOException {
        super(new IAPNIOLifecycle(config), config.getServerInfo().getPort(),
            config.getServerInfo().getTimeout(), config.getServerInfo().getSelectTimeout());
        logger.log(Level.INFO, "IAPServer started on IP [" + InetAddress.getLocalHost().getHostAddress() +
            "] Port [" + config.getServerInfo().getPort() + "]");
    }

    public static void main(String[] args) {
        try {
            // Initialize the TransportFactory for the configuration and the transports
            JAXBTools.addObjectFactory(com.inversoft.iap.server.config.jaxb.ObjectFactory.class);

            logger.log(Level.INFO, "Starting IAPServer on IP [" +
                InetAddress.getLocalHost().getHostAddress() + "]");

            ServerConfigBuilder builder = new ServerConfigBuilder();
            ServerConfig serverConfig = builder.build();
            IAPServer server = new IAPServer(serverConfig);
            Runtime.getRuntime().addShutdownHook(new IAPShutdown(server));
        } catch (IOException ioe) {
            logger.log(Level.SEVERE, "Unable to create server", ioe);
            System.exit(1);
        } catch (JAXBException e) {
            logger.log(Level.SEVERE, "Unable to load the JAXBContext", e);
            System.exit(1);
        }
    }
}