package com.inversoft.iap.server.config.jaxb;

import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAttribute;

@XmlType(name = "perform-action-handler")
public class PerformActionHandlerBind extends BaseHandlerBind {
    @XmlAttribute(required = true) protected String action;
    @XmlAttribute(required = true) protected String view;

    /**
     * Gets the value of the action property.
     */
    public String getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     */
    public void setAction(String value) {
        action = value;
    }

    /**
     * Gets the value of the view property.
     */
    public String getView() {
        return view;
    }

    /**
     * Sets the value of the view property.
     */
    public void setView(String value) {
        view = value;
    }
}