/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;

import iap.request.IAPRequest;
import iap.request.IAPSession;

/**
 * <p>
 * This class is the abstract base class for all the request
 * implementations that provides the IAPSession handling.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class BaseRequestImpl implements IAPRequest {
    private final IAPSession session;

    /**
     * Constructs a new <code>BaseRequestImpl</code> that uses the given IAPSession
     * implementation to pass back to clients.
     *
     * @param   session The session.
     */
    public BaseRequestImpl(IAPSession session) {
        this.session = session;
    }

    /**
     * @inheritDoc
     */
    public IAPSession getSession() {
        return session;
    }
}