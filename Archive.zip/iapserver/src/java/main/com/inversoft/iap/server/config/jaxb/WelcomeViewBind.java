package com.inversoft.iap.server.config.jaxb;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "welcome-view")
public class WelcomeViewBind {
    protected String viewId;

    /**
     * Gets the value of the viewId property.
     */
    public String getViewId() {
        return viewId;
    }

    /**
     * Sets the value of the viewId property.
     */
    public void setViewId(String value) {
        viewId = value;
    }
}