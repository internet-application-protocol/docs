/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;


import iap.TransportType;
import iap.response.AuthenticateUserResponse;
import iap.response.AuthenticationFailure;
import iap.response.ResponseData;


/**
 * <p>
 * This class is an implementation of the AuthenticateUserResponse
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class AuthenticateUserResponseImpl extends BaseResponseImpl
implements AuthenticateUserResponse {
    private AuthenticationFailure authFailure;
    private ResponseData responseData;


    /**
     * Constructs a new <code>AuthenticateUserResponseImpl</code> with the given
     * ResponseData object.
     *
     * @param   responseData The response data.
     */
    public AuthenticateUserResponseImpl(ResponseData responseData) {
        this.responseData = responseData;
    }


    /**
     * Returns the response type, which for this implementation is
     * {@link iap.TransportType.AUTHENTICATE_USER}.
     */
    public TransportType getResponseType() {
        return TransportType.AUTHENTICATE_USER;
    }

    /**
     * @inheritDoc
     */
    public AuthenticationFailure getAuthenticationFailure() {
        return authFailure;
    }

    /**
     * @inheritDoc
     */
    public void setAuthenticationFailure(AuthenticationFailure authFailure) {
        this.authFailure = authFailure;
    }

    /**
     * @inheritDoc
     */
    public ResponseData getResponseData() {
        return responseData;
    }
}