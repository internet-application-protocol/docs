/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config.jaxb;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlType;

import iap.VersionNumber;

import com.inversoft.iap.server.ApplicationKey;

/**
 * <p>
 * This class is a bind object for the default application information.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
@XmlType(name = "")
@XmlAccessorType(AccessType.FIELD)
public class DefaultApplicationBind {
    @XmlAttribute(required = true) private String name;
    @XmlAttribute() private String version;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public ApplicationKey toApplicationKey() {
        VersionNumber ver = null;
        if (version != null) {
            ver = VersionNumber.decode(version);
        }

        return new ApplicationKey(name, ver);
    }
    
    public String toString() {
        return name + ", " + version;
    }
}