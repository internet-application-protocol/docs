/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import javax.xml.bind.JAXBException;

import iap.VersionNumber;
import iap.handler.annotation.FetchModule;
import iap.handler.annotation.Handler;
import iap.handler.annotation.ModuleResource;
import iap.handler.annotation.OpenApplication;
import iap.handler.annotation.OpenView;
import iap.handler.annotation.PerformAction;
import iap.handler.annotation.ReconnectSession;
import iap.handler.annotation.ViewAction;
import iap.handler.annotation.ViewResource;
import iap.response.Rating;

import com.inversoft.iap.server.config.jaxb.ApplicationBind;
import com.inversoft.iap.server.config.jaxb.BaseHandlerBind;
import com.inversoft.iap.server.config.jaxb.DefaultApplicationBind;
import com.inversoft.iap.server.config.jaxb.FetchModuleHandlerBind;
import com.inversoft.iap.server.config.jaxb.IAPBind;
import com.inversoft.iap.server.config.jaxb.ObjectFactory;
import com.inversoft.iap.server.config.jaxb.OpenViewHandlerBind;
import com.inversoft.iap.server.config.jaxb.ParameterBind;
import com.inversoft.iap.server.config.jaxb.PerformActionHandlerBind;
import com.inversoft.iap.server.config.jaxb.ServerBind;
import com.inversoft.iap.server.config.jaxb.SessionBind;
import com.inversoft.util.JAXBTools;

/**
 * <p>
 * This class builds the configuration objects for a server
 * using JAXB and then constructs the Inversoft config objects
 * from the JAXB objects. The Inversoft objects are a bit
 * better modeled and the conversion should not influence start
 * up time by much.
 * </p>
 *
 * <p>
 * This looks in the current directory for a file named server.xml.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class ServerConfigBuilder {
    private static final Logger logger = Logger.getLogger(ServerConfigBuilder.class.getName());
    public static final String IAP_FILE = "IAP-INF" + File.separator + "iap.xml";

    static {
        try {
            JAXBTools.addObjectFactory(ObjectFactory.class);
        } catch (JAXBException e) {
            logger.log(Level.SEVERE, "Unable to initialize JAXB", e);
            throw new ExceptionInInitializerError(e);
        }
    }

    /**
     * Builds the server configuration using the server.xml file and all the
     * application XML files.
     *
     * @return The server configuration object.
     */
    public ServerConfig build() {
        String location = System.getProperty("iap.server.config");
        if (location == null) {
            location = "server.xml";
        }

        ClassLoader bootCL = Thread.currentThread().getContextClassLoader();
        File serverDotXml = new File(location);
        ServerBind server = (ServerBind) JAXBTools.unmarshal(serverDotXml, ObjectFactory.class);
        List<ApplicationBind> apps = server.getApplication();
        Set<ApplicationDeploymentConfig> appDeploys = new HashSet<ApplicationDeploymentConfig>();
        DefaultApplicationBind defApp = server.getDefaultApplication();
        boolean foundDefault = false;
        for (int i = 0; i < apps.size(); i++) {
            ApplicationBind app = apps.get(i);
            File iapBase = new File(app.getLocation());
            if (!iapBase.exists()) {
                logger.log(Level.SEVERE, "Unable to locate application at [" + iapBase.toString() + "]");
                throw new IllegalArgumentException("Invalid configuration consult server logs for details");
            }

            IAPBind iap;
            if (iapBase.isDirectory()) {
                File iapDotXml = new File(iapBase + File.separator + IAP_FILE);
                iap = (IAPBind) JAXBTools.unmarshal(iapDotXml, ObjectFactory.class);
            } else {
                try {
                    JarFile file = new JarFile(iapBase);
                    ZipEntry entry = file.getEntry(IAP_FILE);
                    if (entry == null) {
                        logger.log(Level.SEVERE, "Application at [" + iapBase.toString() +
                            "] does not contain the file IAP-INF/iap.xml");
                        throw new IllegalArgumentException("Invalid application consult server logs for details");
                    }

                    iap = (IAPBind) JAXBTools.unmarshal(file.getInputStream(entry), ObjectFactory.class);
                } catch (IOException ioe) {
                    logger.log(Level.SEVERE, "Exception during configuration load", ioe);
                    throw new IllegalArgumentException(ioe);
                }
            }

            // Normalize the name.
            String name = iap.getName();
            if (name!= null && name.startsWith("/")) {
                name = name.substring(1);
            }

            ClassLoader iapCL = createIapCL(iapBase, bootCL);
            ApplicationConfig appConfig = convert(iap, iapCL);
            ApplicationDeploymentConfig appDeployConfig = new ApplicationDeploymentConfig(name, iapBase, appConfig);
            appDeploys.add(appDeployConfig);

            if (defApp != null && defApp.getName().equals(iap.getName()) &&
                    defApp.getVersion().equals(iap.getVersion())) {
                foundDefault = true;
            } else if (defApp == null) {
                foundDefault = true;
            }
        }

        if (!foundDefault) {
            logger.log(Level.SEVERE, "DefaultApplication [" + defApp + "] does not exist");
            throw new IllegalArgumentException("Invalid default application configured");
        }

        // Locate the default application
        return new ServerConfig(appDeploys, server);
    }

    private ClassLoader createIapCL(File iapbase, ClassLoader parent) {
        List<URL> urls = new ArrayList<URL>();
        File iapInfLib = new File(iapbase, "IAP-INF" + File.separatorChar + "lib");
        File[] files = iapInfLib.listFiles();
        try {
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        urls.add(file.toURL());
                    }
                }
            }

            File iapInfClasses = new File(iapbase, "IAP-INF" + File.separatorChar + "classes");
            urls.add(iapInfClasses.toURL());
        } catch (MalformedURLException mue) {
            logger.log(Level.SEVERE, "Unable to load classpath for application at [" +
                iapbase.getName() + "]", mue);
        }

        URL[] urlsArray = urls.toArray(new URL[urls.size()]);
        return new URLClassLoader(urlsArray, parent);
    }

    private ApplicationConfig convert(IAPBind iap, ClassLoader iapCL) {
        List<String> errors = new ArrayList<String>();

        BaseHandlerBind userJAXB = iap.getAuthenticateUserHandler();
        HandlerConfig userHandlerConfig = null;
        if (userJAXB != null) {
            userHandlerConfig = convert(userJAXB, null, iapCL, errors);
        }

        BaseHandlerBind closeJAXB = iap.getCloseApplicationHandler();
        HandlerConfig closeHandlerConfig = null;
        if (closeJAXB != null) {
            closeHandlerConfig = convert(closeJAXB, null, iapCL, errors);
        }

        BaseHandlerBind dataJAXB = iap.getFetchDataHandler();
        HandlerConfig dataHandlerConfig = null;
        if (dataJAXB != null) {
            dataHandlerConfig = convert(dataJAXB, null, iapCL, errors);
        }

        BaseHandlerBind reconnectJAXB = iap.getReconnectSessionHandler();
        HandlerConfig reconnectHandlerConfig = null;
        if (reconnectJAXB != null) {
            reconnectHandlerConfig = convert(reconnectJAXB, null, iapCL, errors);
        }

        List<FetchModuleHandlerBind> modulesJAXB = iap.getFetchModuleHandler();
        Set<RegexHandlerConfig> moduleHandlerConfigs = new HashSet<RegexHandlerConfig>();
        if (modulesJAXB != null && modulesJAXB.size() > 0) {
            for (FetchModuleHandlerBind moduleJAXB : modulesJAXB) {
                moduleHandlerConfigs.add(convert(moduleJAXB, null, iapCL, errors, moduleJAXB.getModule()));
            }
        }

        BaseHandlerBind appJAXB = iap.getOpenApplicationHandler();
        HandlerConfig appHandlerConfig = null;
        if (appJAXB != null) {
            appHandlerConfig = convert(appJAXB, null, iapCL, errors);
        }

        List<OpenViewHandlerBind> viewsJAXB = iap.getOpenViewHandler();
        Set<RegexHandlerConfig> viewHandlerConfigs = new HashSet<RegexHandlerConfig>();
        if (viewsJAXB != null && viewsJAXB.size() > 0) {
            for (OpenViewHandlerBind viewJAXB : viewsJAXB) {
                viewHandlerConfigs.add(convert(viewJAXB, null, iapCL, errors, viewJAXB.getView()));
            }
        }

        List<PerformActionHandlerBind> actionsJAXB = iap.getPerformActionHandler();
        Set<ViewActionHandlerConfig> actionHandlerConfigs = new HashSet<ViewActionHandlerConfig>();
        if (actionsJAXB != null && actionsJAXB.size() > 0) {
            for (PerformActionHandlerBind actionJAXB : actionsJAXB) {
                actionHandlerConfigs.add(convert(actionJAXB, null, iapCL, errors, actionJAXB.getView(),
                    actionJAXB.getAction()));
            }
        }

        List<BaseHandlerBind> genericsJAXB = iap.getGenericHandler();
        if (genericsJAXB != null && genericsJAXB.size() > 0) {
            for (BaseHandlerBind genericJAXB : genericsJAXB) {
                Class<?> klass;
                try {
                    klass = Class.forName(genericJAXB.getClassname(), true, iapCL);
                } catch (ClassNotFoundException cnfe) {
                    errors.add(cnfe.toString());
                    continue;
                }

                if (iap.handler.AuthenticateUserHandler.class.isAssignableFrom(klass)) {
                    if (userHandlerConfig != null) {
                        errors.add("Only one authenticate user handler can be specified");
                    } else {
                        Handler annotation = klass.getAnnotation(Handler.class);
                        iap.handler.annotation.Parameter[] params = annotation.parameters();
                        Map<String, String> paramsMap = convert(params);
                        userHandlerConfig = convert(genericJAXB, paramsMap, iapCL, errors);
                    }
                }

                if (iap.handler.CloseApplicationHandler.class.isAssignableFrom(klass)) {
                    if (closeHandlerConfig != null) {
                        errors.add("Only one close application handler can be specified");
                    } else {
                        Handler annotation = klass.getAnnotation(Handler.class);
                        iap.handler.annotation.Parameter[] params = annotation.parameters();
                        Map<String, String> paramsMap = convert(params);
                        closeHandlerConfig = convert(genericJAXB, paramsMap, iapCL, errors);
                    }
                }

                if (iap.handler.FetchModuleHandler.class.isAssignableFrom(klass)) {
                    FetchModule annotation = klass.getAnnotation(FetchModule.class);
                    if (annotation == null) {
                        errors.add("Generic fetch module handlers must be annotated correctly");
                    } else {
                        iap.handler.annotation.Parameter[] params = annotation.parameters();
                        Map<String, String> paramsMap = convert(params);

                        ModuleResource[] resources = annotation.resources();
                        for (ModuleResource resource : resources) {
                            moduleHandlerConfigs.add(convert(genericJAXB, paramsMap, iapCL, errors,
                                resource.moduleId()));
                        }
                    }
                }

                if (iap.handler.FetchDataHandler.class.isAssignableFrom(klass)) {
                    if (dataHandlerConfig != null) {
                        errors.add("Only one data application handler can be specified");
                    } else {
                        Handler annotation = klass.getAnnotation(Handler.class);
                        iap.handler.annotation.Parameter[] params = annotation.parameters();
                        Map<String, String> paramsMap = convert(params);
                        dataHandlerConfig = convert(genericJAXB, paramsMap, iapCL, errors);
                    }
                }

                if (iap.handler.OpenApplicationHandler.class.isAssignableFrom(klass)) {
                    if (appHandlerConfig != null) {
                        errors.add("Only one open application handler can be specified");
                    } else {
                        OpenApplication annotation = klass.getAnnotation(OpenApplication.class);
                        iap.handler.annotation.Parameter[] params = annotation.parameters();
                        Map<String, String> paramsMap = convert(params);
                        appHandlerConfig = convert(genericJAXB, paramsMap, iapCL, errors);
                    }
                }

                if (iap.handler.OpenViewHandler.class.isAssignableFrom(klass)) {
                    OpenView annotation = klass.getAnnotation(OpenView.class);
                    if (annotation == null) {
                        errors.add("Generic open view handlers must be annotated correctly");
                    } else {
                        iap.handler.annotation.Parameter[] params = annotation.parameters();
                        Map<String, String> paramsMap = convert(params);

                        ViewResource[] resources = annotation.resources();
                        for (ViewResource resource : resources) {
                            moduleHandlerConfigs.add(convert(genericJAXB, paramsMap, iapCL, errors,
                                resource.viewId()));
                        }
                    }
                }

                if (iap.handler.PerformActionHandler.class.isAssignableFrom(klass)) {
                    PerformAction annotation = klass.getAnnotation(PerformAction.class);
                    if (annotation == null) {
                        errors.add("Generic perform action handlers must be annotated correctly");
                    } else {
                        iap.handler.annotation.Parameter[] params = annotation.parameters();
                        Map<String, String> paramsMap = convert(params);

                        ViewAction[] viewActions = annotation.viewActions();
                        for (ViewAction viewAction : viewActions) {
                            actionHandlerConfigs.add(convert(genericJAXB, paramsMap, iapCL, errors,
                                viewAction.view(), viewAction.action()));
                        }
                    }
                }

                if (iap.handler.ReconnectSessionHandler.class.isAssignableFrom(klass)) {
                    if (appHandlerConfig != null) {
                        errors.add("Only one reconnect session handler can be specified");
                    } else {
                        ReconnectSession annotation = klass.getAnnotation(ReconnectSession.class);
                        iap.handler.annotation.Parameter[] params = annotation.parameters();
                        Map<String, String> paramsMap = convert(params);
                        appHandlerConfig =
                                convert(genericJAXB, paramsMap, iapCL, errors);
                    }
                }
            }
        }

        if (errors.size() > 0) {
            throw new IllegalArgumentException("Invalid configuration\n[" + errors.toString() + "]");
        }

        String viewId = null;
        if (iap.getWelcomeView() != null) {
            viewId = iap.getWelcomeView().getViewId();
        }

        VersionNumber version = VersionNumber.decode(iap.getVersion());
        Rating rating = null;
        if (iap.getRating() != null) {
            rating = iap.getRating();
        }

        SessionBind session = iap.getSession();
        // default the duration to 30 minutes
        int defaultDuration = 30;
        // if the session element is defined in the iap.xml
        // then set the duration to the defaultDuration
        if (session != null) {
            defaultDuration = session.getDefaultDuration();
        }

        try {
            return new ApplicationConfig(userHandlerConfig, closeHandlerConfig,
                    dataHandlerConfig, appHandlerConfig, moduleHandlerConfigs,
                    viewHandlerConfigs, actionHandlerConfigs, iapCL, viewId,
                    version, rating, defaultDuration, reconnectHandlerConfig);
        } catch (ConfigurationException ce) {
            errors.add("Application [" + iap.getName() + " " + version +
                    "] encountered error [" + ce.getMessage() + "]");
            throw new IllegalArgumentException("Invalid configuration\n[" +
                    errors.toString() + "]");
        }
    }

    private ViewActionHandlerConfig convert(BaseHandlerBind handler, Map<String, String> paramsMap, ClassLoader cl,
            List<String> errors, String regex, String action) {
        try {
            Class klass = Class.forName(handler.getClassname(), true, cl);
            Map<String, String> params = convert(handler.getParameter());
            if (paramsMap != null) {
                params.putAll(paramsMap);
            }

            return new ViewActionHandlerConfig(handler.getName(), klass, handler.isPreStart(), params,
                regex, action);
        } catch (ClassNotFoundException cnfe) {
            errors.add(cnfe.toString());
        }

        return null;
    }

    private RegexHandlerConfig convert(BaseHandlerBind handler, Map<String, String> paramsMap, ClassLoader cl,
            List<String> errors, String regex) {
        try {
            Class klass = Class.forName(handler.getClassname(), true, cl);
            Map<String, String> params = convert(handler.getParameter());
            if (paramsMap != null) {
                params.putAll(paramsMap);
            }

            return new RegexHandlerConfig(handler.getName(), klass, handler.isPreStart(), params, regex);
        } catch (ClassNotFoundException cnfe) {
            errors.add(cnfe.toString());
        }

        return null;
    }

    private HandlerConfig convert(BaseHandlerBind handler, Map<String, String> paramsMap, ClassLoader cl,
            List<String> errors) {
        try {
            Class klass = Class.forName(handler.getClassname(), true, cl);
            Map<String, String> params = convert(handler.getParameter());
            if (paramsMap != null) {
                params.putAll(paramsMap);
            }

            return new HandlerConfig(handler.getName(), klass, handler.isPreStart(), params);
        } catch (ClassNotFoundException cnfe) {
            errors.add(cnfe.toString());
        }

        return null;
    }

    private Map<String, String> convert(iap.handler.annotation.Parameter[] params) {
        Map<String, String> map = new HashMap<String, String>();
        for (int i = 0; i < params.length; i++) {
            iap.handler.annotation.Parameter param = params[i];
            map.put(param.name(), param.value());
        }
        return map;
    }

    private Map<String, String> convert(List<ParameterBind> parameters) {
        if (parameters == null || parameters.size() == 0) {
            return new HashMap<String, String>();
        }

        Map<String, String> params = new HashMap<String, String>();
        for (int i = 0; i < parameters.size(); i++) {
            ParameterBind p = parameters.get(i);
            params.put(p.getName(), p.getValue());
        }

        return params;
    }
}