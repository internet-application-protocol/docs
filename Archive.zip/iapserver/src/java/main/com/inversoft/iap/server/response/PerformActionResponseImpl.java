/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;

import iap.TransportType;
import iap.response.PerformActionResponse;
import iap.response.ResponseData;

/**
 * <p>
 * This class is an implementation of the PerformActionResponse
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class PerformActionResponseImpl extends BaseResponseImpl
implements PerformActionResponse {
    private final ResponseData responseData;

    /**
     * Constructs a new <code>PerformActionResponseImpl</code> with the given
     * ResponseData object.
     *
     * @param   responseData The response data.
     */
    public PerformActionResponseImpl(ResponseData responseData) {
        this.responseData = responseData;
    }


    /**
     * Returns the response type, which for this implementation is the
     * {@link iap.TransportType#PERFORM_ACTION} type.
     */
    public TransportType getResponseType() {
        return TransportType.PERFORM_ACTION;
    }

    /**
     * @inheritDoc
     */
    public ResponseData getResponseData() {
        return this.responseData;
    }
}