/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import java.util.List;

import com.inversoft.beans.JavaBean;
import com.inversoft.iap.Data;
import com.inversoft.iap.DataBody;

/**
 * <p>
 * This class is the base class for the data implementations of
 * IAP.
 * </p>
 *
 * @author  Brian Pontarelli
 * @see
 * @since   IAP 1.0
 * @version 1.0
 */
public class BaseDataImpl {
    protected final DataBody dataBody;

    /**
     * Constructs a new <code>BaseDataImpl</code> using the given {@link DataBody}
     * to retrieve the values from and set new values into.
     *
     * @param   dataBody The data body.
     */
    public BaseDataImpl(DataBody dataBody) {
        this.dataBody = dataBody;
    }

    /**
     * @inheritDoc
     */
    public <T> T getValue(String key, Class<T> type) {
        List<Data> values = this.dataBody.getAllValues(key);
        if (values.size() == 0) {
            return null;
        } else if (values.size() == 1 && values.get(0).getKey().equals(key)) {
            return (T) values.get(0).getValue();
        }

        T bean;
        try {
            bean = type.newInstance();
        } catch (InstantiationException ie) {
            throw new IllegalArgumentException("The type given [" + type.toString() +
                " cannot be instantiated", ie);
        } catch (IllegalAccessException iae) {
            throw new IllegalArgumentException("The type given [" + type.toString() +
                " cannot be instantiated", iae);
        }

        populateJavaBean(key, bean, values);
        return bean;
    }

    /**
     * Returns the internal DataBody that is used to store the data values.
     *
     * @return  The dataBody and never null.
     */
    public DataBody getDataBody() {
        return this.dataBody;
    }

    /**
     * Populates the given JavaBean with all the values from the List of Data
     * objects.
     */
    protected void populateJavaBean(String key, Object bean, List<Data> values) {
        JavaBean jb = JavaBean.getInstance(bean.getClass());
        int len = key.length();
        for (Data data : values) {
            String propName = data.getKey().substring(len + 1);
            jb.setPropertyValue(propName, bean, data.getValue());
        }
    }
}