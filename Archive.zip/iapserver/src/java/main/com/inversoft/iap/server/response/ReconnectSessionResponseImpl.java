/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.server.response;

import iap.TransportType;
import iap.response.ReconnectSessionResponse;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ReconnectSessionResponseImpl extends BaseResponseImpl
        implements ReconnectSessionResponse {

    /**
     * Returns the {@link iap.TransportType#RECONNECT_SESSION} type.
     */
    public TransportType getResponseType() {
        return TransportType.RECONNECT_SESSION;
    }
}
