/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import com.inversoft.iap.transport.Request;
import com.inversoft.iap.transport.BaseResponse;

/**
 * <p>
 * This interface defines how the IAPServer handlers a single
 * type of IAPRequest.
 * </p>
 *
 * @author  Brian Pontarelli
 * @see
 * @since   IAP 1.0
 * @version 1.0
 */
public interface Processor<T extends Request, U extends BaseResponse> {
    /**
     * Handles the given request transport object. This method handles the request
     * however it needs to and returns the base response transport that can be
     * encoded and sent back to the client.
     *
     * @param   transport The base request transport object to handle.
     * @return  The base response transport and never null. Failures should never
     *          generate null responses but valid responses that inform the client
     *          of the failure.
     */
    U handle(T transport);
}