/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;


import iap.TransportType;
import iap.request.AuthenticateUserRequest;
import iap.request.IAPSession;


/**
 * <p>
 * This is the implementation of the authenticate user
 * request interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class AuthenticateUserRequestImpl extends BaseRequestImpl
implements AuthenticateUserRequest {
    private final String username;
    private final String password;


    /**
     * Creates a new <code>AuthenticateUserRequestImpl</code> that uses the given
     * IAPSession.
     *
     * @param   session The session.
     */
    public AuthenticateUserRequestImpl(IAPSession session, String username,
            String password) {
        super(session);
        this.username = username;
        this.password = password;
    }

    /**
     * Returns the type of this request, which is {@link iap.TransportType#AUTHENTICATE_USER}
     * type.
     *
     * @return  The type of this request.
     */
    public TransportType getRequestType() {
        return TransportType.AUTHENTICATE_USER;
    }

    /**
     * @inheritDoc
     */
    public String getUsername() {
        return username;
    }

    /**
     * @inheritDoc
     */
    public String getPassword() {
        return password;
    }
}