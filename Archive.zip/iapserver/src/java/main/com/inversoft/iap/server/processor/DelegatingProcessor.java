/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.processor;

import iap.TransportType;

import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.AuthenticateUserRequest;
import com.inversoft.iap.transport.CloseApplicationRequest;
import com.inversoft.iap.transport.FetchDataRequest;
import com.inversoft.iap.transport.FetchModuleRequest;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenViewRequest;
import com.inversoft.iap.transport.PerformActionRequest;
import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.Request;
import com.inversoft.iap.transport.BaseResponse;

/**
 * <p>
 * This class is a {@link Processor} implementation that delegates
 * to the other {@link Processor} implemenations.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class DelegatingProcessor implements Processor<Request, BaseResponse> {
    private final AuthenticateUserProcessor authProcessor;
    private final CloseApplicationProcessor closeProcessor;
    private final FetchDataProcessor dataProcessor;
    private final FetchModuleProcessor moduleProcessor;
    private final OpenApplicationProcessor appProcessor;
    private final OpenViewProcessor viewProcessor;
    private final PerformActionProcessor actionProcessor;
    private final ReconnectSessionProcessor reconnectProcessor;

    /**
     * Constructs a new <code>DelegatingProcessor</code> that delegates to another
     * processor.
     */
    public DelegatingProcessor(SessionManager sessionManager, IAPHandlerManager handlerManager,
            ServerConfig serverConfig) {
        this.authProcessor = new AuthenticateUserProcessor(sessionManager, handlerManager, serverConfig);
        this.closeProcessor = new CloseApplicationProcessor(sessionManager, handlerManager, serverConfig);
        this.dataProcessor = new FetchDataProcessor(sessionManager, handlerManager, serverConfig);
        this.moduleProcessor = new FetchModuleProcessor(sessionManager, handlerManager, serverConfig);
        this.appProcessor = new OpenApplicationProcessor(sessionManager, handlerManager, serverConfig);
        this.viewProcessor = new OpenViewProcessor(sessionManager, handlerManager, serverConfig);
        this.actionProcessor = new PerformActionProcessor(sessionManager, handlerManager, serverConfig);
        this.reconnectProcessor = new ReconnectSessionProcessor(sessionManager, handlerManager, serverConfig);
    }

    /**
     * Handles the request by delegating to one of the {@link Processor} implementations
     * in the same package. This delegation is based on the {@link TransportType} retrieved from
     * the {@link Request} object using the method {@link Request#getType()}.
     *
     * @param   transport The transport to delegate the handle call to one of the other
     *          processors.
     * @return  The response from the processor delegated to.
     */
    public BaseResponse handle(Request transport) {
        TransportType type = transport.getType();
        BaseResponse response = null;
        if (type == TransportType.AUTHENTICATE_USER) {
            response = this.authProcessor.handle((AuthenticateUserRequest) transport);
        } else if (type == TransportType.CLOSE_APPLICATION) {
            response = this.closeProcessor.handle((CloseApplicationRequest) transport);
        } else if (type == TransportType.FETCH_DATA) {
            response = this.dataProcessor.handle((FetchDataRequest) transport);
        } else if (type == TransportType.FETCH_MODULE) {
            response = this.moduleProcessor.handle((FetchModuleRequest) transport);
        } else if (type == TransportType.OPEN_APPLICATION) {
            response = this.appProcessor.handle((OpenApplicationRequest) transport);
        } else if (type == TransportType.OPEN_VIEW) {
            response = this.viewProcessor.handle((OpenViewRequest) transport);
        } else if (type == TransportType.PERFORM_ACTION) {
            response = this.actionProcessor.handle((PerformActionRequest) transport);
        } else if (type == TransportType.RECONNECT_SESSION) {
            response = this.reconnectProcessor.handle((ReconnectSessionRequest) transport);
        }
        return response;
    }
}