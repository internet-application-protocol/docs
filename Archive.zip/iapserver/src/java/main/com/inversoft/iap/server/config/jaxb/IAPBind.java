package com.inversoft.iap.server.config.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import iap.response.Rating;

@XmlRootElement(name = "iap")
public class IAPBind {
    @XmlElement(name = "open-application-handler") protected BaseHandlerBind openApplicationHandler;
    @XmlElement(name = "close-application-handler") protected BaseHandlerBind closeApplicationHandler;
    @XmlElement(name = "authenticate-user-handler") protected BaseHandlerBind authenticateUserHandler;
    @XmlElement(name = "open-view-handler")
    protected List<OpenViewHandlerBind> openViewHandler = new ArrayList<OpenViewHandlerBind>();
    @XmlElement(name = "fetch-data-handler")
    protected BaseHandlerBind fetchDataHandler;
    @XmlElement(name = "perform-action-handler")
    protected List<PerformActionHandlerBind> performActionHandler = new ArrayList<PerformActionHandlerBind>();
    @XmlElement(name = "fetch-module-handler")
    protected List<FetchModuleHandlerBind> fetchModuleHandler = new ArrayList<FetchModuleHandlerBind>();
    @XmlElement(name = "generic-handler")
    protected List<BaseHandlerBind> genericHandler = new ArrayList<BaseHandlerBind>();
    @XmlElement(name = "reconnect-session-handler") protected BaseHandlerBind reconnectSessionHandler;
    @XmlElement(name = "welcome-view")
    protected WelcomeViewBind welcomeView;
    protected SessionBind session;
    @XmlAttribute(required = true) protected String name;
    @XmlAttribute() protected Rating rating;
    @XmlAttribute() protected String version;

    /**
     * Gets the value of the openApplicationHandler property.
     */
    public BaseHandlerBind getOpenApplicationHandler() {
        return openApplicationHandler;
    }

    /**
     * Sets the value of the openApplicationHandler property.
     */
    public void setOpenApplicationHandler(BaseHandlerBind value) {
        openApplicationHandler = value;
    }

    /**
     * Gets the value of the closeApplicationHandler property.
     */
    public BaseHandlerBind getCloseApplicationHandler() {
        return closeApplicationHandler;
    }

    /**
     * Sets the value of the closeApplicationHandler property.
     */
    public void setCloseApplicationHandler(BaseHandlerBind value) {
        closeApplicationHandler = value;
    }

    /**
     * Gets the value of the authenticateUserHandler property.
     */
    public BaseHandlerBind getAuthenticateUserHandler() {
        return authenticateUserHandler;
    }

    /**
     * Sets the value of the authenticateUserHandler property.
     */
    public void setAuthenticateUserHandler(BaseHandlerBind value) {
        authenticateUserHandler = value;
    }

    /**
     * Gets the value of the reconnectSessionHandler property.
     */
    public BaseHandlerBind getReconnectSessionHandler() {
        return reconnectSessionHandler;
    }

    /**
     * Sets the value of the reconnectSessionHandler property.
     */
    public void setReconnectSessionHandler(BaseHandlerBind value) {
        reconnectSessionHandler = value;
    }

    /**
     * Gets the value of the OpenViewHandler property.
     */
    public List<OpenViewHandlerBind> getOpenViewHandler() {
        return this.openViewHandler;
    }

    /**
     * Gets the value of the fetchDataHandler property.
     */
    public BaseHandlerBind getFetchDataHandler() {
        return fetchDataHandler;
    }

    /**
     * Sets the value of the fetchDataHandler property.
     */
    public void setFetchDataHandler(BaseHandlerBind value) {
        fetchDataHandler = value;
    }

    /**
     * Gets the value of the PerformActionHandler property.
     */
    public List<PerformActionHandlerBind> getPerformActionHandler() {
        return this.performActionHandler;
    }

    /**
     * Gets the value of the FetchModuleHandler property.
     */
    public List<FetchModuleHandlerBind> getFetchModuleHandler() {
        return this.fetchModuleHandler;
    }

    /**
     * Gets the value of the GenericHandler property.
     */
    public List<BaseHandlerBind> getGenericHandler() {
        return this.genericHandler;
    }

    /**
     * Gets the value of the welcomeView property.
     */
    public WelcomeViewBind getWelcomeView() {
        return welcomeView;
    }

    /**
     * Sets the value of the welcomeView property.
     */
    public void setWelcomeView(WelcomeViewBind value) {
        welcomeView = value;
    }

    /**
     * Gets the value of the session property.
     */
    public SessionBind getSession() {
        return session;
    }

    /**
     * Sets the value of the session property.
     */
    public void setSession(SessionBind value) {
        session = value;
    }

    /**
     * Gets the value of the name property.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     */
    public void setName(String value) {
        name = value;
    }

    /**
     * Gets the value of the rating property.
     */
    public Rating getRating() {
        return rating;
    }

    /**
     * Sets the value of the rating property.
     */
    public void setRating(Rating value) {
        rating = value;
    }

    /**
     * Gets the value of the version property.
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     */
    public void setVersion(String value) {
        version = value;
    }
}