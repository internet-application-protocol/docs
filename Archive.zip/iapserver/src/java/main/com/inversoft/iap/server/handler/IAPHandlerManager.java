/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.handler;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import iap.TransportType;
import iap.handler.IAPHandler;
import iap.handler.annotation.FetchModule;
import iap.handler.annotation.Handler;
import iap.handler.annotation.OpenApplication;
import iap.handler.annotation.OpenView;
import iap.handler.annotation.Parameter;
import iap.handler.annotation.PerformAction;
import iap.handler.annotation.ReconnectSession;

import com.inversoft.iap.server.ApplicationKey;
import com.inversoft.iap.server.config.ApplicationConfig;
import com.inversoft.iap.server.config.ApplicationDeploymentConfig;
import com.inversoft.iap.server.config.HandlerConfig;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.transport.Request;
import com.inversoft.iap.util.IAPTools;

/**
 * <p>
 * This class creates and stores all the {@link IAPHandler}
 * instances used by the IAP Server when handling incoming
 * requests. This uses the {@link ApplicationConfig}
 * to locate the configuration for handlers. This
 * configuration is then used to locate or build the necessary
 * {@link IAPHandler} implementation.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPHandlerManager {
    private final static Logger logger = Logger.getLogger(IAPHandlerManager.class.getName());
    private final Map<ApplicationKey, Map<String, IAPHandler>> handlers =
        new HashMap<ApplicationKey, Map<String, IAPHandler>>();
    private final ServerConfig config;

    /**
     * Constructs a new <code>IAPHandlerManager</code> that uses the given
     * {@link ApplicationConfig} to locate handlers and the configuration
     * associated with them.
     *
     * @param   config The server configuration.
     */
    public IAPHandlerManager(ServerConfig config) {
        this.config = config;
    }

    /**
     * Attempts to locate an existing handler or the configuration for the handler
     * with the given name. If the configuration can be found, then the handler
     * is constructed and cached. If it cannot be found, then null is returned
     * and a SEVERE message is logged.
     *
     * @param   appKey The ApplicationKey of the application (name and version tuple).
     * @param   handler The name of the handler to fetch.
     * @return  The handler or null.
     */
    public IAPHandler fetchHandler(ApplicationKey appKey, String handler) {
        ApplicationDeploymentConfig ac = this.config.getApplication(appKey);
        if (ac == null) {
            logger.log(Level.SEVERE, "Invalid application name [" + appKey.name + "]");
            throw new IllegalArgumentException("Invalid application name");
        }

        HandlerConfig config = ac.getApplicationConfig().lookupHandlerConfig(handler);
        if (config == null) {
            logger.log(Level.SEVERE, "IAPHandler named [" + handler + "] is not " +
                "defined from this application");
            return null;
        }

        return fetchHandler(config, appKey);
    }

    /**
     * Attempts to locate an existing handler or the configuration that can handle
     * the given transport object. If the configuration can be found, then the
     * handler is constructed and cached. If it cannot be found, then null is
     * returned and a SEVERE message is logged.
     *
     * @param   appKey The ApplicationKey of the application (name and version tuple).
     * @param   transport The transport that the handler must be able to handle.
     * @return  The handler or null.
     */
    public IAPHandler fetchHandler(ApplicationKey appKey, Request transport) {
        ApplicationDeploymentConfig adc = config.getApplication(appKey);
        if (adc == null) {
            logger.log(Level.SEVERE, "Invalid application name [" + appKey.name + "]");
            throw new IllegalArgumentException("Invalid application name");
        }

        HandlerConfig config = adc.getApplicationConfig().lookupHandlerConfig(transport);
        if (config == null) {
            return null;
        }

        return fetchHandler(config, appKey);
    }

    /**
     * Looks up the handler, possibly creating and initializing it.
     */
    private synchronized IAPHandler fetchHandler(HandlerConfig config, ApplicationKey key) {
        String name = config.getName();
        Map<String, IAPHandler> map = handlers.get(key);
        IAPHandler handler = null;
        if (map == null) {
            map = new HashMap<String, IAPHandler>();
            handlers.put(key, map);
        } else {
            handler = map.get(name);
        }

        if (handler == null) {
            String className = config.getClassName();
            try {
                Class klass = Class.forName(className);
                handler = (IAPHandler) klass.newInstance();
                map.put(name, handler);
            } catch (ClassNotFoundException cnfe) {
                logger.log(Level.SEVERE, "IAPHandler class [" + className + "] " +
                    "not found in classpath", cnfe);
                return null;
            } catch (Exception e) {
                logger.log(Level.SEVERE, "IAPHandler class [" + className + "] " +
                    "could not be instantiated", e);
                return null;
            }

            initializeHandler(handler, config);
        }

        return handler;
    }

    /**
     * Initializes the handler by calling the {@link IAPHandler#create(java.util.Map<String, String>)}
     * on the handler. The parameters passed to this method are fetched from the
     * configuration object as well as from any annotations that the class has.
     *
     * @param   handler The handler initialize.
     * @param   config The handler configuration to fetch additional parameters from.
     */
    private void initializeHandler(IAPHandler handler, HandlerConfig config) {
        Parameter[] params = null;
        TransportType type = IAPTools.determineType(handler);
        if (type == TransportType.AUTHENTICATE_USER || type == TransportType.CLOSE_APPLICATION ||
                type == TransportType.FETCH_DATA) {
            Handler ha = handler.getClass().getAnnotation(Handler.class);
            if (ha != null) {
                params = ha.parameters();
            }
        } else if (type == TransportType.FETCH_MODULE) {
            FetchModule fm = handler.getClass().getAnnotation(FetchModule.class);
            if (fm != null) {
                params = fm.parameters();
            }
        } else if (type == TransportType.OPEN_APPLICATION) {
            OpenApplication oa = handler.getClass().getAnnotation(OpenApplication.class);
            if (oa != null) {
                params = oa.parameters();
            }
        } else if (type == TransportType.OPEN_VIEW) {
            OpenView ov = handler.getClass().getAnnotation(OpenView.class);
            if (ov!= null) {
                params = ov.parameters();
            }
        } else if (type == TransportType.PERFORM_ACTION) {
            PerformAction pa = handler.getClass().getAnnotation(PerformAction.class);
            if (pa != null) {
                params = pa.parameters();
            }
        } else if (type == TransportType.RECONNECT_SESSION) {
            ReconnectSession rc = handler.getClass().getAnnotation(ReconnectSession.class);
            if (rc != null) {
                params = rc.parameters();
            }
        }

        // Protect the config Map.
        Map<String, String> paramsMap = new HashMap<String, String>();
        if (config.getParameters() != null) {
            paramsMap.putAll(config.getParameters());
        }

        if (params != null) {
            for (Parameter parameter : params) {
                paramsMap.put(parameter.name(), parameter.value());
            }
        }
        handler.create(paramsMap);
    }
}