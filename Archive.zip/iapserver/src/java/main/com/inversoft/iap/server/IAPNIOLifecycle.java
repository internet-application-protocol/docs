/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import com.inversoft.iap.IAPTransactionManager;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.nio.NIOLifecycle;
import com.inversoft.nio.NIOCallback;

/**
 * <p>
 * This class puts the requests onto a queue where threads
 * in a pool can pull them off and handle them.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class IAPNIOLifecycle implements NIOLifecycle {
    private final IAPTransactionManager transactionManager = new IAPTransactionManager();
    private final ExecutorService pool;
    private final SessionManager sessionManager;
    private final IAPHandlerManager handlerManager;
    private final ServerConfig serverConfig;

    public IAPNIOLifecycle(ServerConfig serverConfig) {
        this.pool = Executors.newFixedThreadPool(serverConfig.getServerInfo().getExecuteThreads());
        this.sessionManager = new SessionManager(serverConfig.getSessionCleanInterval());
        this.handlerManager = new IAPHandlerManager(serverConfig);
        this.serverConfig = serverConfig;
    }

    /**
     * Creates a unique transaction ID for a single connection with a client.
     *
     * @return  A unique transaction ID.
     */
    public String startTransaction() {
        return this.transactionManager.createTransactionID();
    }

    /**
     * Handles the request parser after the IAP server has determine it is complete.
     * This process involves creating a transaction if it is the first request in
     * the transaction, setting the transaction stage if necessary, creating a
     * runnable to handle the call, and adding the runnable to the execute queue.
     *
     * @param   transactionID The transaction ID.
     */
    public void startProcessing(NIOCallback callback, String transactionID, InputStream inputStream,
            OutputStream outputStream) {
        IAPRequestRunnable runner = new IAPRequestRunnable(callback, transactionID, inputStream,
            outputStream, transactionManager, sessionManager, handlerManager, serverConfig);
        pool.submit(runner);
    }

    /**
     * Ends the transaction with the given ID.
     *
     * @param   transactionID The transaction ID to end.
     */
    public void endTransaction(String transactionID) {
        this.transactionManager.endTransaction(transactionID);
    }

    public class IAPRejectedHandler implements RejectedExecutionHandler {
        public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
            throw new RejectedExecutionException("Queue full");
        }
    }
}