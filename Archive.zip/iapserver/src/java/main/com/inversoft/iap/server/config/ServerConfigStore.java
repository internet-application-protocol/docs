/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.config;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a store for all the Server configurations
 * defined in the IAP server XML configuration file.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class ServerConfigStore {
    private final Map<String, ServerConfig> servers = new HashMap<String, ServerConfig>();
}