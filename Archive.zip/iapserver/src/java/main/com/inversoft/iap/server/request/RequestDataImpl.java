/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;


import java.util.List;

import iap.request.RequestData;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataBody;
import com.inversoft.iap.server.BaseDataImpl;


/**
 * <p>
 * This class is an implementation of the RequestData interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class RequestDataImpl extends BaseDataImpl implements RequestData {
    /**
     * Constructs a new <code>RequestDataImpl</code> with the given DataBody.
     *
     * @param   dataBody The DataBody.
     */
    public RequestDataImpl(DataBody dataBody) {
        super(dataBody);
    }


    /**
     * @inheritDoc
     */
    public void populateJavaBean(String key, Object bean) {
        List<Data> values = super.dataBody.getAllValues(key);
        populateJavaBean(key, bean, values);
    }
}