/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;


import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import iap.response.DataScope;
import iap.response.ResponseData;

import com.inversoft.beans.BeanProperty;
import com.inversoft.beans.JavaBean;
import com.inversoft.iap.DataBody;
import com.inversoft.iap.DataType;
import com.inversoft.iap.server.BaseDataImpl;


/**
 * <p>
 * This class is an implementation of the ResponseData interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class ResponseDataImpl extends BaseDataImpl implements ResponseData {
    private static final Logger logger = Logger.getLogger(ResponseData.class.toString());

    /**
     * Constructs a new <code>ResponseDataImpl</code>.
     */
    public ResponseDataImpl() {
        super(new DataBody());
    }

    /**
     * Constructs a new <code>ResponseDataImpl</code>.
     */
    public ResponseDataImpl(DataBody dataBody) {
        super(dataBody);
    }


    /**
     * @inheritDoc
     */
    public DataScope getScope(String key) {
        return this.dataBody.getScope(key);
    }

    /**
     * Stores the value in the map directly.
     */
    public <T> void setValue(String key, T value, Class<T> type, DataScope scope) {
        recursivelySetValue(key, type, value, scope);
    }

    /**
     * Recursively populates the DataBody with the values from the object given.
     */
    private void recursivelySetValue(String key, Class<?> type, Object value, DataScope scope) {
        Class<?> finalType = type;
        int depth = 0;
        while (finalType.isArray()) {
            finalType = finalType.getComponentType();
            depth++;
        }

        DataType dataType = DataType.find(finalType);
        if (dataType != null) {
            this.dataBody.setValue(key, value, dataType, depth, scope);
        } else if (depth > 0) {
            throw new IllegalArgumentException("IAP doesn't support arrays of" +
                " complex types yet.");
        } else {
            JavaBean jb = JavaBean.getInstance(finalType);
            List<BeanProperty> props = jb.getAllBeanProperties();
            for (BeanProperty bp : props) {
                Object propValue = bp.getPropertyValue(value);
                Class<?> propType;
                if (propValue == null) {
                    // We can use the property type, because it only works for simple
                    // types and those can be determined from the property type
                    // in most cases.
                    propType = bp.getPropertyType();
                } else {
                    propType = propValue.getClass();
                }

                // IAP doesn't support null complex objects yet, but arrays don't
                // count so we skip those
                dataType = DataType.find(propType);
                if (!propType.isArray() && dataType == null && propValue == null) {
                    logger.log(Level.FINE, "Property named [" + bp.getPropertyName() +
                        "] is null and appears to be a complex type. IAPServer doesn't" +
                        " support null complex types yet so this data value was not" +
                        " added to the response");
                    continue;
                }

                String propKey = key + "." + bp.getPropertyName();
                recursivelySetValue(propKey, propType, propValue, scope);
            }
        }
    }
}