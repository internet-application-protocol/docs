/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import iap.VersionNumber;

/**
 * <p/>
 * This class is a tuple that uniquely identifies a single application.
 * </p>
 *
 * @author  Brian Pontarelli
 * @version 1.0
 * @since   IAP 1.0
 */
public class ApplicationKey {
    public final String name;
    public final VersionNumber version;

    public ApplicationKey(String name, VersionNumber version) {
        assert (name != null) : "name == null";
        this.name = name;
        this.version = version;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ApplicationKey)) return false;

        final ApplicationKey applicationKey = (ApplicationKey) o;

        if (!name.equals(applicationKey.name)) return false;
        if (version != null && !version.equals(applicationKey.version)) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = name.hashCode();
        if (version != null) {
            result = 29 * result + version.hashCode();
        }
        return result;
    }
}