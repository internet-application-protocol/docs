/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;


import iap.response.IAPResponse;


/**
 * <p>
 * This class is the base implementation of all IAP response
 * objects. It also implements the IAPResponse interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class BaseResponseImpl implements IAPResponse {
    private boolean success;

    /**
     * @inheritDoc
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * @inheritDoc
     */
    public void setSuccess(boolean success) {
        this.success = success;
    }
}