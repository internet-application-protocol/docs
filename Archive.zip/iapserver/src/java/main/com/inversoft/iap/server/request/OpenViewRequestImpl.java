/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;


import iap.TransportType;
import iap.request.IAPSession;
import iap.request.OpenViewRequest;


/**
 * <p>
 * This class is the implementation of the OpenViewRequest
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenViewRequestImpl extends BaseRequestImpl
implements OpenViewRequest {
    private String viewId;


    /**
     * Constructs a new <code>OpenViewRequestImpl</code> that uses the given
     * IAPSession and view id.
     *
     * @param   session The session.
     * @param   viewId The view id.
     */
    public OpenViewRequestImpl(IAPSession session, String viewId) {
        super(session);
        this.viewId = viewId;
    }


    /**
     * Returns the type of this request, which is {@link TransportType#OPEN_VIEW}
     * type.
     *
     * @return  The type of this request.
     */
    public TransportType getRequestType() {
        return TransportType.OPEN_VIEW;
    }

    /**
     * @inheritDoc
     */
    public String getViewId() {
        return viewId;
    }
}