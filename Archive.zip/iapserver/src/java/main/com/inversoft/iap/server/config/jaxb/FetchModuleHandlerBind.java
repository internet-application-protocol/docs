package com.inversoft.iap.server.config.jaxb;

import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.AccessType;

@XmlType(name = "fetch-module-handler")
@XmlAccessorType(AccessType.FIELD)
public class FetchModuleHandlerBind extends BaseHandlerBind {
    @XmlAttribute(required = true) protected String module;

    /**
     * Gets the value of the module property.
     */
    public String getModule() {
        return module;
    }

    /**
     * Sets the value of the module property.
     */
    public void setModule(String value) {
        module = value;
    }
}