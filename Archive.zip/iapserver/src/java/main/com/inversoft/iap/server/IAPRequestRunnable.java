/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import iap.TransportType;

import com.inversoft.iap.IAPTransaction;
import com.inversoft.iap.IAPTransactionException;
import com.inversoft.iap.IAPTransactionManager;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.handler.IAPHandlerManager;
import com.inversoft.iap.server.processor.DelegatingProcessor;
import com.inversoft.iap.server.session.SessionManager;
import com.inversoft.iap.transport.AuthenticateUserResponse;
import com.inversoft.iap.transport.CloseApplicationResponse;
import com.inversoft.iap.transport.FetchDataResponse;
import com.inversoft.iap.transport.FetchModuleResponse;
import com.inversoft.iap.transport.MetaDataResponse;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.OpenViewResponse;
import com.inversoft.iap.transport.PerformActionResponse;
import com.inversoft.iap.transport.ReconnectSessionResponse;
import com.inversoft.iap.transport.Request;
import com.inversoft.iap.transport.Response;
import com.inversoft.iap.transport.Status;
import com.inversoft.iap.transport.util.TransportTools;
import com.inversoft.iap.transport.util.IAPTransportException;
import com.inversoft.nio.NIOCallback;

/**
 * <p>
 * This class is the runnable that handles the processing of
 * an IAP request.
 * </p>
 *
 * @author  Brian Pontarelli
 */
public class IAPRequestRunnable implements Runnable {
    private static final Logger logger = Logger.getLogger(IAPRequestRunnable.class.getName());
    private final NIOCallback callback;
    private final String transactionID;
    private final IAPTransactionManager transactionManager;
    private final DelegatingProcessor processor;
    private final InputStream inputStream;
    private final OutputStream outputStream;

    /**
     * Creates a new request runnable that handles the call to the processors.
     */
    public IAPRequestRunnable(NIOCallback callback, String transactionID, InputStream readInputStream,
            OutputStream writeOutputStream, IAPTransactionManager transactionManager,
            SessionManager sessionManager, IAPHandlerManager handlerManager, ServerConfig serverConfig) {
        this.callback = callback;
        this.transactionID = transactionID;
        this.transactionManager = transactionManager;
        this.inputStream = readInputStream;
        this.outputStream = writeOutputStream;
        this.processor = new DelegatingProcessor(sessionManager, handlerManager, serverConfig);
    }

    /**
     * Builds the request XML, constructs the request transport object, calls the
     * processor, puts the response into the callback.
     */
    public void run() {
        Request request;
        try {
            logger.info("Swapping");
            logger.info("Handling request");
            request = TransportTools.handle(inputStream, false);
            callback.doneReading();
        } catch (Throwable t) {
            // TODO - will we need a new response element that is generic for all requests called error?
            // The application is unknown here, so it needs to be generic
            logger.log(Level.SEVERE, "Unable to deserialize request", t);

            try {
                this.inputStream.close();
            } catch (IOException e) {
            }

            try {
                this.outputStream.close();
            } catch (IOException e) {
            }

            callback.failed();
            return;
        }

        Response response = null;
        try{
            verifyTransaction(request);
        } catch (IAPTransactionException rte) {
            // TODO - need to decided if this warrants a status code or not.
            response = buildResponse(request);
            response.setStatus(new Status());
            response.getStatus().setCode("2.0");
            response.getStatus().setValue(rte.getMessage());
        } catch (Throwable t) {
            response = buildResponse(request);
            response.setStatus(new Status());
            response.getStatus().setCode("2.0");
            response.getStatus().setValue("Fatal server error [" + t.getMessage() + "]");
        }

        if (response == null) {
            try {
                response = processor.handle(request);
            } catch (Throwable t) {
                response = buildResponse(request);
                response.setStatus(new Status());
                response.getStatus().setCode("2.0");
                response.getStatus().setValue(t.toString());
            }
        }

        try {
            TransportTools.serialize(response, outputStream, false);
            callback.doneWriting();
        } catch (Throwable t) {
            // Try one more time, otherwise bail completely and close everything and post a failure
            response = buildResponse(request);
            response.setStatus(new Status());
            response.getStatus().setCode("2.0");
            response.getStatus().setValue(t.toString());

            try {
                TransportTools.serialize(response, outputStream, false);
            } catch (IAPTransportException e) {
                // TODO - will we need a new response element that is generic for all requests called error?
                // The application is unknown here, so it needs to be generic
                logger.log(Level.SEVERE, "Unable to serialize response", t);
                logger.log(Level.SEVERE, "Unable to serialize failure response", e);

                try {
                    this.inputStream.close();
                } catch (IOException ioe) {
                }

                try {
                    this.outputStream.close();
                } catch (IOException ioe) {
                }

                callback.failed();
                return;
            }
        }
    }

    private Response buildResponse(Request request) {
        TransportType type = request.getType();
        Response response = null;
        switch (type) {
            case AUTHENTICATE_USER:
                response = new AuthenticateUserResponse();
                break;
            case CLOSE_APPLICATION:
                response = new CloseApplicationResponse();
                break;
            case FETCH_DATA:
                response = new FetchDataResponse();
                break;
            case FETCH_MODULE:
                response = new FetchModuleResponse();
                break;
            case METADATA:
                response = new MetaDataResponse();
                break;
            case OPEN_APPLICATION:
                response = new OpenApplicationResponse();
                break;
            case OPEN_VIEW:
                response = new OpenViewResponse();
                break;
            case PERFORM_ACTION:
                response = new PerformActionResponse();
                break;
            case RECONNECT_SESSION:
                response = new ReconnectSessionResponse();
                break;
        }

        return response;
    }

    private void verifyTransaction(Request request) throws IAPTransactionException {
        IAPTransaction transaction = this.transactionManager.fetchTransaction(transactionID);
        TransportType type = request.getType();

        if (transaction == null) {
            this.transactionManager.createTransaction(transactionID, type);
        } else {
            TransportType old = transaction.getStage();
            try {
                transaction.setStage(type);
            } catch (IAPTransactionException e) {
                logger.log(Level.SEVERE, "Invalid transaction transition from [" + old + "] to [" +
                    type + "]", e);
                throw new IAPTransactionException("Invalid transaction transition from [" + old +
                    "] to [" + type + "]");
            }
        }
    }
}