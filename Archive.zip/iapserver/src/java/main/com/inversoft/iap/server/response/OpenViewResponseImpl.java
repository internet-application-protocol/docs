/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;

import java.nio.ByteBuffer;

import iap.TransportType;
import iap.response.OpenViewResponse;

/**
 * <p>
 * This class is an implementation of the OpenViewResponse
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenViewResponseImpl extends BaseBinaryResponseImpl implements OpenViewResponse {
    private String contentType;

    /**
     * Constructs a new <code>OpenViewResponseImpl</code>.
     */
    public OpenViewResponseImpl() {
    }

    /**
     * Returns the response type, which for this implementation is
     * {@link iap.TransportType.OPEN_VIEW}.
     */
    public TransportType getResponseType() {
        return TransportType.OPEN_VIEW;
    }

    /**
     * @inheritDoc
     */
    public ByteBuffer getViewBytes() {
        return super.bytes;
    }

    /**
     * @inheritDoc
     */
    public void setViewBytes(ByteBuffer bytes) {
        if (super.stream != null) {
            throw new IllegalStateException("Unable to set ByteBuffer after the OutputStream has been " +
                "written to.");
        }

        super.bytes = bytes;
    }

    /**
     * @inheritDoc
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * @inheritDoc
     */
    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}