/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;


import iap.TransportType;
import iap.response.CloseApplicationResponse;


/**
 * <p>
 * This class is an implementation of the CloseApplicationResponse
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class CloseApplicationResponseImpl extends BaseResponseImpl
implements CloseApplicationResponse {
    /**
     * Returns the response type, which for this implementation is the
     * {@link iap.TransportType#CLOSE_APPLICATION} type.
     */
    public TransportType getResponseType() {
        return TransportType.CLOSE_APPLICATION;
    }
}