/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.request;


import iap.TransportType;
import iap.request.ActionType;
import iap.request.IAPSession;
import iap.request.PerformActionRequest;
import iap.request.RequestData;


/**
 * <p>
 * This class is the implementation of the PerformActionRequest
 * interface.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class PerformActionRequestImpl extends BaseRequestImpl
implements PerformActionRequest {
    private final String actionName;
    private final ActionType actionType;
    private final String viewId;
    private final RequestData requestData;


    /**
     * Constructs a new <code>PerformActionRequestImpl</code> that uses the given
     * IAPSession, action name, action type, and request data.
     *
     * @param   session The session.
     * @param   actionName The action name.
     * @param   actionType The action type.
     * @param   viewId The view id of the view that generated the action.
     * @param   requestData The request data.
     */
    public PerformActionRequestImpl(IAPSession session, String actionName,
            ActionType actionType, String viewId, RequestData requestData) {
        super(session);
        this.actionName = actionName;
        this.actionType = actionType;
        this.viewId = viewId;
        this.requestData = requestData;
    }


    /**
     * Returns the type of this request, which is {@link TransportType#PERFORM_ACTION}
     * type.
     *
     * @return  The type of this request.
     */
    public TransportType getRequestType() {
        return TransportType.PERFORM_ACTION;
    }

    /**
     * @inheritDoc
     */
    public String getActionName() {
        return this.actionName;
    }

    /**
     * @inheritDoc
     */
    public ActionType getActionType() {
        return this.actionType;
    }

    /**
     * @inheritDoc
     */
    public String getViewId() {
        return this.viewId;
    }

    /**
     * @inheritDoc
     */
    public RequestData getRequestData() {
        return this.requestData;
    }
}