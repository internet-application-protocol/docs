/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.server.response;

import java.io.InputStream;
import java.nio.ByteBuffer;

/**
 * <p>
 * This class should be sub-classed whenever there is binary
 * data in the response.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class BaseBinaryResponseImpl extends BaseResponseImpl {
    ByteBuffer bytes;
    InputStream stream;

    /**
     * Returns the InputStream.
     */
    public InputStream getInputStream() {
        return stream;
    }

    /**
     * Sets the input stream.
     */
    public void setInputStream(InputStream stream) {
        if (bytes != null) {
            throw new IllegalStateException("Bytes already set and therefore an InputStream cannot be" +
                " used.");
        }
        
        this.stream = stream;
    }
}