#!/bin/bash

DIST_DIR=../../../../target/dist
files=`ls $DIST_DIR`
for file in $files; do
  CLASSPATH=$DIST_DIR/$file:$CLASSPATH
done

os=`uname -o`
if [ $os == "Cygwin" ]; then
  CLASSPATH=`cygpath -dp $CLASSPATH`
fi

echo $CLASSPATH

java -cp $CLASSPATH com.inversoft.iap.server.IAPServer
