package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}response">
 *       &lt;sequence>
 *         &lt;element name="viewBody" type="{}viewBody" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "openViewResponse", isRootElement = true)
public class OpenViewResponse extends BaseResponse {

    @XmlElement(name = "viewBody", isRequired = false)
    ViewBody viewBody;

    /**
     * Returns the type of response.
     */
    public TransportType getType() {
        return TransportType.OPEN_VIEW;
    }

    /**
     * Gets the value of the viewBody property.
     */
    public ViewBody getViewBody() {
        return viewBody;
    }

    /**
     * Sets the value of the viewBody property.
     */
    public void setViewBody(ViewBody value) {
        viewBody = value;
    }
}