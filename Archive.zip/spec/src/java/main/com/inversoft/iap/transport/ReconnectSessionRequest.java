/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}sessionRequest">
 *       &lt;sequence>
 *         &lt;element name="clientCredentials" type="{}clientCredentials" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "reconnectSessionRequest", isRootElement = true)
public class ReconnectSessionRequest extends SessionRequest {

    @XmlElement(name = "clientCredentials", isRequired = false)
    ClientCredentials clientCredentials;

    /**
     * Returns the type of request.
     */
    public TransportType getType() {
        return TransportType.RECONNECT_SESSION;
    }

    /**
     * Gets the value of the clientCredentials property.    
     */
    public ClientCredentials getClientCredentials() {
        return clientCredentials;
    }

    /**
     * Sets the value of the clientCredentials property.
     */
    public void setClientCredentials(ClientCredentials clientCredentials) {
        this.clientCredentials = clientCredentials;
    }
}