package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}response">
 *       &lt;choice>
 *         &lt;group ref="{}success"/>
 *         &lt;group ref="{}redirect"/>
 *       &lt;/choice>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "openApplicationResponse", isRootElement = true)
public class OpenApplicationResponse extends BaseResponse {
    SuccessGroup successGroup;
    RedirectGroup redirectGroup;

    /**
     * Returns the type of response.
     */
    public TransportType getType() {
        return TransportType.OPEN_APPLICATION;
    }

    /**
     * Returns the {@link SuccessGroup} for this instance
     *
     * @return {@link SuccessGroup}
     */
    public SuccessGroup getSuccessGroup() {
        return successGroup;
    }

    /**
     * Sets the {@link SuccessGroup} for this instance
     *
     * @param successGroup
     */
    public void setSuccessGroup(SuccessGroup successGroup) {
        this.successGroup = successGroup;
    }

    /**
     * Returns the {@link RedirectGroup} for this instance
     *
     * @return {@link RedirectGroup}
     */
    public RedirectGroup getRedirectGroup() {
        return redirectGroup;
    }

    /**
     * Sets the {@link RedirectGroup} for this instance
     *
     * @param redirectGroup
     */
    public void setRedirectGroup(RedirectGroup redirectGroup) {
        this.redirectGroup = redirectGroup;
    }
}