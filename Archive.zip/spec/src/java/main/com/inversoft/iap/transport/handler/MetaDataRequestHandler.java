/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.MetaDataRequest;
import org.xml.sax.Attributes;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link MetaDataRequest} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MetaDataRequestHandler extends BaseRequestHandler<MetaDataRequest> {

    public MetaDataRequestHandler() {
        super(new MetaDataRequest());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseElement(String uri, String localName, String qName, Attributes attributes) {
        // stub.  Nothing to parse
    }
}
