/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.serializer;

import java.util.List;

import com.inversoft.iap.transport.ApplicationInfo;
import com.inversoft.iap.transport.Certificate;
import com.inversoft.iap.transport.ClientConstraint;
import com.inversoft.iap.transport.ClientCredentials;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.Param;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import iap.Coord;
import iap.Size;
import iap.VersionNumber;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link OpenApplicationRequest} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OpenApplicationRequestSerializer extends BaseRequestSerializer<OpenApplicationRequest> {

    public OpenApplicationRequestSerializer(OpenApplicationRequest request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeChildren(AttributesHolder attributes) throws SAXException {
        ClientCredentials credentials = getTransport().getClientCredentials();

        // serializer credentials
        if (credentials != null) {
            String credentialsMapping = TransportTools.getElementName(ClientCredentials.class);

            startElement("", credentialsMapping, credentialsMapping, attributes);
            SessionId sessionId = credentials.getSessionId();
            Certificate certificate = credentials.getCertificate();

            // serialize sessionId or certificate or neither
            if (sessionId != null) {
                String sessionIdMapping = TransportTools.getElementName(SessionId.class);
                String applicataionIdMapping = "applicationId";
                String versionNumberMapping = "versionNumber";
                String idMapping = "id";
                attributes.addAttribute(new QualifiedName("", "", applicataionIdMapping, applicataionIdMapping),
                        sessionId.getApplicationId());
                attributes.addAttribute(new QualifiedName("", "", versionNumberMapping, versionNumberMapping),
                        sessionId.getVersionNumber().toString());
                attributes.addAttribute(new QualifiedName("", "", idMapping, idMapping), sessionId.getStringId());
                startElement("", sessionIdMapping, sessionIdMapping, attributes);
                endElement("", sessionIdMapping, sessionIdMapping);
            } else if (certificate != null) {
                String certificateMapping = TransportTools.getElementName(Certificate.class);
                String expiresMapping = "dateExpires";
                String createdMapping = "dateCreated";
                attributes.addAttribute(new QualifiedName("", "", expiresMapping, expiresMapping),
                        certificate.getDateExpires().toXMLFormat());
                attributes.addAttribute(new QualifiedName("", "", createdMapping, createdMapping),
                        certificate.getDateCreated().toXMLFormat());
                startElement("", certificateMapping, certificateMapping, attributes);
                char[] c = certificate.getValue().toCharArray();
                characters(c, 0, c.length);
                endElement("", certificateMapping, certificateMapping);
            }
            endElement("", credentialsMapping, credentialsMapping);
            attributes.clear();
        }

        // serialize application info
        ApplicationInfo appInfo = getTransport().getApplicationInfo();
        String appInfoMapping = TransportTools.getElementName(ApplicationInfo.class);
        String appIdMapping = "applicationId";
        String vNumberMapping = TransportTools.getElementName(VersionNumber.class);
        if (appInfo.getVersionNumber() != null) {
            attributes.addAttribute(new QualifiedName("", "", vNumberMapping, vNumberMapping),
                    appInfo.getVersionNumber().toString());
        }
        attributes.addAttribute(new QualifiedName("", "", appIdMapping, appIdMapping),
                appInfo.getApplicationId());
        startElement("", appInfoMapping, appInfoMapping, attributes);
        attributes.clear();
        List<Param> params = appInfo.getParams();
        for (Param param : params) {
            String paramMapping = TransportTools.getElementName(Param.class);
            String nameMapping = "name";
            String valueMapping = "value";
            attributes.addAttribute(new QualifiedName("", "", nameMapping, nameMapping),
                    param.getName());
            attributes.addAttribute(new QualifiedName("", "", valueMapping, valueMapping),
                    param.getValue());
            startElement("", paramMapping, paramMapping, attributes);
            endElement("", paramMapping, paramMapping);
            attributes.clear();
        }
        endElement("", appInfoMapping, appInfoMapping);
        attributes.clear();

        // serialize client constraint
        ClientConstraint constraint = getTransport().getClientConstraint();
        String constraintMapping = TransportTools.getElementName(ClientConstraint.class);
        String dcMapping = "deviceConstraint";
        String pcMapping = "protocolConstraint";
        String mrMapping = "maximumRating";
        attributes.addAttribute(new QualifiedName("", "", dcMapping, dcMapping),
                constraint.getDeviceConstraint().toString());
        attributes.addAttribute(new QualifiedName("", "", pcMapping, pcMapping),
                constraint.getProtocolConstraint().toString());
        attributes.addAttribute(new QualifiedName("", "", mrMapping, mrMapping),
                constraint.getMaximumRating().toString());
        startElement("", constraintMapping, constraintMapping, attributes);
        attributes.clear();
        if (constraint.getSizeConstraint() != null) {
            Size size = constraint.getSizeConstraint();
            String sMapping = TransportTools.getElementName(Size.class);
            String xMapping = "x";
            String yMapping = "y";
            Coord min = size.getMin();
            Coord max = size.getMax();
            startElement("", sMapping, sMapping, attributes);
            if (min != null) {
                String minMapping = "min";
                attributes.addAttribute(new QualifiedName("", "", xMapping, xMapping),
                        Integer.toString(min.getX()));
                attributes.addAttribute(new QualifiedName("", "", yMapping, yMapping),
                        Integer.toString(min.getY()));
                startElement("", minMapping, minMapping, attributes);
                endElement("", minMapping, minMapping);
                attributes.clear();
            } else if (max != null) {
                String maxMapping = "max";
                attributes.addAttribute(new QualifiedName("", "", xMapping, xMapping),
                        Integer.toString(max.getX()));
                attributes.addAttribute(new QualifiedName("", "", yMapping, yMapping),
                        Integer.toString(max.getY()));
                startElement("", maxMapping, maxMapping, attributes);
                endElement("", maxMapping, maxMapping);
                attributes.clear();
            }
            endElement("", sMapping, sMapping);
        }
        endElement("", constraintMapping, constraintMapping);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // stub
    }
}
