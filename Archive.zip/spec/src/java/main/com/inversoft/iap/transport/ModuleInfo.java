package com.inversoft.iap.transport;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for moduleInfo complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="moduleInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="moduleId" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "moduleInfo")
public class ModuleInfo {

    @XmlAttribute()
    String moduleId;

    /**
     * Gets the value of the moduleId property.
     */
    public String getModuleId() {
        return moduleId;
    }

    /**
     * Sets the value of the moduleId property.
     */
    public void setModuleId(String value) {
        moduleId = value;
    }
}