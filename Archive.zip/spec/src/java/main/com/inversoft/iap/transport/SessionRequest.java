/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

import iap.annotation.XmlElement;

/**
 * Java class for sessionRequest complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="sessionRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{}request">
 *       &lt;sequence>
 *         &lt;element name="sessionId" type="{}sessionId"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */
public abstract class SessionRequest implements Request {

    @XmlElement(name = "sessionId")
    SessionId sessionId;

    /**
     * Gets the value of the sessionId property.
     *
     * @return {@link SessionId}
     */
    public SessionId getSessionId() {
        return sessionId;
    }

    /**
     * Sets the value of the sessionId property.
     *
     * @param value {@link SessionId}
     */
    public void setSessionId(SessionId value) {
        this.sessionId = value;
    }
}