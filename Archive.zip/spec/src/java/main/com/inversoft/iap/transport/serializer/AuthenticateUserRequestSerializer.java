/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.AuthenticateUserRequest;
import com.inversoft.iap.transport.UserInfo;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link AuthenticateUserRequest} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */
public class AuthenticateUserRequestSerializer extends BaseSessionRequestSerializer<AuthenticateUserRequest> {
    public AuthenticateUserRequestSerializer(AuthenticateUserRequest request) {
        super(request);
    }

    /**
     * Encodes the concrete Transport into Fast Infoset format
     *
     * @param attributes {@link AttributesHolder} object
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        UserInfo userInfo = getTransport().getUserInfo();
        String userInfoMapping = TransportTools.getElementName(UserInfo.class);
        String usernameMapping = "username";
        String passwordMapping = "password";
        attributes.addAttribute(new QualifiedName("", "", usernameMapping, usernameMapping),
                userInfo.getUsername());
        attributes.addAttribute(new QualifiedName("", "", passwordMapping, passwordMapping),
                userInfo.getPassword());
        startElement("", userInfoMapping, userInfoMapping, attributes);
        endElement("", userInfoMapping, userInfoMapping);
    }
}