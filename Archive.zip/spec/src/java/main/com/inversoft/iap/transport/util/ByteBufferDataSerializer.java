/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.util;

import java.nio.ByteBuffer;

/**
 * <p>
 * This class is a byte buffer storage implementation of the data serializer
 * interface that is used for encoding IAP data values.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class ByteBufferDataSerializer implements DataSerializer {
    private ByteBuffer buf = ByteBuffer.allocate(1024);

    public void addBoolean(boolean b) {
        buf = checkCapacity(1);
        buf.put((b) ? (byte) 0x01 : (byte) 0x00);
    }

    public void addByte(byte b) {
        buf = checkCapacity(1);
        buf.put(b);
    }

    public void addChar(char c) {
        // TODO Is this UTF-8 compliant?
        buf = checkCapacity(2);
        buf.putChar(c);
    }

    public void addDouble(double d) {
        buf = checkCapacity(8);
        buf.putDouble(d);
    }

    public void addFloat(float f) {
        buf = checkCapacity(4);
        buf.putFloat(f);
    }

    public void addInt(int i) {
        buf = checkCapacity(4);
        buf.putInt(i);
    }

    public void addLong(long l) {
        buf = checkCapacity(8);
        buf.putLong(l);
    }

    public void addShort(short s) {
        buf = checkCapacity(2);
        buf.putShort(s);
    }

    public void addBooleanArray(boolean[] b) {
        buf = checkCapacity(b.length);
        for (boolean bool : b) {
            buf.put((bool) ? (byte) 0x01 : (byte) 0x00);
        }
    }

    public void addByteArray(byte[] ba) {
        buf = checkCapacity(ba.length);
        for (byte b : ba) {
            buf.put(b);
        }
    }

    public void addCharArray(char[] ca) {
        buf = checkCapacity(ca.length * 4);
        for (char c : ca) {
            buf.putChar(c);
        }
    }

    public void addDoubleArray(double[] da) {
        buf = checkCapacity(da.length * 8);
        for (double d : da) {
            buf.putDouble(d);
        }
    }

    public void addFloatArray(float[] fa) {
        buf = checkCapacity(fa.length * 4);
        for (float f : fa) {
            buf.putFloat(f);
        }
    }

    public void addIntArray(int[] ia) {
        buf = checkCapacity(ia.length * 4);
        for (int i : ia) {
            buf.putInt(i);
        }
    }

    public void addLongArray(long[] la) {
        buf = checkCapacity(la.length * 8);
        for (long l : la) {
            buf.putLong(l);
        }
    }

    public void addShortArray(short[] sa) {
        buf = checkCapacity(sa.length * 2);
        for (short s : sa) {
            buf.putShort(s);
        }
    }

    public void addArrayHeader(int[] header) {
        buf = checkCapacity(header.length + 4);
        buf.putInt(header.length);
        for (int i : header) {
            buf.putInt(i);
        }
    }

    public byte[] getBytes() {
        buf.flip();
        int index = buf.arrayOffset();
        int length = buf.remaining();
        byte[] bytes = buf.array();
        byte[] ret = new byte[length];
        System.arraycopy(bytes, index, ret, 0, length);
        return ret;
    }

    private ByteBuffer checkCapacity(int needed) {
        if (buf.remaining() < needed) {
            int length = Math.max(needed, 1024);
            ByteBuffer newBuf = ByteBuffer.allocate(length);
            newBuf.put(buf);
            buf = newBuf;
        }

        return buf;
    }
}