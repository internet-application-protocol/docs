/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.util;

import java.lang.reflect.Array;
import java.nio.IntBuffer;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataType;
import com.inversoft.util.ObjectTools;

/**
 * <p>
 * This class is a toolkit that encodes data values into the binary
 * format for fast infoset.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class DataBinaryEncoder {
    public static final int NULL = 0xFFFFFFFF;

    /**
     * Encodes the given value by first determining whether or not it is an array.
     *
     * <h3>Header</h3>
     * <p>
     * Whether or not an array is being serialized, a header is written out. This header minimally
     * contains the number of array dimensions of the data value being serialized. For single values
     * this header will simply contain an integer array of length one containing the value 0. This
     * denotes that the value serialized as zero array dimensions.
     * </p>
     *
     * <h3>Arrays</h3>
     * <p>
     * Arrays are treated specially. First the header array of integers are written out to the Fast
     * Infoset document. These integers contain information about the array dimensions. The
     * first value of this array is the number of array dimensions that are for the array (i.e.
     * double[][] = 2 dimensions).
     * </p>
     *
     * <p>
     * The second part of the header is the dimensions for each array in a multi-dimensional array or
     * the dimension of the single array being serialized. The lengths are written out in depth
     * first traversal order. Here are some examples:
     * </p>
     *
     * <table>
     * <tr><th>Java expr.</th><th>Header contents</th><tr>
     * <tr><td>new int[10];</td><td>0x0000000A</td></tr>
     * <tr><td>new int[10][20];</td><td>0x0000000A 0x0000004F 0x0000004F ... 0x0000004F (20 of these)</td></tr>
     * <tr><td>new int[2][2][3];</td><td>0x00000002 0x000000002 0x00000003 0x00000003 0x00000002 0x00000003 0x00000003</td></tr>
     * </table>
     *
     * <p>
     * The next data written out are the arrays themselves. Each array is written out as an array
     * of the primitive type of the array. For example, if the method is passed boolean[][][] than
     * arrays of booleans are serialized out to the Fast Infoset document. For multi-dimensional arrays
     * a depth first traversal is performed starting with the zeroth array elements first. So, the
     * first array serialized would be double[0][0][0] if that array is not null.
     * </p>
     *
     * <p>
     * Null arrays are not serialized. The header will contan a dimension of -1 for a null array in
     * which case nothing is serialized for that array. The same is true for zero length arrays except
     * that the header will contain 0 rather than -1.
     * </p>
     *
     * <h3>Single Values</h3>
     * <p>
     * Single values are serialized out as an array of length 1 that contains the value.
     * </p>
     */
    public static void encode(Data data, DataSerializer serializer) throws DataSerializerException {
        IntBuffer header = IntBuffer.allocate(1);

        Object value = data.getValue();
        DataType dataType = data.getType();
        if (value != null && dataType == DataType.STRING) {
            Class<?> type = value.getClass();
            int depth = 0;
            while (type.isArray()) {
                depth++;
                type = type.getComponentType();
            }

            try {
                value = convertString(value, depth);
            } catch (ClassNotFoundException e) {
                throw new DataSerializerException(e);
            }

            dataType = DataType.CHAR;
            header.put(depth + 1);
        } else {
            header.put(data.getArrayDepth());
        }

        if (value != null && value.getClass().isArray()) {
            header = makeArrayHeader(value, header);
            serializer.addArrayHeader(header.array());
            encodeArray(dataType, value, serializer);
        } else if (value != null) {
            serializer.addArrayHeader(header.array());
            encodeSingleValue(dataType, value, serializer);
        }
    }

    private static Object convertString(Object value, int depth) throws ClassNotFoundException {
        if (value == null) {
            return null;
        }

        if (depth > 0) {
            StringBuilder name = new StringBuilder();
            for (int i = 0; i < depth; i++) {
                name.append("[");
            }

            name.append("C");

            Class<?> charArrayType = Class.forName(name.toString());
            int length = Array.getLength(value);
            Object newArray = Array.newInstance(charArrayType, length);
            Object[] array = (Object[]) value;
            for (int i = 0; i < array.length; i++) {
                Array.set(newArray, i, convertString(array[i], depth - 1));
            }

            return newArray;
        }

        return ((String) value).toCharArray();
    }

    private static void encodeSingleValue(DataType dataType, Object value, DataSerializer serializer)
    throws DataSerializerException {
        if (dataType == DataType.BOOLEAN) {
            serializer.addBoolean((Boolean) value);
        } else if (dataType == DataType.BYTE) {
            serializer.addByte((Byte) value);
        } else if (dataType == DataType.CHAR) {
            serializer.addChar((Character) value);
        } else if (dataType == DataType.SHORT) {
            serializer.addShort((Short) value);
        } else if (dataType == DataType.INT) {
            serializer.addInt((Integer) value);
        } else if (dataType == DataType.LONG) {
            serializer.addLong((Long) value);
        } else if (dataType == DataType.FLOAT) {
            serializer.addFloat((Float) value);
        } else if (dataType == DataType.DOUBLE) {
            serializer.addDouble((Double) value);
        } else {
            throw new IllegalArgumentException("DataType cannot be null");
        }
    }

    private static void encodeArray(DataType dataType, Object array, DataSerializer serializer)
    throws DataSerializerException {
        if (array == null) {
            return;
        }

        int length = Array.getLength(array);
        if (length == 0) {
            return;
        }

        Class<?> type = array.getClass().getComponentType();
        if (type != null && type.isArray()) {
            Object[] casted = (Object[]) array;
            for (Object o : casted) {
                encodeArray(dataType, o, serializer);
            }
        } else if (dataType == DataType.BOOLEAN) {
            boolean[] a;
            if (type == Boolean.TYPE) {
                a = (boolean[]) array;
            } else {
                a = (boolean[]) ObjectTools.unwrapArray((Number[]) array);
            }
            serializer.addBooleanArray(a);
        } else if (dataType == DataType.BYTE) {
            byte[] a;
            if (type == byte.class) {
                a = (byte[]) array;
            } else {
                a = (byte[]) ObjectTools.unwrapArray((Number[]) array);
            }
            serializer.addByteArray(a);
        } else if (dataType == DataType.CHAR) {
            char[] chars;
            if (type == char.class) {
                chars = (char[]) array;
            } else {
                chars = ObjectTools.unwrapArray((Character[]) array);
            }
            serializer.addCharArray(chars);
        } else if (dataType == DataType.DOUBLE) {
            double[] a;
            if (type == double.class) {
                a = (double[]) array;
            } else {
                a = (double[]) ObjectTools.unwrapArray((Number[]) array);
            }
            serializer.addDoubleArray(a);
        } else if (dataType == DataType.FLOAT) {
            float[] a;
            if (type == float.class) {
                a = (float[]) array;
            } else {
                a = (float[]) ObjectTools.unwrapArray((Number[]) array);
            }
            serializer.addFloatArray(a);
        } else if (dataType == DataType.LONG) {
            long[] a;
            if (type == long.class) {
                a = (long[]) array;
            } else {
                a = (long[]) ObjectTools.unwrapArray((Number[]) array);
            }
            serializer.addLongArray(a);
        } else if (dataType == DataType.INT) {
            int[] a;
            if (type == int.class) {
                a = (int[]) array;
            } else {
                a = (int[]) ObjectTools.unwrapArray((Number[]) array);
            }
            serializer.addIntArray(a);
        } else if (dataType == DataType.SHORT) {
            short[] a;
            if (type == short.class) {
                a = (short[]) array;
            } else {
                a = (short[]) ObjectTools.unwrapArray((Number[]) array);
            }
            serializer.addShortArray(a);
        }
    }

    /**
     * First time through is:
     * int[][][] - component type is int[][]
     *
     * Second time through is:
     * int[][] - component type is int[]
     *
     * Third time through is:
     * int[]
     *
     * int[][][] i = {{{3, 4}, {5}}, {{6, 7, 8}}, {{1}, {2}, {3}}}
     * this is also int[3][][]
     * i[0] = int[2][]
     * i[0][0] = int[2]
     * i[0][1] = int[1]
     * i[1] = int[1][]
     * i[1][0] = int[3]
     * i[2] = int[3][]
     * i[2][0] = int[1]
     * i[2][1] = int[1]
     * i[2][2] = int[1]
     *
     * encodes as
     * 0x0003, 0x0002, 0x0002, 0x0001, 0x0001, 0x0003, 0x0003, 0x0001, 0x0001, 0x0001
     */
    private static IntBuffer makeArrayHeader(Object array, IntBuffer header) {
        if (header.remaining() == 0) {
            IntBuffer newHeader = IntBuffer.allocate(header.capacity() + 1);
            header.flip();
            newHeader.put(header);
            header = newHeader;
        }

        if (array != null) {
            int length = Array.getLength(array);
            header.put(length);
        } else {
            header.put(NULL);
        }

        if (array != null) {
            Class<?> type = array.getClass().getComponentType();
            if (type != null && type.isArray()) {
                Object[] casted = (Object[]) array;
                for (Object o : casted) {
                    header = makeArrayHeader(o, header);
                }
            }
        }

        return header;
    }
}