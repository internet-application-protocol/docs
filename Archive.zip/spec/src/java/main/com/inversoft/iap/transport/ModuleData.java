/**
 * Date Created: Aug 9, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport;

import java.io.InputStream;
import java.nio.ByteBuffer;

import iap.annotation.XmlElement;

@XmlElement(name = "moduleData")
public class ModuleData {
    ByteBuffer data;
    InputStream valueStream;
    long contentLength;

    /**
     * Returns the module data
     *
     * @return the module data
     */
    public ByteBuffer getData() {
        return data;
    }

    /**
     * Sets the module data
     *
     * @param data the module data
     */
    public void setData(ByteBuffer data) {
        this.data = data;
    }

    public InputStream getValueStream() {
        return valueStream;
    }

    public void setValueStream(InputStream valueStream) {
        this.valueStream = valueStream;
    }

    public long getContentLength() {
        return contentLength;
    }

    public void setContentLength(long contentLength) {
        this.contentLength = contentLength;
    }
}
