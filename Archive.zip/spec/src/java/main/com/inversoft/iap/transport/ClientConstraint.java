package com.inversoft.iap.transport;

import iap.Size;
import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;
import iap.request.DeviceType;
import iap.response.Rating;

import com.inversoft.iap.request.VersionSpecification;

/**
 * Java class for clientConstraint complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="clientConstraint">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sizeConstraint" type="{}sizeConstraint" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="deviceConstraint" use="required" type="{}deviceType" />
 *       &lt;attribute name="protocolConstraint" use="required" type="{}versionSpecification" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "clientConstraint")
public class ClientConstraint {

    @XmlAttribute(isRequired = false)
    Size sizeConstraint;

    @XmlAttribute()
    DeviceType deviceConstraint;

    @XmlAttribute()
    VersionSpecification protocolConstraint;

    @XmlAttribute()
    Rating maximumRating;

    /**
     * Gets the value of the sizeConstraint property.
     */
    public Size getSizeConstraint() {
        return sizeConstraint;
    }

    /**
     * Sets the value of the sizeConstraint property.
     */
    public void setSizeConstraint(Size value) {
        sizeConstraint = value;
    }

    /**
     * Gets the value of the deviceConstraint property.
     */
    public DeviceType getDeviceConstraint() {
        return deviceConstraint;
    }

    /**
     * Sets the value of the deviceConstraint property.
     */
    public void setDeviceConstraint(DeviceType value) {
        deviceConstraint = value;
    }

    /**
     * Gets the value of the protocolConstraint property.
     */
    public VersionSpecification getProtocolConstraint() {
        return protocolConstraint;
    }

    /**
     * Sets the value of the protocolConstraint property.
     */
    public void setProtocolConstraint(VersionSpecification value) {
        protocolConstraint = value;
    }

    /**
     * Gets the maximum rating value
     */
    public Rating getMaximumRating() {
        return maximumRating;
    }

    /**
     * Sets the maximum rating value
     */
    public void setMaximumRating(Rating maximumRating) {
        this.maximumRating = maximumRating;
    }
}