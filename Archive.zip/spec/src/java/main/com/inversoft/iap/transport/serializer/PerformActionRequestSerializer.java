/**
 * Date Created: Aug 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.ActionInfo;
import com.inversoft.iap.transport.PerformActionRequest;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Concrete {@link TransportSerializer} to encode {@link PerformActionRequest} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class PerformActionRequestSerializer extends BaseSessionRequestSerializer<PerformActionRequest> {

    public PerformActionRequestSerializer(PerformActionRequest request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // serialize view info
        ViewInfo viewInfo = getTransport().getViewInfo();
        String viewInfoMapping = TransportTools.getElementName(ViewInfo.class);
        String viewIdMapping = "viewId";
        attributes.addAttribute(new QualifiedName("", "", viewIdMapping, viewIdMapping), viewInfo.getViewId());
        startElement("", viewInfoMapping, viewInfoMapping, attributes);
        endElement("", viewInfoMapping, viewInfoMapping);

        // serialize actionInfo
        ActionInfo actionInfo = getTransport().getActionInfo();
        String actionInfoMapping = TransportTools.getElementName(ActionInfo.class);
        String actionIdMapping = "actionId";
        String actionTypeMapping = "actionType";
        attributes.addAttribute(new QualifiedName("", "", actionIdMapping, actionIdMapping), actionInfo.getActionId());
        attributes.addAttribute(new QualifiedName("", "", actionTypeMapping, actionTypeMapping),
                actionInfo.getActionType().toString());
        startElement("", actionInfoMapping, actionInfoMapping, attributes);
        endElement("", actionInfoMapping, actionInfoMapping);

        // serialize dataBody
        encodeData(getTransport().getDataBody(), attributes);
    }
}
