/**
 * Date Created: Aug 9, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.FetchModuleRequest;
import com.inversoft.iap.transport.ModuleInfo;
import com.inversoft.iap.transport.handler.TransportValidationException;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link FetchModuleRequest} objects to Fast Infoset format
 *
 * @author James Humphrey (humphjj)
 * @version 1.0
 */

public class FetchModuleRequestSerializer extends BaseSessionRequestSerializer<FetchModuleRequest> {

    public FetchModuleRequestSerializer(FetchModuleRequest request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        ModuleInfo moduleInfo = getTransport().getModuleInfo();
        if (moduleInfo == null) {
            throw new TransportValidationException("ModuleInfo == null");
        } else if (moduleInfo.getModuleId() == null) {
            throw new TransportValidationException("ModuleInfo.moduleId == null");
        }
        String moduleInfoMapping = TransportTools.getElementName(ModuleInfo.class);
        String moduleIdMapping = "moduleId";
        attributes.addAttribute(new QualifiedName("", "", moduleIdMapping, moduleIdMapping), moduleInfo.getModuleId());
        startElement("", moduleInfoMapping, moduleInfoMapping, attributes);
        endElement("", moduleInfoMapping, moduleInfoMapping);
    }
}
