package com.inversoft.iap.transport;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.inversoft.iap.transport package.
 *
 * <p>A TransportFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
public class TransportFactory {
    /**
     * Create an instance of {@link AuthenticateUserRequest}
     */
    public AuthenticateUserRequest createAuthenticateUserRequest() {
        return new AuthenticateUserRequest();
    }

    /**
     * Create an instance of {@link AuthenticateUserResponse}
     */
    public AuthenticateUserResponse createAuthenticateUserResponse() {
        return new AuthenticateUserResponse();
    }

    /**
     * Create an instance of {@link CloseApplicationRequest}
     */
    public CloseApplicationRequest createCloseApplicationRequest() {
        return new CloseApplicationRequest();
    }

    /**
     * Create an instance of {@link CloseApplicationResponse}
     */
    public CloseApplicationResponse createCloseApplicationResponse() {
        return new CloseApplicationResponse();
    }

    /**
     * Create an instance of {@link FetchModuleRequest}
     */
    public FetchModuleRequest createFetchModuleRequest() {
        return new FetchModuleRequest();
    }

    /**
     * Create an instance of {@link FetchModuleResponse}
     */
    public FetchModuleResponse createFetchModuleResponse() {
        return new FetchModuleResponse();
    }

    /**
     * Create an instance of {@link FetchDataRequest}
     */
    public FetchDataRequest createFetchDataRequest() {
        return new FetchDataRequest();
    }

    /**
     * Create an instance of {@link FetchDataResponse}
     */
    public FetchDataResponse createFetchDataResponse() {
        return new FetchDataResponse();
    }

    /**
     * Create an instance of {@link OpenApplicationRequest}
     */
    public OpenApplicationRequest createOpenApplicationRequest() {
        return new OpenApplicationRequest();
    }

    /**
     * Create an instance of {@link OpenApplicationResponse}
     */
    public OpenApplicationResponse createOpenApplicationResponse() {
        return new OpenApplicationResponse();
    }

    /**
     * Create an instance of {@link OpenViewRequest}
     */
    public OpenViewRequest createOpenViewRequest() {
        return new OpenViewRequest();
    }

    /**
     * Create an instance of {@link OpenViewResponse}
     */
    public OpenViewResponse createOpenViewResponse() {
        return new OpenViewResponse();
    }

    /**
     * Create an instance of {@link PerformActionRequest}
     */
    public PerformActionRequest createPerformActionRequest() {
        return new PerformActionRequest();
    }

    /**
     * Create an instance of {@link PerformActionResponse}
     */
    public PerformActionResponse createPerformActionResponse() {
        return new PerformActionResponse();
    }

    /**
     * Create an instance of {@link ReconnectSessionRequest}
     */
    public ReconnectSessionRequest createReconnectSessionRequest() {
        return new ReconnectSessionRequest();
    }

    /**
     * Create an instance of {@link ReconnectSessionResponse}
     */
    public ReconnectSessionResponse createReconnectSessionResponse() {
        return new ReconnectSessionResponse();
    }

    /**
     * Create an instance of {@link MetaDataRequest}
     */
    public MetaDataRequest createMetaDataRequest() {
        return new MetaDataRequest();
    }

    /**
     * Create an instance of {@link MetaDataResponse}
     */
    public MetaDataResponse createMetadataResponse() {
        return new MetaDataResponse();
    }
}