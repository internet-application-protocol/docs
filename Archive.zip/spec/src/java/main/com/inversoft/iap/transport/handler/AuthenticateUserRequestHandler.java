/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.AuthenticateUserRequest;
import com.inversoft.iap.transport.UserInfo;
import com.inversoft.iap.transport.util.TransportTools;
import org.xml.sax.Attributes;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link AuthenticateUserRequest} object
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class AuthenticateUserRequestHandler extends BaseSessionRequestHandler<AuthenticateUserRequest> {

    public AuthenticateUserRequestHandler() {
        super(new AuthenticateUserRequest());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(UserInfo.class))) {
            UserInfo userInfo = new UserInfo();
            userInfo.setUsername(attributes.getValue("username"));
            userInfo.setPassword(attributes.getValue("password"));
            getTransport().setUserInfo(userInfo);
        }
    }
}