/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

/**
 * Java class for response complex type that defines the interface for all concrete Transport Response types
 *
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="response">
 *   &lt;complexContent>
 *     &lt;extension base="{}transport">
 *       &lt;sequence>
 *         &lt;element name="status" type="{}status"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface Response extends Transport {

    /**
     * Retrieves the {@link Status} object associated to this Response
     *
     * @return {@link Status} associated to this Response
     */
    public Status getStatus();

    /**
     * Sets the {@link Status} associated to this Response
     *
     * @param status the status associated to this Response
     */
    public void setStatus(Status status);
}
