/**
 * Date Created: Aug 2, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import java.io.InputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import com.sun.xml.fastinfoset.sax.SAXDocumentSerializer;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.Response;
import com.inversoft.iap.transport.Status;
import com.inversoft.iap.transport.handler.TransportValidationException;
import com.inversoft.iap.transport.util.TransportTools;
import com.inversoft.util.StringTools;

/**
 * Base abstract {@link SAXDocumentSerializer} for all concrete {@link TransportSerializer) Response types
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseResponseSerializer<T extends Response> extends BaseTransportSerializer<T> {

    protected BaseResponseSerializer(T transport) {
        super(transport);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeChildren(AttributesHolder attributes) throws SAXException {
        encodeStatus(attributes);
        attributes.clear();
        encodeConcrete(attributes);
    }

    /**
     * Encodes the Transport Status.  The status is associated to every Response
     *
     * @param attributes {@link AttributesHolder}
     * @throws SAXException thrown if there is a problem during encoding
     */
    private void encodeStatus(AttributesHolder attributes) throws SAXException {
        Status status = getTransport().getStatus();

        // validate required components
        if (status == null) {
            throw new TransportValidationException("Status == null");
        } else if (StringTools.isEmpty(status.getCode())) {
            throw new TransportValidationException("Status.code == null or empty string");
        }

        String statusElement = TransportTools.getElementName(Status.class);
        String codeMapping = "code";
        String sessionDurationMapping = "sessionDuration";
        attributes.addAttribute(new QualifiedName("", "", codeMapping,codeMapping), status.getCode());

        // session duration is not required so check if it's defined first
        if (status.getSessionDuration() != null) {
            attributes.addAttribute(new QualifiedName("", "", sessionDurationMapping, sessionDurationMapping),
                Integer.toString(status.getSessionDuration()));
        }
        startElement("", statusElement, statusElement, attributes);

        // if the status has content then process accordingly
        if (!StringTools.isEmpty(status.getValue())) {
            char[] value = status.getValue().toCharArray();
            characters(value, 0, value.length);
        }
        endElement("", statusElement, statusElement);
    }

    protected void transmitStream(InputStream is) throws SAXException {
        byte[] buf = new byte[1024];
        int count;
        do {
            try {
                count = is.read(buf);
            } catch (IOException e) {
                throw new SAXException(e);
            }

            if (count > 0) {
                bytes(buf, 0, count);
            }
        } while (count > 0);
    }

    protected void transmitData(ByteBuffer data) {
        byte[] buf = new byte[1024];
        int length;
        do {
            length = Math.min(data.remaining(), 1024);
            if (length > 0) {
                data.get(buf, 0, length);
            }
        } while (length == 1024);
    }
}