package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}sessionRequest">
 *       &lt;sequence>
 *         &lt;element name="dataRequestBody" type="{}dataRequestBody"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "fetchDataRequest", isRootElement = true)
public class FetchDataRequest extends SessionRequest {

    @XmlAttribute()
    DataRequestBody dataRequestBody;

    /**
     * Returns the type of request.
     */
    public TransportType getType() {
        return TransportType.FETCH_DATA;
    }

    /**
     * Gets the value of the dataRequestBody property.
     */
    public DataRequestBody getDataRequestBody() {
        return dataRequestBody;
    }

    /**
     * Sets the value of the dataRequestBody property.
     */
    public void setDataRequestBody(DataRequestBody value) {
        dataRequestBody = value;
    }
}