/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.SessionRequest;
import com.inversoft.iap.transport.Certificate;
import com.inversoft.iap.transport.util.TransportTools;
import iap.VersionNumber;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * <p>
 * This is a base class that provides sessionId handling for concrete {@link BaseRequestHandler} implementations.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class BaseSessionRequestHandler<T extends SessionRequest> extends BaseRequestHandler<T> {

    protected BaseSessionRequestHandler(T request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    protected void parseElement(String uri, String localName, String qName, Attributes attributes) {
        // if the element is the sessionId and the parent element is the root then set the sessionId
        if (qName.equals(TransportTools.getElementName(SessionId.class)) &&
                getParentElement().equals(getTransport().getClass())) {
            String applicationId = attributes.getValue("applicationId");
            VersionNumber versionNumber = VersionNumber.decode(
                    attributes.getValue("versionNumber"));
            String id = attributes.getValue("id");
            SessionId sessionId = new SessionId(applicationId, versionNumber, id);
            getTransport().setSessionId(sessionId);
        } else {
            parseUniqueElement(uri, localName, qName, attributes);
        }
    }

    /**
     * Implemented by sub-classes to parse individual elements unique to the implementing class
     *
     * @param uri the namespace uri
     * @param localName the localname
     * @param qName the qualified name including namespace prefix
     * @param attributes {@link Attributes}
     */
    protected abstract void parseUniqueElement(String uri, String localName, String qName, Attributes attributes);
}