/**
 * Date Created: Aug 9, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.CloseApplicationResponse;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link CloseApplicationResponse} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class CloseApplicationResponseSerializer extends BaseResponseSerializer<CloseApplicationResponse> {

    public CloseApplicationResponseSerializer(CloseApplicationResponse transport) {
        super(transport);
    }

    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // no concrete specific elements to serialize
    }
}
