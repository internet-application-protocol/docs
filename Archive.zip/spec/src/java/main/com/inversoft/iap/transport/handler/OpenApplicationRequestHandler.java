/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.ApplicationInfo;
import com.inversoft.iap.transport.ClientConstraint;
import com.inversoft.iap.transport.ClientCredentials;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.Param;
import com.inversoft.iap.transport.Certificate;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.util.TransportTools;
import com.inversoft.iap.request.VersionSpecification;
import com.inversoft.util.StringTools;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import iap.Coord;
import iap.Size;
import iap.VersionNumber;
import iap.request.DeviceType;
import iap.response.Rating;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link OpenApplicationRequest} object
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenApplicationRequestHandler extends BaseRequestHandler<OpenApplicationRequest> {

    Coord min;

    Coord max;

    /**
     * Default no-arg constructor
     */
    public OpenApplicationRequestHandler() {
        super(new OpenApplicationRequest());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(ClientCredentials.class))) {
            ClientCredentials clientCredentials = new ClientCredentials();
            getTransport().setClientCredentials(clientCredentials);
        } else if (qName.equals(TransportTools.getElementName(Certificate.class))) {
            Certificate certificate = new Certificate();
            certificate.setDateCreated(XMLGregorianCalendarImpl.parse(attributes.getValue("dateCreated")));
            certificate.setDateExpires(XMLGregorianCalendarImpl.parse(attributes.getValue("dateExpires")));
            getTransport().getClientCredentials().setCertificate(certificate);
            setParentElement(Certificate.class);
        } else if (qName.equals(TransportTools.getElementName(SessionId.class))) {
            String applicationId = attributes.getValue("applicationId");
            VersionNumber versionNumber = VersionNumber.decode(
                    attributes.getValue("versionNumber"));
            String id = attributes.getValue("id");
            SessionId sessionId = new SessionId(applicationId, versionNumber, id);
            getTransport().getClientCredentials().setSessionId(sessionId);
        } else if (qName.equals(TransportTools.getElementName(ApplicationInfo.class))) {
            ApplicationInfo applicationInfo = new ApplicationInfo();
            String applicationId = attributes.getValue("applicationId");
            applicationInfo.setApplicationId(applicationId);
            if (!StringTools.isEmpty(attributes.getValue("versionNumber"))) {
                VersionNumber versionNumber = VersionNumber.decode(attributes.getValue("versionNumber"));
                applicationInfo.setVersionNumber(versionNumber);
            }
            getTransport().setApplicationInfo(applicationInfo);
        } else if (qName.equals(TransportTools.getElementName(Param.class))) {
            String name = attributes.getValue("name");
            String value = attributes.getValue("value");
            getTransport().getApplicationInfo().addParam(name, value);
        } else if (qName.equals(TransportTools.getElementName(ClientConstraint.class))) {
            ClientConstraint clientConstraint = new ClientConstraint();
            DeviceType type = DeviceType.valueOf(attributes.getValue("deviceConstraint"));
            VersionSpecification pConstraint = VersionSpecification.decode(attributes.getValue("protocolConstraint"));
            String maximumRating = attributes.getValue("maximumRating");
            clientConstraint.setDeviceConstraint(type);
            clientConstraint.setProtocolConstraint(pConstraint);
            clientConstraint.setMaximumRating(Rating.valueOf(maximumRating));
            getTransport().setClientConstraint(clientConstraint);
        } else if (qName.equals("min")) {
            int x = Integer.parseInt(attributes.getValue("x"));
            int y = Integer.parseInt(attributes.getValue("y"));
            min = new Coord(x, y);
        } else if (qName.equals("max")) {
            int x = Integer.parseInt(attributes.getValue("x"));
            int y = Integer.parseInt(attributes.getValue("y"));
            max = new Coord(x, y);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void characters(char ch[], int start, int length) throws SAXException {
        String value = new String(ch, start, length);
        if (getParentElement().equals(Certificate.class)) {
            getTransport().getClientCredentials().getCertificate().setValue(value);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OpenApplicationRequest getTransport() {
        if (min != null || max != null) {
            Size size = new Size(min, max);
            super.getTransport().getClientConstraint().setSizeConstraint(size);
        }

        return super.getTransport();
    }
}