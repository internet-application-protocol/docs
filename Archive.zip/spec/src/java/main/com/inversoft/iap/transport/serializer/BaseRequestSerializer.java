/**
 * Date Created: Aug 2, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.Request;
import com.sun.xml.fastinfoset.sax.SAXDocumentSerializer;

/**
 * Base abstract {@link SAXDocumentSerializer} for all concrete {@link TransportSerializer) Request implementations
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseRequestSerializer<T extends Request> extends BaseTransportSerializer<T> {

    protected BaseRequestSerializer(T request) {
        super(request);
    }
}
