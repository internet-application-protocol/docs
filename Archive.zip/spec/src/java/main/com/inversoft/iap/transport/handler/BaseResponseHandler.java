/**
 * Date Created: Aug 2, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.Response;
import com.inversoft.iap.transport.Status;
import com.inversoft.iap.transport.util.TransportTools;
import com.inversoft.util.StringTools;

/**
 * Base abstract handler to handle conversions from Fast Infoset to concrete {@link Response} transport model objects
 *
 * @author  James Humphrey
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class BaseResponseHandler<T extends Response> extends BaseTransportHandler<T> {
    protected BaseResponseHandler(T response) {
        super(response);
    }

    /**
     * {@inheritDoc}
     */
    protected void parseElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(Status.class))) {
            Status status = new Status();
            status.setCode(attributes.getValue("code"));
            String sessionDuration = attributes.getValue("sessionDuration");
            if (!StringTools.isEmpty(sessionDuration)) {
                status.setSessionDuration(Integer.parseInt(sessionDuration));
            }
            getTransport().setStatus(status);
            setParentElement(Status.class);
        } else {
            parseUniqueElement(uri, localName, qName, attributes);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void characters(char ch[], int start, int length) throws SAXException {
        String value = new String(ch, start, length);
        if (getParentElement().equals(Status.class)) {
            if (getTransport().getStatus() != null) {
                getTransport().getStatus().setValue(value);
            }
        } else {
            decodeCharacterContent(ch, start, length);
        }
    }

    /**
     * Decodes element character content
     *
     * @param ch the array containing the character bytes
     * @param start the start index
     * @param length the off from the start index
     */
    protected abstract void decodeCharacterContent(char[] ch, int start, int length);

    /**
     * Implemented by sub-classes to parse individual elements unique to the implementing class
     *
     * @param uri the namespace uri
     * @param localName the localname
     * @param qName the qualified name including namespace prefix
     * @param attributes {@link Attributes}
     */
    protected abstract void parseUniqueElement(String uri, String localName, String qName, Attributes attributes);
}