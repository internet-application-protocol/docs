/**
 * Date Created: Aug 2, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.Request;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * Base abstract handler to handle conversions from Fast Infoset to concrete {@link Request} transport model objects
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseRequestHandler<T extends Request> extends BaseTransportHandler<T> {

    protected BaseRequestHandler(T request) {
        super(request);
    }
}