/**
 * Copyright (c) 2004, Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;


import java.net.URI;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import static com.inversoft.util.StringTools.isEmpty;
import iap.VersionNumber;
import iap.annotation.XmlElement;


/**
 * <p>
 * The client must break up the URL that the client is using to
 * open the application into its logical parts. It must then send
 * an open application request to the server specified in the URL.
 * The application-info component of the open application request
 * is the application-name and optional parameter-list parts of the URL
 * </p>
 * <p>
 * The BNF definition for a IAP URL is:
 * </p>
 * url-definition = �iap://� server-name [�/� application-name]
 * [�?� parameter-list]
 *
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="applicationInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="param" type="{}baseParam" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="applicationId" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="versionNumber" type="{}versionNumber" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */
@XmlElement(name = "applicationInfo")
public final class ApplicationInfo {
    /**
     * Name of the application
     */
    String applicationId;

    /**
     * Stores the name-value query parameters
     */
    final List<Param> params = new LinkedList<Param>();

    /**
     * Local version number on client
     */
    VersionNumber versionNumber;

    /**
     * No arg constructor.
     */
    public ApplicationInfo() {
    }

    /**
     * Creates an ApplicationInfo object from a URI
     *
     * @param uri URL object
     */
    public ApplicationInfo(URI uri) {
        setApplicationId(uri.getPath());
        if (!isEmpty(uri.getQuery())) {
            parseQuery(uri.getQuery());
        }
    }

    /**
     * Creates an ApplicationInfo object from a application name string
     * and a application parameter map
     *
     * @param   applicationId  The name of the application.
     * @param   params (Optional) List containing parameter name-value pairs.
     * @param   versionNumber The version number of the application.
     */
    public ApplicationInfo(String applicationId,
                           List<Param> params,
                           VersionNumber versionNumber) {
        assert (applicationId != null) : "applicationId == null";
        assert (versionNumber != null) : "versionNumber == null";
        setApplicationId(applicationId);
        this.versionNumber = versionNumber;
        if (params != null) {
            this.params.addAll(params);
        }
    }

    /**
     * Parses the URI query string and places the name-value
     * pairs into the queryMap with name as the key
     */
    void parseQuery(String query) {
        String[] nameValuePairs = query.split("&");

        for (String nameValuePair : nameValuePairs) {
            String[] nameValue = nameValuePair.split("=");
            addParam(nameValue[0], nameValue[1]);
        }
    }

    /**
     * adds a parameter to the map
     *
     * @param name name of the parameter
     * @param value value of the paramter
     */
    public void addParam(String name, String value) {
        Param param = new Param();
        param.setName(name);
        param.setValue(value);
        this.params.add(param);
    }

    /**
     * Return the name of the application
     *
     * @return the name of the application
     */
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * Set the name of the application.
     *
     * @param   applicationId the application name
     */
    public void setApplicationId(String applicationId) {
        if (!applicationId.startsWith("/")) {
            this.applicationId = "/" + applicationId;
        } else {
            this.applicationId = applicationId;
        }
    }

    /**
     * <p>
     * Returns an unmodifiable parameter list back to the caller.
     * </p>
     *
     * <p>
     * The ApplicationInfo interface should be used explicitly
     * to do any kind of object manipulation
     *
     * @return the parameter map
     */
    public List<Param> getParams() {
        return Collections.unmodifiableList(this.params);
    }

    /**
     * Set the parameter list
     *
     * @param params
     */
    public void setParams(List<Param> params) {
        this.params.addAll(params);
    }

    /**
     * Returns the application-info defined in the IAP specification.
     * This is a concatenation of the applicationId and paramter map
     *
     * @return application-info defined in IAP specification
     */
    public String getApplicationInfo() {
        return applicationId + parameterListToString();
    }

    /**
     * Remove a parameter from parameter list
     *
     * @param param {@link Param}
     */
    public void removeParam(Param param) {
        params.remove(param);
    }

    /**
     * returns the params as a string.  Will return
     * empty string if the parameter map is null
     *
     * @return string representation of the paramter map
     */
    public String parameterListToString() {
        String parameterString = "";
        int index = 0;

        // check for size
        if (this.params.size() > 0) {
            parameterString = "?";
            for (Param param : params) {
                String name = param.getName();
                String value = param.getValue();
                parameterString += name + "=" + value;
                if (index != (this.params.size() - 1)) {
                    parameterString += "&";
                }
                index++;
            }
        }

        return parameterString;
    }

    /**
     * Converts a String into an ApplicationInfo object.  The string
     * must be in the correct format as defined in the IAP Specification
     *
     * @param appIdString Application Info string representation
     * @param versionNumber version number associated to the application
     * @return ApplicationInfo object
     */
    public static ApplicationInfo decode(String appIdString,
                                         VersionNumber versionNumber) {
        // escape the question mark so regex will recognize
        String[] appId = appIdString.split("\\?");
        // set applicationId
        String applicationId = appId[0];

        List<Param> params = null;

        // if appId[1] is not null or empty string then parameters exist
        if (appId.length > 1) {
            params = new LinkedList<Param>();
            String[] nameValuePairs = appId[1].split("&");

            for (String nameValuePair : nameValuePairs) {
                String[] nameValue = nameValuePair.split("=");
                Param param = new Param();
                param.setName(nameValue[0]);
                param.setValue(nameValue[1]);
                params.add(param);
            }
        }

        return new ApplicationInfo(applicationId, params, versionNumber);
    }

    /**
     * returns a string representation of an ApplicationInfo object
     *
     * @return a string representation of the object.
     * @param applicationInfo
     */
    public static String encode(ApplicationInfo applicationInfo) {
        return applicationInfo.toString();
    }

    /**
     * Returns a string representation of the object.
     *
     * @return a string representation of the object.
     */
    public String toString() {
        return this.applicationId + parameterListToString();
    }

    /**
     * Returns the version number associated to this application
     *
     * @return version number
     */
    public VersionNumber getVersionNumber() {
        return versionNumber;
    }

    /**
     * Can be used to set the version number for this particular application
     *
     * @param versionNumber version number
     */
    public void setVersionNumber(VersionNumber versionNumber) {
        this.versionNumber = versionNumber;
    }
}