package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for the AuthenticateUserRequest Transport.
 *
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}sessionRequest">
 *       &lt;sequence>
 *         &lt;element name="userInfo" type="{}userInfo"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "authenticateUserRequest", isRootElement = true)
public class AuthenticateUserRequest extends SessionRequest {

    @XmlElement(name = "userInfo")
    UserInfo userInfo;

    /**
     * Returns the type of request.
     */
    public TransportType getType() {
        return TransportType.AUTHENTICATE_USER;
    }

    /**
     * Gets the value of the userInfo property.
     *
     * @return The user info.
     */
    public UserInfo getUserInfo() {
        return userInfo;
    }

    /**
     * Sets the value of the userInfo property.
     *
     * @param value The user info.
     */
    public void setUserInfo(UserInfo value) {
        userInfo = value;
    }
}