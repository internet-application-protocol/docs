/**
 * Date Created: Aug 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.ClientCredentials;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.Certificate;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import com.sun.xml.fastinfoset.QualifiedName;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link ReconnectSessionRequest} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ReconnectSessionRequestSerializer extends BaseSessionRequestSerializer<ReconnectSessionRequest> {

    public ReconnectSessionRequestSerializer(ReconnectSessionRequest request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // serializer credentials
        ClientCredentials credentials = getTransport().getClientCredentials();
        if (credentials != null) {
            String credentialsMapping = TransportTools.getElementName(ClientCredentials.class);

            startElement("", credentialsMapping, credentialsMapping, attributes);
            SessionId sessionId = credentials.getSessionId();
            Certificate certificate = credentials.getCertificate();

            // serialize sessionId or certificate or neither
            if (sessionId != null) {
                String sessionIdMapping = TransportTools.getElementName(SessionId.class);
                String applicataionIdMapping = "applicationId";
                String versionNumberMapping = "versionNumber";
                String idMapping = "id";
                attributes.addAttribute(new QualifiedName("", "", applicataionIdMapping, applicataionIdMapping),
                        sessionId.getApplicationId());
                attributes.addAttribute(new QualifiedName("", "", versionNumberMapping, versionNumberMapping),
                        sessionId.getVersionNumber().toString());
                attributes.addAttribute(new QualifiedName("", "", idMapping, idMapping), sessionId.getStringId());
                startElement("", sessionIdMapping, sessionIdMapping, attributes);
                endElement("", sessionIdMapping, sessionIdMapping);
            } else if (certificate != null) {
                String certificateMapping = TransportTools.getElementName(Certificate.class);
                String expiresMapping = "dateExpires";
                String createdMapping = "dateCreated";
                attributes.addAttribute(new QualifiedName("", "", expiresMapping, expiresMapping),
                        certificate.getDateExpires().toXMLFormat());
                attributes.addAttribute(new QualifiedName("", "", createdMapping, createdMapping),
                        certificate.getDateCreated().toXMLFormat());
                startElement("", certificateMapping, certificateMapping, attributes);
                char[] c = certificate.getValue().toCharArray();
                characters(c, 0, c.length);
                endElement("", certificateMapping, certificateMapping);
            }
            endElement("", credentialsMapping, credentialsMapping);
            attributes.clear();
        }
    }
}
