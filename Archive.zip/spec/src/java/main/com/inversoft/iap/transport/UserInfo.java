package com.inversoft.iap.transport;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for userInfo complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="userInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="password" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="username" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "userInfo")
public class UserInfo {

    @XmlAttribute()
    String password;

    @XmlAttribute()
    String username;

    /**
     * Gets the value of the password property.
     *
     * @return The password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of the password property.
     *
     * @param value The password.
     */
    public void setPassword(String value) {
        password = value;
    }

    /**
     * Gets the value of the username property.
     *
     * @return The username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the value of the username property.
     *
     * @param value The username.
     */
    public void setUsername(String value) {
        username = value;
    }
}