/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.util;

/**
 * <p>
 * This interface defines the methods that are called by a data encoder
 * to serialize out data values to binary.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public interface DataSerializer {
    /**
     * Adds a single boolean to the serialized form.
     */
    void addBoolean(boolean b) throws DataSerializerException;

    /**
     * Adds a single byte to the serialized form.
     */
    void addByte(byte b) throws DataSerializerException;

    /**
     * Adds a single char to the serialized form.
     */
    void addChar(char c) throws DataSerializerException;

    /**
     * Adds a single double to the serialized form.
     */
    void addDouble(double d) throws DataSerializerException;

    /**
     * Adds a single float to the serialized form.
     */
    void addFloat(float f) throws DataSerializerException;

    /**
     * Adds a single int to the serialized form.
     */
    void addInt(int i) throws DataSerializerException;

    /**
     * Adds a single long to the serialized form.
     */
    void addLong(long l) throws DataSerializerException;

    /**
     * Adds a single short to the serialized form.
     */
    void addShort(short s) throws DataSerializerException;

    /**
     * Adds a boolean array to the serialized form.
     */
    void addBooleanArray(boolean[] b) throws DataSerializerException;

    /**
     * Adds a byte array to the serialized form.
     */
    void addByteArray(byte[] b) throws DataSerializerException;

    /**
     * Adds a char array to the serialized form.
     */
    void addCharArray(char[] c) throws DataSerializerException;

    /**
     * Adds a double array to the serialized form.
     */
    void addDoubleArray(double[] d) throws DataSerializerException;

    /**
     * Adds a float array to the serialized form.
     */
    void addFloatArray(float[] f) throws DataSerializerException;

    /**
     * Adds an int array to the serialized form.
     */
    void addIntArray(int[] i) throws DataSerializerException;

    /**
     * Adds a long array to the serialized form.
     */
    void addLongArray(long[] l) throws DataSerializerException;

    /**
     * Adds a short array to the serialized form.
     */
    void addShortArray(short[] s) throws DataSerializerException;

    /**
     * Adds the array header to the serialized form.
     */
    void addArrayHeader(int[] header) throws DataSerializerException;
}