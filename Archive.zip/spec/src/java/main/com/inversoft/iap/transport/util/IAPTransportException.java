/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.util;

/**
 * <p>
 * This exception is thrown when the TransportTools has problems parsing or
 * serializing the transport objects.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class IAPTransportException extends Exception {
    public IAPTransportException() {
        super();
    }

    public IAPTransportException(String message) {
        super(message);
    }

    public IAPTransportException(String message, Throwable cause) {
        super(message, cause);
    }

    public IAPTransportException(Throwable cause) {
        super(cause);
    }
}