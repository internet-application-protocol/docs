package com.inversoft.iap.transport;

import com.inversoft.iap.DataBody;
import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for AuthenticateUserResponse Transport.
 *
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}response">
 *       &lt;sequence>
 *         &lt;element name="dataBody" type="{}dataBody" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "authenticateUserResponse", isRootElement = true)
public class AuthenticateUserResponse extends BaseResponse {

    @XmlElement(name = "dataBody", isRequired = false)
    DataBody dataBody;

    /**
     * Returns the type of response.
     */
    public TransportType getType() {
        return TransportType.AUTHENTICATE_USER;
    }

    /**
     * Gets the value of the dataBody property.
     *
     * @return The data body.
     */
    public DataBody getDataBody() {
        return dataBody;
    }

    /**
     * Sets the value of the dataBody property.
     *
     * @param value The data body.
     */
    public void setDataBody(DataBody value) {
        dataBody = value;
    }
}