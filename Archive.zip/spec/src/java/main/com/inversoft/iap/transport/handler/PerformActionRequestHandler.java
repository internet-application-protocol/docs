/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.handler;

import iap.request.ActionType;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataBody;
import com.inversoft.iap.transport.ActionInfo;
import com.inversoft.iap.transport.PerformActionRequest;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link PerformActionRequest} object
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class PerformActionRequestHandler extends BaseSessionRequestHandler<PerformActionRequest> {

    public PerformActionRequestHandler() {
        super(new PerformActionRequest());
        getTransport().setDataBody(new DataBody());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(ViewInfo.class))) {
            ViewInfo viewInfo = new ViewInfo();
            viewInfo.setViewId(attributes.getValue("viewId"));
            getTransport().setViewInfo(viewInfo);
        } else if (qName.equals(TransportTools.getElementName(ActionInfo.class))) {
            ActionInfo actionInfo = new ActionInfo();
            actionInfo.setActionId(attributes.getValue("actionId"));
            actionInfo.setActionType(ActionType.valueOf(attributes.getValue("actionType")));
            getTransport().setActionInfo(actionInfo);
        } else if (qName.equals(TransportTools.getElementName(Data.class))) {
            addNewDataBean(attributes);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void bytes(byte[] b, int start, int length) throws SAXException {
        super.addData(b, start, length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals(TransportTools.getElementName(Data.class))) {
            DataBody dataBody = getTransport().getDataBody();
            Data data = decodeDataValue();
            dataBody.addData(data);
        }
    }
}