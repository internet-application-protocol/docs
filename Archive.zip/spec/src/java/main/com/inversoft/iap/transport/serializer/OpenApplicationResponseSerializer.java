/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.serializer;

import java.net.URL;

import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import iap.response.Redirect;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.ApplicationDescription;
import com.inversoft.iap.transport.ApplicationSpec;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.RatingInfo;
import com.inversoft.iap.transport.RedirectGroup;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.SuccessGroup;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Concrete {@link TransportSerializer} to encode {@link com.inversoft.iap.transport.OpenApplicationResponse}
 * objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OpenApplicationResponseSerializer extends BaseResponseSerializer<OpenApplicationResponse> {

    public OpenApplicationResponseSerializer(OpenApplicationResponse transport) {
        super(transport);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        SuccessGroup successGroup = getTransport().getSuccessGroup();
        RedirectGroup redirectGroup = getTransport().getRedirectGroup();
        if (redirectGroup != null) {
            Redirect redirect = redirectGroup.getRedirect();
            String redirectMapping = TransportTools.getElementName(Redirect.class);
            String applicationSpecMapping = "applicationSpec";
            URL url = redirect.getUrl();
            attributes.addAttribute(new QualifiedName("", "", applicationSpecMapping, applicationSpecMapping),
                    url.toString());
            startElement("", redirectMapping, redirectMapping, attributes);
            endElement("", redirectMapping, redirectMapping);
        } else if (successGroup != null) {
            // serialize application description
            ApplicationDescription appDesc = successGroup.getApplicationDescription();
            String appDescMapping = TransportTools.getElementName(ApplicationDescription.class);
            String cacheMapping = "isCacheable";
            attributes.addAttribute(new QualifiedName("", "", cacheMapping, cacheMapping),
                    Boolean.toString(appDesc.isIsCacheable()));
            startElement("", appDescMapping, appDescMapping, attributes);
            endElement("", appDescMapping, appDescMapping);

            attributes.clear();

            // serialize application ref
            ApplicationSpec appRef = successGroup.getApplicationRef();
            if (appRef != null) {
                String appRefMapping = TransportTools.getElementName(ApplicationSpec.class);
                String appSpecMapping = "applicationSpec";
                attributes.addAttribute(new QualifiedName("", "", appSpecMapping, appSpecMapping),
                        appRef.getApplicationSpec());
                startElement("", appRefMapping, appRefMapping, attributes);
                endElement("", appRefMapping, appRefMapping);
                
                attributes.clear();
            }

            // serialize rating info
            RatingInfo ratingInfo = successGroup.getRatingInfo();
            String ratingInfoMapping = TransportTools.getElementName(RatingInfo.class);
            String ratingMapping = "rating";
            attributes.addAttribute(new QualifiedName("", "", ratingMapping, ratingMapping),
                    ratingInfo.getRating().toString());
            startElement("", ratingInfoMapping, ratingInfoMapping, attributes);
            endElement("", ratingInfoMapping, ratingInfoMapping);

            attributes.clear();

            // serialize sessionId
            SessionId sessionId = successGroup.getSessionId();
            String sessionIdMapping = TransportTools.getElementName(SessionId.class);
            String applicataionIdMapping = "applicationId";
            String versionNumberMapping = "versionNumber";
            String idMapping = "id";
            attributes.addAttribute(new QualifiedName("", "", applicataionIdMapping, applicataionIdMapping),
                    sessionId.getApplicationId());
            attributes.addAttribute(new QualifiedName("", "", versionNumberMapping, versionNumberMapping),
                    sessionId.getVersionNumber().toString());
            attributes.addAttribute(new QualifiedName("", "", idMapping, idMapping), sessionId.getStringId());
            startElement("", sessionIdMapping, sessionIdMapping, attributes);
            endElement("", sessionIdMapping, sessionIdMapping);

            attributes.clear();

            // serialize view info
            ViewInfo viewInfo = successGroup.getViewInfo();
            String viewInfoMapping = TransportTools.getElementName(ViewInfo.class);
            String viewIdMapping = "viewId";
            attributes.addAttribute(new QualifiedName("", "", viewIdMapping, viewIdMapping),
                    viewInfo.getViewId());
            startElement("", viewInfoMapping, viewInfoMapping, attributes);
            endElement("", viewInfoMapping, viewInfoMapping);

            attributes.clear();
        }
    }
}