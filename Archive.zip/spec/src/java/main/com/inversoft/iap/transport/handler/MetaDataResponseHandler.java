/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.handler;

import java.util.List;

import com.inversoft.iap.request.VersionSpecification;
import com.inversoft.iap.transport.Application;
import com.inversoft.iap.transport.Description;
import com.inversoft.iap.transport.Keyword;
import com.inversoft.iap.transport.MetaData;
import com.inversoft.iap.transport.MetaDataResponse;
import com.inversoft.iap.transport.util.TransportTools;
import iap.VersionNumber;
import iap.request.DeviceType;
import iap.response.Rating;
import org.xml.sax.Attributes;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link MetaDataResponse} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MetaDataResponseHandler extends BaseResponseHandler<MetaDataResponse> {

    public MetaDataResponseHandler() {
        super(new MetaDataResponse());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(Application.class))) {
            Application application = new Application();
            String name = attributes.getValue("name");
            VersionNumber versionNumber = VersionNumber.decode(attributes.getValue("versionNumber"));
            DeviceType deviceType = DeviceType.valueOf(attributes.getValue("deviceType"));
            Rating rating = Rating.valueOf(attributes.getValue("rating"));
            VersionSpecification versionSpecification =
                    VersionSpecification.decode(attributes.getValue("versionSpecification"));
            application.setName(name);
            application.setRating(rating);
            application.setVersionNumber(versionNumber);
            application.setVersionSpecification(versionSpecification);
            application.setDeviceType(deviceType);
            getTransport().getApplications().add(application);
            setParentElement(Application.class);
        } else if (qName.equals(TransportTools.getElementName(Description.class))) {
            Description description = new Description();
            getApplication().setDescription(description);
            setParentElement(Description.class);
        } else if (qName.equals(TransportTools.getElementName(Keyword.class))) {
            Keyword keyword = new Keyword();
            getApplication().getKeywords().add(keyword);
            setParentElement(Keyword.class);
        } else if (qName.equals(TransportTools.getElementName(MetaData.class))) {
            MetaData metadata = new MetaData();
            String name = attributes.getValue("name");
            String value = attributes.getValue("value");
            metadata.setName(name);
            metadata.setValue(value);
            getApplication().getMetaData().add(metadata);
            setParentElement(MetaData.class);
        }
    }

    /**
     * {@inheritDoc}
     */
    protected void decodeCharacterContent(char[] ch, int start, int length) {
        String value = new String(ch, start, length);
        List<Application> applications = getTransport().getApplications();
        Application application = applications.get(applications.size() - 1);
        if (getParentElement().equals(Description.class)) {
            application.getDescription().setValue(value);
        } else if (getParentElement().equals(Keyword.class)) {
            List<Keyword> keywords = application.getKeywords();
            Keyword keyword = keywords.get(keywords.size() - 1);
            keyword.setValue(value);
        }
    }

    /**
     * Returns the last {@link Application} object added to the application list
     *
     * @return {@link Application}
     */
    private Application getApplication() {
        List<Application> applications = getTransport().getApplications();
        return getTransport().getApplications().get(applications.size() - 1);
    }
}
