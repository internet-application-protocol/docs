/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.CloseApplicationRequest;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link CloseApplicationRequest} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class CloseApplicationRequestSerializer extends BaseSessionRequestSerializer<CloseApplicationRequest> {

    public CloseApplicationRequestSerializer(CloseApplicationRequest request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // no concrete elements to encode
    }
}
