/**
 * Date Created: Aug 2, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import java.util.List;
import java.util.logging.Logger;

import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import com.sun.xml.fastinfoset.sax.SAXDocumentSerializer;
import org.xml.sax.SAXException;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataBody;
import com.inversoft.iap.transport.Transport;
import com.inversoft.iap.transport.TransportValidator;
import com.inversoft.iap.transport.util.ByteBufferDataSerializer;
import com.inversoft.iap.transport.util.DataBinaryEncoder;
import com.inversoft.iap.transport.util.DataSerializerException;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Base abstract interface that defines base implementations for all {@link TransportSerializer} classes
 *
 * @author  James Humphrey
 * @since   IAP 1.0
 * @version 1.0
 */
public abstract class BaseTransportSerializer<T extends Transport> extends SAXDocumentSerializer
        implements TransportSerializer<T> {
    private static final Logger logger = Logger.getLogger(BaseTransportSerializer.class.getName());
    private T transport;
    private boolean validateTransport = false;

    /**
     * Base contructor provide for concrete implementation that takes a {@link Transport} parameter
     *
     * @param transport {@link Transport}
     */
    protected BaseTransportSerializer(T transport) {
        this.transport = transport;
    }

    /**
     * {@inheritDoc}
     */
    public void serialize() throws SAXException {

        // validate if applicable
        if (validatingTransport()) {
            logger.finest("***Serializer validation enabled***");
            TransportValidator.validate(getTransport());
        }

        AttributesHolder attributes = new AttributesHolder();
        String rootElement = TransportTools.getElementName(getTransport().getClass());
        startDocument();
        startElement("", rootElement, rootElement, attributes);
        encodeChildren(attributes);
        endElement("", rootElement, rootElement);
        endDocument();
    }

    /**
     * Encodes {@link com.inversoft.iap.Data}
     *
     * @param dataBody {@link com.inversoft.iap.DataBody}
     * @param attributes {@link AttributesHolder}
     * @throws SAXException thrown if there is a problem during the serialization process
     */
    protected void encodeData(DataBody dataBody, AttributesHolder attributes) throws SAXException {
        if (dataBody != null) {
            String dataBodyMapping = TransportTools.getElementName(DataBody.class);

            startElement("", dataBodyMapping, dataBodyMapping, attributes);

            List<Data> dataList = dataBody.getAllData();
            if (!dataList.isEmpty()) {
                String dataMapping = TransportTools.getElementName(Data.class);
                String nameMapping = "name";
                String arrayDepthMapping = "arrayDepth";
                String scopeMapping = "scope";
                String typeMapping = "type";

                for (Data data : dataList) {
                    attributes.addAttribute(new QualifiedName("", "", nameMapping, nameMapping), data.getKey());
                    attributes.addAttribute(new QualifiedName("", "", scopeMapping, scopeMapping),
                        data.getScope().toString());
                    attributes.addAttribute(new QualifiedName("", "", arrayDepthMapping, arrayDepthMapping),
                        Integer.toString(data.getArrayDepth()));
                    attributes.addAttribute(new QualifiedName("", "", typeMapping, typeMapping),
                        data.getType().toString());
                    startElement("", dataMapping, dataMapping, attributes);
                    try {
                        ByteBufferDataSerializer serializer = new ByteBufferDataSerializer();
                        DataBinaryEncoder.encode(data, serializer);
                        byte[] bytes = serializer.getBytes();
                        bytes(bytes, 0, bytes.length);
                    } catch (DataSerializerException e) {
                        throw new SAXException(e);
                    }
                    endElement("", dataMapping, dataMapping);
                    attributes.clear();
                }
            }

            endElement("", dataBodyMapping, dataBodyMapping);
        }
    }

    /**
     * {@inheritDoc}
     */
    public T getTransport() {
        return transport;
    }

    /**
     * true if validatingTransport the transport during serialization, false otherwise
     *
     * @return true if validatingTransport the transport during serialization, false otherwise
     */
    public boolean validatingTransport() {
        return validateTransport;
    }

    /**
     * Set to true if the serializer should validateTransport the transport type during the encoding process
     *
     * @param validateTransport true if validation is required, false otherwise
     */
    public void setValidateTransport(boolean validateTransport) {
        this.validateTransport = validateTransport;
    }

    /**
     * Encodes the all the root element children to Fast Infoset format
     *
     * @param attributes the {@link AttributesHolder} object
     */
    protected abstract void encodeChildren(AttributesHolder attributes) throws SAXException;

    /**
     * Encodes the concrete Transport into Fast Infoset format
     *
     * @param attributes {@link AttributesHolder} object
     */
    protected abstract void encodeConcrete(AttributesHolder attributes) throws SAXException;
}