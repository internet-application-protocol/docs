package com.inversoft.iap.transport;

/**
 * Java class for request complex type that defines the interface for all concrete Transport Request types
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="request">
 *   &lt;complexContent>
 *     &lt;extension base="{}transport">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 *
 */

public interface Request extends Transport {

}