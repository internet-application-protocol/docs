/**
 * Date Created: Aug 2, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.Transport;
import org.xml.sax.SAXException;

/**
 * Interface that defines the Transport Serializer type.  The Transport Serializer interface encodes {@link Transport}
 * objects into Fast Infoset format so that xml messaging can be accomplished efficiently.
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface TransportSerializer<T extends Transport> {
    /**
     * Serializes the object to Fast Infoset format
     */
    public void serialize() throws SAXException;

    /**
     * Returns the {@link Class} for the concrete transport that is being serialized
     *
     * @return the {@link Class} for the concrete transport that is being serialized
     */
    public T getTransport();
}