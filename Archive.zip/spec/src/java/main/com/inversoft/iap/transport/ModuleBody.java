package com.inversoft.iap.transport;

import iap.annotation.XmlElement;

/**
 * Java class for moduleBody complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="moduleBody">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="moduleData" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "moduleBody")
public class ModuleBody {

    @XmlElement(name = "moduleData")
    ModuleData moduleData;

    /**
     * Gets the value of the moduleData property.
     */
    public ModuleData getModuleData() {
        return moduleData;
    }

    /**
     * Sets the value of the moduleData property.
     */
    public void setModuleData(ModuleData value) {
        moduleData = value;
    }
}