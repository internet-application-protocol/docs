/**
 * Date Created: Aug 9, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.CloseApplicationResponse;
import org.xml.sax.Attributes;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link CloseApplicationResponse} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class CloseApplicationResponseHandler extends BaseResponseHandler<CloseApplicationResponse> {

    public CloseApplicationResponseHandler() {
        super(new CloseApplicationResponse());
    }

    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        // close application response has no concrete specific elements
    }

    protected void decodeCharacterContent(char[] ch, int start, int length) {
        // no concrete content contained in this transport
    }
}
