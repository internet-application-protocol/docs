/*
 * Copyright (c) 2003-2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport;


import com.inversoft.iap.SessionIdGenerator;
import iap.VersionNumber;
import iap.annotation.XmlElement;


/**
 * <p>
 * The Session Id is the unique Identifier part of every application. It's
 * built from the following 3 strings:
 * </p>
 *
 * <ul>
 *   <li>Application Name</li>
 *   <li>Version Number</li>
 *   <li>Unique Session Id</li>
 * </ul>
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="sessionId">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="applicationId" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="versionNumber" use="required" type="{}versionNumber" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

@XmlElement(name = "sessionId")
public final class SessionId {

    /**
     * Name of the application.  This is part of the Open Application Response
     */
    String applicationId;

    /**
     * Controlled Version Number of application
     */
    VersionNumber versionNumber;

    /**
     * Unique string Id
     */
    String stringId;

    /**
     * Constructor initializes the values of applicationId and VersionNumber
     * upon instantiation and then calls <code>generateId()</code> to build the
     * unique session Id
     *
     * @param applicationId String representation of applicatoin name
     * @param versionNumber   Object containing type checked application version
     *                        number
     */
    public SessionId(String applicationId, VersionNumber versionNumber) {
        assert (applicationId != null && versionNumber != null) : "applicationId == null && versionNumber == null";

        this.applicationId = applicationId;
        this.versionNumber = versionNumber;

        // call generate() to generate unique string Id
        generateId();
    }

    /**
     * Constructor initializes the values of applicationId, VersionNumber, and
     * sessionId upon instantiation unique session Id
     *
     * @param applicationId String representation of applicatoin name
     * @param versionNumber   Object containing type checked application version
     *                        number
     * @param stringId        string id of the sessionId
     */
    public SessionId(String applicationId, VersionNumber versionNumber,
                     String stringId) {
        this.applicationId = applicationId;
        this.versionNumber = versionNumber;
        this.stringId = stringId;
    }

    /**
     * Uses SessionIdGenerator
     */
    void generateId() {
        // get unique session Id using the current
        // time as the seed for the random generator
        this.stringId = SessionIdGenerator.getIdentifier();
    }

    /**
     * returns the applicationId
     *
     * @return applicationId
     */
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * returns the versionNumber
     *
     * @return {@link VersionNumber}
     */
    public VersionNumber getVersionNumber() {
        return versionNumber;
    }

    /**
     * returns the unique id
     *
     * @return the unique id
     */
    public String getStringId() {
        return stringId;
    }

    /**
     * Indicates whether some other SessionId object is "equal to" this one.
     *
     * @param   o the reference object with which to compare.
     * @return  <code>true</code> if this object is the same as the obj argument;
     *          <code>false</code> otherwise.
     */
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SessionId)) return false;

        final SessionId sessionId1 = (SessionId) o;

        if (!applicationId.equals(sessionId1.applicationId)) return false;
        if (!stringId.equals(sessionId1.stringId)) return false;

        return versionNumber.equals(sessionId1.versionNumber);

    }

    /**
     * Generates the hash code using the application id, version number and string id.
     *
     * @return THe hash code.
     */
    public int hashCode() {
        int result;
        result = applicationId.hashCode();
        result = 29 * result + versionNumber.hashCode();
        result = 29 * result + stringId.hashCode();
        return result;
    }
}