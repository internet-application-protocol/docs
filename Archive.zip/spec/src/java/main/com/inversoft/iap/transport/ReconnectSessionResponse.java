/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * @author James Humphrey
 * @version 1.0
 * @since IAP 1.0
 */
@XmlElement(name = "reconnectSessionResponse", isRootElement = true)
public class ReconnectSessionResponse extends BaseResponse {

    /**
     * Returns the type of response.
     */
    public TransportType getType() {
        return TransportType.RECONNECT_SESSION;
    }
}
