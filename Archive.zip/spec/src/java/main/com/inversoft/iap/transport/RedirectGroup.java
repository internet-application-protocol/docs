/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

import iap.annotation.XmlElement;
import iap.response.Redirect;

/**
 * the Redirect Group for OpenApplicationResponse Transports
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class RedirectGroup {

    @XmlElement(name = "redirect")
    Redirect redirect;

    /**
     * Returns the {@link Redirect} object
     *
     * @return the {@link Redirect}
     */
    public Redirect getRedirect() {
        return redirect;
    }

    /**
     * Sets the {@link Redirect}
     *
     * @param redirect {@link Redirect}
     */
    public void setRedirect(Redirect redirect) {
        this.redirect = redirect;
    }
}
