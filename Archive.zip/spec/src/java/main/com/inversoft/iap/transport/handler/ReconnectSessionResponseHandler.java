/**
 * Date Created: Aug 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.ReconnectSessionResponse;
import org.xml.sax.Attributes;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link ReconnectSessionResponse} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ReconnectSessionResponseHandler extends BaseResponseHandler<ReconnectSessionResponse> {

    public ReconnectSessionResponseHandler() {
        super(new ReconnectSessionResponse());
    }

    /**
     * {@inheritDoc}
     */
    protected void decodeCharacterContent(char[] ch, int start, int length) {
        // stub.  no content to parse
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        // stub.  no unique elements to parse
    }
}
