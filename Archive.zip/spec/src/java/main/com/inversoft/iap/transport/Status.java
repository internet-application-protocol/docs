package com.inversoft.iap.transport;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlContent;
import iap.annotation.XmlElement;

/**
 * Java class for status complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="status">
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *       &lt;attribute name="code" use="required" type="{}statusCode" />
 *       &lt;attribute name="sessionDuration" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "status")
public class Status {

    @XmlContent(isRequired = false)
    String value;

    @XmlAttribute()
    String code;

    @XmlAttribute(isRequired = false)
    Integer sessionDuration;

    /**
     * Gets the value of the value property.
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the value of the code property.
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     */
    public void setCode(String value) {
        code = value;
    }

    /**
     * Gets the value of the sessionDuration
     */
    public Integer getSessionDuration() {
        return sessionDuration;
    }

    /**
     * Sets the value of the sessionDuration
     */
    public void setSessionDuration(Integer sessionDuration) {
        this.sessionDuration = sessionDuration;
    }
}