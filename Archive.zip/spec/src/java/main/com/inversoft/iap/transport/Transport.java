/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

import iap.TransportType;

/**
 * <p>Java class for transport complex type that is the base interface for all concrete Transport types as
 * defined in the IAP Specification v1.0.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="transport">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface Transport {

    /**
     * Returns the {@link TransportType} enumeration associated to this Transport model object
     *
     * @return the {@link TransportType} enumeration
     */
    public TransportType getType();
}