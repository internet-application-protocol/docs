/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.SessionRequest;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

/**
 * Base abstract interface for all concrete {@link TransportSerializer} objects that serialize {@link SessionRequest}
 * objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseSessionRequestSerializer<T extends SessionRequest> extends BaseRequestSerializer<T> {

    protected BaseSessionRequestSerializer(T request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeChildren(AttributesHolder attributes) throws SAXException {
        encodeSession(attributes);
        attributes.clear();
        encodeConcrete(attributes);
    }

    /**
     * Encodes a {@link } into Fast Infoset format.  This is required for all {@link SessionRequest} Tranports
     *
     * @param attributes {@link AttributesHolder}
     */
    private void encodeSession(AttributesHolder attributes) throws SAXException {
        SessionId sessionId = getTransport().getSessionId();
        String sessionIdMapping = TransportTools.getElementName(SessionId.class);
        String applicataionIdMapping = "applicationId";
        String versionNumberMapping = "versionNumber";
        String idMapping = "id";
        attributes.addAttribute(new QualifiedName("", "", applicataionIdMapping, applicataionIdMapping), sessionId.getApplicationId());
        attributes.addAttribute(new QualifiedName("", "", versionNumberMapping, versionNumberMapping), sessionId.getVersionNumber().toString());
        attributes.addAttribute(new QualifiedName("", "", idMapping, idMapping), sessionId.getStringId());
        startElement("", sessionIdMapping, sessionIdMapping, attributes);
        endElement("", sessionIdMapping, sessionIdMapping);
    }
}