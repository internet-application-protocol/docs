/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

import java.util.ArrayList;
import java.util.List;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}response">
 *       &lt;sequence>
 *         &lt;element name="application" type="{}application" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "metaDataResponse", isRootElement = true)
public class MetaDataResponse extends BaseResponse {

    @XmlElement(name = "application", isRequired = false)
    List<Application> application = new ArrayList<Application>();

    /**
     * Gets the value of the application property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the application property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getApplications().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Application}
     *
     *
     */
    public List<Application> getApplications() {
        return this.application;
    }

    /**
     * {@inheritDoc}
     */
    public TransportType getType() {
        return TransportType.METADATA;
    }
}