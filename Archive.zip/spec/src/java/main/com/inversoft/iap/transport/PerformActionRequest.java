package com.inversoft.iap.transport;

import com.inversoft.iap.DataBody;
import iap.TransportType;
import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}sessionRequest">
 *       &lt;sequence>
 *         &lt;element name="viewInfo" type="{}viewInfo"/>
 *         &lt;element name="actionInfo" type="{}actionInfo"/>
 *         &lt;element name="dataBody" type="{}dataBody"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "performActionRequest", isRootElement = true)
public class PerformActionRequest extends SessionRequest {

    @XmlElement(name = "ViewInfo")
    ViewInfo viewInfo;

    @XmlElement(name = "actionInfo")
    ActionInfo actionInfo;

    @XmlAttribute(isRequired = false)
    DataBody dataBody;

    /**
     * Returns the type of request.
     */
    public TransportType getType() {
        return TransportType.PERFORM_ACTION;
    }

    /**
     * Gets the value of the viewInfo property.
     */
    public ViewInfo getViewInfo() {
        return viewInfo;
    }

    /**
     * Sets the value of the viewInfo property.
     */
    public void setViewInfo(ViewInfo value) {
        viewInfo = value;
    }

    /**
     * Gets the value of the actionInfo property.
     */
    public ActionInfo getActionInfo() {
        return actionInfo;
    }

    /**
     * Sets the value of the actionInfo property.
     */
    public void setActionInfo(ActionInfo value) {
        actionInfo = value;
    }

    /**
     * Gets the value of the dataBody property.
     */
    public DataBody getDataBody() {
        return dataBody;
    }

    /**
     * Sets the value of the dataBody property.
     */
    public void setDataBody(DataBody value) {
        dataBody = value;
    }
}