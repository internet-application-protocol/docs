/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

import iap.annotation.XmlElement;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class SuccessGroup {

    @XmlElement(name = "applicationDescription")
    ApplicationDescription applicationDescription;

    @XmlElement(name = "applicationRef")
    ApplicationSpec applicationRef;

    @XmlElement(name = "ratingInfo")
    RatingInfo ratingInfo;

    @XmlElement(name = "sessionId")
    SessionId sessionId;

    @XmlElement(name = "viewInfo")
    ViewInfo viewInfo;

    public ApplicationDescription getApplicationDescription() {
        return applicationDescription;
    }

    public void setApplicationDescription(ApplicationDescription applicationDescription) {
        this.applicationDescription = applicationDescription;
    }

    public ApplicationSpec getApplicationRef() {
        return applicationRef;
    }

    public void setApplicationRef(ApplicationSpec applicationRef) {
        this.applicationRef = applicationRef;
    }

    public RatingInfo getRatingInfo() {
        return ratingInfo;
    }

    public void setRatingInfo(RatingInfo ratingInfo) {
        this.ratingInfo = ratingInfo;
    }

    public SessionId getSessionId() {
        return sessionId;
    }

    public void setSessionId(SessionId sessionId) {
        this.sessionId = sessionId;
    }

    public ViewInfo getViewInfo() {
        return viewInfo;
    }

    public void setViewInfo(ViewInfo viewInfo) {
        this.viewInfo = viewInfo;
    }
}
