/**
 * Date Created: Aug 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

import java.net.MalformedURLException;
import java.net.URL;

import com.inversoft.iap.transport.ApplicationDescription;
import com.inversoft.iap.transport.ApplicationSpec;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.RatingInfo;
import com.inversoft.iap.transport.RedirectGroup;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.SuccessGroup;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.iap.transport.util.TransportTools;
import iap.VersionNumber;
import iap.response.Rating;
import iap.response.Redirect;
import org.xml.sax.Attributes;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link OpenApplicationResponse} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OpenApplicationResponseHandler extends BaseResponseHandler<OpenApplicationResponse> {

    boolean redirecting = false;

    SuccessGroup sGroup = new SuccessGroup();

    RedirectGroup rGroup = new RedirectGroup();

    public OpenApplicationResponseHandler() {
        super(new OpenApplicationResponse());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(ApplicationDescription.class))) {
            ApplicationDescription appDesc = new ApplicationDescription();
            appDesc.setIsCacheable(new Boolean(attributes.getValue("isCacheable")).booleanValue());
            sGroup.setApplicationDescription(appDesc);
        } else if (qName.equals(TransportTools.getElementName(ApplicationSpec.class))) {
            ApplicationSpec appRef = new ApplicationSpec();
            appRef.setApplicationSpec(attributes.getValue("applicationSpec"));
            sGroup.setApplicationRef(appRef);
        } else if (qName.equals(TransportTools.getElementName(RatingInfo.class))) {
            RatingInfo ratingInfo = new RatingInfo();
            ratingInfo.setRating(Rating.valueOf(attributes.getValue("rating")));
            sGroup.setRatingInfo(ratingInfo);
        } else if (qName.equals(TransportTools.getElementName(SessionId.class))) {
            String applicationId = attributes.getValue("applicationId");
            VersionNumber versionNumber = VersionNumber.decode(attributes.getValue("versionNumber"));
            String id = attributes.getValue("id");
            SessionId sessionId = new SessionId(applicationId, versionNumber, id);
            sGroup.setSessionId(sessionId);
        } else if (qName.equals(TransportTools.getElementName(ViewInfo.class))) {
            ViewInfo viewInfo = new ViewInfo();
            viewInfo.setViewId(attributes.getValue("viewId"));
            sGroup.setViewInfo(viewInfo);
        } else if (qName.equals(TransportTools.getElementName(Redirect.class))) {
            try {
                URL url = new URL(attributes.getValue("applicationSpec"));
                Redirect redirect = new Redirect(url);
                rGroup.setRedirect(redirect);
                redirecting = true;
            } catch (MalformedURLException e) {
                throw new TransportValidationException(e.getMessage());
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @ Override
    public OpenApplicationResponse getTransport() {
        OpenApplicationResponse response = super.getTransport();
        if (redirecting) {
            response.setRedirectGroup(rGroup);
        } else {
            response.setSuccessGroup(sGroup);
        }

        return response;
    }

    /**
     * {@inheritDoc}
     */
    protected void decodeCharacterContent(char[] ch, int start, int length) {
        // stub.  No content in this transport
    }
}
