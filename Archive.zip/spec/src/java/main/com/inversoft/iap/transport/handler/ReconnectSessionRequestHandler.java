/**
 * Date Created: Aug 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.ClientCredentials;
import com.inversoft.iap.transport.Certificate;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import iap.VersionNumber;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link ReconnectSessionRequest} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ReconnectSessionRequestHandler extends BaseSessionRequestHandler<ReconnectSessionRequest> {

    public ReconnectSessionRequestHandler() {
        super(new ReconnectSessionRequest());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(ClientCredentials.class))) {
            ClientCredentials clientCredentials = new ClientCredentials();
            getTransport().setClientCredentials(clientCredentials);
            setParentElement(ClientCredentials.class);
        } else if (qName.equals(TransportTools.getElementName(Certificate.class))) {
            Certificate certificate = new Certificate();
            certificate.setDateCreated(XMLGregorianCalendarImpl.parse(attributes.getValue("dateCreated")));
            certificate.setDateExpires(XMLGregorianCalendarImpl.parse(attributes.getValue("dateExpires")));
            getTransport().getClientCredentials().setCertificate(certificate);
            setParentElement(Certificate.class);
        } else if (qName.equals(TransportTools.getElementName(SessionId.class))) {
            String applicationId = attributes.getValue("applicationId");
            VersionNumber versionNumber = VersionNumber.decode(attributes.getValue("versionNumber"));
            String id = attributes.getValue("id");
            SessionId sessionId = new SessionId(applicationId, versionNumber, id);
            getTransport().getClientCredentials().setSessionId(sessionId);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void characters(char ch[], int start, int length) throws SAXException {
        String value = new String(ch, start, length);
        if (getParentElement().equals(Certificate.class)) {
            getTransport().getClientCredentials().getCertificate().setValue(value);
        }
    }
}
