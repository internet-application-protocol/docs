/**
 * Date Created: Aug 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.PerformActionResponse;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link PerformActionResponse} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class PerformActionResponseSerializer extends BaseResponseSerializer<PerformActionResponse> {

    public PerformActionResponseSerializer(PerformActionResponse transport) {
        super(transport);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // serialize dataBody
        encodeData(getTransport().getDataBody(), attributes);
    }
}
