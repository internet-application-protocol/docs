package com.inversoft.iap.transport;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for applicationSpec complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="applicationSpec">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="applicationSpec" use="required" type="{http://www.w3.org/2001/XMLSchema}anyURI" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "applicationRef")
public class ApplicationSpec {

    @XmlAttribute()
    String applicationSpec;

    /**
     * Gets the value of the applicationSpec property.
     *
     * @return The application spec for a the client to open or redirect to.
     */
    public String getApplicationSpec() {
        return applicationSpec;
    }

    /**
     * Sets the value of the applicationSpec property.
     *
     * @param value The application spec.
     */
    public void setApplicationSpec(String value) {
        this.applicationSpec = value;
    }
}