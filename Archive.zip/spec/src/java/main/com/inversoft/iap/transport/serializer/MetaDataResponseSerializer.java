/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.serializer;

import java.util.List;

import com.inversoft.iap.request.VersionSpecification;
import com.inversoft.iap.transport.Application;
import com.inversoft.iap.transport.Description;
import com.inversoft.iap.transport.Keyword;
import com.inversoft.iap.transport.MetaData;
import com.inversoft.iap.transport.MetaDataResponse;
import com.inversoft.iap.transport.util.TransportTools;
import com.inversoft.util.StringTools;
import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import iap.VersionNumber;
import iap.request.DeviceType;
import iap.response.Rating;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link MetaDataResponse} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MetaDataResponseSerializer extends BaseResponseSerializer<MetaDataResponse> {

    public MetaDataResponseSerializer(MetaDataResponse transport) {
        super(transport);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // set the applications
        List<Application> applications = getTransport().getApplications();
        String applicationMapping = "application";
        for (Application application : applications) {
            String name = application.getName();
            String nameMapping = "name";
            VersionNumber versionNumber = application.getVersionNumber();
            String versionNumberMapping = "versionNumber";
            DeviceType deviceType = application.getDeviceType();
            String deviceTypeMapping = "deviceType";
            Rating rating = application.getRating();
            String ratingMapping = "rating";
            VersionSpecification versionSpecification = application.getVersionSpecification();
            String vsMapping = "versionSpecification";
            attributes.addAttribute(new QualifiedName("", "", nameMapping, nameMapping), name);
            attributes.addAttribute(new QualifiedName("", "", versionNumberMapping, versionNumberMapping),
                    versionNumber.toString());
            attributes.addAttribute(new QualifiedName("", "", deviceTypeMapping, deviceTypeMapping),
                    deviceType.toString());
            attributes.addAttribute(new QualifiedName("", "", ratingMapping, ratingMapping),
                    rating.toString());
            attributes.addAttribute(new QualifiedName("", "", vsMapping, vsMapping),
                    versionSpecification.toString());

            // start the application element
            startElement("", applicationMapping, applicationMapping, attributes);
            attributes.clear();

            // set the description
            if (application.getDescription() != null) {
                String descriptionMapping = TransportTools.getElementName(Description.class);
                startElement("", descriptionMapping, descriptionMapping, attributes);
                char[] c = application.getDescription().getValue().toCharArray();
                characters(c, 0, c.length);
                endElement("", descriptionMapping, descriptionMapping);
            }
            attributes.clear();

            // set the keywords
            if (application.getKeywords() != null && !application.getKeywords().isEmpty()) {
                List<Keyword> keywords = application.getKeywords();
                for (Keyword keyword : keywords) {
                    if (!StringTools.isEmpty(keyword.getValue())) {
                        String keywordMapping = TransportTools.getElementName(Keyword.class);
                        startElement("", keywordMapping, keywordMapping, attributes);
                        char[] c = keyword.getValue().toCharArray();
                        characters(c, 0, c.length);
                        endElement("", keywordMapping, keywordMapping);
                    }
                    attributes.clear();
                }
            }

            // set the metadata
            if (application.getMetaData() != null && !application.getMetaData().isEmpty()) {
                List<MetaData> metaDataList = application.getMetaData();
                for (MetaData metaData : metaDataList) {
                    String metadataMapping = TransportTools.getElementName(MetaData.class);
                    String valueMapping = "value";
                    attributes.addAttribute(new QualifiedName("", "", nameMapping, nameMapping),
                            metaData.getName());
                    attributes.addAttribute(new QualifiedName("", "", valueMapping, valueMapping),
                            metaData.getValue());
                    startElement("", metadataMapping, metadataMapping, attributes);
                    endElement("", metadataMapping, metadataMapping);
                    attributes.clear();
                }
            }
            attributes.clear();
            
            // end the application element
            endElement("", applicationMapping, applicationMapping);
        }
    }
}
