/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.handler;

import java.nio.ByteBuffer;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.OpenViewResponse;
import com.inversoft.iap.transport.ViewBody;
import com.inversoft.iap.transport.ViewData;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link OpenViewResponse} object
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class OpenViewResponseHandler extends BaseResponseHandler<OpenViewResponse> {

    public OpenViewResponseHandler() {
        super(new OpenViewResponse());
    }

    /**
     * {@inheritDoc}
     */
    public void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(ViewBody.class))) {
            ViewBody viewBody = new ViewBody();
            getTransport().setViewBody(viewBody);
        } else if (qName.equals(TransportTools.getElementName(ViewData.class))) {
            ViewData viewData = new ViewData();
            viewData.setContentLength(Integer.parseInt(attributes.getValue("contentLength")));
            viewData.setContentType(attributes.getValue("contentType"));
            getTransport().getViewBody().setViewData(viewData);
        }
    }

    /**
     * {@inheritDoc}
     */
    protected void decodeCharacterContent(char[] ch, int start, int length) {
        // stub. no content
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void bytes(byte[] b, int start, int length) throws SAXException {
        ViewData vd = getTransport().getViewBody().getViewData();
        ByteBuffer value = vd.getValue();
        if (value == null) {
            value = ByteBuffer.allocate(length);
            value.put(b, start, length);
            value.flip();
        } else {
            ByteBuffer fresh = ByteBuffer.allocate(length + value.capacity());
            fresh.put(value);
            fresh.put(b, start, length);
            fresh.flip();
            value = fresh;
        }

        vd.setValue(value);
    }
}