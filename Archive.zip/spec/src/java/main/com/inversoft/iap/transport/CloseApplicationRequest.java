package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}sessionRequest">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "closeApplicationRequest", isRootElement = true)
public class CloseApplicationRequest extends SessionRequest {

    /**
     * Returns the type of request.
     */
    public TransportType getType() {
        return TransportType.CLOSE_APPLICATION;
    }
}