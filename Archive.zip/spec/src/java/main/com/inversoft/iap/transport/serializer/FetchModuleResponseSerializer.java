/**
 * Copyright (c) 2005, Inversoft LLC, All Rights Reserved
 */
package com.inversoft.iap.transport.serializer;

import java.nio.ByteBuffer;

import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.FetchModuleResponse;
import com.inversoft.iap.transport.ModuleBody;
import com.inversoft.iap.transport.ModuleData;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Concrete {@link TransportSerializer} to encode {@link FetchModuleResponse}
 * objects to Fast Infoset format.
 *
 * @author  James Humphrey (humphjj)
 * @version 1.0
 */
public class FetchModuleResponseSerializer extends BaseResponseSerializer<FetchModuleResponse> {

    public FetchModuleResponseSerializer(FetchModuleResponse transport) {
        super(transport);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // set the view body
        ModuleBody moduleBody = getTransport().getModuleBody();
        if (moduleBody != null) {
            ModuleData moduleData = moduleBody.getModuleData();
            String moduleBodyMapping = TransportTools.getElementName(ModuleBody.class);
            String moduleDataMapping = TransportTools.getElementName(ModuleData.class);

            startElement("", moduleBodyMapping, moduleBodyMapping, attributes);
            startElement("", moduleDataMapping, moduleDataMapping, attributes);
            ByteBuffer data = moduleData.getData();
            if (data == null) {
                transmitStream(moduleData.getValueStream());
            } else {
                transmitData(data);
            }
            bytes(data.array(), 0, data.capacity());
            endElement("", moduleDataMapping, moduleDataMapping);
            endElement("", moduleDataMapping, moduleDataMapping);
        }
    }
}