/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.handler;

import java.nio.ByteBuffer;

import iap.response.DataScope;
import org.jvnet.fastinfoset.sax.FastInfosetDefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataType;
import com.inversoft.iap.transport.Transport;
import com.inversoft.iap.transport.TransportValidator;
import com.inversoft.iap.transport.util.DataBinaryDecoder;

/**
 * Base abstract interface that provides a base implementation for all {@link TransportHandler} sub-classes
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseTransportHandler<T extends Transport> extends FastInfosetDefaultHandler
        implements TransportHandler<T> {
    private T transport;
    private boolean validatingTransport = false;
    private DataBean dataBean;

    /**
     * Represents the class name of the element currently being parsed
     */
    private Class<?> parentElement;

    /**
     * Base constructor that initializes the {@link Transport} for this instance
     *
     * @param transport {@link Transport}
     */
    protected BaseTransportHandler(T transport) {
        this.transport = transport;

        // default the parentElement root element's class name
        parentElement = transport.getClass();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        parseElement(uri, localName, qName, attributes);
    }

    /**
     * Implemented by sub-classes to parse individual elements.
     *
     * @param uri the namespace uri
     * @param localName the localname
     * @param qName the qualified name including namespace prefix
     * @param attributes {@link Attributes}
     */
    protected abstract void parseElement(String uri, String localName, String qName, Attributes attributes);

    /**
     * {@inheritDoc}
     */
    public T getTransport() {
        return transport;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void endDocument() throws SAXException {
        if (validatingTransport) {
            TransportValidator.validate(getTransport());
        }
    }

    /**
     * Adds a new {@link DataBean} object to the list of data beans
     *
     * @param attributes {@link org.xml.sax.Attributes}
     */
    protected void addNewDataBean(Attributes attributes) {
        int arrayDepth = Integer.parseInt(attributes.getValue("arrayDepth"));
        String key = attributes.getValue("name");
        DataScope scope = DataScope.valueOf(attributes.getValue("scope"));
        DataType type = DataType.valueOf(attributes.getValue("type"));

        dataBean = new DataBean(key, arrayDepth, scope, type);
    }

    /**
     * Adds the bytes from the given array into the current data bean's ByteBuffer.
     */
    protected void addData(byte[] b, int start, int length) {
        byte[] t = new byte[length];
        System.arraycopy(b, start, t, 0, length);
        if (dataBean.data == null) {
            dataBean.data = ByteBuffer.wrap(t);
        } else {
            ByteBuffer fresh = ByteBuffer.allocate(dataBean.data.capacity() + length);
            fresh.put(dataBean.data);
            fresh.put(t);
            fresh.flip();
            dataBean.data = fresh;
        }
    }

    /**
     * Called to decode a data value
     */
    protected Data decodeDataValue() {
        assert (dataBean != null) : "DataBean must not be null";

        // get the last bean in the list
        DataBinaryDecoder decoder = new DataBinaryDecoder(dataBean.dataType);
        Object value = decoder.decode(dataBean.data).second;
        Data data = new Data(dataBean.key, value, dataBean.dataType, dataBean.arrayDepth, dataBean.dataScope);
        dataBean = null;
        return data;
    }

    /**
     * True if validating transport, false otherwise
     *
     * @return true if validating transport, false otherwise
     */
    public boolean validatingTransport() {
        return validatingTransport;
    }

    /**
     * set to true of transport validation is required.  Default is falise.
     *
     * @param validatingTransport
     */
    public void setValidatingTransport(boolean validatingTransport) {
        this.validatingTransport = validatingTransport;
    }

    /**
     * gets the element currently being parsed
     *
     * @return the current element being parsed
     */
    public Class<?> getParentElement() {
        return parentElement;
    }

    /**
     * Sets the class of the current element being parsed
     *
     * @param parentElement the element being parsed
     */
    public void setParentElement(Class<?> parentElement) {
        this.parentElement = parentElement;
    }

    /**
     * Immutable Bean to hold {@link com.inversoft.iap.Data} attributes during Fast Infoset
     * Handler Data decoding. All attributes except the value are stored
     */
    public static class DataBean {
        public String key;
        public int arrayDepth;
        public DataScope dataScope;
        public DataType dataType;
        public ByteBuffer data;

        public DataBean(String key, int arrayDepth, DataScope dataScope, DataType dataType) {
            this.key = key;
            this.arrayDepth = arrayDepth;
            this.dataScope = dataScope;
            this.dataType = dataType;
        }
    }
}