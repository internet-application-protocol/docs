/**
 * Date Created: Aug 2, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import java.nio.ByteBuffer;

import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.OpenViewResponse;
import com.inversoft.iap.transport.ViewBody;
import com.inversoft.iap.transport.ViewData;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Concrete {@link TransportSerializer} to encode {@link OpenViewResponse} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OpenViewResponseSerializer extends BaseResponseSerializer<OpenViewResponse> {

    public OpenViewResponseSerializer(OpenViewResponse response) {
        super(response);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // set the view body
        ViewBody viewBody = getTransport().getViewBody();
        String viewBodyMapping = TransportTools.getElementName(ViewBody.class);
        String viewDataMapping = TransportTools.getElementName(ViewData.class);
        String contentLengthMapping = "contentLength";
        String contentTypeMapping = "contentType";

        startElement("", viewBodyMapping, viewBodyMapping, attributes);
        // set the view data
        ViewData viewData = viewBody.getViewData();
        attributes.addAttribute(new QualifiedName("", "", contentLengthMapping, contentLengthMapping),
                Long.toString(viewBody.getViewData().getContentLength()));
        attributes.addAttribute(new QualifiedName("", "", contentTypeMapping, contentTypeMapping),
                viewData.getContentType());
        startElement("", viewDataMapping, viewDataMapping, attributes);
        ByteBuffer data = viewData.getValue();
        if (data == null) {
            transmitStream(viewData.getValueStream());
        } else {
            transmitData(data);
        }

        endElement("", viewDataMapping, viewDataMapping);
        endElement("", viewBodyMapping, viewBodyMapping);
    }
}