/**
 * Date Created: Aug 10, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport;

import java.lang.reflect.Field;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlContent;
import iap.annotation.XmlElement;

import com.inversoft.iap.transport.handler.TransportValidationException;

/**
 * <p>Validates all class fields that are annotated with the following:</p>
 * <ul>
 *      <li>{@link XmlElement}</li>
 *      <li>{@link XmlContent}</li>
 *      <li>{@link XmlAttribute}</li>
 * </ul>
 * <p>This happens through a reflection process by iterating through all class and superclass fields.
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */
public class TransportValidator {
    private static final Logger logger = Logger.getLogger(TransportValidator.class.getName());

    /**
     * Static method to validate an object
     *
     * @param object
     */
    public static void validate(Object object) {
        validate(object, object.getClass());
    }

    /**
     * Static method to validate
     *
     * @param objectToValidate
     */
    private static void validate(Object objectToValidate, Class aClass) {
        Field[] fields = aClass.getDeclaredFields();

        // if the object being validated has a super class (and it's not Object), then recurse into the super class
        // to check it's member fields
        Class superClass = aClass.getSuperclass();
        if (superClass != null && !superClass.equals(Object.class)) {
            validate(objectToValidate, superClass);
        }

        if (logger.isLoggable(Level.FINEST)) {
            logger.finest("Checking [" + aClass.getCanonicalName() + "] for any fields that require validation");
        }

        for (Field field : fields) {
            try {
                String qFieldName = field.getDeclaringClass().getCanonicalName() + "." + field.getName();
                Object aFieldObject = field.get(objectToValidate);

                if (field.getAnnotation(XmlElement.class) != null) {
                    validateElement(field, aFieldObject, qFieldName);
                } else if (field.getAnnotation(XmlAttribute.class) != null) {
                    validateAttribute(field, aFieldObject, qFieldName);
                } else if (field.getAnnotation(XmlContent.class) != null) {
                    validateContent(field, aFieldObject, qFieldName);
                }
            } catch (IllegalAccessException e) {
                logger.log(Level.WARNING, "Unable to access value [" + e + "]");
            }
        }
    }

    /**
     * Validates content
     *
     * @param field
     * @param aFieldObject
     * @param qFieldName
     */
    private static void validateContent(Field field, Object aFieldObject, String qFieldName) {
        boolean required = field.getAnnotation(XmlContent.class).isRequired();

        if (logger.isLoggable(Level.FINEST)) {
            logger.finest("\tfound content field [" + field.getName() + "]");
        }

        if (required) {
            logger.finest("...validating");
            // process null case
            if (aFieldObject == null) {
                throw new TransportValidationException(qFieldName + " == null");
            }
        } else {
            logger.finest("...not required");
        }
    }

    /**
     * Valies attributes
     *
     * @param field
     * @param aFieldObject
     * @param qFieldName
     */
    private static void validateAttribute(Field field, Object aFieldObject, String qFieldName) {
        boolean required = field.getAnnotation(XmlAttribute.class).isRequired();

        if (logger.isLoggable(Level.FINEST)) {
            logger.finest("\tfound attribute field [" + field.getName() + "]");
        }

        if (required) {
            logger.finest("...required and validating");
            // process null case
            if (aFieldObject == null) {
                throw new TransportValidationException(qFieldName + " == null");
            }

            // process String case
            if (aFieldObject instanceof String && aFieldObject.equals("")) {
                throw new TransportValidationException(qFieldName + " == empty string");
            }
        } else {
            if (aFieldObject != null) {
                logger.finest("...not required but not null so validating");
                validate(aFieldObject);
            } else {
                logger.finest("...not required");
            }
        }
    }

    /**
     * Validates Elements
     *
     * @param field
     * @param aFieldObject
     * @param qFieldName
     */
    private static void validateElement(Field field, Object aFieldObject, String qFieldName) {
        boolean required = field.getAnnotation(XmlElement.class).isRequired();

        if (logger.isLoggable(Level.FINEST)) {
            logger.finest("\tfound element field [" + field.getName() + "]");
        }

        if (!required) {
            if (aFieldObject != null) {
                logger.finest("...not required but not null so validating.");
                if (aFieldObject instanceof List) {
                    List someObjects = (List) aFieldObject;
                    for (Object someObject : someObjects) {
                        validate(someObject, someObject.getClass());
                    }
                } else {
                    validate(aFieldObject, aFieldObject.getClass());
                }
            } else {
                logger.finest("...not required");
            }
        } else {
            logger.finest("...validating");
            if (aFieldObject == null) {
                throw new TransportValidationException(qFieldName + " == null");
            } else {
                if (aFieldObject instanceof List) {
                    List someObjects = (List) aFieldObject;
                    if (someObjects.isEmpty()) {
                        throw new TransportValidationException(qFieldName + " is empty set");
                    } else {
                        for (Object someObject : someObjects) {
                            TransportValidator.validate(someObject, someObject.getClass());
                        }
                    }
                } else {
                    validate(aFieldObject, aFieldObject.getClass());
                }
            }
        }
    }
}
