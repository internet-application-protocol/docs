package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}sessionRequest">
 *       &lt;sequence>
 *         &lt;element name="moduleInfo" type="{}moduleInfo"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "fetchModuleRequest", isRootElement = true)
public class FetchModuleRequest extends SessionRequest {

    @XmlAttribute()
    ModuleInfo moduleInfo;

    /**
     * Returns the type of request.
     */
    public TransportType getType() {
        return TransportType.FETCH_MODULE;
    }

    /**
     * Gets the value of the moduleInfo property.
     */
    public ModuleInfo getModuleInfo() {
        return moduleInfo;
    }

    /**
     * Sets the value of the moduleInfo property.
     */
    public void setModuleInfo(ModuleInfo value) {
        moduleInfo = value;
    }
}