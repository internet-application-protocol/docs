package com.inversoft.iap.transport;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for applicationDescription complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="applicationDescription">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="isCacheable" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "applicationDescription")
public class ApplicationDescription {

    @XmlAttribute()
    Boolean isCacheable;

    /**
     * Gets the value of the isCacheable property.
     */
    public boolean isIsCacheable() {
        return isCacheable;
    }

    /**
     * Sets the value of the isCacheable property.
     */
    public void setIsCacheable(boolean value) {
        this.isCacheable = value;
    }
}