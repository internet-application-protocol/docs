/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.AuthenticateUserRequest;
import com.inversoft.iap.transport.AuthenticateUserResponse;
import com.inversoft.iap.transport.CloseApplicationRequest;
import com.inversoft.iap.transport.CloseApplicationResponse;
import com.inversoft.iap.transport.FetchDataRequest;
import com.inversoft.iap.transport.FetchDataResponse;
import com.inversoft.iap.transport.FetchModuleRequest;
import com.inversoft.iap.transport.FetchModuleResponse;
import com.inversoft.iap.transport.MetaDataRequest;
import com.inversoft.iap.transport.MetaDataResponse;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.OpenViewRequest;
import com.inversoft.iap.transport.OpenViewResponse;
import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.PerformActionRequest;
import com.inversoft.iap.transport.PerformActionResponse;
import com.inversoft.iap.transport.ReconnectSessionResponse;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.xml.fastinfoset.sax.SAXDocumentParser;
import org.jvnet.fastinfoset.sax.FastInfosetDefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * <p>
 * A {@link FastInfosetDefaultHandler} that delegates to a concrete {@link TransportHandler} to handle incoming
 * Fast Infoset Transport message content and decode it into a {@link com.inversoft.iap.transport.Transport} object.
 * </p>
 *
 * <p>
 * This delegates by determining the root element name, which is annotated on each concrete
 * {@link com.inversoft.iap.transport.Transport} object
 * </p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TransportHandlerDelegator extends FastInfosetDefaultHandler {

    private SAXDocumentParser parser;

    private TransportHandler handler;

    private boolean validatingTransport;

    public TransportHandlerDelegator(SAXDocumentParser parser, boolean validateTransport) {
        this.parser = parser;
        this.validatingTransport = validateTransport;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (qName.equals(TransportTools.getElementName(AuthenticateUserRequest.class))) {
            handler = new AuthenticateUserRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(AuthenticateUserResponse.class))) {
            handler = new AuthenticateUserResponseHandler();
        } else if (qName.equals(TransportTools.getElementName(CloseApplicationRequest.class))) {
            handler = new CloseApplicationRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(CloseApplicationResponse.class))) {
            handler = new CloseApplicationResponseHandler();
        } else if (qName.equals(TransportTools.getElementName(FetchDataRequest.class))) {
            handler = new FetchDataRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(FetchDataResponse.class))) {
            handler = new FetchDataResponseHandler();
        } else if (qName.equals(TransportTools.getElementName(FetchModuleRequest.class))) {
            handler = new FetchModuleRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(FetchModuleResponse.class))) {
            handler = new FetchModuleResponseHandler();
        } else if (qName.equals(TransportTools.getElementName(MetaDataRequest.class))) {
            handler = new MetaDataRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(MetaDataResponse.class))) {
            handler = new MetaDataResponseHandler();
        } else if (qName.equals(TransportTools.getElementName(OpenApplicationRequest.class))) {
            handler = new OpenApplicationRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(OpenApplicationResponse.class))) {
            handler = new OpenApplicationResponseHandler();
        } else if (qName.equals(TransportTools.getElementName(OpenViewResponse.class))) {
            handler = new OpenViewResponseHandler();
        } else if (qName.equals(TransportTools.getElementName(OpenViewRequest.class))) {
            handler = new OpenViewRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(PerformActionRequest.class))) {
            handler = new PerformActionRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(PerformActionResponse.class))) {
            handler = new PerformActionResponseHandler();
        }else if (qName.equals(TransportTools.getElementName(ReconnectSessionRequest.class))) {
            handler = new ReconnectSessionRequestHandler();
        } else if (qName.equals(TransportTools.getElementName(ReconnectSessionResponse.class))) {
            handler = new ReconnectSessionResponseHandler();
        } else {
            // this should only ever throw during testing
            throw new SAXException("No handler defined for [" + qName + "]");
        }

        // if transport validation is required set appropriately
        if (validatingTransport) {
            handler.setValidatingTransport(true);
        }

        // reset the SAXDocumentParser content handler and primitive content handler to the delegate
        parser.setContentHandler(handler);
        parser.setPrimitiveTypeContentHandler(handler);
    }

    /**
     * Returns the {@link TransportHandler} delegated to by this instance
     *
     * @return the {@link TransportHandler} delegated by this instance
     */
    public TransportHandler getDelegateHandler() {
        return handler;
    }
}