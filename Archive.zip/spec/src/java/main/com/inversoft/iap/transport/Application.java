/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport;

import java.util.ArrayList;
import java.util.List;

import com.inversoft.iap.request.VersionSpecification;
import iap.VersionNumber;
import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;
import iap.request.DeviceType;
import iap.response.Rating;

/**
 * Java class for application complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="application">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="keywords" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="metaData" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{}baseParam">
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="deviceType" use="required" type="{}deviceType" />
 *       &lt;attribute name="name" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="rating" use="required" type="{}ratingType" />
 *       &lt;attribute name="versionNumber" use="required" type="{}versionNumber" />
 *       &lt;attribute name="versionSpecification" use="required" type="{}versionSpecification" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "application", isRequired = false)
public class Application {

    @XmlAttribute()
    DeviceType deviceType;

    @XmlAttribute()
    String name;

    @XmlAttribute()
    Rating rating;

    @XmlAttribute()
    VersionNumber versionNumber;

    @XmlAttribute()
    VersionSpecification versionSpecification;

    @XmlElement(name = "description", isRequired = false)
    Description description;

    @XmlElement(name = "keyword", isRequired = false)
    List<Keyword> keywords = new ArrayList<Keyword>();

    @XmlElement(name = "metaData", isRequired = false)
    List<MetaData> metaData = new ArrayList<MetaData>();

    /**
     * Gets the value of the description property.
     */
    public Description getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     */
    public void setDescription(Description value) {
        this.description = value;
    }

    /**
     * Gets the value of the keywords property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keywords property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeywords().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     *
     *
     */
    public List<Keyword> getKeywords() {
        return this.keywords;
    }

    /**
     * Gets the value of the metaData property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the metaData property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMetaData().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String}
     *
     *
     */
    public List<MetaData> getMetaData() {
        return this.metaData;
    }

    /**
     * Gets the value of the deviceType property.
     */
    public DeviceType getDeviceType() {
        return deviceType;
    }

    /**
     * Sets the value of the deviceType property.
     */
    public void setDeviceType(DeviceType value) {
        this.deviceType = value;
    }

    /**
     * Gets the value of the name property.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the rating property.
     */
    public Rating getRating() {
        return rating;
    }

    /**
     * Sets the value of the rating property.
     */
    public void setRating(Rating value) {
        this.rating = value;
    }

    /**
     * Gets the value of the versionNumber property.
     */
    public VersionNumber getVersionNumber() {
        return versionNumber;
    }

    /**
     * Sets the value of the versionNumber property.
     */
    public void setVersionNumber(VersionNumber value) {
        this.versionNumber = value;
    }

    /**
     * Gets the value of the versionSpecification property.
     */
    public VersionSpecification getVersionSpecification() {
        return versionSpecification;
    }

    /**
     * Sets the value of the versionSpecification property.
     */
    public void setVersionSpecification(VersionSpecification value) {
        this.versionSpecification = value;
    }
}