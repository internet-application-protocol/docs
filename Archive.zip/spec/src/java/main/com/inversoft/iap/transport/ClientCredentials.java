package com.inversoft.iap.transport;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for clientCredentials complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="clientCredentials">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="certificate" type="{}certificate"/>
 *         &lt;element name="sessionId" type="{}sessionId"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "clientCredentials")
public class ClientCredentials {

    @XmlAttribute(isRequired = false)
    Certificate certificate;

    @XmlAttribute(isRequired = false)
    SessionId sessionId;

    /**
     * Gets the value of the certificate property.
     */
    public Certificate getCertificate() {
        return certificate;
    }

    /**
     * Sets the value of the certificate property.
     */
    public void setCertificate(Certificate value) {
        certificate = value;
    }

    /**
     * Gets the value of the sessionId property.
     */
    public SessionId getSessionId() {
        return sessionId;
    }

    /**
     * Sets the value of the sessionId property.
     */
    public void setSessionId(SessionId value) {
        sessionId = value;
    }
}