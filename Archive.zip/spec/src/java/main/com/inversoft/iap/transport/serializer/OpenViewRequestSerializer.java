/**
 * Date Created: Aug 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.OpenViewRequest;
import com.inversoft.iap.transport.ViewBody;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.iap.transport.ClientConstraint;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import com.sun.xml.fastinfoset.QualifiedName;
import org.xml.sax.SAXException;
import iap.Size;
import iap.Coord;

/**
 * Concrete {@link TransportSerializer} to encode {@link OpenViewRequest} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OpenViewRequestSerializer extends BaseSessionRequestSerializer<OpenViewRequest> {

    public OpenViewRequestSerializer(OpenViewRequest request) {
        super(request);
    }

    /**
     * {@inheritDoc}
     */
    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        ViewInfo viewInfo = getTransport().getViewInfo();
        String viewInfoMapping = TransportTools.getElementName(ViewInfo.class);
        String viewIdMapping = "viewId";
        attributes.addAttribute(new QualifiedName("", "", viewIdMapping, viewIdMapping),
                viewInfo.getViewId());
        startElement("", viewInfoMapping, viewInfoMapping, attributes);
        endElement("", viewInfoMapping, viewInfoMapping);
    }
}
