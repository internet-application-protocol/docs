/*
 * Copyright (c) 2004, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.util;

import java.io.InputStream;
import java.io.OutputStream;

import com.sun.xml.fastinfoset.sax.SAXDocumentParser;
import iap.annotation.XmlElement;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.AuthenticateUserRequest;
import com.inversoft.iap.transport.AuthenticateUserResponse;
import com.inversoft.iap.transport.CloseApplicationRequest;
import com.inversoft.iap.transport.CloseApplicationResponse;
import com.inversoft.iap.transport.FetchDataRequest;
import com.inversoft.iap.transport.FetchDataResponse;
import com.inversoft.iap.transport.FetchModuleRequest;
import com.inversoft.iap.transport.FetchModuleResponse;
import com.inversoft.iap.transport.MetaDataRequest;
import com.inversoft.iap.transport.MetaDataResponse;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.OpenViewRequest;
import com.inversoft.iap.transport.OpenViewResponse;
import com.inversoft.iap.transport.PerformActionRequest;
import com.inversoft.iap.transport.PerformActionResponse;
import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.ReconnectSessionResponse;
import com.inversoft.iap.transport.Transport;
import com.inversoft.iap.transport.handler.TransportHandlerDelegator;
import com.inversoft.iap.transport.serializer.AuthenticateUserRequestSerializer;
import com.inversoft.iap.transport.serializer.AuthenticateUserResponseSerializer;
import com.inversoft.iap.transport.serializer.BaseTransportSerializer;
import com.inversoft.iap.transport.serializer.CloseApplicationRequestSerializer;
import com.inversoft.iap.transport.serializer.CloseApplicationResponseSerializer;
import com.inversoft.iap.transport.serializer.FetchDataRequestSerializer;
import com.inversoft.iap.transport.serializer.FetchDataResponseSerializer;
import com.inversoft.iap.transport.serializer.FetchModuleRequestSerializer;
import com.inversoft.iap.transport.serializer.FetchModuleResponseSerializer;
import com.inversoft.iap.transport.serializer.MetaDataRequestSerializer;
import com.inversoft.iap.transport.serializer.MetaDataResponseSerializer;
import com.inversoft.iap.transport.serializer.OpenApplicationRequestSerializer;
import com.inversoft.iap.transport.serializer.OpenApplicationResponseSerializer;
import com.inversoft.iap.transport.serializer.OpenViewRequestSerializer;
import com.inversoft.iap.transport.serializer.OpenViewResponseSerializer;
import com.inversoft.iap.transport.serializer.PerformActionRequestSerializer;
import com.inversoft.iap.transport.serializer.PerformActionResponseSerializer;
import com.inversoft.iap.transport.serializer.ReconnectSessionRequestSerializer;
import com.inversoft.iap.transport.serializer.ReconnectSessionResponseSerializer;

/**
 * <p> This class is a toolkit that helps in translating between XML and transport objects and vice
 * versa using JAXB. The transport objects must be JAXB binding objects compiled using XJC. </p>
 *
 * @author Brian Pontarelli
 * @version 1.0
 * @since IAP 1.0
 */
public class TransportTools {

    /**
     * Returns the element name for the given {@link Transport} class.  The element name is defined by annotated
     * the transport class with {@link @XmlElement} annotation and specifying the setting the name attribute
     * equal to the element name.  Can return null if the annotation isn't defined for the particular class
     *
     * @param aClass the class to retieve the annotation from
     * @return annotation of type {@link javax.xml.bind.annotation.XmlRootElement}.  Null if not defined.
     */
    public static String getElementName(Class<?> aClass) {
        return aClass.getAnnotation(XmlElement.class).name();
    }

    /**
     * Serializes a {@link Transport} to Fast Infoset format
     *
     * @param transport {@link Transport}
     * @param os {@link OutputStream}
     * @param validate true if validating the transport, false otherwise
     */
    public static void serialize(Transport transport, OutputStream os, boolean validate) throws IAPTransportException {
        BaseTransportSerializer serializer = null;

        // instantiate the appropriate serializer
        if (transport instanceof AuthenticateUserRequest) {
            serializer = new AuthenticateUserRequestSerializer((AuthenticateUserRequest) transport);
        } else if (transport instanceof AuthenticateUserResponse) {
            serializer = new AuthenticateUserResponseSerializer((AuthenticateUserResponse) transport);
        } else if (transport instanceof CloseApplicationRequest) {
            serializer = new CloseApplicationRequestSerializer((CloseApplicationRequest) transport);
        } else if (transport instanceof CloseApplicationResponse) {
            serializer = new CloseApplicationResponseSerializer((CloseApplicationResponse) transport);
        } else if (transport instanceof FetchDataRequest) {
            serializer = new FetchDataRequestSerializer((FetchDataRequest) transport);
        } else if (transport instanceof FetchDataResponse) {
            serializer = new FetchDataResponseSerializer((FetchDataResponse) transport);
        } else if (transport instanceof FetchModuleRequest) {
            serializer = new FetchModuleRequestSerializer((FetchModuleRequest) transport);
        } else if (transport instanceof FetchModuleResponse) {
            serializer = new FetchModuleResponseSerializer((FetchModuleResponse) transport);
        } else if (transport instanceof MetaDataRequest) {
            serializer = new MetaDataRequestSerializer((MetaDataRequest) transport);
        } else if (transport instanceof MetaDataResponse) {
            serializer = new MetaDataResponseSerializer((MetaDataResponse) transport);
        } else if (transport instanceof OpenApplicationRequest) {
            serializer = new OpenApplicationRequestSerializer((OpenApplicationRequest) transport);
        } else if (transport instanceof OpenApplicationResponse) {
            serializer = new OpenApplicationResponseSerializer((OpenApplicationResponse) transport);
        } else if (transport instanceof OpenViewResponse) {
            serializer = new OpenViewResponseSerializer((OpenViewResponse) transport);
        } else if (transport instanceof OpenViewRequest) {
            serializer = new OpenViewRequestSerializer((OpenViewRequest) transport);
        } else if (transport instanceof PerformActionRequest) {
            serializer = new PerformActionRequestSerializer((PerformActionRequest) transport);
        } else if (transport instanceof PerformActionResponse) {
            serializer = new PerformActionResponseSerializer((PerformActionResponse) transport);
        } else if (transport instanceof ReconnectSessionRequest) {
            serializer = new ReconnectSessionRequestSerializer((ReconnectSessionRequest) transport);
        } else if (transport instanceof ReconnectSessionResponse) {
            serializer = new ReconnectSessionResponseSerializer((ReconnectSessionResponse) transport);
        }

        // set validation and output stream
        serializer.setValidateTransport(validate);
        serializer.setOutputStream(os);

        // serialize to fast infoset format
        try {
            serializer.serialize();
        } catch (SAXException e) {
            throw new IAPTransportException(e);
        }
    }

    /**
     * Called to Handle Fast Infoset encoded Transport messages and convert them to a {@link Transport} object
     *
     * @param is {@link InputStream}
     * @param validate true if validating the incoming message, false otherwise.
     * @return {@link Transport} object decoded from the Fast Infoset format
     */
    public static <T extends Transport> T handle(InputStream is, boolean validate)
    throws IAPTransportException {
        SAXDocumentParser parser = new SAXDocumentParser();
        TransportHandlerDelegator handlerDelegator = new TransportHandlerDelegator(parser, validate);
        parser.setInputStream(is);
        parser.setContentHandler(handlerDelegator);

        // should only ever throw during testing
        try {
            parser.parse();
        } catch (Exception e) {
            throw new IAPTransportException(e);
        }

        // this unchecked cast is relatively safe if properly tested
        //noinspection unchecked
        return (T) handlerDelegator.getDelegateHandler().getTransport();
    }
}