/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.util;

import java.lang.reflect.Array;
import java.nio.ByteBuffer;

import com.inversoft.iap.DataType;
import com.inversoft.Pair;

/**
 * <p>
 * This class is a data decoder that reads from a FastInfoset document
 * to parse out data values. A detailed explanation of the format on the
 * wire of data values is given in the {@link DataBinaryEncoder} class.
 * </p>
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class DataBinaryDecoder {
    private int[] header;
    private DataType type;

    public DataBinaryDecoder(DataType type) {
        this.type = type;
    }

    public Pair<Integer, Object> decode(ByteBuffer buf) {
        int headerLength = buf.getInt();
        header = new int[headerLength];
        for (int i = 0; i < headerLength; i++) {
            header[i] = buf.getInt();
        }

        Object value;
        if (header[0] != 0) {
            ArrayInfo info = buildArray(buf, header[0], 1);
            value = info.array;
        } else {
            value = decodePrimitive(buf);
        }

        int depth;
        if (type == DataType.STRING) {
            depth = header[0] - 1;
        } else {
            depth = header[0];
        }

        return new Pair<Integer, Object>(depth, value);
    }

    private Object decodePrimitive(ByteBuffer buf) {
        if (buf.remaining() > 0) {
            switch (type) {
                case BOOLEAN:
                    return (buf.get() == (byte) 0x01);
                case BYTE:
                    return buf.get();
                case CHAR:
                    return buf.getChar();
                case DOUBLE:
                    return buf.getDouble();
                case FLOAT:
                    return buf.getFloat();
                case INT:
                    return buf.getInt();
                case LONG:
                    return buf.getLong();
                case SHORT:
                    return buf.getShort();
            }
        }

        return null;
    }

    private ArrayInfo buildArray(ByteBuffer buf, int depth, int index) {
        Class<?> classType = determineArrayComponentType(depth);
        int length = header[index];
        ArrayInfo info = new ArrayInfo();
        if (depth > 1) {
            info.array = Array.newInstance(classType, length);
            for (int i = 0; i < length; i++) {
                ArrayInfo subInfo = buildArray(buf, depth - 1, index + 1);
                index = subInfo.offset;
                Array.set(info.array, i, subInfo.array);
            }
        } else {
            // Determine if we are at a spot that has an array, otherwise it is null or empty.
            if (length == 0) {
                if (type == DataType.STRING) {
                    info.array = "";
                } else {
                    info.array = Array.newInstance(classType, length);
                }
            } else if (length == DataBinaryEncoder.NULL) {
                info.array = null; // This code is hard enough to read, figured I'd be explicit
            } else {
                if (buf.remaining() >= length) {
                    if (type == DataType.STRING) {
                        StringBuilder build = new StringBuilder();
                        for (int i = 0; i <  length; i++) {
                            char c = buf.getChar();
                            build.append(c);
                        }

                        info.array = build.toString();
                    } else {
                        info.array = buildPrimitiveArray(buf, length);
                    }
                } else {
                    throw new IllegalArgumentException("Invalid data contained. Array expected but " +
                        "the fast infoset stream was empty.");
                }
            }
        }

        info.offset = index;
        return info;
    }

    private Object buildPrimitiveArray(ByteBuffer buf, int length) {
        Object array = null;
        switch (type) {
            case BOOLEAN:
                boolean[] ba = new boolean[length];
                for (int i = 0; i < length; i++) {
                    ba[i] = (buf.get() == (byte) 0x01);
                }
                array = ba;
                break;
            case BYTE:
                byte[] bya = new byte[length];
                for (int i = 0; i < length; i++) {
                    bya[i] = buf.get();
                }
                array = bya;
                break;
            case CHAR:
                char[] ca = new char[length];
                for (int i = 0; i < length; i++) {
                    ca[i] = buf.getChar();
                }
                array = ca;
                break;
            case DOUBLE:
                double[] da = new double[length];
                for (int i = 0; i < length; i++) {
                    da[i] = buf.getDouble();
                }
                array = da;
                break;
            case FLOAT:
                float[] fa = new float[length];
                for (int i = 0; i < length; i++) {
                    fa[i] = buf.getFloat();
                }
                array = fa;
                break;
            case INT:
                int[] ia = new int[length];
                for (int i = 0; i < length; i++) {
                    ia[i] = buf.getInt();
                }
                array = ia;
                break;
            case LONG:
                long[] la = new long[length];
                for (int i = 0; i < length; i++) {
                    la[i] = buf.getLong();
                }
                array = la;
                break;
            case SHORT:
                short[] sa = new short[length];
                for (int i = 0; i < length; i++) {
                    sa[i] = buf.getShort();
                }
                array = sa;
                break;
        }

        return array;
    }

    /**
     * Uses the Java class name specification from the JavaDoc of {@link Class#getName()} to build
     * a string that matches the name of the array type. This builds the type such that building an
     * array with that component type should be acceptable (i.e. 1 less than the depth).
     *
     * Therefore if the depth is 2 (i.e. int[][]), this method will return int[].
     *
     * @param   depth The depth of the array whose component type to create.
     * @return  The array component type.
     */
    private Class<?> determineArrayComponentType(int depth) {
        int dimensions = type == DataType.STRING ? (depth - 2) : (depth - 1);
        if (dimensions > 0) {
            StringBuilder build = new StringBuilder();
            for (int j = 0; j < dimensions; j++) {
                build.append("[");
            }

            if (type != DataType.STRING) {
                build.append(type.getPrimitiveSymbol());
            } else {
                build.append("Ljava.lang.String;");
            }

            try {
                return Class.forName(build.toString());
            } catch (ClassNotFoundException e) {
                throw new AssertionError("CRITICAL: Unable to create array type [" + build.toString() + "]!");
            }
        }

        return type.getPrimitive();
    }

    public static class ArrayInfo {
        public Object array;
        public int offset;
    }
}