package com.inversoft.iap.transport;

import java.io.InputStream;
import java.nio.ByteBuffer;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;

/**
 * Java class for viewData complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="viewData">
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *       &lt;attribute name="contentLength" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="contentType" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "viewData")
public class ViewData {
    ByteBuffer value;

    /**
     * This can be used rather than the byte array to get the value.
     */
    InputStream valueStream;

    @XmlAttribute()
    long contentLength;

    @XmlAttribute()
    String contentType;

    /**
     * Gets the value of the value property.
     */
    public ByteBuffer getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     */
    public void setValue(ByteBuffer value) {
        this.value = value;
    }

    /**
     * This stream contains the bytes of the view.
     */
    public InputStream getValueStream() {
        return valueStream;
    }

    /**
     * Sets a stream that contains the bytes of the view.
     */
    public void setValueStream(InputStream valueStream) {
        this.valueStream = valueStream;
    }

    /**
     * Gets the value of the contentLength property.
     */
    public long getContentLength() {
        return contentLength;
    }

    /**
     * Sets the value of the contentLength property.
     */
    public void setContentLength(long value) {
        contentLength = value;
    }

    /**
     * Gets the value of the contentType property.
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * Sets the value of the contentType property.
     */
    public void setContentType(String value) {
        contentType = value;
    }
}