package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}response">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "closeApplicationResponse", isRootElement = true)
public class CloseApplicationResponse extends BaseResponse {

    /**
     * Returns the type of response.
     */
    public TransportType getType() {
        return TransportType.CLOSE_APPLICATION;
    }
}