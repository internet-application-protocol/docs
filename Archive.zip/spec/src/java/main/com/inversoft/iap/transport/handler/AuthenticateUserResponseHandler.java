/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */

package com.inversoft.iap.transport.handler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataBody;
import com.inversoft.iap.transport.AuthenticateUserResponse;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link AuthenticateUserResponse} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class AuthenticateUserResponseHandler extends BaseResponseHandler<AuthenticateUserResponse> {

    public AuthenticateUserResponseHandler() {
        super(new AuthenticateUserResponse());
        getTransport().setDataBody(new DataBody());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(Data.class))) {
            addNewDataBean(attributes);
        }
    }

    /**
     * {@inheritDoc}
     */
    protected void decodeCharacterContent(char[] ch, int start, int length) {
       // no concrete element content to decode
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void bytes(byte[] b, int start, int length) throws SAXException {
        super.addData(b, start, length);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals(TransportTools.getElementName(Data.class))) {
            DataBody dataBody = getTransport().getDataBody();
            Data data = decodeDataValue();
            dataBody.addData(data);
        }
    }
}