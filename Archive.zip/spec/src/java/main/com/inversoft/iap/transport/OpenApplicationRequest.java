package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}request">
 *       &lt;sequence>
 *         &lt;element name="clientCredentials" type="{}clientCredentials" minOccurs="0"/>
 *         &lt;element name="applicationInfo" type="{}applicationInfo"/>
 *         &lt;element name="clientConstraint" type="{}clientConstraint"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "openApplicationRequest", isRootElement = true)
public class OpenApplicationRequest implements Request {

    @XmlElement(name = "clientCredentials", isRequired = false)
    ClientCredentials clientCredentials;

    @XmlElement(name = "applicationInfo")
    ApplicationInfo applicationInfo;

    @XmlElement(name = "clientConstraint")
    ClientConstraint clientConstraint;

    /**
     * Returns the type of request.
     */
    public TransportType getType() {
        return TransportType.OPEN_APPLICATION;
    }

    /**
     * Gets the value of the clientCredentials property.
     */
    public ClientCredentials getClientCredentials() {
        return clientCredentials;
    }

    /**
     * Sets the value of the clientCredentials property.
     */
    public void setClientCredentials(ClientCredentials value) {
        clientCredentials = value;
    }

    /**
     * Gets the value of the applicationInfo property.
     */
    public ApplicationInfo getApplicationInfo() {
        return applicationInfo;
    }

    /**
     * Sets the value of the applicationInfo property.
     */
    public void setApplicationInfo(ApplicationInfo value) {
        applicationInfo = value;
    }

    /**
     * Gets the value of the clientConstraint property.
     */
    public ClientConstraint getClientConstraint() {
        return clientConstraint;
    }

    /**
     * Sets the value of the clientConstraint property.
     */
    public void setClientConstraint(ClientConstraint value) {
        clientConstraint = value;
    }
}