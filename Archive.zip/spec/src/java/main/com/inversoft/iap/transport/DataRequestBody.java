package com.inversoft.iap.transport;

import java.util.ArrayList;
import java.util.List;

import iap.annotation.XmlElement;

/**
 * Java class for dataRequestBody complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="dataRequestBody">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dataRequest" type="{}dataRequest" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "dataRequestBody")
public class DataRequestBody {

    @XmlElement(name = "dataRequest")
    List<DataRequest> dataRequest = new ArrayList<DataRequest>();

    /**
     * Gets the value of the DataRequest property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the DataRequest property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDataRequest().add(newItem);
     * </pre>
     */
    public List<DataRequest> getDataRequest() {
        return this.dataRequest;
    }
}