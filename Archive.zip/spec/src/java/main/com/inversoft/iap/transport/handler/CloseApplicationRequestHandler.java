/**
 * Copyright (c) 2005, Inversoft, All Rights Reserved
 */
package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.CloseApplicationRequest;
import org.xml.sax.Attributes;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link CloseApplicationRequest} object
 *
 * @author  Brian Pontarelli
 * @since   IAP 1.0
 * @version 1.0
 */
public class CloseApplicationRequestHandler extends BaseSessionRequestHandler<CloseApplicationRequest> {

    public CloseApplicationRequestHandler() {
        super(new CloseApplicationRequest());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        // Close application request has no unique elements to parse
    }
}