package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}sessionRequest">
 *       &lt;sequence>
 *         &lt;element name="viewInfo" type="{}viewInfo"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "openViewRequest", isRootElement = true)
public class OpenViewRequest extends SessionRequest {

    @XmlElement(name = "viewInfo")
    ViewInfo viewInfo;

    /**
     * Returns the type of request.
     */
    public TransportType getType() {
        return TransportType.OPEN_VIEW;
    }

    /**
     * Gets the value of the viewInfo property.
     */
    public ViewInfo getViewInfo() {
        return viewInfo;
    }

    /**
     * Sets the value of the viewInfo property.
     */
    public void setViewInfo(ViewInfo value) {
        viewInfo = value;
    }
}