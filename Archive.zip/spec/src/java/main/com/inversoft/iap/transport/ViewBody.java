package com.inversoft.iap.transport;

import iap.annotation.XmlElement;

/**
 * Java class for viewBody complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="viewBody">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="viewData" type="{}viewData"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "viewBody")
public class ViewBody {

    @XmlElement(name = "viewData")
    ViewData viewData;

    /**
     * Gets the value of the viewData property.
     */
    public ViewData getViewData() {
        return viewData;
    }

    /**
     * Sets the value of the viewData property.
     */
    public void setViewData(ViewData value) {
        viewData = value;
    }
}