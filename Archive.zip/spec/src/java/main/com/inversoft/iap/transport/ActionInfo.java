package com.inversoft.iap.transport;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;
import iap.request.ActionType;

/**
 * Java class for actionInfo complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="actionInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="actionId" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="actionType" use="required" type="{}actionType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "actionInfo")
public class ActionInfo {

    @XmlAttribute()
    String actionId;

    @XmlAttribute()
    ActionType actionType;

    /**
     * Gets the value of the actionId property.
     */
    public String getActionId() {
        return actionId;
    }

    /**
     * Sets the value of the actionId property.
     */
    public void setActionId(String value) {
        actionId = value;
    }

    /**
     * Gets the value of the actionType property.
     */
    public ActionType getActionType() {
        return actionType;
    }

    /**
     * Sets the value of the actionType property.
     */
    public void setActionType(ActionType value) {
        actionType = value;
    }
}