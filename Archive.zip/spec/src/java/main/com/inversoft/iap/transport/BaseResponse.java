package com.inversoft.iap.transport;

import iap.annotation.XmlElement;

/**
 * Base abstract interface for all {@link Response} types
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseResponse implements Response {

    @XmlElement(name = "status")
    Status status;

    /**
     * Gets the value of the status property.
     *
     * @return A {@link Status}
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     *
     * @param value The {@link Status}
     */
    public void setStatus(Status value) {
        status = value;
    }
}