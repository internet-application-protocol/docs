/**
 * Date Created: Aug 9, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

/**
 * Runtime Exception thrown if there are any problems during a {@link com.inversoft.iap.transport.Transport} object
 * validation process.
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TransportValidationException extends RuntimeException {

    /**
     * {@inheritDoc}
     */
    public TransportValidationException() {
        super();
    }

    /**
     * {@inheritDoc}
     */
    public TransportValidationException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public TransportValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public TransportValidationException(Throwable cause) {
        super(cause);
    }
}
