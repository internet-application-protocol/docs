/**
 * Date Created: Aug 9, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

import java.nio.ByteBuffer;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.inversoft.iap.transport.FetchModuleResponse;
import com.inversoft.iap.transport.ModuleBody;
import com.inversoft.iap.transport.ModuleData;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Concrete {@link TransportHandler} to decode Fast Infoset format to a {@link FetchModuleResponse} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class FetchModuleResponseHandler extends BaseResponseHandler<FetchModuleResponse> {

    public FetchModuleResponseHandler() {
        super(new FetchModuleResponse());
    }

    /**
     * {@inheritDoc}
     */
    protected void parseUniqueElement(String uri, String localName, String qName, Attributes attributes) {
        if (qName.equals(TransportTools.getElementName(ModuleBody.class))) {
            ModuleBody body = new ModuleBody();
            getTransport().setModuleBody(body);
            setParentElement(ModuleBody.class);
        } else if (qName.equals(TransportTools.getElementName(ModuleData.class))) {
            ModuleData moduleData = new ModuleData();
            getTransport().getModuleBody().setModuleData(moduleData);
            setParentElement(ModuleData.class);
        }
    }

    /**
     * {@inheritDoc}
     */
    protected void decodeCharacterContent(char[] ch, int start, int length) {
    }

    /**
     * Stores the bytes of the module.
     */
    public void bytes(byte[] b, int start, int length) throws SAXException {
        ModuleData data = getTransport().getModuleBody().getModuleData();
        ByteBuffer value = data.getData();
        if (value == null) {
            value = ByteBuffer.allocate(length);
            value.put(b, start, length);
            value.flip();
        } else {
            ByteBuffer fresh = ByteBuffer.allocate(length + value.capacity());
            fresh.put(value);
            fresh.put(b, start, length);
            fresh.flip();
            value = fresh;
        }

        data.setData(value);
    }
}