package com.inversoft.iap.transport;

import javax.xml.datatype.XMLGregorianCalendar;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlContent;
import iap.annotation.XmlElement;

/**
 * Java class for certificate complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="certificate">
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *       &lt;attribute name="dateCreated" use="required" type="{http://www.w3.org/2001/XMLSchema}date" />
 *       &lt;attribute name="dateExpires" use="required" type="{http://www.w3.org/2001/XMLSchema}date" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "certificate")
public class Certificate {

    @XmlContent()
    String value;

    @XmlAttribute()
    XMLGregorianCalendar dateCreated;

    @XmlAttribute()
    XMLGregorianCalendar dateExpires;

    /**
     * Gets the value of the value property.
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the value of the dateCreated property.
     */
    public XMLGregorianCalendar getDateCreated() {
        return dateCreated;
    }

    /**
     * Sets the value of the dateCreated property.
     */
    public void setDateCreated(XMLGregorianCalendar value) {
        dateCreated = value;
    }

    /**
     * Gets the value of the dateExpires property.
     */
    public XMLGregorianCalendar getDateExpires() {
        return dateExpires;
    }

    /**
     * Sets the value of the dateExpires property.
     */
    public void setDateExpires(XMLGregorianCalendar value) {
        dateExpires = value;
    }
}