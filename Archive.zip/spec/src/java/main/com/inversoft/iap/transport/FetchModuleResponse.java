package com.inversoft.iap.transport;

import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for FetchModuleResponse Transport type.
 * 
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}response">
 *       &lt;sequence>
 *         &lt;element name="moduleBody" type="{}moduleBody" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "fetchModuleResponse", isRootElement = true)
public class FetchModuleResponse extends BaseResponse {

    @XmlElement(name = "moduleBody", isRequired = false)
    ModuleBody moduleBody;

    /**
     * Returns the type of response.
     */
    public TransportType getType() {
        return TransportType.FETCH_MODULE;
    }

    /**
     * Gets the value of the moduleBody property.
     */
    public ModuleBody getModuleBody() {
        return moduleBody;
    }

    /**
     * Sets the value of the moduleBody property.
     */
    public void setModuleBody(ModuleBody value) {
        moduleBody = value;
    }
}