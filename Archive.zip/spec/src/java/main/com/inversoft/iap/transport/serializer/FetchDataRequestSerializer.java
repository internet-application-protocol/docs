/**
 * Date Created: Aug 9, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.serializer;

import java.util.List;

import com.inversoft.iap.transport.DataRequest;
import com.inversoft.iap.transport.DataRequestBody;
import com.inversoft.iap.transport.FetchDataRequest;
import com.inversoft.iap.transport.util.TransportTools;
import com.sun.xml.fastinfoset.QualifiedName;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link FetchDataRequest} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class FetchDataRequestSerializer extends BaseSessionRequestSerializer<FetchDataRequest> {

    public FetchDataRequestSerializer(FetchDataRequest request) {
        super(request);
    }

    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        DataRequestBody dataRequestBody = getTransport().getDataRequestBody();

        // assign xml mappings
        String dataRequestBodyMapping = TransportTools.getElementName(DataRequestBody.class);
        String dataRequestMapping = TransportTools.getElementName(DataRequest.class);
        String nameMapping = "name";

        startElement("", dataRequestBodyMapping, dataRequestBodyMapping, attributes);

        List<DataRequest> dataRequestList = dataRequestBody.getDataRequest();

        for (DataRequest dataRequest : dataRequestList) {
            attributes.addAttribute(new QualifiedName("", "", nameMapping, nameMapping), dataRequest.getName());
            startElement("", dataRequestMapping, dataRequestMapping, attributes);
            endElement("", dataRequestMapping, dataRequestMapping);
            attributes.clear();
        }

        endElement("", dataRequestBodyMapping, dataRequestBodyMapping);
    }
}
