package com.inversoft.iap.transport;

import com.inversoft.iap.DataBody;
import iap.TransportType;
import iap.annotation.XmlElement;

/**
 * Java class for anonymous complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{}response">
 *       &lt;sequence>
 *         &lt;element name="dataBody" type="{}dataBody" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "performActionResponse", isRootElement = true)
public class PerformActionResponse extends BaseResponse {

    @XmlElement(name = "dataBody", isRequired = false)
    DataBody dataBody;

    /**
     * Returns the type of response.
     */
    public TransportType getType() {
        return TransportType.PERFORM_ACTION;
    }

    /**
     * Gets the value of the dataBody property.
     */
    public DataBody getDataBody() {
        return dataBody;
    }

    /**
     * Sets the value of the dataBody property.
     */
    public void setDataBody(DataBody value) {
        dataBody = value;
    }
}