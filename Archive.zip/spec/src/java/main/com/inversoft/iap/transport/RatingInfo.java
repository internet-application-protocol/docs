package com.inversoft.iap.transport;

import iap.annotation.XmlAttribute;
import iap.annotation.XmlElement;
import iap.response.Rating;

/**
 * Java class for ratingInfo complex type.
 *  <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;complexType name="ratingInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="rating" use="required" type="{}ratingType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
@XmlElement(name = "ratingInfo")
public class RatingInfo {

    @XmlAttribute()
    Rating rating;

    /**
     * Gets the value of the ratingType property.
     *
     * @return The rating.
     */
    public Rating getRating() {
        return rating;
    }

    /**
     * Sets the value of the ratingType property.
     *
     * @param value The new rating.
     */
    public void setRating(Rating value) {
        this.rating = value;
    }
}