/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.transport.serializer;

import com.inversoft.iap.transport.MetaDataRequest;
import com.sun.xml.fastinfoset.sax.AttributesHolder;
import org.xml.sax.SAXException;

/**
 * Concrete {@link TransportSerializer} to encode {@link MetaDataRequest} objects to Fast Infoset format
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MetaDataRequestSerializer extends BaseRequestSerializer<MetaDataRequest> {

    public MetaDataRequestSerializer(MetaDataRequest request) {
        super(request);
    }

    protected void encodeChildren(AttributesHolder attributes) throws SAXException {
        // stub.  Nothing to parse
    }

    protected void encodeConcrete(AttributesHolder attributes) throws SAXException {
        // stub.  Nothing to parse
    }
}
