/**
 * Date Created: Aug 2, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.transport.handler;

import com.inversoft.iap.transport.Transport;
import org.jvnet.fastinfoset.sax.PrimitiveTypeContentHandler;
import org.xml.sax.ContentHandler;

/**
 * Interface for all Transport Handler types.  This interface extends the {@link ContentHandler} and
 * {@link PrimitiveTypeContentHandler} interfaces to decode Fast Infoset formats to IAP {@link Transport} objects
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface TransportHandler<T extends Transport> extends ContentHandler, PrimitiveTypeContentHandler {

    /**
     * Gets the {@link Transport} associated to this Handler instance
     *
     * @return {@link Transport}
     */
    public T getTransport();

    /**
     * Sets the handler to validate the {@link Transport} object after it decodes from Fast Infoset format.
     * Validation is set to false by default.
     *
     * @param validate true if validating, false otherwise.  Default validation mode is set to false
     */
    public void setValidatingTransport(boolean validate);
}