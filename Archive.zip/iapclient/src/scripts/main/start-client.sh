#!/bin/bash

jars=$(ls *.jar)
RUNTIME_CP=
for f in $jars; do 
  if [ -z "$RUNTIME_CP" ]; then
    RUNTIME_CP=$f
  else
    RUNTIME_CP=$f:$RUNTIME_CP
  fi
done

os=`uname -o`
if [ $os == "Cygwin" ]; then
  RUNTIME_CP=`cygpath -dp $RUNTIME_CP`
fi

echo "Classpath is: $RUNTIME_CP"

java -cp $RUNTIME_CP com.inversoft.iap.client.IAPClient
