/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

import java.io.File;

import junit.framework.TestCase;

import com.inversoft.iap.client.controllers.CacheManager;
import com.inversoft.iap.client.controllers.MessageManager;
import com.inversoft.iap.client.controllers.TransactionManager;
import com.inversoft.iap.client.controllers.transport.ProcessorFactory;
import com.inversoft.iap.client.model.Scope;
import com.inversoft.iap.net.IapURLStreamHandlerFactory;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class IAPClientConfigTest extends TestCase {

    public IAPClientConfigTest(String s) {
        super(s);
    }

    public void testConfig() throws ConfigurationException {
        File cacheDirectory = new File(System.getProperty("user.home") + "/.iapclient/cache");
        IAPClientConfig config = new IAPClientConfig(cacheDirectory, new IapURLStreamHandlerFactory());
        assertEquals(MessageManager.class, config.getContainer().get(MessageManager.class).getClass());
        assertEquals(cacheDirectory.getAbsolutePath(),
                config.getContainer().get(CacheManager.class).getCacheDir().getAbsolutePath());
        assertEquals(Scope.class, config.getContainer().get(Scope.class).getClass());
        assertEquals(IAPClientPropertyManager.class, config.getContainer().get(IAPClientPropertyManager.class).getClass());
        assertEquals(ProcessorFactory.class, config.getContainer().get(ProcessorFactory.class).getClass());
        assertEquals(TransactionManager.class, config.getContainer().get(TransactionManager.class).getClass());
    }
}
