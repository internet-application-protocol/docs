/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.model;

import java.util.Iterator;
import java.util.Set;

import junit.framework.TestCase;

import iap.VersionNumber;
import iap.response.DataScope;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataType;
import com.inversoft.iap.SessionIdGenerator;
import com.inversoft.iap.transport.SessionId;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ScopeTest extends TestCase {

    private String data1Name = "data1";
    private String value1 = "value1";
    private String data2Name = "data2";
    private String value2 = "value2";
    private String data3Name = "data3";
    private String value3 = "value3";
    private String data4Name = "data4";
    private String value4 = "value4";
    private String data5Name = "data5";
    private String value5 = "value5";
    private String data6Name = "data6";
    private String value6 = "value6";
    private Data data1;
    private Data data2;
    private Data data3;
    private Data data4;
    private Data data5;
    private Data data6;
    private SessionId sessionId1;
    private SessionId sessionId2;
    private String applicationId1;
    private String applicationId2;
    private VersionNumber version1;
    private VersionNumber version2;
    private String id1;
    private String id2;
    private String viewId1;
    private String viewId2;
    private String viewId3;
    private String viewId4;

    public ScopeTest(String s) {
        super(s);
        init();
    }

    private void init() {
        // define some Data
        data1 = new Data(data1Name, value1, DataType.STRING, 0,
                DataScope.VIEW);
        data2 = new Data(data2Name, value2, DataType.STRING, 0,
                DataScope.VIEW);
        data3 = new Data(data3Name, value3, DataType.STRING, 0,
                DataScope.APPLICATION);
        data4 = new Data(data4Name, value4, DataType.STRING, 0,
                DataScope.VIEW);
        data5 = new Data(data5Name, value5, DataType.STRING, 0,
                DataScope.APPLICATION);
        data6 = new Data(data6Name, value6, DataType.STRING, 0,
                DataScope.APPLICATION);

        // define some SessionIds
        applicationId1 = "application1";
        version1 = VersionNumber.decode("1.0.1");
        id1 = SessionIdGenerator.getIdentifier();
        sessionId1 = new SessionId(applicationId1, version1, id1);
        applicationId2 = "application2";
        version2 = VersionNumber.decode("1.0.2");
        id2 = SessionIdGenerator.getIdentifier();
        sessionId2 = new SessionId(applicationId2, version2, id2);

        // define some viewIds
        viewId1 = "view1.iapl";
        viewId2 = "view2.iapl";
        viewId3 = "view3.iapl";
        viewId4 = "view4.iapl";
    }

    private Scope getScope() {
        Scope scope = new Scope();
        scope.registerSessionId(sessionId1);
        scope.registerSessionId(sessionId2);
        return scope;
    }

    public void testRegisterSessionId() {
        Scope scope = getScope();
        assertTrue(scope.isSessionIdRegistered(sessionId1));
        assertTrue(scope.isSessionIdRegistered(sessionId2));
    }

    public void testRemoveSessionId() {
        Scope scope = getScope();
        scope.removeSessionId(sessionId1);
        assertFalse(scope.isSessionIdRegistered(sessionId1));
        assertTrue(scope.isSessionIdRegistered(sessionId2));
        scope.removeSessionId(sessionId2);
        assertFalse(scope.isSessionIdRegistered(sessionId2));
    }

    public void testRegisterViewIdWithoutSessionRegistered() {
        Scope scope = new Scope();
        scope.registerViewId(sessionId1, viewId1);
        assertTrue(scope.isViewIdRegistered(sessionId1, viewId1));
    }

    public void testRegisterViewIdWithSessionIdRegistered() {
        Scope scope = getScope();
        scope.registerViewId(sessionId1, viewId1);
        assertTrue(scope.isViewIdRegistered(sessionId1, viewId1));
    }

    public void test_Add_Get_ApplicationScopeData() {
        Scope scope = getScope();
        scope.addApplicationScopeData(sessionId1, data1Name, value1, DataType.STRING);
        Data data = scope.getApplicationData(sessionId1, data1Name);
        assertEquals("data1", data.getKey());
        assertEquals("value1", data.getValue().toString());
        assertEquals(0, data.getArrayDepth());

        scope.addApplicationScopeData(sessionId1, data1Name, value2, DataType.STRING, 0);
        Data data_1 = scope.getApplicationData(sessionId1, data1Name);
        assertNotSame("value2", data_1.getValue().toString());

        scope.addApplicationScopeData(sessionId1, data2Name, value2, DataType.STRING, 0);
        Data data2 = scope.getApplicationData(sessionId1, data2Name);
        assertEquals("data2", data2.getKey());
        assertEquals("value2", data2.getValue().toString());

        scope.addApplicationScopeData(sessionId1, data3Name, value3, DataType.STRING);
        Data data3 = scope.getApplicationData(sessionId1, data3Name);
        assertEquals("data3", data3.getKey());
        assertEquals("value3", data3.getValue().toString());

        Set<Data> allAppData = scope.getAllApplicationData(sessionId1);
        assertEquals(3, allAppData.size());
        for (Iterator<Data> iterator = allAppData.iterator(); iterator.hasNext();) {
            Data aData = iterator.next();
            if (aData.getKey().equals(data1Name)) {
                assertEquals("value1", aData.getValue().toString());
            } else if (aData.getKey().equals(data2Name)) {
                assertEquals("value2", aData.getValue().toString());
            } else if (aData.getKey().equals(data3Name)) {
                assertEquals("value3", aData.getValue().toString());
            } else {
                fail();
            }
        }
    }

    public void test_Add_Get_ViewData() {
        Scope scope = getScope();
        scope.addViewScopeData(sessionId1, viewId1, data1Name, value1, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data2Name, value2, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data3Name, value3, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data4Name, value4, DataType.STRING);

        Set<Data> allViewData = scope.getAllViewData(sessionId1, viewId1);
        assertEquals(4, allViewData.size());
        for (Iterator<Data> iterator = allViewData.iterator(); iterator.hasNext();) {
            Data aData = iterator.next();
            if (aData.getKey().equals(data1Name)) {
                assertEquals("value1", aData.getValue().toString());
            } else if (aData.getKey().equals(data2Name)) {
                assertEquals("value2", aData.getValue().toString());
            } else if (aData.getKey().equals(data3Name)) {
                assertEquals("value3", aData.getValue().toString());
            } else if (aData.getKey().equals(data4Name)) {
                assertEquals("value4", aData.getValue().toString());
            } else {
                fail();
            }
        }
    }

    public void test_Add_Get_AllData() {
        Scope scope = getScope();
        scope.addViewScopeData(sessionId1, viewId1, data1Name, value1, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data2Name, value2, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data3Name, value3, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data4Name, value4, DataType.STRING);

        Set<Data> allViewData = scope.getAllViewData(sessionId1, viewId1);
        assertEquals(4, allViewData.size());
        for (Iterator<Data> iterator = allViewData.iterator(); iterator.hasNext();) {
            Data aData = iterator.next();
            if (aData.getKey().equals(data1Name)) {
                assertEquals("value1", aData.getValue().toString());
            } else if (aData.getKey().equals(data2Name)) {
                assertEquals("value2", aData.getValue().toString());
            } else if (aData.getKey().equals(data3Name)) {
                assertEquals("value3", aData.getValue().toString());
            } else if (aData.getKey().equals(data4Name)) {
                assertEquals("value4", aData.getValue().toString());
            } else {
                fail();
            }
        }

        scope.addApplicationScopeData(sessionId1, data5Name, value5, DataType.STRING);
        scope.addApplicationScopeData(sessionId1, data6Name, value6, DataType.STRING, 0);
        scope.addApplicationScopeData(sessionId1, data1Name, value1, DataType.STRING);

        Set<Data> allAppData = scope.getAllApplicationData(sessionId1);
        assertEquals(3, allAppData.size());
        for (Iterator<Data> iterator = allAppData.iterator(); iterator.hasNext();) {
            Data aData = iterator.next();
            if (aData.getKey().equals(data1Name)) {
                assertEquals("value1", aData.getValue().toString());
            } else if (aData.getKey().equals(data5Name)) {
                assertEquals("value5", aData.getValue().toString());
            } else if (aData.getKey().equals(data6Name)) {
                assertEquals("value6", aData.getValue().toString());
            } else {
                fail();
            }
        }

        Set<Data> allData = scope.getAllScopedData(sessionId1, viewId1);
        // The size should be 6, although, 7 seems more likely.  The reason it's 6 is because 'data1Name' defined above
        // in application scope, is also defined in view scope.  Since view scope takes precedence over application
        // scope, the application scope's 'data1Name' gets omitted from the set when retrieving all scoped data
        assertEquals(6, allData.size());
    }

    public void testDeletingData() {
        Scope scope = getScope();
        scope.addViewScopeData(sessionId1, viewId1, data1Name, value1, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data2Name, value2, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data3Name, value3, DataType.STRING);
        scope.addViewScopeData(sessionId1, viewId1, data4Name, value4, DataType.STRING);
        scope.addApplicationScopeData(sessionId1, data5Name, value5, DataType.STRING);
        scope.addApplicationScopeData(sessionId1, data6Name, value6, DataType.STRING, 0);
        scope.addApplicationScopeData(sessionId1, data1Name, value1, DataType.STRING);

        Data data1 = scope.getViewData(sessionId1, viewId1, data1Name);
        assertEquals(data1Name, data1.getKey());
        scope.deleteViewData(sessionId1, viewId1, data1Name);
        assertNull(scope.getViewData(sessionId1, viewId1, data1Name));

        Data data2 = scope.getApplicationData(sessionId1, data5Name);
        assertEquals(data5Name, data2.getKey());
        scope.deleteApplicationData(sessionId1, data5Name);
        assertNull(scope.getApplicationData(sessionId1, data5Name));
    }
}