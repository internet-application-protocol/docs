/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import iap.TransportType;
import iap.VersionNumber;

import com.inversoft.iap.IAPTransaction;
import com.inversoft.iap.IAPTransactionManager;
import com.inversoft.iap.client.IAPClientContainer;
import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.client.model.EnvironmentVariables;
import com.inversoft.iap.client.model.Scope;
import com.inversoft.iap.transport.SessionId;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TestContextBuilder {
    public static ApplicationTransactionContext getContext(TransportType type) {
        IAPClientContainer container = new IAPClientContainer();
        IAPTransactionManager tManager = new IAPTransactionManager();
        IAPTransaction transaction = new IAPTransaction(type, tManager.createTransactionID());
        Scope scope = new Scope();
        EnvironmentVariables envVars = new EnvironmentVariables(scope);
        SessionId sessionId = new SessionId("testApp", VersionNumber.decode("1.0.1"));
        String viewId = "testViewId";
        return new ApplicationTransactionContext(container, transaction,
                envVars, sessionId, viewId);
    }
}
