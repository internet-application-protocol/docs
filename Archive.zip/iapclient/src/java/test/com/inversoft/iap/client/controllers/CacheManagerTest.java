/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers;

import java.io.File;

import junit.framework.TestCase;

import iap.VersionNumber;

import com.inversoft.iap.client.IAPClientContainer;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class CacheManagerTest extends TestCase {

    String rootCacheDir = System.getProperty("user.home") + "/.iapclient/cache";

    String host = "www.test.com";

    String appId = "testAppID";

    VersionNumber versionNumber = VersionNumber.decode("1.0.1");

    String viewId = "testViewId.iapl";

    String viewCode = "some random view code that gets written to the viewId";

    MessageManager messageManager = new MessageManager(new IAPClientContainer());

    public CacheManagerTest(String s) {
        super(s);
    }

    public void testInit() {
        File file = new File(System.getProperty("user.home") + "/.iapclient/cache");
        MessageManager messageManager = new MessageManager(new IAPClientContainer());
        CacheManager manager = new CacheManager(file, messageManager);
        assertEquals(file.getAbsolutePath(), manager.getCacheDir().getAbsolutePath());
    }

    public void testSave() {
        File file = new File(rootCacheDir);
        CacheManager manager = new CacheManager(file, messageManager);
        File appCacheDir = new File(rootCacheDir + "/" + host + "_" + appId + "_" + versionNumber);
        assertFalse(appCacheDir.exists());
        manager.save(host, appId, versionNumber, viewId, viewCode.getBytes());
        assertTrue(appCacheDir.exists());
        manager.deleteApplication(host, appId, versionNumber);
    }

    public void testLoad() throws CacheException {
        File file = new File(rootCacheDir);
        CacheManager manager = new CacheManager(file, messageManager);
        File appCacheDir = new File(rootCacheDir + "/" + host + "_" + appId + "_" + versionNumber);
        assertFalse(appCacheDir.exists());
        manager.save(host, appId, versionNumber, viewId, viewCode.getBytes());
        assertTrue(appCacheDir.exists());
        byte[] encodedViewCode = manager.load(appId, versionNumber, viewId, host);
        assertEquals(this.viewCode, new String(encodedViewCode));
        manager.deleteApplication(host, appId, versionNumber);
    }

    public void testBooleans() throws CacheException {
        File file = new File(rootCacheDir);
        CacheManager manager = new CacheManager(file, messageManager);
        File appCacheDir = new File(rootCacheDir + "/" + host + "_" + appId + "_" + versionNumber);
        assertFalse(appCacheDir.exists());
        manager.save(host, appId, versionNumber, viewId, viewCode.getBytes());
        assertTrue(appCacheDir.exists());

        assertTrue(manager.isApplicationCached(host, appId));
        assertTrue(manager.isApplicationVersionCached(host, appId, versionNumber));
        assertTrue(manager.isViewCached(host, appId, versionNumber, viewId));

        manager.deleteApplication(host, appId, versionNumber);
    }

    public void testFileExt() {
        File file = new File(rootCacheDir);
        CacheManager manager = new CacheManager(file, messageManager);
        File appCacheDir = new File(rootCacheDir + "/" + host + "_" + appId + "_" + versionNumber);
        assertFalse(appCacheDir.exists());
        manager.save(host, appId, versionNumber, viewId, viewCode.getBytes());

        assertEquals("iapl", manager.getViewFileExt(host, appId, versionNumber, viewId));

        manager.deleteApplication(host, appId, versionNumber);
    }

    public void testGetMostCurrentVersion() {
        File file = new File(rootCacheDir);
        CacheManager manager = new CacheManager(file, messageManager);
        manager.save(host, appId, versionNumber, viewId, viewCode.getBytes());
        manager.save(host, appId, VersionNumber.decode("1.0.2"), viewId, viewCode.getBytes());
        manager.save(host, appId, VersionNumber.decode("1.0.3"), viewId, viewCode.getBytes());
        manager.save(host, appId, VersionNumber.decode("1.0.4"), viewId, viewCode.getBytes());
        manager.save(host, appId, VersionNumber.decode("1.1.2"), viewId, viewCode.getBytes());
        manager.save(host, appId, VersionNumber.decode("1.3.2"), viewId, viewCode.getBytes());
        manager.save(host, appId, VersionNumber.decode("2.3.1"), viewId, viewCode.getBytes());

        assertEquals(VersionNumber.decode("2.3.1"), manager.getMostCurrentVersion(host, appId));

        manager.deleteCache();

        assertTrue(file.listFiles().length == 0);
    }
}
