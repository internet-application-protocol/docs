/**
 * Date Created: Jun 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.client.controllers;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import javax.xml.bind.JAXBException;

import junit.framework.TestCase;

import static iap.TransportType.OPEN_APPLICATION;
import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.client.ConfigurationException;
import com.inversoft.iap.client.IAPClientConfig;
import com.inversoft.iap.client.IAPClientProperty;
import com.inversoft.iap.client.IAPClientPropertyManager;
import com.inversoft.iap.client.context.MainFrameContext;
import com.inversoft.iap.client.view.ViewContext;
import com.inversoft.iap.client.view.frames.MainIAPClientFrame;
import com.inversoft.iap.net.IapURLStreamHandlerFactory;
import com.inversoft.iap.server.IAPServer;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.ServerConfigBuilder;
import com.inversoft.iap.transport.TransportFactory;
import com.inversoft.util.JAXBTools;

/**
 *
 * @author James Humphrey (humphjj)
 * @version 1.0
 */

public class TransactionManagerTest extends TestCase {

    IAPServer server;

    IAPClientConfig config;

    public TransactionManagerTest() {
    }

    public TransactionManagerTest(String s) throws ConfigurationException {
        super(s);
        config = new IAPClientConfig(new File(System.getProperty("user.home") + "/.iapclient/cache"),
                new IapURLStreamHandlerFactory());
    }

    public void setUp() {
        try {
            // Initialize the TransportFactory for the configuration and the transports
            JAXBTools.addObjectFactory(TransportFactory.class);
        } catch (JAXBException e) {
            fail(e.getMessage());
        }
    }

    public void testOpenAppOpenView() throws IOException, InterruptedException, TransactionException {
        startServer();

        TransactionManager tManager = new TransactionManager(config.getContainer());
        ViewContext viewContext = new ViewContext(config.getContainer(),
                new MainIAPClientFrame(new MainFrameContext(config.getContainer(), "test")));

        IAPClientPropertyManager pManager = viewContext.getMainFrame().getContext().getPropertyManager();
        // default Rating set in the IAPClientProperty is 'E'.  App being opened is 'M' so we need to
        // set the rating to 'M' or greater
        pManager.set(IAPClientProperty.RATING, Rating.M.toString());
        // set default cacheing to 'never cache'
        pManager.set(IAPClientProperty.CACHE_STATUS, CacheOptions.NEVER_CACHE.toString());

        tManager.doTransaction(viewContext, getUrl(), OPEN_APPLICATION);

        // verify view context data
        assertNotNull(viewContext.getSessionId());
        assertNotNull(viewContext.getViewId());
        assertEquals("index.iapl", viewContext.getViewId());

        // verify some transaction context data
        assertEquals(getUrl(), viewContext.getTransactionContext().getUrl());
        assertEquals(Rating.M, viewContext.getTransactionContext().getRating());
        assertEquals("1.0.1", viewContext.getTransactionContext().getVersionNumber().toString());
        assertNotNull(viewContext.getTransactionContext().getEncodedViewCode());
        assertNotNull(viewContext.getTransactionContext().getViewCode());
        assertEquals("Test IAPL file", viewContext.getTransactionContext().getViewCode());

        // verify env vars
        assertEquals("test-app1", viewContext.getTransactionContext().getEnvironmentVariables().getApplicationId());
        assertEquals(getUrl(), viewContext.getTransactionContext().getEnvironmentVariables().getUrl());
        assertEquals(getUrl().getHost(), viewContext.getTransactionContext().getEnvironmentVariables().getHost());
        assertEquals(getUrl().getPort(), viewContext.getTransactionContext().getEnvironmentVariables().getPort());
        assertEquals(Rating.M, viewContext.getTransactionContext().getEnvironmentVariables().getRating());
        assertEquals(VersionNumber.decode("1.0.1"),
                viewContext.getTransactionContext().getEnvironmentVariables().getVersionNumber());
        assertEquals(true, viewContext.getTransactionContext().getEnvironmentVariables().isCacheable());


        stopServer();
    }

    public void testOpenAppOpenViewFetchData() throws IOException, InterruptedException, TransactionException {
        startServer();

        TransactionManager tManager = new TransactionManager(config.getContainer());
        ViewContext viewContext = new ViewContext(config.getContainer(),
                new MainIAPClientFrame(new MainFrameContext(config.getContainer(), "test")));

        IAPClientPropertyManager pManager = viewContext.getMainFrame().getContext().getPropertyManager();
        // default Rating set in the IAPClientProperty is 'E'.  App being opened is 'M' so we need to
        // set the rating to 'M' or greater
        pManager.set(IAPClientProperty.RATING, Rating.M.toString());
        // set default cacheing to 'never cache'
        pManager.set(IAPClientProperty.CACHE_STATUS, CacheOptions.NEVER_CACHE.toString());

        tManager.doTransaction(viewContext, getUrl(), OPEN_APPLICATION);

        // verify view context data
        assertNotNull(viewContext.getSessionId());
        assertNotNull(viewContext.getViewId());
        assertEquals("index.iapl", viewContext.getViewId());

        // verify some transaction context data
        assertEquals(getUrl(), viewContext.getTransactionContext().getUrl());
        assertEquals(Rating.M, viewContext.getTransactionContext().getRating());
        assertEquals("1.0.1", viewContext.getTransactionContext().getVersionNumber().toString());
        assertNotNull(viewContext.getTransactionContext().getEncodedViewCode());
        assertNotNull(viewContext.getTransactionContext().getViewCode());
        assertEquals("Test IAPL file", viewContext.getTransactionContext().getViewCode());

        // verify env vars
        assertEquals("test-app1", viewContext.getTransactionContext().getEnvironmentVariables().getApplicationId());
        assertEquals(getUrl(), viewContext.getTransactionContext().getEnvironmentVariables().getUrl());
        assertEquals(getUrl().getHost(), viewContext.getTransactionContext().getEnvironmentVariables().getHost());
        assertEquals(getUrl().getPort(), viewContext.getTransactionContext().getEnvironmentVariables().getPort());
        assertEquals(Rating.M, viewContext.getTransactionContext().getEnvironmentVariables().getRating());
        assertEquals(VersionNumber.decode("1.0.1"),
                viewContext.getTransactionContext().getEnvironmentVariables().getVersionNumber());
        assertEquals(true, viewContext.getTransactionContext().getEnvironmentVariables().isCacheable());


        stopServer();
    }

    /**
     * Helper Methods
     */
    private void startServer() throws IOException, InterruptedException {
        System.setProperty("iap.server.config",
                "src/java/test/com/inversoft/iap/server/test-server.xml".replace('/', File.separatorChar));
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        server = new IAPServer(serverConfig);
        Thread.sleep(1000);
    }

    private void stopServer() throws InterruptedException {
        Thread.sleep(1000);
        server.shutdown();
        Thread.sleep(1000);
    }

    private URL getUrl() throws UnknownHostException, MalformedURLException {
        InetAddress addr = InetAddress.getLocalHost();
        URL url = new URL("iap", addr.getHostAddress(), 8080, "/test-app1");
        return url;
    }
}
