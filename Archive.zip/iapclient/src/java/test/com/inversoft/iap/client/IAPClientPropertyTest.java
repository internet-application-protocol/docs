/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

import junit.framework.TestCase;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class IAPClientPropertyTest extends TestCase {

    public IAPClientPropertyTest(String s) {
        super(s);
    }

    public void testProperties() {
        assertEquals("http://www.inversoft.com/iap/", IAPClientProperty.CURRENT_VIEW_URL.getDefaultValue());
        assertEquals("HOME_URL", IAPClientProperty.HOME_URL.toString());
        assertEquals("TIMEOUT", IAPClientProperty.TIMEOUT.getName());
    }
}
