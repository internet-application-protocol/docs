/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import junit.framework.TestCase;

import iap.TransportType;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class FetchDataProcessorTest extends TestCase {

    public FetchDataProcessorTest(String s) {
        super(s);
    }

    public void testProcessorInstantiation() {
        FetchDataProcessor processor = new FetchDataProcessor(TestContextBuilder.getContext(TransportType.FETCH_DATA));
    }
}
