/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.model;

import java.net.MalformedURLException;
import java.net.URL;

import junit.framework.TestCase;

import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.IAPEnvironmentVariable;
import static com.inversoft.iap.IAPEnvironmentVariable.*;
import com.inversoft.iap.SessionIdGenerator;
import com.inversoft.iap.transport.SessionId;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class EnvironmentVariablesTest extends TestCase {

    private SessionId sessionId;

    private URL url;

    public EnvironmentVariablesTest(String s) throws MalformedURLException {
        super(s);
        init();
    }

    private void init() throws MalformedURLException {
        String applicationId1 = "application1";
        VersionNumber version1 = VersionNumber.decode("1.0.1");
        String id1 = SessionIdGenerator.getIdentifier();
        sessionId = new SessionId(applicationId1, version1, id1);
        url = new URL("http://www.inversoft.com/");
    }

    public void testEnvVarsWithNullSession() {
        Scope scope = new Scope();
        EnvironmentVariables envVars = EnvironmentVariables.get(scope, url, sessionId);
        assertEquals(url, envVars.getUrl());
        assertEquals(url.getHost(), "www.inversoft.com");
        assertEquals(url.getPort(), -1);
        assertEquals("/", envVars.getApplicationId());
        assertNull(envVars.getVersionNumber());
        assertFalse(envVars.isCacheable());
        assertNull(envVars.getRating());
    }

    public void testEnvVarsWithSession() {
        Scope scope = new Scope();
        scope.addApplicationScopeData(sessionId, VERSION_NUMBER.toString(), "1.0.1",
                VERSION_NUMBER.getDataType());
        scope.addApplicationScopeData(sessionId, RATING.toString(), Rating.T.toString(),
                RATING.getDataType());
        scope.addApplicationScopeData(sessionId, CACHEABLE.toString(), true,
                CACHEABLE.getDataType());
        EnvironmentVariables envVars = EnvironmentVariables.get(scope, url, sessionId);
        assertEquals("1.0.1", envVars.getVersionNumber().toString());
        assertEquals(Rating.T.toString(), envVars.getRating().toString());
        assertTrue(envVars.isCacheable());
    }

    public void testSettingUnderSession() {
        Scope scope = new Scope();
        scope.addApplicationScopeData(sessionId, VERSION_NUMBER.toString(), "1.0.1",
                VERSION_NUMBER.getDataType());
        scope.addApplicationScopeData(sessionId, RATING.toString(), Rating.T.toString(),
                RATING.getDataType());
        scope.addApplicationScopeData(sessionId, CACHEABLE.toString(), true,
                CACHEABLE.getDataType());
        EnvironmentVariables envVars = EnvironmentVariables.get(scope, url, sessionId);
        assertEquals("1.0.1", envVars.getVersionNumber().toString());
        assertEquals(Rating.T.toString(), envVars.getRating().toString());
        assertTrue(envVars.isCacheable());

        scope.deleteApplicationData(sessionId, IAPEnvironmentVariable.VERSION_NUMBER.toString());
        envVars.setVersionNumber(VersionNumber.decode("1.0.2"), sessionId);
        assertEquals("1.0.2", envVars.getVersionNumber().toString());
        assertEquals("1.0.2", scope.getApplicationData(sessionId,
                IAPEnvironmentVariable.VERSION_NUMBER.toString()).getValue().toString());
    }
}
