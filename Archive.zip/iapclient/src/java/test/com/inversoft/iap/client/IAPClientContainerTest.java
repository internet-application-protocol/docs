/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

import java.io.File;

import junit.framework.TestCase;

import com.inversoft.iap.client.controllers.CacheManager;
import com.inversoft.iap.client.controllers.MessageManager;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class IAPClientContainerTest extends TestCase {

    public IAPClientContainerTest() {
    }

    public IAPClientContainerTest(String s) {
        super(s);
    }

    public void testContainer() throws IAPClientContainerException {
        IAPClientContainer container = new IAPClientContainer();
        File file = new File(System.getProperty("user.home") + "/.iapclient/cache");
        Object[] params = {file, new MessageManager(container)};
        container.register(CacheManager.class, true, params);
        assertEquals(CacheManager.class, container.get(CacheManager.class).getClass());
        assertEquals(file.getAbsolutePath(), container.get(CacheManager.class).getCacheDir().getAbsolutePath());
    }
}
