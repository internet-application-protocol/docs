/**
 * Date Created: Jun 16, 2005
 * Created By:   James Humphrey (humphjj)
 */

package com.inversoft.iap.client.controllers;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import javax.xml.bind.JAXBException;

import junit.framework.TestCase;

import iap.TransportType;
import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.client.ConfigurationException;
import com.inversoft.iap.client.IAPClientConfig;
import com.inversoft.iap.net.IapURLStreamHandlerFactory;
import com.inversoft.iap.server.IAPServer;
import com.inversoft.iap.server.config.ServerConfig;
import com.inversoft.iap.server.config.ServerConfigBuilder;
import com.inversoft.iap.transport.ApplicationInfo;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.TransportFactory;
import com.inversoft.util.JAXBTools;

/**
 * Test Class for the {@link ConnectionManager}.  This test case must be run from the iapserver working directory
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ConnectionManagerTest extends TestCase {

    IAPServer server;

    IAPClientConfig clientConfig;

    public ConnectionManagerTest(String s) throws ConfigurationException {
        super(s);
        clientConfig = new IAPClientConfig(new File(System.getProperty("user.home") + "/.iapclient/cache"),
                new IapURLStreamHandlerFactory());
    }

    public void setUp() {
        try {
            // Initialize the TransportFactory for the configuration and the transports
            JAXBTools.addObjectFactory(TransportFactory.class);
            JAXBTools.addObjectFactory(com.inversoft.iap.server.config.jaxb.ObjectFactory.class);
        } catch (JAXBException e) {
            fail(e.getMessage());
        }
    }

    public void testOpenConnection()  throws ConfigurationException, IOException, InterruptedException {
        startServer();

        ConnectionManager manager = new ConnectionManager(clientConfig.getContainer(), TransportType.OPEN_APPLICATION);
        manager.openConnection(getUrl());

        assertNotNull(manager.getIapConnection());
        assertTrue(manager.getIapConnection().getSocket().isConnected());

        stopServer();
    }

    public void testDisconnecting() throws ConfigurationException, IOException, InterruptedException {
        startServer();

        ConnectionManager manager = new ConnectionManager(clientConfig.getContainer(), TransportType.OPEN_APPLICATION);
        manager.openConnection(getUrl());

        assertNotNull(manager.getIapConnection());
        assertNotNull(manager.getIapConnection().getSocket());
        assertTrue(manager.getIapConnection().getSocket().isConnected());

        manager.disconnect();
        assertFalse(manager.getIapConnection().isConnected());

        stopServer();
    }


    public void testPinging() throws ConfigurationException, IOException, InterruptedException {

        startServer();

        ConnectionManager manager = new ConnectionManager(clientConfig.getContainer(), TransportType.OPEN_APPLICATION);
        manager.openConnection(getUrl());

        // create a request
        OpenApplicationRequest request = new OpenApplicationRequest();
        request.setApplicationInfo(new ApplicationInfo());
        request.getApplicationInfo().setApplicationId("test-app1");
        request.getApplicationInfo().setVersionNumber(VersionNumber.decode("1.0.1"));

        // do ping (sends request and waits for a java.util.concurrent.Future<Response> object)
        OpenApplicationResponse response = (OpenApplicationResponse) manager.ping(request);

        // verify some response data
        assertTrue(response.getSuccessGroup().getApplicationDescription().isIsCacheable());
        assertEquals(Rating.M.toString(), response.getSuccessGroup().getRatingInfo().getRating().toString());

        stopServer();
    }



    /**
     * Helper Methods
     */
    private void startServer() throws IOException, InterruptedException {
        System.setProperty("iap.server.config",
                "src/java/test/com/inversoft/iap/client/test-server.xml");
        ServerConfigBuilder builder = new ServerConfigBuilder();
        ServerConfig serverConfig = builder.build();
        server = new IAPServer(serverConfig);
        Thread.sleep(1000);
    }

    private void stopServer() throws InterruptedException {
        Thread.sleep(1000);
        server.shutdown();
        Thread.sleep(1000);
    }

    private URL getUrl() throws UnknownHostException, MalformedURLException {
        InetAddress addr = InetAddress.getLocalHost();
        return new URL("iap", addr.getHostAddress(), 8080, "/test-app1");
    }
}
