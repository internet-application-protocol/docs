/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import java.io.IOException;

import iap.TransportType;

import com.inversoft.iap.net.IapURLConnection;
import com.inversoft.iap.transport.Request;
import com.inversoft.iap.transport.Response;
import com.inversoft.iap.transport.util.TransportTools;

/**
 * Handles reading and writing {@link com.inversoft.iap.transport.Transport}
 * objects from and to the connection socket
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TransportIOHandler {

    private IapURLConnection connection;

    private TransportType transactionType;

    public TransportIOHandler(IapURLConnection connection, TransportType transportType) {
        this.connection = connection;
        this.transactionType = transportType;
    }

    /**
     * Processes the Request by writing the transport xml to the
     * output stream of the connection's socket
     *
     * @throws com.inversoft.iap.client.controllers.transport.TransportIOHandlerException
     */
    public void write(Request request) throws TransportIOHandlerException {
        try {
            TransportTools.serialize(request, connection.getOutputStream(), true);
        } catch (IOException ioe) {
            throw new TransportIOHandlerException("i/o occurred while writing Transport request [" +
                    request.getType().toString() + "] to the output stream socket");
        }

    }

    /**
     * Returns the {@link Response} object contained in the connection input stream
     *
     * @throws TransportIOHandlerException thrown if there is a problem with the input stream
     */
    public Response read() throws TransportIOHandlerException {
        try {
            return TransportTools.handle(connection.getInputStream(), true);
        } catch (IOException ioe) {
            throw new TransportIOHandlerException("i/o error occurred opening the input stream" +
                    " socket during the [" + transactionType + "] transaction");
        }
    }
}
