/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

import com.inversoft.vertigo.VertigoContainer;
import com.inversoft.vertigo.VertigoException;
import com.inversoft.vertigo.VertigoObject;

/**
 * <p>This class serves as an adapter to an IoC Container interface.  This class is intended to make it quick and easy
 * to switch out different IoC Container APIs if necessary</p>
 *
 * <p>This class is currently using a very prototypical IoC Container called Veritigo.  Vertigo is a new
 * IoC Container currently in development by the developers of Inversoft</p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class IAPClientContainer {

    private VertigoContainer container = new VertigoContainer();

    public IAPClientContainer() {
        // stub
    }

    public <C> C get(Class<C> aClass) {
        return container.get(aClass);
    }

    public <C> void register(Class<C> aClass, boolean instantiate, Object... params)
            throws IAPClientContainerException {
        try {
            VertigoObject<C> object = new VertigoObject<C>(aClass, params);
            container.register(object, instantiate);
        } catch (VertigoException ve) {
            throw new IAPClientContainerException(ve.getMessage());
        }

    }
}
