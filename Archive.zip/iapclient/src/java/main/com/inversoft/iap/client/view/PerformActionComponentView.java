/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.view;

import java.awt.*;
import javax.swing.*;
import javax.swing.text.ComponentView;
import javax.swing.text.Element;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class PerformActionComponentView extends ComponentView {

    public PerformActionComponentView(Element elem) {
        super(elem);
    }

    /**
     * Create the component that is associated with
     * this view.  This will be called when it has
     * been determined that a new component is needed.
     * This would result from a call to setParent or
     * as a result of being notified that attributes
     * have changed.
     */
    protected Component createComponent() {
        return new JLabel("Temp Perform Action Request Label");
    }
}
