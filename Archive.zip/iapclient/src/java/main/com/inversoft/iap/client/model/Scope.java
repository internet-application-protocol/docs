/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.model;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static iap.response.DataScope.APPLICATION;
import static iap.response.DataScope.VIEW;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataType;
import com.inversoft.iap.transport.SessionId;

/**
 * The Scope maintains state for  all 'view' and 'application' scoped Data pertaining to a particular Application
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public final class Scope {

    /**
     * Map to store Scope associated to a particular application.
     * The key to the map is a SessionId object
     */
    private final Map<SessionId, DataStore> map = new HashMap<SessionId, DataStore>();

    /**
     * Registers a {@link SessionId} into Scope without having to add any {@link Data}
     *
     * @param sessionId {@link SessionId}
     */
    public void registerSessionId(SessionId sessionId) {
        synchronized(map) {
            if (!map.containsKey(sessionId)) {
                DataStore dataStore = new DataStore();
                map.put(sessionId, dataStore);
            }
        }
    }

    /**
     * Used to register a view id.  If the sessionId isn't yet registered, then this method will register it
     *
     * @param sessionId
     * @param viewId
     */
    public void registerViewId(SessionId sessionId, String viewId) {
        synchronized(map) {
            DataStore dataStore = null;
            if (map.containsKey(sessionId)) {
                dataStore = map.get(sessionId);
                 dataStore.registerViewId(viewId);
            } else {
                dataStore = new DataStore();
                dataStore.registerViewId(viewId);
                map.put(sessionId, dataStore);
            }
        }
    }

    /**
     * Removes a {@link SessionId} completely from Scope
     *
     * @param sessionId {@link SessionId}
     */
    public void removeSessionId(SessionId sessionId) {
        synchronized(map) {
            map.remove(sessionId);
        }
    }

    /**
     * Returns true if the {@link SessionId} is registered into the Scope
     *
     * @param sessionId {@link SessionId}
     * @return true if the {@link SessionId} is registered, false otherwise
     */
    public boolean isSessionIdRegistered(SessionId sessionId) {
        boolean registered = false;
        synchronized(map) {
            if (map.containsKey(sessionId)) {
                registered = true;
            }
        }

        return registered;
    }

    /**
     * True if the viewId associatd to the sessionId is registered, false otherwise
     *
     * @param sessionId {@link SessionId}
     * @param viewId the viewId
     * @return true if the viewId is registered, false otherwise
     */
    public boolean isViewIdRegistered(SessionId sessionId, String viewId) {
        boolean registered = false;
        synchronized(map) {
            if (isSessionIdRegistered(sessionId)) {
                DataStore dataStore = map.get(sessionId);
                registered = dataStore.isViewIdRegistered(viewId);
            }
        }

        return registered;
    }

    /**
     * Returns all scoped {@link Data} pertaining to a particular {@link SessionId} and view Id.  Any variables
     * within view scope that have the exact same name as a variable in application scope will override
     * (take precedence) appliaction scope.  *View Scope always takes precedence
     *
     * @param sessionId {@link SessionId}
     * @param viewId the view Id
     * @return Set of all {@link Data} pertaining to a particular sessionId and viewId
     */
    public Set<Data> getAllScopedData(SessionId sessionId, String viewId) {
        Set<Data> allScopeData = new HashSet<Data>(getAllViewData(sessionId, viewId));
        Set<Data> allApplicationScopeData = new HashSet<Data>(getAllApplicationData(sessionId));
        // iterate on all application scoped data and compare it to the view data.  if comparing both app and view data
        // with Data.areVariablesEqual() returns true, then DO NOT add the app data to the 'allScopeData' map
        // since view scope takes precedence over application scope
        for (Data appData : allApplicationScopeData) {
            boolean sameVariable = false;
            for (Data viewData : allScopeData) {
                if (Data.areVariablesEqual(appData, viewData)) {
                    sameVariable = true;
                }
            }
            if (!sameVariable) {
                allScopeData.add(appData);
            }
        }

        return allScopeData;
    }

    /**
     * Creates a {@link Data} object specified by the name-value as type {@link DataType} and adds it
     * to Application scope.  This method can be used if array depth is specified
     *
     * @param sessionId {@link SessionId}
     * @param name String name of the variable to add
     * @param value the Object value of the variable
     * @param type the {@link com.inversoft.iap.DataType}
     * @param arrayDepth the array depth
     */
    public void addApplicationScopeData(SessionId sessionId, String name, Object value, DataType type, int arrayDepth) {
        Data data = new Data(name, value, type, arrayDepth, APPLICATION);
        try {
            addApplicationScopeData(sessionId, data);
        } catch (InvalidScopeException ise) {
            throw new AssertionError(); // this will never throw since DataScope is guaranteed to be Application
        }
    }

    /**
     * Creates a {@link Data} object specified by the name-value as type {@link DataType} and adds it
     * to Application scope.  This method can be used if no array depth is specified
     *
     * @param sessionId {@link SessionId}
     * @param name String name of the variable to add
     * @param value the Object value of the variable
     * @param type the {@link com.inversoft.iap.DataType}
     */
    public void addApplicationScopeData(SessionId sessionId, String name, Object value, DataType type) {
        addApplicationScopeData(sessionId, name, value, type, 0);
    }

    /**
     * Adds an Application Scoped {@link Data} object to the store
     *
     * @param sessionId {@link SessionId}
     * @param data {@link Data}
     * @throws InvalidScopeException thrown if the {@link Data} object isn't in Application Scope
     */
    private void addApplicationScopeData(SessionId sessionId, Data data) throws InvalidScopeException {
        synchronized (map) {
            if (data.getScope().equals(APPLICATION)) {
                DataStore dataStore = map.get(sessionId);
                if (dataStore != null) {
                    dataStore.addApplicationData(data);
                } else {
                    dataStore = new DataStore();
                    dataStore.addApplicationData(data);
                    map.put(sessionId, dataStore);
                }
            } else {
                throw new InvalidScopeException("Data is not in Application scope");
            }
        }
    }

    /**
     * Creates a {@link Data} object specified by the name-value as type {@link DataType} and adds it
     * to view scope.  This can be used if array depth is specified
     *
     * @param sessionId {@link SessionId}
     * @param viewId the viewId
     * @param name String name of the variable to add
     * @param value the Object value of the variable
     * @param type the {@link com.inversoft.iap.DataType}
     * @param arrayDepth the array depth
     */
    public void addViewScopeData(SessionId sessionId, String viewId, String name, Object value, DataType type, int arrayDepth) {
        Data data = new Data(name, value, type, arrayDepth, VIEW);
        try {
            addViewScopeData(sessionId, viewId, data);
        } catch (InvalidScopeException ise) {
            throw new AssertionError(); // this will never throw since DataScope is guaranteed to be View
        }
    }

    /**
     * Creates a {@link Data} object specified by the name-value as type {@link DataType} and adds it
     * to view scope.  This can be used if no array depth is specified
     *
     * @param sessionId {@link SessionId}
     * @param viewId the viewId
     * @param name String name of the variable to add
     * @param value the Object value of the variable
     * @param type the {@link com.inversoft.iap.DataType}
     */
    public void addViewScopeData(SessionId sessionId, String viewId, String name, Object value, DataType type) {
        addViewScopeData(sessionId, viewId, name, value, type, 0);
    }

    /**
     * Adds View Scoped {@link Data} to the store
     *
     * @param sessionId {@link SessionId}
     * @param viewId String viewId
     * @param data {@link com.inversoft.iap.Data}
     * @throws InvalidScopeException thrown if the {@link Data} object isn't in View Scope
     */
    private void addViewScopeData(SessionId sessionId, String viewId, Data data) throws InvalidScopeException {
        if (data.getScope().equals(VIEW)) {
            synchronized (map) {
                DataStore dataStore = map.get(sessionId);
                if (dataStore != null) {
                    dataStore.addViewData(data, viewId);
                } else {
                    dataStore = new DataStore();
                    dataStore.addViewData(data, viewId);
                    map.put(sessionId, dataStore);
                }
            }
        } else {
            throw new InvalidScopeException("Data is not in View scope");
        }
    }

    /**
     * Returns the set of {@link Data} associated to a particular viewId
     *
     * @param sessionId {@link SessionId}
     * @param viewId the viewId
     * @return Data set of {@link Data} associated to the viewId or empty set of sessionId hasn't yet been registered
     */
    public Set<Data> getAllViewData(SessionId sessionId, String viewId) {
        synchronized (map) {
            DataStore dataStore = map.get(sessionId);
            Set<Data> viewSet = new HashSet<Data>();
            if (dataStore != null) {
                viewSet = dataStore.getAllViewData(viewId);
            }

            return viewSet;
        }
    }

    /**
     * Gets the set of application scoped Data object associated to a
     * particular {@link SessionId}
     *
     * @param sessionId the key to the Scope map
     * @return the Data object set of all application scoped data associated to the {@link SessionId}
     */
    public Set<Data> getAllApplicationData(SessionId sessionId) {
        synchronized(map) {
            DataStore dataStore = map.get(sessionId);
            Set<Data> applicationData = new HashSet<Data>();
            if (dataStore != null) {
                applicationData = dataStore.getAllApplicationData();
            }

            return applicationData;
        }
    }

    /**
     * Returns a {@link Data} object associated to a particular Application Scope
     *
     * @param sessionId {@link SessionId}
     * @param name they key to {@link Data}
     * @return {@link Data}
     */
    public Data getApplicationData(SessionId sessionId, String name) {
        synchronized(map) {
            DataStore dataStore = map.get(sessionId);
            Data data = null;
            if (dataStore != null) {
                data = dataStore.getApplicationData(name);
            }

            return data;
        }
    }

    /**
     * Returns a {@link Data} object associated to a particular View Scope
     *
     * @param sessionId {@link SessionId}
     * @param viewId the view Id
     * @param name they key to {@link Data}
     * @return {@link Data}
     */
    public Data getViewData(SessionId sessionId, String viewId, String name) {
        synchronized (map) {
            DataStore dataStore = map.get(sessionId);
            Data data = null;
            if (dataStore != null) {
                data = dataStore.getViewData(viewId, name);
            }

            return data;
        }
    }

    /**
     * Deletes View Scoped data for a particular viewId
     *
     * @param sessionId {@link SessionId}
     * @param viewId the view Id to delete from Scope
     */
    public void deleteAllViewData(SessionId sessionId, String viewId) {
        synchronized(map) {
            DataStore dataStore = map.get(sessionId);
            if (dataStore != null) {
                dataStore.deleteAllViewData(viewId);
            }
        }
    }

    /**
     * Deletes all application scoped data associated to a particular {@link SessionId}
     *
     * @param sessionId {@link SessionId}
     */
    public void deleteAllApplicationData(SessionId sessionId) {
        synchronized(map) {
            DataStore dataStore = map.get(sessionId);
            if (dataStore != null) {
                dataStore.deleteAllApplicationData();
            }
        }
    }

    /**
     * Deletes an individual {@link Data} object from application scope
     *
     * @param sessionId {@link SessionId}
     * @param name the variable name (key to {@link Data}
     */
    public void deleteApplicationData(SessionId sessionId, String name) {
        synchronized(map) {
            DataStore dataStore = map.get(sessionId);
            if (dataStore != null) {
                dataStore.deleteApplicationData(name);
            }
        }
    }

    public void deleteViewData(SessionId sessionId, String viewId, String name) {
        synchronized(map) {
            DataStore dataStore = map.get(sessionId);
            if (dataStore != null) {
                dataStore.deleteViewData(viewId, name);
            }
        }
    }

    /**
     * Inner class model object to store Data state for a particular
     * application.  Each DataStore object contains a Set of unique application scoped data and a Map
     * of view scoped data that is viewId dependent
     */
    private final class DataStore {

        /**
         * The set of Data objects contained within the application scope
         */
        Set<Data> applicationScope = new HashSet<Data>();

        /**
         * Map of all view scoped data.  Each element is a set of Data objects
         * pertaining to a particular viewId of the application
         */
        Map<String, Set<Data>> viewScope = new HashMap<String, Set<Data>>();

        /**
         * Adds {@link Data} to the view scope.  If the viewId is not yet registered, this method
         * will create new view scope for this viewId
         *
         * @param data {@link Data}
         * @param viewId the viewId
         */
        public void addViewData(Data data, String viewId) {
            if (isViewIdRegistered(viewId)) {
                Set<Data> dataset = viewScope.get(viewId);
                boolean variableExists = false;
                for (Data aData : dataset) {
                    if (Data.areVariablesEqual(aData, data)) {
                        variableExists = true;
                    }
                }
                if (!variableExists) {
                    dataset.add(data);
                }
            } else {
                Set<Data> dataSet = new HashSet<Data>();
                dataSet.add(data);
                viewScope.put(viewId, dataSet);
            }
        }

        /**
         * Puts a new viewId into the view scope with an empty set
         *
         * @param viewId the viewId
         */
        public void registerViewId(String viewId) {
            if (!viewScope.containsKey(viewId)) {
                viewScope.put(viewId, new HashSet<Data>());
            }
        }

        /**
         * True if the viewId is already in view scope, false otherwise
         *
         * @param viewId the viewId
         */
        public boolean isViewIdRegistered(String viewId) {
            boolean registered = false;
            if (viewScope.containsKey(viewId)) {
                registered = true;
            }

            return registered;
        }

        /**
         * Adds {@link Data} to application scope.  The important aspect of this is that any duplicate Data
         * registrations override previous versions
         *
         * @param data {@link Data}
         */
        public void addApplicationData(Data data) {
            Set<Data> dataSet = applicationScope;
            boolean variableExists = false;
            for (Data aData : dataSet) {
                if (Data.areVariablesEqual(aData, data)) {
                    variableExists = true;
                }
            }
            if (!variableExists) {
                dataSet.add(data);
            }
        }

        /**
         * Returns the the data set for a particular view
         *
         * @param viewId the key to the viewScope map
         * @return the data set
         */
        public Set<Data> getAllViewData(String viewId) {
            if (viewScope.containsKey(viewId)) {
                return Collections.unmodifiableSet(viewScope.get(viewId));
            }

            return new HashSet<Data>();
        }

        /**
         * Returns an unmodifiable set of all application scoped Data objects
         *
         * @return set of all Data objects
         */
        public Set<Data> getAllApplicationData() {
            if (!applicationScope.isEmpty()) {
                return Collections.unmodifiableSet(applicationScope);
            }

            return new HashSet<Data>();
        }

        /**
         * Searches the applicationScope for the {@link Data} object matching the key specified
         *
         * @param key the key of the {@link Data}
         * @return {@link Data} or null if it doesn't exist
         */
        public Data getApplicationData(String key) {
            Data data = null;
            for (Data aData : applicationScope) {
                if (aData.getKey().equals(key)) {
                    data = aData;
                }
            }

            return data;
        }

        /**
         * Searches the viewScope for the {@link Data} object matching the key and viewId specified
         *
         * @param viewId the view Id
         * @param key the key of the {@link Data}
         * @return {@link Data} or null if it doesn't exist
         */
        public Data getViewData(String viewId, String key) {
            Data theData = null;
            Set<Data> viewData = viewScope.get(viewId);
            if (viewData != null) {
                for (Data data : viewData) {
                    if (data.getKey().equals(key)) {
                        theData = data;
                    }
                }
            }

            return theData;
        }

        /**
         * Removes a {@link Data} object mapped to the viewId from View scope
         *
         * @param viewId the viewId
         * @param dataToCompare {@link Data}
         */
        public void deleteViewData(String viewId, Data dataToCompare) {
            Set<Data> viewData = viewScope.get(viewId);
            Data dataToDelete = null;
            for (Data data : viewData) {
                if (data.getKey().equals(dataToCompare.getKey())) {
                    dataToDelete = data;
                }
            }
            if (dataToDelete != null) {
                viewData.remove(dataToDelete);
            }
        }

        /**
         * Removes all the View scoped data mapped to the viewId
         *
         * @param viewId the viewId
         */
        public void deleteAllViewData(String viewId) {
            viewScope.remove(viewId);
        }

        /**
         * Removes all View scoped data.  This is a complete clear() of the map
         */
        public void deleteAllViewData() {
            viewScope.clear();
        }

        /**
         * Removes a {@link Data} object from Application Scope if they are equal
         *
         * @param data1 {@link Data}
         */
        public void deleteApplicationData(Data data1) {
            Data dataToDelete = null;
            for (Data data2 : applicationScope) {
                if (Data.areVariablesEqual(data1, data2)) {
                    dataToDelete = data2;
                }
            }
            if (dataToDelete != null) {
                applicationScope.remove(dataToDelete);
            }
        }

        /**
         * Removes a single view scope entry using the {@link Data} key
         *
         * @param key the key to the {@link Data}
         */
        public void deleteApplicationData(String key) {
            Data dataToDelete = null;
            for (Data data : applicationScope) {
                if (data.getKey().equals(key)) {
                    dataToDelete = data;
                    break;
                }
            }
            if (dataToDelete != null) {
                applicationScope.remove(dataToDelete);
            }
        }

        /**
         * Removes a single application scope entry using the {@link Data} key
         *
         * @param key the key to the {@link Data}
         */
        public void deleteViewData(String viewId, String key) {
            Set<Data> viewData = viewScope.get(viewId);
            Data dataToDelete = null;
            for (Data data : viewData) {
                if (data.getKey().equals(key)) {
                    dataToDelete = data;
                }
            }
            if (dataToDelete != null) {
                viewData.remove(dataToDelete);
            }
        }

        /**
         * Removes all Application Scoped data
         */
        public void deleteAllApplicationData() {
            applicationScope.clear();
        }
    }
}
