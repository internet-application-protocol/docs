/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.mimeTypes;

import com.inversoft.iap.client.context.MimeTypeContextImpl;

/**
 * Represents View MimeTypes the client supports.  Each concrete BaseMimeTypeProcessor
 * contains mimeType-specific decode implementations to transform itself into
 * an IAP compliant and renderable View
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseMimeTypeProcessor implements MimeTypeProcessor {

    /**
     * BaseMimeTypeProcessor Context
     */
    protected MimeTypeContextImpl context;

    public BaseMimeTypeProcessor(MimeTypeContextImpl context) {
        this.context = context;
    }

    /**
     * {@inheritDoc}
     */
    public MimeTypeContextImpl getMimeTypeContext() {
        return context;
    }
}
