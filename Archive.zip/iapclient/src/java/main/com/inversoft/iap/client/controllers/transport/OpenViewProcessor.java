/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.response.OpenViewStatus;
import com.inversoft.iap.transport.OpenViewRequest;
import com.inversoft.iap.transport.OpenViewResponse;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.util.StringTools;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OpenViewProcessor extends BaseProcessor<OpenViewRequest, OpenViewResponse> {

    public OpenViewProcessor(ApplicationTransactionContext transactionContext) {
        super(transactionContext);
    }

    /**
     * {@inheritDoc}
     */
    public OpenViewRequest createRequest() {
        OpenViewRequest request = new OpenViewRequest();
        // set the ViewInfo
        ViewInfo viewInfo = new ViewInfo();
        viewInfo.setViewId(getTransactionContext().getViewId());
        request.setViewInfo(viewInfo);
        // set the SessionId
        request.setSessionId(getTransactionContext().getSessionId());
        return request;
    }

    /**
     * {@inheritDoc}
     */
    public void processStatus(OpenViewResponse response, String statusMsg, String statusCode)
            throws ProcessorException {
        OpenViewStatus status = OpenViewStatus.resolve(statusCode);
        if (StringTools.isEmpty(statusMsg)) {
            statusMsg = status.toString();
        }
        switch (status) {
            case SUCCESS:
                String contentType = response.getViewBody().getViewData().getContentType();
                byte[] encodedViewCode = response.getViewBody().getViewData().getValue();
                getTransactionContext().setContentType(contentType);
                getTransactionContext().setEncodedViewCode(encodedViewCode);
                break;
            case FAILURE:
                processGeneralFailure(statusMsg);
            case SESSION_EXPIRATION:
                processSessionExpiration(statusMsg);
            case FAILURE_SESSION_ID:
                processSessionIdFailure(statusMsg);
            case FAILURE_NON_EXISTENT:
                statusMsg = getTransactionContext().getApplicationId() + " does not exist at " +
                        getTransactionContext().getUrl().getHost();
                processException(statusMsg);
        }
    }
}