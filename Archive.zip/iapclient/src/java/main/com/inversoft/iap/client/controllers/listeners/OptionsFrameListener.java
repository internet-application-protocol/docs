/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.listeners;

import java.awt.event.ActionEvent;
import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.event.HyperlinkEvent;

import iap.response.Rating;

import com.inversoft.iap.client.IAPClientProperty;
import com.inversoft.iap.client.view.frames.OptionsIAPClientFrame;


/**
 * The ActionListener object for the OptionsFrame
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OptionsFrameListener extends BaseIAPClientListener<OptionsIAPClientFrame> {

    public OptionsFrameListener(OptionsIAPClientFrame optionsIAPClientFrame) {
        super(optionsIAPClientFrame);
    }

    /**
     * Invoked when an action occurs.
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == getFrame().getOkButton()) {
            if (isTimeoutValid() && isHomeURLValid()) {
                savePrefs();
                getFrame().close();
            }
        } else if (e.getSource() == getFrame().getHomeUrlButton()) {
            String currentViewURL = getFrame().getContext().getPropertyManager().get(IAPClientProperty.CURRENT_VIEW_URL);
            getFrame().getContext().getPropertyManager().set(IAPClientProperty.HOME_URL, currentViewURL);
            getFrame().getHomeUrlField().setText(currentViewURL);
        } else if (e.getSource() == getFrame().getCancelButton()) {
            getFrame().close();
        } else if (e.getSource() == getFrame().getDelCacheButton()) {
            getFrame().getContext().getCacheManager().deleteCache();
            getFrame().getContext().getMessageManager().displayInfoMsg("Cache Deleted Successfully");
        }
    }

    /**
     * Validates the Timeout value
     *
     * @return true if valid, false otherwise
     */
    private boolean isTimeoutValid() {
        boolean isValid = true;
        if (getFrame().getTimeoutField().getText().equals("")) {
            isValid = false;
        } else {
            // make sure that the timeout entered is a valid int format
            try {
                Integer.valueOf(getFrame().getTimeoutField().getText());
            } catch (NumberFormatException nfe) {
                isValid = false;
            }
        }
        if (!isValid) {
            // set the focus to the tab that contains the timeout text field
            getFrame().getTabbedPane().setSelectedIndex(1);
            getFrame().getTimeoutField().requestFocusInWindow();
            getFrame().getTimeoutField().selectAll();
            getFrame().getContext().getMessageManager().displayInfoMsg("Please enter a valid timeout in seconds");
        }

        return isValid;
    }

    /**
     * Validates the home url text field
     *
     * @return true if valid, false otherwise
     */
    private boolean isHomeURLValid() {
        boolean isValid = true;
        String homeURL = getFrame().getHomeUrlField().getText();
        if (homeURL.equals("")) {
            isValid = false;
        } else {
            // make sure it's a valid URL
            try {
                new URL(homeURL);
            } catch (MalformedURLException mue) {
                isValid = false;
            }
        }
        if (!isValid) {
            // set the focus to the tab that contains the home url field
            getFrame().getTabbedPane().setSelectedIndex(0);
            getFrame().getHomeUrlField().requestFocusInWindow();
            getFrame().getHomeUrlField().selectAll();
            getFrame().getContext().getMessageManager().displayInfoMsg("Please enter a valid home URL");
        }

        return isValid;
    }

    /**
     * all preferences set through the Options interface are saved here
     */
    private void savePrefs() {
        // save home url
        getFrame().getContext().getPropertyManager().set(IAPClientProperty.HOME_URL,
                getFrame().getHomeUrlField().getText());
        // save cache status
        getFrame().getContext().getPropertyManager().set(IAPClientProperty.CACHE_STATUS,
                (String) getFrame().getCacheList().getSelectedItem());
        // save timeout
        getFrame().getContext().getPropertyManager().set(IAPClientProperty.TIMEOUT,
                getFrame().getTimeoutField().getText());
        // save rating
        int ratingIndex = getFrame().getRatingSlider().getValue();
        Rating[] ratings = Rating.values();
        Rating rating = ratings[ratingIndex];
        getFrame().getContext().getPropertyManager().set(IAPClientProperty.RATING, rating.toString());
    }

    /**
     * Called when a hypertext link is updated.
     *
     * @param e the event responsible for the update
     */
    public void hyperlinkUpdate(HyperlinkEvent e) {
        // stub.  Hyperlinks not yet used in the Options Frame
    }
}
