/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.context;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.Data;
import com.inversoft.iap.IAPTransaction;
import com.inversoft.iap.client.IAPClientContainer;
import com.inversoft.iap.client.model.EnvironmentVariables;
import com.inversoft.iap.transport.DataRequest;
import com.inversoft.iap.transport.SessionId;


/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ApplicationTransactionContext extends BaseTransactionContext {

    /**
     * The environment variables for this transaction context
     */
    EnvironmentVariables environmentVariables;

    /**
     * The SessionId for this context.  This is the key to the scoped data
     */
    private SessionId sessionId;

    /**
     * The viewId for this context.  ViewIds are used as keys to store View scope
     */
    private String viewId;

    /**
     * This is the view code decoded from cache or from the response transport
     */
    private String viewCode;

    /**
     * The content type of the view
     */
    private String contentType;

    /**
     * Encoded view code
     */
    private byte[] encodedViewCode;

    /**
     * Contains the Data being sent delivered to the server via a fetch data request
     */
    private List<DataRequest> dataRequestList = new ArrayList<DataRequest>();

    /**
     * Contains the data rettrieved from the server via the Fetch Data Response
     */
    private List<Data> dataBodyList = new ArrayList<Data>();

    /**
     * Map of expanded variables obtained from processing a fetch data response
     */
    private Map<String, Data> variablesToExpand = new HashMap<String, Data>();

    public ApplicationTransactionContext(IAPClientContainer container, IAPTransaction iapTransaction,
                                         EnvironmentVariables environmentVariables, SessionId sessionId,
                                         String viewId) {
        super(container, iapTransaction);
        this.environmentVariables = environmentVariables;
        this.sessionId = sessionId;
        this.viewId = viewId;
    }

    /**
     * Returns the {@link URL} associated to this context
     *
     * @return {@link URL}
     */
    public URL getUrl() {
        return environmentVariables.getUrl();
    }

    /**
     * Delegates to {@link EnvironmentVariables} to get the {@link VersionNumber} for this context.
     * Will be null if the application has not yet been opened
     *
     * @return {@link VersionNumber}.  Will be null if the application has not yet been opened
     */
    public VersionNumber getVersionNumber() {
        return environmentVariables.getVersionNumber();
    }

    /**
     * Delegates to the {@link EnvironmentVariables} {@link Rating}
     *
     * @return {@link Rating}
     */
    public Rating getRating() {
        return environmentVariables.getRating();
    }

    /**
     * Delegates to {@link EnvironmentVariables} to gets the applicationId (also the name of the application)
     * associated to this context
     *
     * @return the applicationId
     */
    public String getApplicationId() {
        return environmentVariables.getApplicationId();
    }

    /**
     * Returns the {@link EnvironmentVariables} for this {@link TransactionContext}
     *
     * @return {@link EnvironmentVariables}
     */
    public EnvironmentVariables getEnvironmentVariables() {
        return environmentVariables;
    }

    /**
     * Returns the encoded view code
     *
     * @return encoded view code
     */
    public String getViewCode() {
        return viewCode;
    }

    /**
     * Used to set the view code.  This is the code to be rendered into the GUI view
     *
     * @param viewCode the view code
     */
    public void setViewCode(String viewCode) {
        this.viewCode = viewCode;
    }

    /**
     * Returns the {@link SessionId} for this context. Will be null if the application has not yet been opened
     *
     * @return {@link SessionId}.  Will be null if the application has not yet been opened
     */
    public SessionId getSessionId() {
        return sessionId;
    }

    /**
     * Sets the {@link SessionId}
     *
     * @param sessionId {@link SessionId}
     */
    public void setSessionId(SessionId sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * Returns the viewId for this context.  Will be null if the application has not yet been opened
     *
     * @return the viewId. Will be null if the application has not yet been opened
     */
    public String getViewId() {
        return viewId;
    }

    /**
     * Sets the viewId
     *
     * @param viewId the viewId
     */
    public void setViewId(String viewId) {
        this.viewId = viewId;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public byte[] getEncodedViewCode() {
        return encodedViewCode;
    }

    public void setEncodedViewCode(byte[] encodedViewCode) {
        this.encodedViewCode = encodedViewCode;
    }

    public List<DataRequest> getDataRequestList() {
        return dataRequestList;
    }

    public void setDataRequestList(List<DataRequest> dataRequestList) {
        this.dataRequestList = dataRequestList;
    }

    public Map<String, Data> getVariablesToExpand() {
        return variablesToExpand;
    }

    public void setVariablesToExpand(Map<String, Data> variablesToExpand) {
        this.variablesToExpand = variablesToExpand;
    }

    public List<Data> getDataBodyList() {
        return dataBodyList;
    }

    public void setDataBodyList(List<Data> dataBodyList) {
        this.dataBodyList = dataBodyList;
    }
}
