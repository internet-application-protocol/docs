/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import iap.TransportType;

import com.inversoft.iap.client.context.ApplicationTransactionContext;

/**
 * Factory Method to build a {@link com.inversoft.iap.client.controllers.transport.Processor} object.  The concrete object instantiated is dependent on the
 * {@link com.inversoft.iap.IAPTransaction} stage.
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ProcessorFactory {

    /**
     * Instantiates and returns a {@link com.inversoft.iap.client.controllers.transport.Processor} object dependent on the Stage defined in
     * {@link com.inversoft.iap.IAPTransaction}
     *
     * @param context the {@link ApplicationTransactionContext} under which the {@link com.inversoft.iap.client.controllers.transport.Processor}
     * object instantiates
     * @return {@link com.inversoft.iap.client.controllers.transport.Processor}
     */
    public Processor build(ApplicationTransactionContext context) {
        TransportType stage = context.getIAPTransaction().getStage();
        Processor processor = null;
        if (stage.equals(TransportType.OPEN_APPLICATION)) {
            processor = new OpenApplicationProcessor(context);
        } else if (stage.equals(TransportType.OPEN_VIEW)) {
            processor = new OpenViewProcessor(context);
        } else if (stage.equals(TransportType.FETCH_DATA)) {
            processor = new FetchDataProcessor(context);
        } else if (stage.equals(TransportType.PERFORM_ACTION)) {
            processor = new PerformActionProcessor(context);
        } else if (stage.equals(TransportType.RECONNECT_SESSION)) {
            processor = new ReconnectSessionProcessor(context);
        }

        return processor;
    }
}
