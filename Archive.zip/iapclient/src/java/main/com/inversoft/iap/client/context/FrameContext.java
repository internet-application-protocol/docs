/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.context;

/**
 * Interface for all concrete {@link com.inversoft.iap.client.view.frames.BaseIAPClientFrame} Context objects
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface FrameContext extends IAPClientContext {
    /**
     * Returns the Title for this frame instance
     *
     * @return the frame title
     */
    public String getFrameTitle();
}
