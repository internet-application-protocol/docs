/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

import iap.response.Rating;

import com.inversoft.iap.client.controllers.CacheOptions;

/**
 * <p>Enumeration properties used to store client properties.  If a property is needed
 * to help maintain state, its enumeration must be entered here first to enforce type checking.</p>
 *
 * <p>The first string is the name of the property.  This value is used
 * as the key in storing info to the java.util.Preferences object.  The second
 * String is the default value used if it doesn't already
 * exist.  Some properties may not require a default value, in which
 * case IAPClientProperty.UNDEFINED should be used</p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public enum IAPClientProperty {

    /**
     * Used to defined an undefined status.  This is used for default value when bootstrapping properties
     * at IAPClient boot
     */
    UNDEFINED("UNDEFINED"),

    /**
     * Defines the user cache option.  This is type checked by the {@link CacheOptions} Enum
     */
    CACHE_STATUS(CacheOptions.ALWAYS_CACHE_AUTO.toString()),

    /**
     * The timeout governing connection timeouts
     */
    TIMEOUT("99"),
    HOME_URL("http://www.inversoft.com/iap/"),
    CURRENT_VIEW_URL("http://www.inversoft.com/iap/"),
    OPTION_COORDS(IAPClientProperty.UNDEFINED.getName()),
    MAIN_COORDS(IAPClientProperty.UNDEFINED.getName()),
    RATING(Rating.E.toString());


    /**
     * Name of the Enum
     */
    private String name = toString();

    /**
     * Default value used when setting the pref object for the first time
     */
    private String defaultValue;

    private IAPClientProperty(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    /**
     * Returns the String representation of the name of the Enum.
     * This is the first String in the enum declaration list
     *
     * @return name The String name of the Enum
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the default value which is the
     * second String in the enum declaration list
     *
     * @return String - default value of the enum
     */
    public String getDefaultValue() {
        return defaultValue;
    }
}
