/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

import java.util.prefs.Preferences;

/**
 * <p>This object is a delegator between the client and java.util.Preferences to store user
 * defined properties such as cache info, timeouts, startup url, etc.
 * These properties are generally set by the client user</p>
 *
 * <p>In order to add a new property it must first be entered
 * into the IAPClientProperty Enum to enforce type checking and variable
 * accountability</p>
 *
 * <p>This object is thread safe</p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public final class IAPClientPropertyManager {
    // Preference object used to facilitate storing the properties on disk
    private Preferences prefs;

    public IAPClientPropertyManager() {
        // exception can only be thrown if the security manager prevents
        // the use of java.util.prefs.  This will cause a non-recoverable
        // error
        try {
            prefs = Preferences.userNodeForPackage(IAPClientPropertyManager.class);
        } catch (SecurityException se) {
            throw new AssertionError("The Java Security Manager is preventing the usage of java.util.Preferences: [" +
                    se.getMessage() + "]");
        }
    }

    /**
     * Returns a property value
     *
     * @param key key in name-value set
     * @return value in name-value set
     */
    public String get(IAPClientProperty key) {
        synchronized (prefs) {
            return prefs.get(key.getName(), key.getDefaultValue());
        }
    }

    /**
     * Adds a name-value pair to the Properties object
     *
     * @param key the key of the property
     * @param value value of the property
     */
    public void set(IAPClientProperty key, String value) {
        synchronized (prefs) {
            prefs.put(key.getName(), value);
        }
    }
}

