/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.context;

import com.inversoft.iap.client.IAPClientContainer;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class DialogBoxFrameContext extends FrameContextImpl {

    public DialogBoxFrameContext(IAPClientContainer container, String frameTitle) {
        super(container, frameTitle);
    }
}
