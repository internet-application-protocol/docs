/**
 * Date Created: Apr 18, 2005
 * Created By:   James Humphrey
 */

package com.inversoft.iap.client.view;

import com.inversoft.iap.client.IAPClientContainer;
import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.client.context.BaseIAPClientContext;
import com.inversoft.iap.client.context.IAPClientContext;
import com.inversoft.iap.client.view.frames.MainIAPClientFrame;
import com.inversoft.iap.transport.SessionId;

/**
 *
 * @author James Humphrey
 * @version 1.0
 */

public class ViewContext extends BaseIAPClientContext implements IAPClientContext {

    private ApplicationTransactionContext transactionContext;

    private MainIAPClientFrame mainFrame;

    public ViewContext(IAPClientContainer container, MainIAPClientFrame mainFrame) {
        super(container);
        this.mainFrame = mainFrame;
    }

    /**
     * Gets the {@link SessionId} for this context
     *
     * @return {@link SessionId}
     */
    public SessionId getSessionId() {
        return (transactionContext != null) ? transactionContext.getSessionId() : null;
    }

    /**
     * Gets the viewId for this context
     *
     * @return the viewId
     */
    public String getViewId() {
        return (transactionContext != null) ? transactionContext.getViewId() : null;
    }

    /**
     * Returns the transaction context associated to this view
     *
     * @return {@link ApplicationTransactionContext}
     */
    public ApplicationTransactionContext getTransactionContext() {
        return transactionContext;
    }

    /**
     * Used to set the transaction context for this view
     *
     * @param transactionContext the transaction context
     */
    public void setTransactionContext(ApplicationTransactionContext transactionContext) {
        this.transactionContext = transactionContext;
    }


    /**
     * Returns the main frame associated to this view
     *
     * @return the main frame
     */
    public MainIAPClientFrame getMainFrame() {
        return mainFrame;
    }
}
