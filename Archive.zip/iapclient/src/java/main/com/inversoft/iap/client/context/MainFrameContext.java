/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.context;

import com.inversoft.iap.client.IAPClientContainer;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MainFrameContext extends FrameContextImpl {

    public MainFrameContext(IAPClientContainer container, String frameTitle) {
        super(container, frameTitle);
    }
}
