/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TransportIOHandlerException extends Exception {

    /**
     * {@inheritDoc}
     */
    public TransportIOHandlerException() {
        super();
    }

    /**
     * {@inheritDoc}
     */
    public TransportIOHandlerException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public TransportIOHandlerException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public TransportIOHandlerException(Throwable cause) {
        super(cause);
    }
}
