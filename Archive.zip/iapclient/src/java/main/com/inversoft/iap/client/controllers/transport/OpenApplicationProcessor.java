/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.IAPEnvironmentVariable;
import com.inversoft.iap.client.IAPClientProperty;
import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.client.controllers.CacheOptions;
import com.inversoft.iap.client.model.Scope;
import com.inversoft.iap.response.OpenApplicationStatus;
import com.inversoft.iap.transport.ApplicationInfo;
import com.inversoft.iap.transport.OpenApplicationRequest;
import com.inversoft.iap.transport.OpenApplicationResponse;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.util.StringTools;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OpenApplicationProcessor extends BaseProcessor<OpenApplicationRequest, OpenApplicationResponse> {

    public OpenApplicationProcessor(ApplicationTransactionContext transactionContext) {
        super(transactionContext);
    }

    /**
     * {@inheritDoc}
     */
    public OpenApplicationRequest createRequest() {
        String cacheStatus = getTransactionContext().getPropertyManager().get(IAPClientProperty.CACHE_STATUS);
        String applicationId = getTransactionContext().getApplicationId();
        VersionNumber versionNumber = getTransactionContext().getVersionNumber();
        String host = getTransactionContext().getUrl().getHost();
        // if caching is enabled and the version has not yet been specified
        // then get the most current version from the cache
        if (!cacheStatus.equals(CacheOptions.NEVER_CACHE.toString()) && versionNumber == null) {
            boolean cached = getTransactionContext().getCacheManager().isApplicationCached(host, applicationId);
            if (cached) {
                versionNumber = getTransactionContext().getCacheManager().getMostCurrentVersion(host,
                        applicationId);
                getTransactionContext().getEnvironmentVariables().setVersionNumber(versionNumber);
            }
        }
        OpenApplicationRequest request = new OpenApplicationRequest();
        request.setApplicationInfo(new ApplicationInfo());
        request.getApplicationInfo().setApplicationId(applicationId);

        if (versionNumber != null) {
            request.getApplicationInfo().setVersionNumber(versionNumber);
        }

        return request;
    }

    /**
     * {@inheritDoc}
     */
    public void processStatus(OpenApplicationResponse response, String statusMsg, String statusCode)
            throws ProcessorException {
        OpenApplicationStatus status = OpenApplicationStatus.resolve(statusCode);
        if (StringTools.isEmpty(statusMsg)) {
            statusMsg = status.toString();
        }
        String applicationId = getTransactionContext().getApplicationId();
        VersionNumber clientVersion = null;
        switch (status) {
            case SUCCESS:
                initApplication(response);
                break;
            case SUCCESS_NEWER_VERSION:
                IAPClientProperty cacheStatus = IAPClientProperty.CACHE_STATUS;
                clientVersion = getTransactionContext().getVersionNumber();
                if (getTransactionContext().getPropertyManager().get(cacheStatus).equals(CacheOptions.ALWAYS_CACHE_MANUAL)) {
                    statusMsg = applicationId + " version " + clientVersion + " is available, however, a newer version " +
                            "exists.\n\nClick 'OK' to upgrade to the newer version.";
                    getTransactionContext().getMessageManager().displayInfoMsg(statusMsg);
                }
                VersionNumber serverVersionNumber = VersionNumber.decode(response.getStatus().getValue());
                // set the version number and the sub processor to open app
                getTransactionContext().getEnvironmentVariables().setVersionNumber(serverVersionNumber);
                break;
            case SUCCESS_AUTH_FAILURE:
                statusMsg = "The application exists on the remote server, however, your client credentials were not " +
                        "authenticated successfully.";
                processException(statusMsg);
            case FAILURE_OPENING:
                statusMsg = "A server error occurred while opening " + getTransactionContext().getApplicationId() + ".";
                processException(statusMsg);
            case FAILURE_NON_EXISTENT:
                statusMsg = "The application requested (" + getTransactionContext().getApplicationId() +
                        ") does not exist on the remote server";
                processException(statusMsg);
            case FAILURE_NEWER_VERSION:
            case FAILURE_OLDER_VERSION:
                clientVersion = getTransactionContext().getVersionNumber();
                String serverVersion = response.getStatus().getValue();
                String host = getTransactionContext().getUrl().getHost();
                statusMsg = applicationId + " version " + clientVersion + " is cached " +
                        "but no longer exists on the remote server.\nHowever, another " +
                        "version [" + serverVersion + "] is " +
                        "availble.\n\nClick 'OK' to delete the local " +
                        "version and open the server version.";
                getTransactionContext().getMessageManager().displayInfoMsg(statusMsg);
                // delete non existent version out of the cache
                getTransactionContext().getCacheManager().deleteApplication(host, applicationId, clientVersion);
                // set version to be what the server returned
                getTransactionContext().getEnvironmentVariables().setVersionNumber(VersionNumber.decode(serverVersion));
                break;
        }
    }

    /**
     * Helper method to process SUCCESS.  This initializes the application by
     * initializing the {@link IAPEnvironmentVariable}s into scope
     *
     * @param response {@link OpenApplicationResponse}
     */
    private void initApplication(OpenApplicationResponse response) {
        // get all application scoped vars from the response
        SessionId sessionId = response.getSuccessGroup().getSessionId();
        VersionNumber versionNumber = sessionId.getVersionNumber();
        String viewId = response.getSuccessGroup().getViewInfo().getViewId();
        boolean cacheable = response.getSuccessGroup().getApplicationDescription().isIsCacheable();
        Rating rating = response.getSuccessGroup().getRatingInfo().getRating();

        // register the sessionId and viewId into scope
        Scope scope = getTransactionContext().getScope();
        scope.registerSessionId(sessionId);
        scope.registerViewId(sessionId, viewId);

        // add variables to scope.  The EnvironmentVariables object provides the proxy inteface for adding
        // IAPEnvironmentVariables to scope
        getTransactionContext().getEnvironmentVariables().setVersionNumber(versionNumber, sessionId);
        getTransactionContext().getEnvironmentVariables().setCacheable(cacheable, sessionId);
        getTransactionContext().getEnvironmentVariables().setRating(rating, sessionId);

        // add sessionId and viewId to the transaction context
        getTransactionContext().setSessionId(sessionId);
        getTransactionContext().setViewId(viewId);
    }
}
