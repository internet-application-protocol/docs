/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.view.frames;

import com.inversoft.iap.client.context.FrameContext;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface IAPClientFrame<FC extends FrameContext> {

    /**
     * Returns the {@link FrameContext} for this IAPClientFrame instance
     *
     * @return {@link FrameContext}
     */
    public FC getContext();
}
