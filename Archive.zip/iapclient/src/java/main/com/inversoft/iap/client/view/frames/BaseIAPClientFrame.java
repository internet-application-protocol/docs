/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.view.frames;

import java.awt.*;
import javax.swing.*;
import static javax.swing.UIManager.getSystemLookAndFeelClassName;

import com.inversoft.iap.client.IAPClientProperty;
import com.inversoft.iap.client.context.FrameContext;

/**
 * Base Frame for all IAPClient browser frame types.
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseIAPClientFrame<FC extends FrameContext> extends JFrame implements IAPClientFrame {

    /**
     * The IAPClientContext of this frame
     */
    private FC context;

    public BaseIAPClientFrame(FC context) throws HeadlessException {
        super(context.getFrameTitle());
        // set context
        this.context = context;
        // set look and feel
        setLAF(getSystemLookAndFeelClassName());
        // initialize the frame
        initFrame();
        // configure the components
        configComponents();
    }

    /**
     * Called to save frame dimensions
     *
     * @param IAPClientProperty The IAPClientProperty representing the frame's dimensions
     */
    public void saveFrameDimensions(IAPClientProperty IAPClientProperty) {
        context.getPropertyManager().set(IAPClientProperty,
                Integer.toString(getX()) + "," +
                Integer.toString(getY()) + "," +
                Integer.toString(getWidth()) + "," +
                Integer.toString(getHeight()));
    }

    /**
     * Sets the frame dimensions on initial startup.  This is called at
     * each time a frame is instantiated
     *
     * @param resolutionPercentage represents the size scale with respect to
     * the desktop resolution
     * @param iapClientProperty the IAPClientProperty storing the frame dimensions
     */
    public void setFrameDimensions(int resolutionPercentage, IAPClientProperty iapClientProperty) {
        Dimension screenSize = getToolkit().getScreenSize();
        int width = screenSize.width * resolutionPercentage / 100;
        int height = screenSize.height * resolutionPercentage / 100;
        int x = width / 8;
        int y = height / 8;
        // check for the coords for this particular frame in IAPClientPropertyManager
        // they are stored as a comma delimited String list of the following
        // format: x, y, width, height
        String value = context.getPropertyManager().get(iapClientProperty);
        if (!value.equals(IAPClientProperty.UNDEFINED.getName())) {
            String[] coords = value.split(",");
            x = Integer.parseInt(coords[0]);
            y = Integer.parseInt(coords[1]);
            width = Integer.parseInt(coords[2]);
            height = Integer.parseInt(coords[3]);
        }
        setBounds(x, y, width, height);
    }

    /**
     * Used to set the Look and Feel for a particular JFrame instance.
     *
     * @param laf the look and feel of the window interface
     */
    public void setLAF(String laf) {
        // set native look and feel
        try {
            UIManager.setLookAndFeel(laf);
        } catch (Exception e) {
            // todo should set to a default look and feel versus exiting to console..or sumthin
            // print an error directly to system.out and exit with code 1
            System.err.println("Error setting look and feel: " + e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Returns the frame context for this instance
     *
     * @return the frame context
     */
    public FC getContext() {
        return context;
    }

    /**
     * DO NOT MODIFY THIS CODE.  THIS IS GENERATED DIRECTLY BY NETBEANS'
     * RAD FORM SWING TOOL.  ANY EXTRA COMPONENT CONFIGURATION NEEDED
     * SHOULD BE IMPLEMENTED IN: configComponents() 
     */
    protected abstract void initFrame();

    /**
     * Configures components for a particular frame
     */
    protected abstract void configComponents();
}
