/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.view.frames;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Hashtable;
import javax.swing.*;

import iap.response.Rating;

import com.inversoft.iap.client.IAPClientProperty;
import com.inversoft.iap.client.context.OptionsFrameContext;
import com.inversoft.iap.client.controllers.CacheOptions;
import com.inversoft.iap.client.controllers.listeners.OptionsFrameListener;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class OptionsIAPClientFrame extends BaseIAPClientFrame<OptionsFrameContext> {

    // Variables declaration - do not modify
    private JPanel advancedPanel;
    private JPanel bottomPanel;
    private JPanel cachePanel;
    private JLabel cacheStatus;
    private JButton cancelButton;
    private JPanel generalPanel;
    private JTextField homeUrlField;
    private JLabel homeUrlLabel;
    private JButton homeUrlButton;
    private JComboBox cacheList;
    private JButton okButton;
    private JLabel ratingLabel;
    private JPanel ratingPanel;
    private JTabbedPane tabbedPane;
    private JTextField timeoutField;
    private JLabel timeoutLabel;
    private JPanel timeoutPanel;
    private JPanel topPanel;
    private JPanel advBottomPanel;
    private JSlider ratingSlider;
    private JButton delCacheButton;

    public OptionsIAPClientFrame(OptionsFrameContext context) throws HeadlessException {
        super(context);
    }

    /**
     * DO NOT MODIFY THIS CODE.  THIS IS GENERATED DIRECTLY BY NETBEANS'
     * RAD FORM SWING TOOL.  ANY EXTRA COMPONENT CONFIGURATION NEEDED
     * SHOULD BE IMPLEMENTED IN: configComponents()
     */
    protected void initFrame() {
        topPanel = new JPanel();
        tabbedPane = new JTabbedPane();
        generalPanel = new JPanel();
        homeUrlLabel = new JLabel();
        homeUrlField = new JTextField();
        homeUrlButton = new JButton();
        advancedPanel = new JPanel();
        cachePanel = new JPanel();
        cacheStatus = new JLabel();
        cacheList = new JComboBox();
        timeoutPanel = new JPanel();
        timeoutLabel = new JLabel();
        timeoutField = new JTextField();
        ratingPanel = new JPanel();
        ratingLabel = new JLabel();
        ratingSlider = new JSlider();
        advBottomPanel = new JPanel();
        bottomPanel = new JPanel();
        okButton = new JButton();
        cancelButton = new JButton();
        delCacheButton = new JButton();

        getContentPane().setLayout(new BoxLayout(getContentPane(),
                BoxLayout.Y_AXIS));

        topPanel.setLayout(new GridLayout(1, 0));

        homeUrlLabel.setText("Home URL:");
        generalPanel.add(homeUrlLabel);

        homeUrlField.setMinimumSize(null);
        homeUrlField.setPreferredSize(new Dimension(250, 19));
        generalPanel.add(homeUrlField);

        homeUrlButton.setText("Set To Current View");
        generalPanel.add(homeUrlButton);

        tabbedPane.addTab("General", generalPanel);

        advancedPanel.setLayout(new GridLayout(6, 0));

        cachePanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        cachePanel.setMaximumSize(new Dimension(32767, 30));
        cachePanel.setMinimumSize(new Dimension(32767, 30));
        cachePanel.setPreferredSize(new Dimension(110, 30));
        cacheStatus.setText("Cache Status:");
        cachePanel.add(cacheStatus);

        cachePanel.add(cacheList);

        delCacheButton.setText("Delete Cache");
        cachePanel.add(delCacheButton);

        advancedPanel.add(cachePanel);

        timeoutPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        timeoutPanel.setMaximumSize(new Dimension(32767, 30));
        timeoutPanel.setMinimumSize(new Dimension(32767, 30));
        timeoutPanel.setPreferredSize(new Dimension(110, 30));
        timeoutLabel.setText("Timeout (in seconds):");
        timeoutPanel.add(timeoutLabel);

        timeoutField.setMaximumSize(null);
        timeoutField.setMinimumSize(new Dimension(25, 19));
        timeoutField.setPreferredSize(new Dimension(25, 19));
        timeoutPanel.add(timeoutField);

        advancedPanel.add(timeoutPanel);

        ratingPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        ratingPanel.setMaximumSize(new Dimension(32767, 51));
        ratingPanel.setMinimumSize(new Dimension(41, 51));
        ratingPanel.setPreferredSize(new Dimension(41, 51));
        ratingLabel.setText("Rating:");
        ratingPanel.add(ratingLabel);

        ratingSlider.setPaintTicks(true);
        ratingSlider.setSnapToTicks(true);
        ratingPanel.add(ratingSlider);

        advancedPanel.add(ratingPanel);

        advancedPanel.add(advBottomPanel);

        tabbedPane.addTab("Advanced", advancedPanel);

        topPanel.add(tabbedPane);

        getContentPane().add(topPanel);

        bottomPanel.setMaximumSize(new Dimension(32767, 33));
        bottomPanel.setMinimumSize(new Dimension(10, 33));
        bottomPanel.setPreferredSize(new Dimension(10, 33));
        okButton.setText("OK");
        okButton.setOpaque(false);
        okButton.setPreferredSize(new Dimension(65, 23));
        bottomPanel.add(okButton);

        cancelButton.setText("Cancel");
        bottomPanel.add(cancelButton);

        getContentPane().add(bottomPanel);

        pack();
    }

    public void configComponents() {
        // set the home url text field
        homeUrlField.setText(getContext().getPropertyManager().get(IAPClientProperty.HOME_URL));
        // set the timeout field
        timeoutField.setText(getContext().getPropertyManager().get(IAPClientProperty.TIMEOUT));
        // populate the combo list
        String[] optionList = CacheOptions.getValues();
        cacheList.setModel(new DefaultComboBoxModel(optionList));
        // if the cache status is not in propertyContainer then default
        // to Always Cache - Automatically Upgrade
        if (getContext().getPropertyManager().get(IAPClientProperty.CACHE_STATUS) == null) {
            cacheList.setSelectedIndex(0);
        } else {
            // if it does exist then it has to be one of the above options in
            // the optionList array so iterate through it, find it and set
            // the selected index appropriately
            for (int i = 0; i < optionList.length; i++) {
                String option = optionList[i];
                if (getContext().getPropertyManager().get(IAPClientProperty.CACHE_STATUS).equals(option)) {
                    cacheList.setSelectedIndex(i);
                }
            }
        }
        // Create the rating label table.  the setLabelTable takes
        // a Dictionary object, which HashTable is a subclass of
        Hashtable labelTable = new Hashtable();
        // get the Ratings array from the enum
        Rating[] ratings = Rating.values();
        // set the minimum and maximum rating values.  This is dependent
        // on the number of Ratings returned by Rating.values()
        ratingSlider.setMaximum(ratings.length - 1);
        ratingSlider.setMinimum(0);
        // get the saved Rating value from the IAPClientPropertyManager
        String userRatingString = getContext().getPropertyManager().get(IAPClientProperty.RATING);
        Rating userRating = Rating.valueOf(userRatingString);
        int savedRatingValue = -1;
        // iterate through the ratings array to programmatically set
        // the HashTable with corresponding key-value pairs.  The lowest
        // rating is a value of 0, while the highest rating is a value of
        // Rating[].length - 1
        for (int i = 0; i < ratings.length; i++) {
            Rating rating = ratings[i];
            // while iterating, compare the array rating to the savedRating
            // to map the int value to it's enum value
            if (userRating.equals(rating)) {
                savedRatingValue = i;
            }
            labelTable.put(new Integer(i), new JLabel(rating.toString()));
        }
        ratingSlider.setLabelTable(labelTable);
        ratingSlider.setPaintLabels(true);
        ratingSlider.setValue(savedRatingValue);
        // set window dimensions
        setFrameDimensions(40, IAPClientProperty.OPTION_COORDS);
        // add listeners
        addWindowListener(new OptionsIAPClientFrame.ExitListener());
        okButton.addActionListener(new OptionsFrameListener(this));
        homeUrlButton.addActionListener(new OptionsFrameListener(this));
        cancelButton.addActionListener(new OptionsFrameListener(this));
        delCacheButton.addActionListener(new OptionsFrameListener(this));
    }

    public void close() {
        saveFrameDimensions(IAPClientProperty.OPTION_COORDS);
        setVisible(false);
        dispose();
    }

    public JButton getOkButton() {
        return okButton;
    }

    public JButton getHomeUrlButton() {
        return homeUrlButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public JTextField getHomeUrlField() {
        return homeUrlField;
    }

    public JPanel getGeneralPanel() {
        return generalPanel;
    }

    public JTextField getTimeoutField() {
        return timeoutField;
    }

    public JPanel getAdvancedPanel() {
        return advancedPanel;
    }

    public JComboBox getCacheList() {
        return cacheList;
    }

    public JTabbedPane getTabbedPane() {
        return tabbedPane;
    }

    public JSlider getRatingSlider() {
        return ratingSlider;
    }

    public JButton getDelCacheButton() {
        return delCacheButton;
    }

    /** A listener to attach to the top-level JFrame to provide the
     * ability to quit the frame when exiting the application.
     */
    private class ExitListener extends WindowAdapter {
        public void windowClosing(WindowEvent event) {
            close();
        }
    }
}
