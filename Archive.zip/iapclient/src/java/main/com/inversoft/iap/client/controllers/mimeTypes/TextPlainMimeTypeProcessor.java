/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.mimeTypes;

import java.util.Map;

import com.inversoft.iap.client.context.MimeTypeContextImpl;
import com.inversoft.iap.Data;

/**
 * BaseMimeTypeProcessor to start text/plain content types
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TextPlainMimeTypeProcessor extends BaseMimeTypeProcessor {

    public TextPlainMimeTypeProcessor(MimeTypeContextImpl context) {
        super(context);
    }

    /**
     * {@inheritDoc}
     */
    public void processViewCode(String viewCode) throws MimeTypeProcessorException {
        // stub.  Text/Plain requires no additional processing
    }

    /**
     * {@inheritDoc}
     */
    public void expandVariables(Map<String, Data> expandedVariables) throws MimeTypeProcessorException {
    }
}
