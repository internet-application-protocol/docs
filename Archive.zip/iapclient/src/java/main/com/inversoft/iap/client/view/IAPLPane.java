/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.view;

import java.awt.*;
import javax.swing.*;
import javax.swing.text.ComponentView;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.View;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class IAPLPane extends JEditorPane {

    public IAPLPane() {
        registerEditorKitForContentType("text/iapl",
                "com.inversoft.iap.client.view.IAPLPane$IAPLEditorKit");
        setEditorKitForContentType("text/iapl", new IAPLEditorKit());
        setEditorKit(new IAPLEditorKit());
        setEditable(false);
    }

    // extends the HTMLEditor kit to return a custom view factory that will
    // provide the interface for all custom IAPL tags
    public class IAPLEditorKit extends HTMLEditorKit {

        public IAPLEditorKit() {
            setAutoFormSubmission(false);
        }

        private final class IAPLFactory extends HTMLEditorKit.HTMLFactory {
            /**
             * Creates a view from an element.
             *
             * @param elem the element
             * @return the view
             */
            public View create(Element elem) {
                HTML.Tag tag = (HTML.Tag) (
                        elem.getAttributes().getAttribute(
                                StyleConstants.NameAttribute) );
                if (tag instanceof HTML.UnknownTag) {
                    final String elemName = elem.getName().toUpperCase();
                    IAPLElements iaplElement = null;
                    try {
                        iaplElement = IAPLElements.valueOf(elemName);
                    } catch (IllegalArgumentException iae) {
                        return new ComponentView(elem) {
                            protected Component createComponent() {
                                JLabel msg = new JLabel("Invalid IAPL/HTML " +
                                        "tag specified: " + elemName);
                                return msg;
                            }
                        };
                    }
                    switch (iaplElement) {
                        case IAPL_PERFORMACTION:
                            return new PerformActionComponentView(elem);
                    }
                }
                return super.create(elem);
            }
        }
    }
}
