/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers;

/**
 * <p>Enum class that enumerates the options used to set the
 * user's cache preferences.  If an additional option is needed,
 * its enumeration must be entered here first to enforce type
 * checking and variable accountability.</p>
 *
 * <p>The Enum string is the actual value the user sees on the options
 * window</p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public enum CacheOptions {
    ALWAYS_CACHE_AUTO,

    ALWAYS_CACHE_MANUAL,

    NEVER_CACHE;

    /**
     * Returns an array populated with the Enumeration String values
     *
     * @return String Enumeration value
     */
    public static String[] getValues() {
        String[] values = new String[CacheOptions.values().length];
        for (int i = 0; i < values.length; i++) {
            values[i] = CacheOptions.values()[i].toString();
        }
        return values;
    }
}
