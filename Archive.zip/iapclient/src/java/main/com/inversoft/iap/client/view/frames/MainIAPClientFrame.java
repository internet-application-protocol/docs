/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.view.frames;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;

import com.inversoft.iap.client.IAPClientProperty;
import com.inversoft.iap.client.context.MainFrameContext;
import com.inversoft.iap.client.controllers.listeners.MainFrameListener;
import com.inversoft.iap.client.view.IAPLPane;
import com.inversoft.iap.client.view.ViewContext;

/**
 * Main frame for the IAPClient
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MainIAPClientFrame extends BaseIAPClientFrame<MainFrameContext> {

    /**
     * Context for the current view
     */
    private ViewContext viewContext = new ViewContext(getContext().getContainer(), this);

    private JMenuItem options;
    private JPanel bottomPanel;
    private JMenuItem exit;
    private JMenu file;
    private JButton homeButton;
    private JMenuBar menuBar;
    private JPanel middlePanel;
    private JButton openButton;
    private JProgressBar progressBar;
    private JScrollPane scrollArea;
    private JSeparator separator2;
    private JSeparator separator3;
    private JSeparator seperator1;
    private JMenu tools;
    private JPanel topPanel;
    private JComboBox urlField;
    private JLabel urlLabel;
    private IAPLPane viewPane;
    private JTabbedPane viewTab;
    private JButton stopButton;
    private JPanel leftBottomPanel;
    private JLabel statusBar;
    private JPanel rightBottomPanel;

    public MainIAPClientFrame(MainFrameContext context) throws HeadlessException {
        super(context);
    }

    /**
     * DO NOT MODIFY THIS CODE.  THIS IS AUTO-GENERATED DIRECTLY BY NETBEANS'
     * RAD FORM SWING TOOL.  ANY EXTRA COMPONENT CONFIGURATION NEEDED
     * SHOULD BE IMPLEMENTED IN: configComponents()
     */
    protected void initFrame() {
        seperator1 = new javax.swing.JSeparator();
        topPanel = new javax.swing.JPanel();
        homeButton = new javax.swing.JButton();
        urlLabel = new javax.swing.JLabel();
        urlField = new javax.swing.JComboBox();
        openButton = new javax.swing.JButton();
        stopButton = new javax.swing.JButton();
        separator2 = new javax.swing.JSeparator();
        middlePanel = new javax.swing.JPanel();
        viewTab = new javax.swing.JTabbedPane();
        scrollArea = new javax.swing.JScrollPane();
        viewPane = new IAPLPane();
        separator3 = new javax.swing.JSeparator();
        bottomPanel = new javax.swing.JPanel();
        leftBottomPanel = new javax.swing.JPanel();
        statusBar = new javax.swing.JLabel();
        rightBottomPanel = new javax.swing.JPanel();
        progressBar = new javax.swing.JProgressBar();
        menuBar = new javax.swing.JMenuBar();
        file = new javax.swing.JMenu();
        exit = new javax.swing.JMenuItem();
        tools = new javax.swing.JMenu();
        options = new javax.swing.JMenuItem();

        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(),
                javax.swing.BoxLayout.Y_AXIS));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("browser");
        seperator1.setMaximumSize(new java.awt.Dimension(0, 2));
        seperator1.setMinimumSize(new java.awt.Dimension(0, 2));
        getContentPane().add(seperator1);

        topPanel.setMaximumSize(new java.awt.Dimension(32767, 33));
        topPanel.setPreferredSize(new java.awt.Dimension(274, 33));
        homeButton.setText("Home");
        topPanel.add(homeButton);

        urlLabel.setText("URL:");
        topPanel.add(urlLabel);

        urlField.setEditable(true);
        urlField.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(0, 5, 0, 0)));
        urlField.setMaximumSize(new java.awt.Dimension(32767, 22));
        urlField.setMinimumSize(new java.awt.Dimension(300, 22));
        urlField.setPreferredSize(new java.awt.Dimension(300, 22));

        topPanel.add(urlField);

        openButton.setText("Open");

        topPanel.add(openButton);

        stopButton.setText("Stop");
        topPanel.add(stopButton);

        getContentPane().add(topPanel);

        separator2.setMaximumSize(new java.awt.Dimension(0, 2));
        separator2.setMinimumSize(new java.awt.Dimension(0, 2));
        getContentPane().add(separator2);

        middlePanel.setLayout(new javax.swing.BoxLayout(middlePanel,
                javax.swing.BoxLayout.X_AXIS));

        viewPane.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(0, 0, 0, 0)));
        viewPane.setEditable(false);
        viewPane.setMargin(new java.awt.Insets(0, 0, 0, 0));
        viewPane.setMinimumSize(new java.awt.Dimension(0, 0));
        scrollArea.setViewportView(viewPane);

        viewTab.addTab("Default Application", scrollArea);

        middlePanel.add(viewTab);

        getContentPane().add(middlePanel);

        separator3.setMaximumSize(new java.awt.Dimension(0, 2));
        separator3.setMinimumSize(new java.awt.Dimension(0, 2));
        getContentPane().add(separator3);

        bottomPanel.setLayout(new java.awt.GridLayout(1, 2));

        bottomPanel.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(1, 5, 1, 5)));
        bottomPanel.setFocusable(false);
        bottomPanel.setMaximumSize(new java.awt.Dimension(32767, 20));
        bottomPanel.setMinimumSize(new java.awt.Dimension(20, 20));
        bottomPanel.setPreferredSize(new java.awt.Dimension(110, 20));
        leftBottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));

        statusBar.setText("Status:");
        leftBottomPanel.add(statusBar);

        bottomPanel.add(leftBottomPanel);

        rightBottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 0));

        progressBar.setMaximumSize(new java.awt.Dimension(100, 18));
        progressBar.setMinimumSize(new java.awt.Dimension(100, 18));
        rightBottomPanel.add(progressBar);

        bottomPanel.add(rightBottomPanel);

        getContentPane().add(bottomPanel);

        file.setMnemonic('f');
        file.setText("File");
        file.setActionCommand("Menu");

        exit.setMnemonic('x');
        exit.setText("Exit");
        file.add(exit);

        menuBar.add(file);

        tools.setMnemonic('t');
        tools.setText("Tools");
        options.setMnemonic('o');
        options.setText("Options");
        tools.add(options);

        menuBar.add(tools);

        setJMenuBar(menuBar);

        pack();
    }

    protected void configComponents() {
        String startUrl = getContext().getPropertyManager().get(IAPClientProperty.HOME_URL);
        urlField.setModel(new DefaultComboBoxModel(new String[]{startUrl}));
        //viewTab.addTab("Blank Application", browser);
        // configure progress bar
        progressBar.setMinimum(0);
        progressBar.setMaximum(100);
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);
        // set menu names
        exit.setName("Exit");
        options.setName("Options");
        // add listeners
        stopButton.addActionListener(new MainFrameListener(this));
        openButton.addActionListener(new MainFrameListener(this));
        homeButton.addActionListener(new MainFrameListener(this));
        exit.addActionListener(new MainFrameListener(this));
        options.addActionListener(new MainFrameListener(this));
        file.addActionListener(new MainFrameListener(this));
        viewPane.addHyperlinkListener(new MainFrameListener(this));
        // exit when closing
        addWindowListener(new ExitListener());
        // set frame dimensions
        setFrameDimensions(80, IAPClientProperty.MAIN_COORDS);
    }

    /**
     * Called to load the startup page.  Frame must be visible
     */
    public void loadStartupPage() {
        // make sure the frame is visible
        if (isVisible()) {
            homeButton.doClick();
        }
    }

    public void startProgressBar() {
        openButton.setEnabled(false);
        stopButton.setEnabled(true);
        progressBar.setVisible(true);
    }

    public void stopProgressBar() {
        openButton.setEnabled(true);
        stopButton.setEnabled(false);
        progressBar.setVisible(false);
    }

    public void setStatusBar(String msg) {
        statusBar.setText("Status: " + msg);
    }

    public void setUrlField(String msg) {
        urlField.getModel().setSelectedItem(msg);
    }

    public void setTabTitle(String title) {
        viewTab.setTitleAt(0, title);
    }

    public JComboBox getUrlField() {
        return urlField;
    }

    public JButton getOpenButton() {
        return openButton;
    }

    public JButton getHomeButton() {
        return homeButton;
    }

    public JButton getStopButton() {
        return stopButton;
    }

    public IAPLPane getViewPane() {
        return viewPane;
    }

    public ViewContext getViewContext() {
        return viewContext;
    }

    /** A listener to attach to the top-level JFrame to provide the
     * ability to quit the frame when exiting the application.
     */
    private class ExitListener extends WindowAdapter {
        public void windowClosing(WindowEvent event) {
            saveFrameDimensions(IAPClientProperty.MAIN_COORDS);
            System.exit(0);
        }
    }
}
