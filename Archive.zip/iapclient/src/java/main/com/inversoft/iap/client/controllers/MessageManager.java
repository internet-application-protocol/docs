/**
 * Date Created: Mar 16, 2005
 * Created By:   James Humphrey
 */

package com.inversoft.iap.client.controllers;

import javax.swing.*;

import com.inversoft.iap.client.IAPClientContainer;
import com.inversoft.iap.client.context.DialogBoxFrameContext;
import com.inversoft.iap.client.view.frames.DialogBoxIAPClientFrame;

/**
 * This object manages the displaying of all messages thrown
 * from an exception.  In most cases, these messages will be shown
 * in the browser view area. In some cases, however, non-recoverable
 * errors will occur, in which case the MessageManager will display a dialog
 * box indicating what type of error is causing the error, then shutdown
 * the browser appropriately
 *
 * @author James Humphrey
 * @version 1.0
 */

public final class MessageManager {

    DialogBoxFrameContext context;

    public MessageManager(IAPClientContainer container) {
        context = new DialogBoxFrameContext(container, "Dialog Box");
    }

    /**
     * Processes messages that should be displayed in the view area
     *
     * @param viewPane the JEditorPane
     * @param e Exception that occurred
     * @param msg message thrown
     */
    public void displayViewMsg(JEditorPane viewPane, Exception e,
                                      String msg) {
        String formattedMsg = formatMsg(e, msg);
        System.out.println(formattedMsg);
        viewPane.setText(formattedMsg);
        DialogBoxIAPClientFrame dialogBox = new DialogBoxIAPClientFrame(context);
        dialogBox.open(formattedMsg, JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Processes messages that cause application failure.  It will display
     * an informative dialog box indicating to the user what occurred and
     * then shutdown the browser accordingly
     *
     * @param e Exception that occurred
     * @param msg msg thrown
     */
    public void displayErrorMsg(Exception e, String msg) {
        DialogBoxIAPClientFrame dialogBox = new DialogBoxIAPClientFrame(context);
        String formattedMsg = formatMsg(e, msg);
        dialogBox.open(formattedMsg, JOptionPane.ERROR_MESSAGE);
        System.out.println(formattedMsg);
        e.printStackTrace();
        System.exit(-1);
    }

    /**
     * Used to display informative messages to the user
     *
     * @param msg msg thrown
     */
    public void displayInfoMsg(String msg) {
        DialogBoxIAPClientFrame dialogBox = new DialogBoxIAPClientFrame(context);
        dialogBox.open(msg, JOptionPane.INFORMATION_MESSAGE);
    }

    private String formatMsg(Exception e, String msg) {
        return msg + "\n\nReason:\n" + e.getMessage();
    }
}
