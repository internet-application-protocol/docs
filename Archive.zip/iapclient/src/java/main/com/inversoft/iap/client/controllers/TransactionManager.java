/**
 * Date Created: Jun 8, 2005
 * Created By:   James Humphrey
 */

package com.inversoft.iap.client.controllers;

import java.net.URL;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import iap.TransportType;
import static iap.TransportType.*;
import iap.VersionNumber;
import iap.response.Rating;
import iap.response.DataScope;

import com.inversoft.iap.Data;
import com.inversoft.iap.IAPTransaction;
import com.inversoft.iap.IAPTransactionException;
import com.inversoft.iap.IAPTransactionManager;
import com.inversoft.iap.MimeType;
import com.inversoft.iap.DataType;
import static com.inversoft.iap.MimeType.getContentType;
import static com.inversoft.iap.MimeType.getMimeType;
import com.inversoft.iap.client.IAPClientContainer;
import com.inversoft.iap.client.IAPClientProperty;
import static com.inversoft.iap.client.IAPClientProperty.CACHE_STATUS;
import static com.inversoft.iap.client.IAPClientProperty.RATING;
import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.client.context.MimeTypeContextImpl;
import static com.inversoft.iap.client.controllers.CacheOptions.NEVER_CACHE;
import com.inversoft.iap.client.controllers.mimeTypes.MimeTypeProcessor;
import com.inversoft.iap.client.controllers.mimeTypes.MimeTypeProcessorException;
import com.inversoft.iap.client.controllers.mimeTypes.MimeTypeProcessorFactory;
import com.inversoft.iap.client.controllers.transport.Processor;
import com.inversoft.iap.client.controllers.transport.ProcessorException;
import com.inversoft.iap.client.controllers.transport.ProcessorFactory;
import com.inversoft.iap.client.model.EnvironmentVariables;
import com.inversoft.iap.client.model.Scope;
import com.inversoft.iap.client.view.ViewContext;
import com.inversoft.iap.response.FetchDataStatus;
import com.inversoft.iap.response.OpenApplicationStatus;
import com.inversoft.iap.response.OpenViewStatus;
import com.inversoft.iap.response.PerformActionStatus;
import com.inversoft.iap.response.ReconnectSessionStatus;
import com.inversoft.iap.transport.Response;
import com.inversoft.iap.transport.SessionId;


/**
 * Manages Transactions
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TransactionManager {

    private IAPTransactionManager tManager = new IAPTransactionManager();

    private ProcessorFactory processorFactory;

    private Scope scope;

    private IAPClientContainer container;

    private ConnectionManager connectionManager;

    public TransactionManager(IAPClientContainer container) {
        this.container = container;
        scope = container.get(Scope.class);
        processorFactory = container.get(ProcessorFactory.class);
    }

    /**
     * Called to do IAP Transactions
     *
     * @param viewContext the context of the current view
     * @param url the current url
     * @param type the type of the transaction
     * @throws TransactionException thrown if there are problems encountered or transaction failures
     */
    public void doTransaction(ViewContext viewContext, URL url, TransportType type) throws TransactionException {
        // init transaction
        String tId = tManager.createTransactionID();
        IAPTransaction iapTransaction = tManager.createTransaction(tId, type);
        SessionId sessionId = viewContext.getSessionId();   // will be null if OpenApp
        String viewId = viewContext.getViewId();            // will be null if OpenApp

        // open the connection
        try {
            connectionManager = new ConnectionManager(container, type);
            connectionManager.openConnection(url);
        } catch (ConnectionException ce) {
            if (!connectionManager.isUserDisconnected()) {
                //todo this needs fixed
                throw new TransactionException(ce.getMessage());
            }
        }

        // init Env. Vars
        EnvironmentVariables envVars = EnvironmentVariables.get(scope, url, sessionId);

        // instantiate the context for this Transaction
        ApplicationTransactionContext context = new ApplicationTransactionContext(container,
                iapTransaction, envVars, sessionId, viewId);

        // try the transaction and finally stop the transaction
        try {
            doTransportPing(context, type);
        } catch (TransportException e) {
            throw new TransactionException(e.getMessage());
        } finally {
            stopTransaction();
        }

        // set this transaction context into the view context
        viewContext.setTransactionContext(context);
    }

    /**
     * Performs Transport Pings.  A Transport Ping is a complete request/response cycle.  A complete cycle consists
     * of creating the appropriate transport request, sending that request to the server, and then processing
     * the transport response returned from the server.  Multiple Transport Pings are possible (and usually standard)
     * during a single Transaction.
     *
     * @param context {@link ApplicationTransactionContext}
     * @throws TransportException thrown during the transport ping
     */
    private void doTransportPing(ApplicationTransactionContext context, TransportType type) throws TransportException {
        // do the transport ping. The ping returns the status code returned by
        // the response during the Transport processing
        try {
            System.out.println("Transaction Type [" + context.getIAPTransaction().getType().toString() + "]");
            System.out.println("Transaction Stage [" + context.getIAPTransaction().getStage().toString() + "]");

            Processor processor = processorFactory.build(context);
            Response response = connectionManager.ping(processor.createRequest());
            String statusCode = processor.processResponse(response);

            // if the Transport is successful then process according to the IAPType
            switch (type) {
                case OPEN_APPLICATION:
                    doOpenApplicationTransport(context, statusCode);
                    break;
                case OPEN_VIEW:
                    doOpenView(context, statusCode);
                    break;
                case FETCH_DATA:
                    doFetchData(context, statusCode);
                    break;
                case PERFORM_ACTION:
                    doPerformAction(context, statusCode);
                    break;
                case RECONNECT_SESSION:
                    doReconnectSession(context, statusCode);
                    break;
            }
        } catch (ProcessorException e) {
            throw new TransportException(e.getMessage());
        } catch (ConnectionException e) {
            throw new TransportException(e.getMessage());
        } catch (MimeTypeProcessorException e) {
            throw new TransportException(e.getMessage());
        }
    }

    /**
     * Used to do sub transports.   Sub Transport Pings explicitly changes the {@link IAPTransaction} stage
     * to the subTransportType.  This is private because Sub Transport Pings can only be done within the
     * context of the same transaction
     *
     * @param context ApplicationTransactionContext
     * @param subTransportType the sub transport type
     */
    private void doSubTransport(ApplicationTransactionContext context, TransportType subTransportType)
            throws TransportException {
        try {
            System.out.println("Transitioning IAPTransaction.type == " +
                    context.getIAPTransaction().getType().toString() + " from stage [" +
                    context.getIAPTransaction().getStage() + "] to ["+ subTransportType+ "]");
            context.getIAPTransaction().setStage(subTransportType);
            doTransportPing(context, subTransportType);
        } catch (IAPTransactionException e) {
            throw new AssertionError("Invalid IAPTransaction stage transition from type [" +
                    context.getIAPTransaction().getType() + "] to stage [" + subTransportType + "]");
        }
    }

    /**
     * Used when Opening an IAP Application
     *
     * @param context the {@link ApplicationTransactionContext}
     * @throws TransportException if any problems occur during transport
     */
    private void doOpenApplicationTransport(ApplicationTransactionContext context, String statusCode)
            throws MimeTypeProcessorException, TransportException {
        OpenApplicationStatus status = OpenApplicationStatus.resolve(statusCode);
        switch (status) {
            case SUCCESS_NEWER_VERSION:
            case FAILURE_NEWER_VERSION:
            case FAILURE_OLDER_VERSION:
                doSubTransport(context, OPEN_VIEW);
                break;
            case SUCCESS:
                VersionNumber versionNumber = context.getVersionNumber();
                String host = context.getUrl().getHost();
                String applicationId = context.getApplicationId();

                // check if application rating is restricted
                Rating rating = context.getEnvironmentVariables().getRating();
                int ratingOrdinal = rating.ordinal();
                String userRatingString = context.getPropertyManager().get(RATING);
                Rating userRating = Rating.valueOf(userRatingString);
                int userRatingOrdinal = userRating.ordinal();
                if (ratingOrdinal > userRatingOrdinal) {
                    String msg = "The current browser user is restricted from viewing the " +
                            "following Internet Application rating: [" + rating.toString() + "]";
                    System.out.println(msg);
                    throw new TransportException(msg);
                } else {
                    // if it's not cached and and it's not cacheable and the user isn't caching then do the open view
                    boolean cacheable = context.getEnvironmentVariables().isCacheable();
                    boolean isAppVerCached = context.getCacheManager().isApplicationVersionCached(host, applicationId,
                            versionNumber);
                    IAPClientProperty cacheStatus = CACHE_STATUS;
                    String neverCache = CacheOptions.NEVER_CACHE.toString();
                    if (context.getPropertyManager().get(cacheStatus).equals(neverCache)) {
                        doSubTransport(context, OPEN_VIEW);
                    } else if (!cacheable) {
                        doSubTransport(context, OPEN_VIEW);
                    } else if (!isAppVerCached) {
                        doSubTransport(context, OPEN_VIEW);
                    } else {
                        String viewId = context.getViewId();
                        try {
                            byte[] encodedViewCode = context.getCacheManager().load(applicationId, versionNumber, viewId,
                                    host);
                            context.setEncodedViewCode(encodedViewCode);
                            String viewFileExt = context.getCacheManager().getViewFileExt(host,
                                    applicationId, versionNumber, viewId);
                            String contentType = getContentType(viewFileExt);
                            processMimeType(context, getMimeType(contentType), encodedViewCode);
                        } catch (CacheException ce) {
                            context.getMessageManager().displayInfoMsg("There was a problem loading [" + viewId + "]" +
                                    "version [" + versionNumber.toString() + "] from cache.  Retrieving server " +
                                    "version ");
                            doSubTransport(context, OPEN_VIEW);
                        }
                    }
                }
        }
    }

    /**
     * Used to perform Open View Request/Responses
     *
     * @param context {@link ApplicationTransactionContext}
     * @throws MimeTypeProcessorException thrown if there is a problem during the process
     */
    private void doOpenView(ApplicationTransactionContext context, String statusCode)
            throws MimeTypeProcessorException, TransportException {
        OpenViewStatus status = OpenViewStatus.resolve(statusCode);
        switch (status) {
            case SUCCESS:
                String contentType = context.getContentType();
                byte[] encodedViewCode = context.getEncodedViewCode();
                String applicationId = context.getApplicationId();
                VersionNumber versionNumber = context.getVersionNumber();
                String viewId = context.getViewId();
                String cacheStatus = context.getPropertyManager().get(CACHE_STATUS);
                String host = context.getUrl().getHost();

                // process mime type
                processMimeType(context, getMimeType(contentType), encodedViewCode);

                // if caching is enabled and the application can be cached then cache it
                if (!cacheStatus.equals(NEVER_CACHE.toString()) &&
                        context.getEnvironmentVariables().isCacheable()) {
                    context.getCacheManager().save(host, applicationId, versionNumber, viewId, encodedViewCode);
                }
                break;
            case SESSION_EXPIRATION:
                doSubTransport(context, RECONNECT_SESSION);
                break;
        }
    }

    private void doFetchData(ApplicationTransactionContext context, String statusCode) throws TransportException {
        FetchDataStatus status = FetchDataStatus.resolve(statusCode);
        switch (status) {
            case SUCCESS:
                List<Data> dataList = context.getDataBodyList();
                Map<String, Data> variablesToExpand = new HashMap<String, Data>();
                SessionId sessionId = context.getSessionId();
                String viewId = context.getViewId();
                Scope scope = context.getScope();

                // iterate on the Data objects in the data list to decode
                // the data into Strings and populate the map
                for (Data data : dataList) {
                    String name = data.getKey();
                    DataType dataType = data.getType();
                    DataScope dataScope = data.getScope();
                    int arrayDepth = data.getArrayDepth();
                    Object value = data.getValue();
                    // add to scope.
                    if (dataScope.equals(DataScope.APPLICATION)) {
                        scope.addApplicationScopeData(sessionId, name, value, dataType, arrayDepth);
                    } else if (dataScope.equals(DataScope.VIEW)) {
                        scope.addViewScopeData(sessionId, viewId, name, value, dataType, arrayDepth);
                    }
                    variablesToExpand.put(name, data);
                }
                context.setVariablesToExpand(variablesToExpand);
                break;
            case SESSION_EXPIRATION:
                doSubTransport(context, RECONNECT_SESSION);
                break;
        }
    }

    private void doPerformAction(ApplicationTransactionContext context, String statusCode)
            throws MimeTypeProcessorException, TransportException {
        PerformActionStatus status = PerformActionStatus.resolve(statusCode);
        switch (status) {
            case SUCCESS:
                // extract some variables from the transaction context
                String applicationId = context.getApplicationId();
                String viewId = context.getViewId();
                String host = context.getUrl().getHost();
                VersionNumber versionNumber = context.getVersionNumber();
                SessionId sessionId = context.getSessionId();
                Scope scope = context.getScope();

                assert(sessionId != null) : ("sessionId == null");

                List<Data> dataList = context.getDataBodyList();

                // iterate on the Data objects in the data list to decode
                // the data and populate the Scope
                for (Data data : dataList) {
                    String name = data.getKey();
                    DataType dataType = data.getType();
                    int arrayDepth = data.getArrayDepth();
                    Object value = data.getValue();
                    if (data.getScope().equals(DataScope.VIEW)) {
                        scope.addViewScopeData(sessionId, viewId, name, value, dataType, arrayDepth);
                    } else {
                        scope.addApplicationScopeData(sessionId, name, value, dataType, arrayDepth);
                    }
                }
                // if the application is cached (and caching is enabled), then load
                // the view code from the CacheManager.  If not, do an OPEN_VIEW ping.
                // Also, if the cacheManager throws an exception while loading the view
                // code from disk, then revert to an OPEN_VIEW ping.
                boolean isAppVerCached = context.getCacheManager().isApplicationVersionCached(host, applicationId,
                        versionNumber);
                IAPClientProperty cacheStatus = CACHE_STATUS;
                String neverCache = NEVER_CACHE.toString();
                boolean cacheable = context.getEnvironmentVariables().isCacheable();
                if (context.getPropertyManager().get(cacheStatus).equals(neverCache)) {
                    doSubTransport(context, OPEN_VIEW);
                } else if (!cacheable) {
                    doSubTransport(context, OPEN_VIEW);
                } else if (!isAppVerCached) {
                    doSubTransport(context, OPEN_VIEW);
                } else {
                    try {
                        byte[] encodedViewCode = context.getCacheManager().load(applicationId, versionNumber, viewId,
                                host);
                        String viewFileExt = context.getCacheManager().getViewFileExt(host, applicationId,
                                versionNumber, viewId);
                        String contentType = getContentType(viewFileExt);
                        // put the content type into the transaction context
                        context.setContentType(contentType);
                        // process mime type
                        processMimeType(context, getMimeType(contentType), encodedViewCode);
                    } catch (CacheException ce) {
                        doSubTransport(context, OPEN_VIEW);
                    }
                }
                break;
            case SESSION_EXPIRATION:
                doSubTransport(context, RECONNECT_SESSION);
                break;
        }
    }

    /**
     * Performs Reconnect Session Transports.  This is called if a session has expired or to refresh the session
     *
     * @param context {@link ApplicationTransactionContext}
     * @param statusCode the status code
     */
    private void doReconnectSession(ApplicationTransactionContext context, String statusCode)
            throws TransportException {
        ReconnectSessionStatus status = ReconnectSessionStatus.resolve(statusCode);
        switch (status) {
            case SUCCESS:
                TransportType transactionType = context.getIAPTransaction().getType();
                if (!transactionType.equals(RECONNECT_SESSION)) {
                    doSubTransport(context, transactionType);
                }
                break;
        }
    }

    /**
     * Processes the mime type of the view code
     *
     * @param context {@link ApplicationTransactionContext}
     * @param mimeType {@link MimeType}
     * @param encodedViewCode the encoded view from either cache or the response transport
     * @throws MimeTypeProcessorException thrown during the mime type processing
     */
    private void processMimeType(ApplicationTransactionContext context, MimeType mimeType, byte[] encodedViewCode)
            throws MimeTypeProcessorException, TransportException {
        MimeTypeContextImpl mimeTypeContext = new MimeTypeContextImpl(context, mimeType);
        MimeTypeProcessor mimeTypeProcessor = new MimeTypeProcessorFactory().build(mimeTypeContext);
        // decode the transport value
        String viewCode = ByteBuffer.wrap(encodedViewCode).asCharBuffer().toString();
        context.setViewCode(viewCode);
        mimeTypeProcessor.processViewCode(context.getViewCode());
        if (mimeType.equals(MimeType.TEXT_IAPL) && !context.getDataRequestList().isEmpty()) {
            doSubTransport(context, FETCH_DATA);
            // expand all variables from the values returned from the fetch data response
            mimeTypeProcessor.expandVariables(context.getVariablesToExpand());
        }
    }

    /**
     * Delegates to {@link ConnectionManager} stop a transaction.
     */
    public void stopTransaction() {
        if (connectionManager != null) {
            connectionManager.disconnect();
        }
    }

    /**
     * Thread to run Transactions in.  Instaites with a {@link Runnable}
     */
    public static class TransactionThread extends Thread {

        /**
         * the target to run as the transaction
         */
        private Runnable target;

        public TransactionThread(Runnable target) {
            super(target);
            this.target = target;
        }

        /**
         * {@inheritDoc}
         */
        public void run() {
            target.run();
        }
    }
}
