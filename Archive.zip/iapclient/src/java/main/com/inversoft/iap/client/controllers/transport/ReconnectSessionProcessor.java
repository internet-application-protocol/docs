/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.response.ReconnectSessionStatus;
import com.inversoft.iap.transport.ReconnectSessionRequest;
import com.inversoft.iap.transport.ReconnectSessionResponse;
import com.inversoft.util.StringTools;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ReconnectSessionProcessor extends BaseProcessor<ReconnectSessionRequest, ReconnectSessionResponse>{

    public ReconnectSessionProcessor(ApplicationTransactionContext transactionContext) {
        super(transactionContext);
    }

    /**
     * {@inheritDoc}
     */
    public ReconnectSessionRequest createRequest() {
        ReconnectSessionRequest request = new ReconnectSessionRequest();
        // set the SessionId
        request.setSessionId(getTransactionContext().getSessionId());
        return request;
    }

    /**
     * {@inheritDoc}
     */
    public void processStatus(ReconnectSessionResponse response, String statusMsg, String statusCode)
            throws ProcessorException {
        ReconnectSessionStatus status = ReconnectSessionStatus.resolve(statusCode);
        if (StringTools.isEmpty(statusMsg)) {
            statusMsg = status.toString();
        }
        switch (status) {
            case FAILURE:
                processGeneralFailure(statusMsg);
        }
    }
}