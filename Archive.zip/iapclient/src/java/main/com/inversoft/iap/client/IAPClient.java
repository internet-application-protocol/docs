/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.xml.bind.JAXBException;

import com.inversoft.iap.client.context.MainFrameContext;
import com.inversoft.iap.client.view.frames.MainIAPClientFrame;
import com.inversoft.iap.net.IapURLStreamHandlerFactory;
import com.inversoft.util.JAXBTools;

/**
 * The main entry point for running IAPClient.  This class handles some minor
 * initialization calls and then instantiates the appropriate BaseFrame
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class IAPClient {
    private static final Logger logger = Logger.getLogger(IAPClient.class.getName());
    private IAPClientConfig config;

    public IAPClient(IAPClientConfig config) {
        this.config = config;
    }

    /**
     * Runs the browser
     */
    public void run() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MainFrameContext context = new MainFrameContext(config.getContainer(), "IAPClient - Knowname");
                MainIAPClientFrame mainFrame = new MainIAPClientFrame(context);
                mainFrame.setVisible(true);
                mainFrame.loadStartupPage();
            }
        });
    }

    /**
     * Main method to run the browser
     *
     * @param args
     */
    public static void main(String[] args) {
        String cacheDirectory = System.getProperty("user.home") + "/.iapclient/cache";
        try {
            // Initialize the TransportFactory for the configuration and the transports
            JAXBTools.addObjectFactory(com.inversoft.iap.transport.TransportFactory.class);

            IAPClientConfig config = new IAPClientConfig(new File(cacheDirectory), new IapURLStreamHandlerFactory());
            new IAPClient(config).run();
        } catch (ConfigurationException ie) {
            logger.log(Level.SEVERE, "Configuration exception", ie);
            System.exit(1);
        } catch (JAXBException e) {
            logger.log(Level.SEVERE, "Unable to create JAXBContext", e);
            System.exit(1);
        }

    }
}
