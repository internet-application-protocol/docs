/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.listeners;

import com.inversoft.iap.client.view.frames.IAPClientFrame;

/**
 * Base abstract interface for all concrete {@link IAPClientListener} object
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseIAPClientListener<F extends IAPClientFrame> implements IAPClientListener {

    /**
     * Frame for this instance
     */
    private F frame;

    protected BaseIAPClientListener(F frame) {
        this.frame = frame;
    }

    /**
     * {@inheritDoc}
     */
    public F getFrame() {
        return frame;
    }
}
