/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers;

import java.io.IOException;
import java.net.SocketException;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import iap.TransportType;

import com.inversoft.iap.client.IAPClientContainer;
import com.inversoft.iap.client.IAPClientProperty;
import com.inversoft.iap.client.IAPClientPropertyManager;
import com.inversoft.iap.client.controllers.transport.TransportIOHandler;
import com.inversoft.iap.client.controllers.transport.TransportIOHandlerException;
import com.inversoft.iap.net.IapURLConnection;
import com.inversoft.iap.transport.BaseResponse;
import com.inversoft.iap.transport.Request;
import com.inversoft.iap.transport.Response;

/**
 * ConnectionManager is called by an ActionListener implementor to manage
 * an {@link IapURLConnection}.  ConnectionManager spawns a {@link TransportPing} to perform
 * the request/response cycles on a separate Threads.  This is so that
 * the IAPClient doesn't 'freeze' during the transaction processing
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ConnectionManager {

    private IAPClientContainer container;

    private TransportType transactionType;

    private IapURLConnection iapConnection;

    private boolean userDisconnected = false;

    ExecutorService threadPool = Executors.newFixedThreadPool(1);

    public ConnectionManager(IAPClientContainer container, TransportType transactionType) {
        this.container = container;
        this.transactionType = transactionType;
    }

    /**
     * instantiates an IapURLConnection object which establishes a
     * connection to the TCP/IP socket
     *
     * @throws ConnectionException if a problem is ecountered while opening
     * the socket
     */
    public void openConnection(URL url) throws ConnectionException {
        try {
            iapConnection = (IapURLConnection) url.openConnection();
            // open the transactionConnection
            iapConnection.connect();
            System.out.println("Opened socket to [" + url.toString() + "]");
            // set the timeout (in miliseconds) defined in IAPClientProperty
            String to = container.get(IAPClientPropertyManager.class).get(IAPClientProperty.TIMEOUT);
            int timeout = Integer.parseInt(to) * 1000;
            iapConnection.getSocket().setSoTimeout(timeout);
        } catch (SocketException se) {
            System.out.println(se.getMessage());
            throw new ConnectionException(se.getMessage());
        } catch (IOException ioe) {
            System.out.println(userDisconnected);
            System.out.println(ioe.getMessage());
            throw new ConnectionException(ioe.getMessage());
        }
    }

    /**
     * Closes the IapURLConnection
     */
    private void closeConnection() {
        try {
            threadPool.shutdown();
            iapConnection.close();
            System.out.println("Closed socket to [" + iapConnection.getURL().toString() + "]");
        } catch (IOException ioe) {
            throw new AssertionError("Unable to close transactionConnection [" + ioe.getMessage() + "]");
        }
    }

    /**
     * Sends a {@link Request} to the server and returns the {@link BaseResponse} to the caller
     *
     * @param request {@link Request}
     * @return {@link BaseResponse}
     */
    public Response ping(Request request) throws ConnectionException {
        assert(iapConnection != null) : "iapConnection == null";
        assert(iapConnection.isConnected()) : "no connection to socket";
        try {
            TransportPing transportPing = new TransportPing(request);
            Future<Response> response = threadPool.submit(transportPing);
            return response.get();
        } catch (InterruptedException ie) {
            throw new ConnectionException(ie.getMessage());
        } catch (ExecutionException ee) {
            throw new ConnectionException(ee.getMessage());
        }
    }

    /**
     * Used to disconnect a connection
     */
    public void disconnect() {
        System.out.println("User disconnected");
        userDisconnected = true;
        // if connected, close it
        if (iapConnection.getSocket() != null) {
            if (iapConnection.getSocket().isConnected()) {
                closeConnection();
            }
        }
    }

    /**
     * Returns the {@link IapURLConnection} for this instance
     *
     * @return {@link IapURLConnection}
     */
    public IapURLConnection getIapConnection() {
        return iapConnection;
    }

    /**
     * Returns true is user disconnected, false otherwise
     *
     * @return true if user disconnected, false otherwise
     */
    public boolean isUserDisconnected() {
        return userDisconnected;
    }

    /**
     * This class implements Callable and delgates to {@link TransportIOHandler} to write a {@link Request}
     * and read a {@link BaseResponse} from the {@link java.net.Socket} contained in the {@link IapURLConnection}. An IAP
     * Ping is a complete request/response layer established between client and server.
     */
    private class TransportPing implements Callable<Response> {

        private Request request;

        public TransportPing(Request request) {
            assert (request != null) : "request == null";
            this.request = request;
        }

        /**
         * Computes a result, or throws an exception if unable to do so.
         *
         * @return {@link BaseResponse} Transport object
         * @throws TransportIOHandlerException thrown if any problems were encountered during transport IO
         */
        public Response call() throws TransportIOHandlerException {
            TransportIOHandler handler = new TransportIOHandler(iapConnection, transactionType);
            handler.write(request);
            return handler.read();
        }

        /**
         * Used to set the {@link Request} for {@link TransportIOHandler} processing
         *
         * @param request {@link Request}
         */
        public void setRequest(Request request) {
            this.request = request;
        }
    }
}
