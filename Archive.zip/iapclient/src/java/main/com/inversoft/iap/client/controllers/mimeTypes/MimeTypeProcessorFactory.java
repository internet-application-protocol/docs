/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.mimeTypes;

import com.inversoft.iap.MimeType;
import com.inversoft.iap.client.context.MimeTypeContextImpl;

/**
 * // TODO this class will eventually have to be moved to an xml config file so that additional mime types
 * // can be added as plugins
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MimeTypeProcessorFactory {

    public MimeTypeProcessor build(MimeTypeContextImpl context) {
        MimeTypeProcessor mimeTypeProcessor = null;
        MimeType type = context.getMimeType();
        assert (type != null) : "mime type == null";
        if (type.equals(MimeType.TEXT_HTML)) {
            mimeTypeProcessor = new TextHTMLMimeTypeProcessor(context);
        } else if (type.equals(MimeType.TEXT_IAPL)) {
            mimeTypeProcessor = new TextIAPLMimeTypeProcessor(context);
        } else if (type.equals(MimeType.TEXT_PLAIN)) {
            mimeTypeProcessor = new TextPlainMimeTypeProcessor(context);
        }

        return mimeTypeProcessor;
    }
}
