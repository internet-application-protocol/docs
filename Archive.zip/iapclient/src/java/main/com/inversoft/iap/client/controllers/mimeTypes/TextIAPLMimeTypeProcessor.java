/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.mimeTypes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.inversoft.iap.Data;
import com.inversoft.iap.client.context.MimeTypeContextImpl;
import com.inversoft.iap.client.model.Scope;
import com.inversoft.iap.transport.DataRequest;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.util.variable.ExpanderException;
import com.inversoft.util.variable.MapExpanderStrategy;
import com.inversoft.util.variable.VariableExpander;

/**
 * BaseMimeTypeProcessor to process text/iapl content types
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TextIAPLMimeTypeProcessor extends BaseMimeTypeProcessor {

    public TextIAPLMimeTypeProcessor(MimeTypeContextImpl context) {
        super(context);
    }

    /**
     * {@inheritDoc}
     */
    public void processViewCode(String viewCode) throws MimeTypeProcessorException {
        MimeTypeContextImpl context = getMimeTypeContext();
        SessionId sessionId = context.getTransactionContext().getSessionId();
        Scope scope = context.getScope();
        String viewId = context.getTransactionContext().getViewId();

        // get all the variables in the view code
        List<String> varsToFetch = VariableExpander.findVariables(viewCode);

        if (varsToFetch != null) {
            // get all scoped data.
            Set<Data> allScopedData = scope.getAllScopedData(sessionId, viewId);
            // iterate on all scoped data.  Any scoped data contained
            // in the list needs to get removed so they aren't
            // pushed to the remote server via the Fetch Data Request
            for (Data data : allScopedData) {
                if (varsToFetch.contains(data.getKey())) {
                    varsToFetch.remove(data.getKey());
                }
            }
            // if there are still variables to fetch (after having removed those already in scope),
            // then build a list of DataRequest objects.  This list will be used to create the Fetch Data Request
            if (!varsToFetch.isEmpty()) {
                List<DataRequest> dataRequestList = new ArrayList<DataRequest>();
                for (String data : varsToFetch) {
                    DataRequest dataRequest = new DataRequest();
                    dataRequest.setName(data);
                    dataRequestList.add(dataRequest);
                }
                context.getTransactionContext().setDataRequestList(dataRequestList);
            }
        }
    }

    /**
     * <p>This method maps Scope Data objects to the
     * VariableExpander through the MapExpanderStrategy.  This includes any
     * Data that is contained within the Scope that is in this
     * ApplicationTransactionContext scope</p>
     *
     * <p>This method is also reponsible for removing view scoped data out
     * of the Scope after it has been used.  This is so that subsequent
     * MimeTypeProcessing associated to the same viewId and same sessionId
     * will not result in stale client data.  The result of removing the data
     * after every expansion provides the ability to push the view code
     * variables to the remote server via Fetch Data Transactions</p>
     *
     *
     * @param variablesToExpand the variables to expand
     * @throws MimeTypeProcessorException if the VariableExpander throws an exception during the expansion process
     */
    public void expandVariables(Map<String, Data> variablesToExpand)
            throws MimeTypeProcessorException {
        MimeTypeContextImpl context = getMimeTypeContext();
        Scope scope = context.getTransactionContext().getScope();
        SessionId sessionId = context.getTransactionContext().getSessionId();
        String viewId = context.getTransactionContext().getViewId();
        Set<Data> allScopedData = scope.getAllScopedData(sessionId, viewId);
        System.out.println("All Scoped Data: " + allScopedData.toString());
        System.out.println("Variables returned from the Fetch Data Response: " + variablesToExpand.toString());
        // loop through all the scoped variables and add the variable
        // name and value to the expanded variable list
        for (Data data : allScopedData) {
            variablesToExpand.put(data.getKey(), data);
        }
        MapExpanderStrategy strategy = new MapExpanderStrategy(variablesToExpand);
        try {
            String viewCode = VariableExpander.expand(context.getTransactionContext().getViewCode(), strategy);
            context.getTransactionContext().setViewCode(viewCode);
        } catch (ExpanderException ee) {
            throw new AssertionError("Error occurred during " +
                    "the variable expansion process [" + ee.getMessage() + "]");
        }
        // remove the current viewId scope from the Scope so that
        // subsequent MimeTypeProcessing of the same view and same sessionId
        // will result in pushing the view code variables to the remote
        // server via Fetch Data Requests.
        // The consequence of not doing this will have the effect of
        // causing client side Data to become 'stale'.
        scope.deleteAllViewData(sessionId, viewId);
    }
}
