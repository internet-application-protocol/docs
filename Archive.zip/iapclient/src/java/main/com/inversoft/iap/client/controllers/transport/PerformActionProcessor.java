/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import iap.request.ActionType;
import iap.response.DataScope;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataBody;
import com.inversoft.iap.DataType;
import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.response.PerformActionStatus;
import com.inversoft.iap.transport.ActionInfo;
import com.inversoft.iap.transport.PerformActionRequest;
import com.inversoft.iap.transport.PerformActionResponse;
import com.inversoft.iap.transport.ViewInfo;
import com.inversoft.util.StringTools;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class PerformActionProcessor extends BaseProcessor<PerformActionRequest, PerformActionResponse> {

    public PerformActionProcessor(ApplicationTransactionContext transactionContext) {
        super(transactionContext);
    }

    /**
     * {@inheritDoc}
     */
    public PerformActionRequest createRequest() {
        PerformActionRequest request = new PerformActionRequest();
        String urlQuery = getTransactionContext().getUrl().getQuery();
        // now split the urlQuery up into a nameValuePairs array.  Each
        // nameValuePair is delimited by the ampersand (&) sign.
        // The data array will be indexes of 'name=value' pairs.
        String actionId = "";
        String viewId = "";
        String[] nameValuePairs = urlQuery.split("&");
        request.setDataBody(new DataBody());
        // iterate on the data array to fill the Data object
        for (String nameValuePair1 : nameValuePairs) {
            String[] nameValuePair = nameValuePair1.split("=");
            String name = nameValuePair[0];
            String value = "";
            // if a value exists for the name then set it
            if (nameValuePair.length == 2) {
                value = nameValuePair[1];
            }
            // intercept the actionId and viewId to obtain the values and
            // to exclude them from being part of the DataBody request
            if (name.equals("actionId")) {
                System.out.println(value);
                actionId = value;
                continue;
            } else if (name.equals("viewId")) {
                System.out.println(value);
                viewId = value;
                continue;
            }
            request.getDataBody().getAllData().add(new Data(name, value, DataType.STRING, 0, DataScope.VIEW));
        }
        // if the actionId and the viewId are empty set then throw an exception
        if (StringTools.isEmpty(actionId) || StringTools.isEmpty(viewId)) {
            throw new AssertionError("actionId and/or viewId invalid.  " +
                    "Unable to process Perform Action Transaction.");
        }
        getTransactionContext().setViewId(viewId);
        request.setActionInfo(new ActionInfo());
        request.getActionInfo().setActionId(actionId);
        request.getActionInfo().setActionType(ActionType.SYNCHRONOUS);
        request.setSessionId(getTransactionContext().getSessionId());
        request.setViewInfo(new ViewInfo());
        request.getViewInfo().setViewId(viewId);
        return request;
    }

    /**
     * {@inheritDoc}
     */
    public void processStatus(PerformActionResponse response, String statusMsg, String statusCode)
            throws ProcessorException {
        PerformActionStatus status = PerformActionStatus.resolve(statusCode);
        if (StringTools.isEmpty(statusMsg)) {
            statusMsg = status.toString();
        }
        switch (status) {
            case SUCCESS:
                getTransactionContext().setDataBodyList(response.getDataBody().getAllData());
                break;
            case FAILURE_SESSION_ID:
                processSessionIdFailure(statusMsg);
            case SESSION_EXPIRATION:
                processSessionExpiration(statusMsg);
                break;
            case FAILURE:
                processGeneralFailure(statusMsg);
        }
    }
}
