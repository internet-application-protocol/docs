/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.model;

/**
 * Thrown by {@link Scope} if there is a {@link iap.response.DataScope} conflict when adding
 * {@link com.inversoft.iap.Data} to scope
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class InvalidScopeException extends Exception {
    /**
     * {@inheritDoc}
     */
    public InvalidScopeException() {
        super();
    }

    /**
     * {@inheritDoc}
     */
    public InvalidScopeException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public InvalidScopeException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public InvalidScopeException(Throwable cause) {
        super(cause);
    }
}
