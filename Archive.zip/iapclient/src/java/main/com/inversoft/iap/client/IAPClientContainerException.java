/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

/**
 * Thrown from the {@link IAPClientContainer}
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class IAPClientContainerException extends Exception {
    /**
     * {@inheritDoc}
     */
    public IAPClientContainerException() {
        super();
    }
    /**
     * {@inheritDoc}
     */
    public IAPClientContainerException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public IAPClientContainerException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public IAPClientContainerException(Throwable cause) {
        super(cause);
    }
}
