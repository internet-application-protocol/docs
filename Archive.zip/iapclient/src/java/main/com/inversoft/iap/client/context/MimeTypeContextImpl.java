/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.context;

import com.inversoft.iap.MimeType;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MimeTypeContextImpl extends BaseIAPClientContext implements MimeTypeContext {

    private MimeType mimeType;

    private ApplicationTransactionContext transactionContext;

    public MimeTypeContextImpl(ApplicationTransactionContext transactionContext, MimeType mimeType) {
        super(transactionContext.getContainer());
        this.mimeType = mimeType;
        this.transactionContext = transactionContext;
    }

    /**
     * {@inheritDoc}
     */
    public MimeType getMimeType() {
        return mimeType;
    }

    /**
     * {@inheritDoc}
     */
    public ApplicationTransactionContext getTransactionContext() {
        return transactionContext;
    }
}
