/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.mimeTypes;

import java.util.Map;

import com.inversoft.iap.client.context.MimeTypeContext;
import com.inversoft.iap.client.context.MimeTypeContextImpl;
import com.inversoft.iap.Data;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface MimeTypeProcessor {

    /**
     * Returns the {@link MimeTypeContextImpl} for this instance
     *
     * @return {@link MimeTypeContext}
     */
    public MimeTypeContextImpl getMimeTypeContext();

    /**
     * Processes the view code
     *
     * @param viewCode the view code from either cache or the transport object
     */
    public void processViewCode(String viewCode) throws MimeTypeProcessorException;

    /**
     * Expands any variables contained in the view code
     *
     * @param variablesToExpand the variable to expand in the view code
     */
    public void expandVariables(Map<String, Data> variablesToExpand) throws MimeTypeProcessorException;
}
