/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ProcessorException extends Exception {

    /**
     * {@inheritDoc}
     */
    public ProcessorException() {
        super();
    }

    /**
     * {@inheritDoc}
     */
    public ProcessorException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public ProcessorException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public ProcessorException(Throwable cause) {
        super(cause);
    }
}
