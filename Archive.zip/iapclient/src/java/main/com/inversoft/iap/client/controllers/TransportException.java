/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class TransportException extends Exception {

    /**
     * {@inheritDoc}
     */
    public TransportException() {
    }

    /**
     * {@inheritDoc}
     */
    public TransportException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public TransportException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public TransportException(Throwable cause) {
        super(cause);
    }
}
