/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.context;

import com.inversoft.iap.client.IAPClientContainer;
import com.inversoft.iap.client.IAPClientPropertyManager;
import com.inversoft.iap.client.controllers.CacheManager;
import com.inversoft.iap.client.controllers.MessageManager;
import com.inversoft.iap.client.controllers.TransactionManager;
import com.inversoft.iap.client.model.Scope;

/**
 * Interface for all {@link com.inversoft.iap.client.IAPClient} context objects
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface IAPClientContext {
    /**
     * Returns the IoC Container associated to this client context
     *
     * @return IoC Container for this Client context
     */
    public IAPClientContainer getContainer();

    /**
     * Returns the Scope associated to this client context
     *
     * @return the Scope
     */
    public Scope getScope();

    /**
     * Returns the {@link  TransactionManager} associated to this client context
     *
     * @return the {@link TransactionManager}
     */
    public TransactionManager getTransactionManager();

    /**
     * Returns the {@link IAPClientPropertyManager} associated to this client context
     *
     * @return the {@link IAPClientPropertyManager}
     */
    public IAPClientPropertyManager getPropertyManager();

    /**
     * Returns the {@link CacheManager} associated to this client context
     *
     * @return the {@link CacheManager}
     */
    public CacheManager getCacheManager();

    /**
     * Returns the {@link MessageManager} associated to this client context
     *
     * @return {@link MessageManager}
     */
    public MessageManager getMessageManager();
}
