/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

import java.io.File;
import java.net.URL;
import java.net.URLStreamHandlerFactory;

import com.inversoft.iap.client.controllers.CacheManager;
import com.inversoft.iap.client.controllers.MessageManager;
import com.inversoft.iap.client.controllers.TransactionManager;
import com.inversoft.iap.client.controllers.transport.ProcessorFactory;
import com.inversoft.iap.client.model.Scope;

/**
 * Configuration Object for all {@link IAPClient} Browser instances
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class IAPClientConfig {

    /**
     * Location of the cache directory to store views
     */
    private File cacheDirectory;

    /**
     * {@link URLStreamHandlerFactory} to build the appropriate {@link java.net.URLStreamHandler} object
     */
    private URLStreamHandlerFactory handlerFactory;

    /**
     * IoC Container
     */
    private IAPClientContainer container = new IAPClientContainer();

    public IAPClientConfig(File cacheDirectory, URLStreamHandlerFactory handlerFactory)
            throws ConfigurationException {
        this.cacheDirectory = cacheDirectory;
        this.handlerFactory = handlerFactory;
        init();
    }

    /**
     * Initializes
     *
     * @throws ConfigurationException thrown if there are any problems during configuration
     */
    private void init() throws ConfigurationException {
        try {
            URL.setURLStreamHandlerFactory(handlerFactory);
        } catch (Error e) {
            // if this is caught, then the factory is already defined, in which case do nothing.
        } catch (SecurityException se) {
            throw new ConfigurationException(se.getMessage());
        }

        // populate IoC container
        try {
            // add MessageManager
            container.register(MessageManager.class, true, new Object[] {container});
            // add CacheManager
            container.register(CacheManager.class, true,
                    new Object[] {cacheDirectory, container.get(MessageManager.class)});
            // add Scope
            container.register(Scope.class, true);
            // add IAPClientPropertyManager
            container.register(IAPClientPropertyManager.class, true);
            // add transaction processor factory
            container.register(ProcessorFactory.class, true);
            // add transaction manager
            container.register(TransactionManager.class, true, new Object[] {container});
        } catch (IAPClientContainerException icce) {
            throw new ConfigurationException("Unable to configure IoC container successfully: " + icce.getMessage());
        }
    }

    /**
     * Returns the Cache Directory for this {@link IAPClient} instance
     *
     * @return cache directory
     */
    public File getCacheDirectory() {
        return cacheDirectory;
    }

    /**
     * Returns the {@link URLStreamHandlerFactory} for this {@link IAPClient} instance
     *
     * @return
     */
    public URLStreamHandlerFactory getHandlerFactory() {
        return handlerFactory;
    }

    /**
     * Returns the {@link IAPClientContainer} for this instance
     *
     * @return
     */
    public IAPClientContainer getContainer() {
        return container;
    }
}
