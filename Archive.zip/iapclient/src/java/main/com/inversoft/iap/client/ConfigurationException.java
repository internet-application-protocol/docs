/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class ConfigurationException extends Exception {
    /**
     * {@inheritDoc}
     */
    public ConfigurationException() {
        super();
    }
    /**
     * {@inheritDoc}
     */
    public ConfigurationException(String message) {
        super(message);
    }
    /**
     * {@inheritDoc}
     */
    public ConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
    /**
     * {@inheritDoc}
     */
    public ConfigurationException(Throwable cause) {
        super(cause);
    }
}
