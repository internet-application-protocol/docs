/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.context;

import com.inversoft.iap.client.IAPClientContainer;
import com.inversoft.iap.client.IAPClientPropertyManager;
import com.inversoft.iap.client.controllers.CacheManager;
import com.inversoft.iap.client.controllers.MessageManager;
import com.inversoft.iap.client.controllers.TransactionManager;
import com.inversoft.iap.client.model.Scope;

/**
 * Base {@link IAPClientContext} implementor
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseIAPClientContext implements IAPClientContext {

    IAPClientContainer container;

    protected BaseIAPClientContext(IAPClientContainer container) {
        this.container = container;
    }

    /**
     * {@inheritDoc}
     */
    public IAPClientContainer getContainer() {
        return container;
    }

    /**
     * {@inheritDoc}
     */
    public Scope getScope() {
        return container.get(Scope.class);
    }

    /**
     * {@inheritDoc}
     */
    public TransactionManager getTransactionManager() {
        return container.get(TransactionManager.class);
    }

    /**
     * {@inheritDoc}
     */
    public IAPClientPropertyManager getPropertyManager() {
        return container.get(IAPClientPropertyManager.class);
    }

    /**
     * {@inheritDoc}
     */
    public CacheManager getCacheManager() {
        return container.get(CacheManager.class);
    }

    /**
     * {@inheritDoc}
     */
    public MessageManager getMessageManager() {
        return container.get(MessageManager.class);
    }
}
