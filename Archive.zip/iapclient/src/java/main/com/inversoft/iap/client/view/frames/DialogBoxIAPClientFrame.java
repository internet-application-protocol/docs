/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.view.frames;

import java.awt.*;
import static javax.swing.JOptionPane.showMessageDialog;

import com.inversoft.iap.client.context.DialogBoxFrameContext;

/**
 * <p>Parent class for all IAPClient Dialog Boxes.  These are generally used
 * by the MessageManager to display the following types of messages
 * to the user.  This frame is not made visible, only the dialog box
 * gets displayed to the desktop environment</p>
 * <ul>
 * <li>Error</li>
 * <li>Warning</li>
 * <li>Question</li>
 * <li>Info</li>
 * </ul>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class DialogBoxIAPClientFrame extends BaseIAPClientFrame<DialogBoxFrameContext> {
    /**
     * Message that appears in the window bar
     */
    private final String windowBarMsg = "IAPClient Message";

    public DialogBoxIAPClientFrame(DialogBoxFrameContext context) throws HeadlessException {
        super(context);
    }

    /**
     * called to open the dialog box with the supplied message.  The window
     * message is usually but not necessarily an Exception.getMessage()
     *
     * @param windowBodyMsg the message to display in the dialog box
     */
    public void open(String windowBodyMsg, int messageType) {
        // open up the dialog box
        showMessageDialog(this, windowBodyMsg,
                windowBarMsg, messageType);
    }

    protected void initFrame() {
        // stub
    }

    protected void configComponents() {
        // stub

    }
}
