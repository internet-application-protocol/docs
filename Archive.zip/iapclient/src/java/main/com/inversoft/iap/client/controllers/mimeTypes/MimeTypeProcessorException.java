/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.mimeTypes;

/**
 * Thrown if an exception occurs during BaseMimeTypeProcessor processing
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MimeTypeProcessorException extends Exception {

    /**
     * {@inheritDoc}
     */
    public MimeTypeProcessorException() {
        super();
    }

    /**
     * {@inheritDoc}
     */
    public MimeTypeProcessorException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public MimeTypeProcessorException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public MimeTypeProcessorException(Throwable cause) {
        super(cause);
    }
}
