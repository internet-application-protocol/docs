/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.listeners;

import java.awt.event.ActionListener;
import javax.swing.event.HyperlinkListener;

import com.inversoft.iap.client.view.frames.IAPClientFrame;

/**
 * Interface for all concrete IAPClientListeners
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public interface IAPClientListener<F extends IAPClientFrame> extends ActionListener, HyperlinkListener {

    /**
     * Returns the concrete {@link IAPClientFrame} for this Listener
     *
     * @return {@link IAPClientFrame}
     */
    public F getFrame();
}
