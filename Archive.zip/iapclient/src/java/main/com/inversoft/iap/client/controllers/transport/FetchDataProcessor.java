/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import java.util.List;

import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.response.FetchDataStatus;
import com.inversoft.iap.transport.DataRequest;
import com.inversoft.iap.transport.DataRequestBody;
import com.inversoft.iap.transport.FetchDataRequest;
import com.inversoft.iap.transport.FetchDataResponse;
import com.inversoft.util.StringTools;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class FetchDataProcessor extends BaseProcessor<FetchDataRequest, FetchDataResponse> {

    public FetchDataProcessor(ApplicationTransactionContext transactionContext) {
        super(transactionContext);
    }

    /**
     * {@inheritDoc}
     */
    public FetchDataRequest createRequest() {
        FetchDataRequest request = new FetchDataRequest();
        // set the SessionId
        request.setSessionId(getTransactionContext().getSessionId());
        // set the data
        DataRequestBody dataRequestBody = new DataRequestBody();
        List<DataRequest> dataRequestList = getTransactionContext().getDataRequestList();
        dataRequestBody.getDataRequest().addAll(dataRequestList);
        request.setDataRequestBody(dataRequestBody);
        return request;
    }

    /**
     * {@inheritDoc}
     */
    protected void processStatus(FetchDataResponse response, String statusMsg, String statusCode) throws ProcessorException {
        FetchDataStatus status = FetchDataStatus.resolve(statusCode);
        if (StringTools.isEmpty(statusMsg)) {
            statusMsg = status.toString();
        }
        switch (status) {
            case SUCCESS:
                getTransactionContext().setDataBodyList(response.getDataBody().getAllData());
                break;
            case SESSION_EXPIRATION:
                processSessionExpiration(statusMsg);
                break;
            case FAILURE_SESSION_ID:
                processSessionIdFailure(statusMsg);
            case FAILURE:
                processGeneralFailure(statusMsg);
        }
    }

}
