/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.transport;

import com.inversoft.iap.client.context.ApplicationTransactionContext;
import com.inversoft.iap.transport.BaseResponse;
import com.inversoft.iap.transport.Request;
import com.inversoft.util.StringTools;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseProcessor<B extends Request, C extends BaseResponse>
        implements Processor<B, C> {

    private ApplicationTransactionContext transactionContext;

    protected BaseProcessor(ApplicationTransactionContext transactionContext) {
        this.transactionContext = transactionContext;
    }

    /**
     * {@inheritDoc}
     */
    public String processResponse(C response) throws ProcessorException {
        String statusMsg = response.getStatus().getValue();
        String statusCode = response.getStatus().getCode();
        processStatus(response, statusMsg, statusCode);

        return statusCode;
    }

    /**
     * {@inheritDoc}
     */
    public ApplicationTransactionContext getTransactionContext() {
        return transactionContext;
    }

    /**
     * Factors down all 2.* (failure) status code exceptions
     *
     * @param statusMsg the message to display
     * @throws ProcessorException thrown on 2.* failure status codes
     */
    protected void processException(String statusMsg) throws ProcessorException {
        throw new ProcessorException("Transaction Failed: " + statusMsg);
    }

    /**
     * Processes sessionId failures
     *
     * @throws ProcessorException thrown when the sessionId fails
     */
    protected void processSessionIdFailure(String statusMsg) throws ProcessorException {
        if (StringTools.isEmpty(statusMsg)) {
            statusMsg = "Invalid SessionId";
        }
        processException(statusMsg);
    }

    /**
     * Processes a session expiration
     */
    protected void processSessionExpiration(String statusMsg) {
        if (StringTools.isEmpty(statusMsg)) {
            statusMsg = "Session Expired";
        }
        getTransactionContext().getMessageManager().displayInfoMsg("Transaction Failed: " + statusMsg);
    }

    /**
     * Processes general failure messages
     *
     * @param statusMsg the status message returned from the server.  Can be empty string/null
     * @throws ProcessorException thrown when general failure
     */
    protected void processGeneralFailure(String statusMsg) throws ProcessorException {
        if (StringTools.isEmpty(statusMsg)) {
            statusMsg = "General Failure";
        }
        processException(statusMsg);
    }

    /**
     * Processes the {@link com.inversoft.iap.response.Status} associated to this Transport processor
     *
     * @param response the {@link BaseResponse}
     * @throws ProcessorException thrown on failure
     */
    protected abstract void processStatus(C response, String statusMsg, String statusCode) throws ProcessorException;
}