/**
 * Copyright 2003, 2004 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import iap.VersionNumber;

import static com.inversoft.util.FileTools.delTree;
import static com.inversoft.util.FileTools.getFileExtension;

/**
 * <p>The CacheManager manages the cache of Application views.  The
 * CacheManager is nothing more than a liason between the browser
 * and the local hard disk to control reading and writing of
 * application view directories and files</p>
 *
 * <p>Thew views themselves are stored in the following directory hierarchy:</p>
 *
 * <p>cache/cacheId/viewId</p>
 *
 * <p>where cacheId = host + "_" + applicationId + "_" + versionNumber.toString()</p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public final class CacheManager {

    /**
     * Instance of the MessageManager
     */
    private MessageManager messageManager;

    /**
     * Cache directory on disk
     */
    private File cacheDir;

    public CacheManager(File cacheDir, MessageManager messageManager) {
        this.cacheDir = cacheDir;
        this.messageManager = messageManager;
        init();
    }

    /**
     * Insures the Cache Directory exists.  If it doesn't exist, it creates it.  If it can't create it
     * then it displays an informative message to the user indicating such
     */
    private void init() {
        if (!cacheDir.exists()) {
            try {
                if (!cacheDir.mkdirs()) {
                    messageManager.displayErrorMsg(new IOException(""),
                            "Please create a cache directory in the following " +
                            "location: " + cacheDir.getAbsolutePath() +
                            "\nThis directory will be used as the View " +
                            "cache and is for testing purpoes only");
                }
            } catch (SecurityException se) {
                messageManager.displayErrorMsg(se, "Security Manager " +
                        "restricts writes to '" +
                        cacheDir.getAbsolutePath() + "'");
            }
        }
    }
    
    /**
     * Loads an application view from disk
     * 
     * @param applicationId the application name
     * @param versionNumber the application versionNumber.toString()
     * @param viewId the application's viewId
     * @param host the IP host
     * @return returns a ByteBuffer object which contains the encoded view
     * @throws CacheException Throws a Cache Exception if the View can't be
     * found, the UTF-8 Encoding type is unsupported, or there was an i/o
     * error while reading from it
     */ 
    public byte[] load(String applicationId, VersionNumber versionNumber,
                            String viewId, String host) throws CacheException {
        String cacheId = getCacheId(host, applicationId, versionNumber);
        File viewFile = new File(cacheDir.getAbsolutePath() + "/" +
                cacheId + "/" + viewId);
        byte[] b = new byte[(int) viewFile.length()];
        try {
            FileInputStream fileStream = new FileInputStream(viewFile);
            fileStream.read(b);
            fileStream.close();
        } catch (FileNotFoundException fnfe) {
            throw new CacheException("Unable to locate file: " +
                    viewFile.getAbsolutePath());
        } catch (UnsupportedEncodingException uee) {
            throw new CacheException("The UTF-8 encoding type is not " +
                    "supported for the following file: " +
                    viewFile.getAbsolutePath());
        } catch (IOException ioe) {
            throw new CacheException("Error while loading file: " +
                    viewFile.getAbsolutePath());
        }

        return b;
    }

    /**
     * Writes a view to disk. This is accomplished by creating the cacheId
     * directory and then storing the view on disk in a file named by the
     * viewId.
     *
     * @param host the IP host
     * @param applicationId the name of the application
     * @param versionNumber the versionNumber.toString() of the application
     * @param viewId the name of the view
     * @param viewCode the view contents
     * @return true if the save was successful, false otherwise
     */
    public boolean save(String host, String applicationId, VersionNumber versionNumber,
                            String viewId, byte[] viewCode) {
        // booleans to verify directory and file existence
        boolean isSaved = false;
        boolean cacheIdDirExists = false;
        // instantiate the File objects
        String cacheId = getCacheId(host, applicationId, versionNumber);
        File cacheIdDir = new File(cacheDir.getAbsolutePath() + "/" +
                cacheId);
        File viewFile = new File(cacheIdDir.getAbsolutePath() + "/" + viewId);
        // make sure the view isnt already cached.
        if (!viewFile.isFile()) {
            // check to see if it already exists
            if (!cacheIdDir.exists()) {
                // if it doesn't exist, then try and create it
                if(!cacheIdDir.mkdir()) {
                    // if we cant create it, display an informative message
                    // to the user indicating the reason why it couldn't
                    messageManager.displayInfoMsg("The following application " +
                            "is unable to be cached: " + applicationId +
                            "\nReason: Unable to create cache " +
                            "directory hierarchy.  Please check write" +
                            " permissions on the following directory: " +
                            cacheDir.getAbsolutePath());
                } else {
                    cacheIdDirExists = true;
                }
            } else if (cacheIdDir.isDirectory()) { // make sure it's a dir
                cacheIdDirExists = true;
            }
            // This double check is to insure that if we tried to create it,
            // it got created.  It's possible that for some reason
            // or other it wasn't created successfull, in which case
            // we need to skip this block of code
            if (cacheIdDirExists) {
                // create the view under UTF-8 encoding
                try {
                    viewFile.createNewFile();
                    FileOutputStream fileStream =
                            new FileOutputStream(viewFile);
                    fileStream.write(viewCode);
                    fileStream.close();
                    // set the isSaved boolean
                    isSaved = true;
                } catch (IOException ioe) {
                    // if we can't create it, display an informative
                    // message to the user indicating the reason why
                    messageManager.displayInfoMsg("The following " +
                            "application view is unable to be cached: " +
                            viewId + "\nReason: Unable to " +
                            "write view information to file.  " +
                            "Please check write permissions on the " +
                            "following directory: " +
                            cacheIdDir.getAbsolutePath());
                }
            }
        }
        return isSaved;
    }

    /**
     * Returns true if the view in question is cached on disk
     *
     * @param host the IP host
     * @param applicationId the applicationId (application name)
     * @param versionNumber the versionNumber.toString() number of the application
     * @param viewId the viewId of the application (view name, file name)
     * @return boolean true/false depending on if it's cached
     */
    public boolean isViewCached(String host, String applicationId, VersionNumber versionNumber,
                                   String viewId) {
        String cacheId = getCacheId(host, applicationId, versionNumber);
        File viewFile = new File(cacheDir.getAbsolutePath() + "/" +
                cacheId + "/" + viewId);
        return viewFile.isFile();
    }

    /**
     * Checks disk cache to see if an application is cached.  This method is
     * not versionNumber.toString() number dependent and will return true if any directory
     * name within the cache directory contains the host
     * and applicationId specified
     *
     * @param host the IP host
     * @param applicationId the application name
     * @return boolean true/false
     */
    public boolean isApplicationCached(String host, String applicationId) {
        boolean isAppCached = false;
        File[] appDirs = cacheDir.listFiles();
        for (File appDir : appDirs) {
            String appDirName = appDir.getName();
            if (appDirName.contains(host + "_" + applicationId)) {
                isAppCached = true;
            }
        }
        return isAppCached;
    }

    /**
     * Checks disk cache to see if an application versionNumber.toString() is cached.  This
     * method is dependent on the versionNumber.toString() so it specifically checks if
     * an application versionNumber.toString() exists and is a directory in cache
     *
     * @param host the IP host
     * @param applicationId the application name
     * @return boolean true/false
     */
    public boolean isApplicationVersionCached(String host,
                                                     String applicationId,
                                                     VersionNumber versionNumber) {
        String cacheId = getCacheId(host, applicationId, versionNumber);
        File appDir = new File(cacheDir.getAbsolutePath() + "/" + cacheId);
        // returns true if and only if the file is exists and is a directory
        return appDir.isDirectory();
    }

    /**
     * <p>A cacheId is a concatentation of the host, applicationId, and
     * versionNumber.toString() and uniquely identifies each application versionNumber.toString()
     * residing in the cache. CacheIds are in the following format:</p>
     *
     * <p>host_applicationId_version/</p>
     *
     * @param host the IP host
     * @param applicationId the applicationId (application name)
     * @param versionNumber versionNumber.toString() number of the app
     * @return returns the cacheId
     */
    private String getCacheId(String host, String applicationId,
                               VersionNumber versionNumber) {
        return (host + "_" + applicationId + "_" + versionNumber.toString());
    }

    /**
     * Returns the most current application versionNumber.toString() cached on disk.
     *
     * @param host the IP host
     * @param applicationId application name
     * @return String most current versionNumber.toString() number
     */
    public VersionNumber getMostCurrentVersion(String host, String applicationId) {
        // stores the most current versionNumber.toString() number
        String mostCurrentVersion = null;
        // array of all dirs in the cacheDir
        File[] appDirs = cacheDir.listFiles();
        // hostApp is the host_applicationId_ portion of the
        // cacheId
        String hostApp = host + "_" + applicationId + "_";
        // stores the list of versionNumber.toString() numbers associated to the hostApp
        List<String> versionList = new ArrayList<String>();
        // iterate on all the directories in the cacheDir, filter out
        // the ones that contain the hostApp and then populate
        // the versionList with the versions
        for (File appDir : appDirs) {
            String appDirName = appDir.getName();
            if (appDirName.contains(hostApp)) {
                String[] appDirNameSplit = appDirName.split(hostApp);
                versionList.add(appDirNameSplit[1]);
            }
        }
        // if the list isnt empty, find the most current versionNumber.toString()
        if (!versionList.isEmpty()) {
            // set the most current versionNumber.toString() to the first index
            mostCurrentVersion = versionList.get(0);
            // if the list size is greater than 1, then iterate to find
            // the most current versionNumber.toString() number
            if (versionList.size() > 1) {
                for (int i = 1; i < versionList.size(); i++) {
                    VersionNumber thisNumber = VersionNumber.decode(versionList.get(i));
                    VersionNumber mostCurrentVersionNumber = VersionNumber.decode(mostCurrentVersion);
                    if (thisNumber.compareTo(mostCurrentVersionNumber) == 1) {
                        mostCurrentVersion = thisNumber.toString();
                    }
                }
            }
        }
        return VersionNumber.decode(mostCurrentVersion);
    }

    /**
     * Used to delete a particular application and it's associated
     * view files from the cache
     *
     * @param host the IP host
     * @param applicationId the application name
     * @param versionNumber the application versionNumber.toString()
     */
    public void deleteApplication(String host, String applicationId,
                                  VersionNumber versionNumber) {
        String cacheId = getCacheId(host, applicationId, versionNumber);
        File cacheIdDir = new File(cacheDir.getAbsolutePath() + "/" +
                cacheId);
        // make sure it exists first
        if (cacheIdDir.exists()) {
            // now 'rm -rf' it
            delTree(cacheIdDir);
        }
    }

    /**
     * Returns the file extension of a desired view.
     *
     * @param host the IP host
     * @param applicationId the application name
     * @param versionNumber the application versionNumber.toString()
     * @param viewId the application viewId
     * @return String file extension
     */
    public String getViewFileExt(String host, String applicationId,
                                        VersionNumber versionNumber, String viewId) {
        String cacheId = getCacheId(host, applicationId, versionNumber);
        File viewFile = new File(cacheDir.getAbsolutePath() + "/" +
                cacheId + "/" + viewId);
        return getFileExtension(viewFile);
    }

    /**
     * Deletes the entire cache
     */
    public void deleteCache() {
        File[] appDirs = cacheDir.listFiles();
        for (File appDir : appDirs) {
            delTree(appDir);
        }
    }

    /**
     * Returns the {@link File} representing the cache directory on local disk
     *
     * @return {@link File}
     */
    public File getCacheDir() {
        return cacheDir;
    }
}
