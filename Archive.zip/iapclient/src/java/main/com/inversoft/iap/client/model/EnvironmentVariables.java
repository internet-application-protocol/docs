/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.model;

import java.net.URL;

import iap.VersionNumber;
import iap.response.Rating;

import com.inversoft.iap.Data;
import com.inversoft.iap.DataType;
import static com.inversoft.iap.IAPEnvironmentVariable.*;
import com.inversoft.iap.transport.SessionId;
import com.inversoft.util.StringTools;

/**
 * <p>This object is a Proxy to handle collaborations between
 * {@link com.inversoft.iap.client.context.TransactionContext} dependent objects and {@link Scope} when referencing
 * any variable defined by the {@link com.inversoft.iap.IAPEnvironmentVariable} enumeration.  Ultimately, this object
 * is just a modified Java Bean that provides getters and setters for interfacing with
 * {@link com.inversoft.iap.IAPEnvironmentVariable} enumerated variables in any given Internet Application scope.</p>
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class EnvironmentVariables {
    private Scope scope;

    private URL url;

    private String host;

    private int port;

    private String applicationId;

    private VersionNumber versionNumber;

    private Rating rating;

    private boolean cacheable = false;

    public EnvironmentVariables(Scope scope) {
        this.scope = scope;
    }

    /**
     * Used to get the EnvironmentVariable object.  This method will in instantiate with parameters obtained from
     * the current scope, which are mapped through the {@link com.inversoft.iap.IAPEnvironmentVariable} Enumeration.
     * If a particular parameter has not yet been initialized into scope (ie, the application has not yet been opened),
     * then EnvironmentVariables will be instantiated with that particular parameter set to null.
     *
     * @param scope {@link Scope}
     * @param url {@link Scope}
     * @param sessionId {@link SessionId}.  Can and will be null if the application hasn't yet been opened
     * @return EnvironmentVariable object
     */
    public static EnvironmentVariables get(Scope scope, URL url, SessionId sessionId) {
        // only sessionId can be null
        assert (scope != null) : "scope == null";
        assert (url != null) : "url == null";

        EnvironmentVariables envVars = new EnvironmentVariables(scope);

        // set the url
        envVars.setUrl(url, sessionId);

        // get versionNumber, cacheable, and rating from scope (if it exists)
        if (sessionId != null) {
            // set version number
            Data versionNumberData = scope.getApplicationData(sessionId, VERSION_NUMBER.toString());
            if (versionNumberData != null) {
                VersionNumber versionNumber = VersionNumber.decode(versionNumberData.getValue().toString());
                envVars.setVersionNumber(versionNumber);
            }
            // set cacheable
            Data cacheableData = scope.getApplicationData(sessionId, CACHEABLE.toString());
            if (cacheableData != null) {
                boolean cacheable = (Boolean) cacheableData.getValue();
                envVars.setCacheable(cacheable);
            }
            // set rating
            Data ratingData = scope.getApplicationData(sessionId, RATING.toString());
            if (ratingData != null) {
                Rating rating = Rating.valueOf(ratingData.getValue().toString());
                envVars.setRating(rating);
            }
        }

        return envVars;
    }

    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        setUrl(url, null);
    }

    public void setUrl(URL url, SessionId sessionId) {
        this.url = url;
        this.host = url.getHost();
        this.port = url.getPort();
        // url.getFile() returns a partial URL containing all characters
        // after the host, including the forward slash and parameter list
        applicationId = url.getFile().replaceFirst("/", "").split("\\?")[0];
        // if after the string parse application Id is empty, then set it to '/' which is the default application
        if (StringTools.isEmpty(applicationId)) {
            applicationId = "/";
        }
        addToScope(sessionId, URL.toString(), url.toString(), URL.getDataType());
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public VersionNumber getVersionNumber() {
        return versionNumber;
    }

    public Rating getRating() {
        return rating;
    }

    public boolean isCacheable() {
        return cacheable;
    }

    public void setCacheable(boolean cacheable) {
        setCacheable(cacheable, null);
    }

    public void setCacheable(boolean cacheable, SessionId sessionId) {
        this.cacheable = cacheable;
        addToScope(sessionId, CACHEABLE.toString(), cacheable, CACHEABLE.getDataType());
    }

    public void setVersionNumber(VersionNumber versionNumber) {
        setVersionNumber(versionNumber, null);
    }

    public void setVersionNumber(VersionNumber versionNumber, SessionId sessionId) {
        this.versionNumber = versionNumber;
        addToScope(sessionId, VERSION_NUMBER.toString(), versionNumber.toString(), VERSION_NUMBER.getDataType());
    }

    public void setRating(Rating rating) {
        setRating(rating, null);
    }

    public void setRating(Rating rating, SessionId sessionId) {
        this.rating = rating;
        addToScope(sessionId, RATING.toString(), rating.toString(), RATING.getDataType());
    }

    /**
     * Adds an Environment Variable to scope
     *
     * @param sessionId {@link SessionId}
     * @param name the key to the {@link com.inversoft.iap.Data}
     * @param value the value of the {@link com.inversoft.iap.Data}
     * @param dataType {@link com.inversoft.iap.DataType} of {@link com.inversoft.iap.Data}
     */
    private void addToScope(SessionId sessionId, String name, Object value, DataType dataType) {
        if (sessionId != null) {
            scope.addApplicationScopeData(sessionId, name, value, dataType);
        }
    }
}