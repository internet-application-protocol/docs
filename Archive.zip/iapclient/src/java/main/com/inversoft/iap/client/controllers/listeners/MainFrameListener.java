/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.controllers.listeners;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.*;
import javax.swing.event.HyperlinkEvent;
import javax.swing.text.Element;
import javax.swing.text.html.FormSubmitEvent;
import javax.swing.text.html.HTML;

import iap.TransportType;
import static iap.TransportType.OPEN_APPLICATION;
import static iap.TransportType.PERFORM_ACTION;

import com.inversoft.iap.client.IAPClientProperty;
import static com.inversoft.iap.client.IAPClientProperty.CURRENT_VIEW_URL;
import com.inversoft.iap.client.context.OptionsFrameContext;
import com.inversoft.iap.client.controllers.MessageManager;
import com.inversoft.iap.client.controllers.TransactionException;
import com.inversoft.iap.client.controllers.TransactionManager;
import com.inversoft.iap.client.view.frames.MainIAPClientFrame;
import com.inversoft.iap.client.view.frames.OptionsIAPClientFrame;
import com.inversoft.util.StringTools;


/**
 * The ActionListener object for the MainFrame
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public class MainFrameListener extends BaseIAPClientListener<MainIAPClientFrame> {

    private TransactionManager transactionManager;

    private MessageManager messageManager;

    public MainFrameListener(MainIAPClientFrame mainIAPClientFrame) {
        super(mainIAPClientFrame);
        transactionManager = mainIAPClientFrame.getContext().getTransactionManager();
        messageManager = mainIAPClientFrame.getContext().getMessageManager();
    }


    /**
     * {@inheritDoc}
     */
    public void actionPerformed(ActionEvent event) {
        String url = null;
        // start 'Open' button, URL text field, or the Home Button
        if (event.getSource() == getFrame().getUrlField()) {
            url = (String) getFrame().getUrlField().getModel().getSelectedItem();
            processUrl(url);
        } else if (event.getSource() == getFrame().getOpenButton()) {
            url = (String) getFrame().getUrlField().getModel().getSelectedItem();
            processUrl(url);
        } else if (event.getSource() == getFrame().getHomeButton()) {
            url = getFrame().getContext().getPropertyManager().get(IAPClientProperty.HOME_URL);
            getFrame().getUrlField().setModel(new DefaultComboBoxModel(new String[]{
                url}));
            processUrl(url);
        } else if (event.getSource() instanceof JMenuItem) {
            JMenuItem menuItem = (JMenuItem) event.getSource();
            // Process each menu item accordingly
            if (menuItem.getName().equals("Exit")) {
                System.exit(0);
            } else if (menuItem.getName().equals("Options")) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        new OptionsIAPClientFrame(new OptionsFrameContext(getFrame().getContext().getContainer(),
                                "IAPClient - Options")).setVisible(true);
                    }
                });
            }
        } else if (event.getSource() == getFrame().getStopButton()) {
            transactionManager.stopTransaction();
            transactionComplete("Action Cancelled", "Action Cancelled");
        }
    }

    /**
     * {@inheritDoc}
     */
    public void hyperlinkUpdate(HyperlinkEvent e) {
        if (e instanceof FormSubmitEvent) {
            FormSubmitEvent event = (FormSubmitEvent) e;
            // event.getData() is an ampersand (&) delimited list of
            // form field data.  This string gets concatenated
            // to the URL as the parameter list
            String formData = event.getData();
            // get the form element.  this is the parent of the parent of
            // of the <input type="submit"...>
            Element formElement = event.getSourceElement().getParentElement().getParentElement();
            // action attribute value in the form HTML tag.  In HTTP, this is
            // the URL to start the form submission.  In IAP, this is
            // the actionId submitted in the Perform Action Request
            String action = (String) formElement.getAttributes().getAttribute(HTML.Attribute.ACTION);
            String url = action + "&" + formData;
            processUrl(url);
        }
        // user clicked a link
        else if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED)  {
            URL url = e.getURL();
            getFrame().setUrlField(url.toString());
            processUrl(e.getURL().toString());
        }
        // user mouseover-ed a link
        else if (e.getEventType() == HyperlinkEvent.EventType.ENTERED) {
            getFrame().setStatusBar(e.getURL().toString());
        }
        // user mouse-offed a link
        else if (e.getEventType() == HyperlinkEvent.EventType.EXITED) {
            getFrame().setStatusBar("");
        }
    }

    /**
     * Processes a url String supplied from the UI.  This is either from the url address bar, a link or an action
     * from form based input
     *
     * @param urlString the URL string
     */
    private void processUrl(String urlString) {
        // check for null/empty string case
        if (StringTools.isEmpty(urlString)) {
            messageManager.displayInfoMsg("Invalid URL Specified");
        } else {
            try {
                final URL url = new URL(urlString);
                getFrame().setStatusBar("Loading " + getApplicationName(url) + "...");
                getFrame().startProgressBar();

                // runnable object sent to the Transaction
                final Runnable doTransaction = new Runnable() {
                    public void run() {
                        if (url.getProtocol().equals("http")) {
                            // limited support for HTTP. Once a connection to an HTTP URL is fired it can't be stopped
                            // mid process. Someday we'll make this more robust or just not support HTTP entirely
                            try {
                                getFrame().getViewPane().setPage(url);
                                transactionComplete(getApplicationName(url), "HTML Page Loaded");
                            } catch (IOException ioe) {
                                transactionComplete(getApplicationName(url), "Failed To Load: " + ioe.getMessage());
                                messageManager.displayInfoMsg("Unable to establish a connection to " + url.toString());
                            }
                        } else if (url.getProtocol().equals("iap")) {
                            try {
                                // check transaction type.  if 'actionId' and 'viewId' are
                                // present, then it's a PERFORM_ACTION transaction
                                TransportType type = OPEN_APPLICATION;
                                String urlQuery = url.getQuery();
                                if (urlQuery != null) {
                                    if (urlQuery.contains("actionId") && urlQuery.contains("viewId")) {
                                        type = PERFORM_ACTION;
                                    }
                                }
                                transactionManager.doTransaction(getFrame().getViewContext(), url, type);
                                getFrame().getViewPane().setText(getFrame().getViewContext().getTransactionContext().getViewCode());
                                getFrame().getViewContext().getPropertyManager().set(CURRENT_VIEW_URL, url.toString());
                                String applicationName = getFrame().getViewContext().getTransactionContext().getApplicationId();
                                if (StringTools.isEmpty(applicationName) || applicationName.equals("/")) {
                                    applicationName = "Default Application";
                                }
                                transactionComplete(applicationName, "Transaction Completed Successfully");
                            } catch (TransactionException ce) {
                                transactionComplete(getApplicationName(url), "Failed To Load: " + ce.getMessage());
                                messageManager.displayInfoMsg("Unable to establish a connection: " + ce.getMessage());
                            }
                        }
                    }
                };

                // invoke the transaction thread in the EventDispatcher to prevent locking of the GUI
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        new TransactionManager.TransactionThread(doTransaction).start();
                    }
                });
            } catch (MalformedURLException mue) {
                messageManager.displayInfoMsg("Invalid URL Specified: " + urlString);
            }
        }
    }

    /**
     * Sets the gui state after a transaction completes
     *
     * @param applicationName the name of the application
     * @param statusText the status text
     */
    private void transactionComplete(String applicationName, String statusText) {
        getFrame().getOpenButton().setEnabled(true);
        getFrame().getStopButton().setEnabled(false);
        getFrame().setTabTitle(applicationName);
        getFrame().setStatusBar(statusText);
        getFrame().stopProgressBar();
    }

    /**
     * Gets the Sring portion of the URL that contains the application to load.
     * This is obtained through the URL.getFile()
     *
     * @param url the URL object
     * @return the name of the application being accessed
     */
    private String getApplicationName(URL url) {
        String applicationName = url.getFile().replaceFirst("/", "");
        if (StringTools.isEmpty(applicationName)) {
            applicationName = "Default Application";
        }
        return applicationName;
    }
}