/**
 * Copyright 2003, 2004, 2005 Inversoft, Inc.  All rights reserved.
 */
package com.inversoft.iap.client.context;

import com.inversoft.iap.IAPTransaction;
import com.inversoft.iap.client.IAPClientContainer;

/**
 *
 *
 * @author James Humphrey
 * @since IAP 1.0
 * @version 1.0
 */

public abstract class BaseTransactionContext extends BaseIAPClientContext implements TransactionContext {

    /**
     * The model object representing the Transaction pertaining to this context
     */
    private IAPTransaction iapTransaction;

    protected BaseTransactionContext(IAPClientContainer container, IAPTransaction iapTransaction) {
        super(container);
        this.iapTransaction = iapTransaction;
    }

    /**
     * {@inheritDoc}
     */
    public IAPTransaction getIAPTransaction() {
        return iapTransaction;
    }
}
